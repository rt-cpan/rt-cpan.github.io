#!/usr/bin/perl 

use strict;
use warnings;

use XML::Compile::Schema;
use XML::Compile::Util qw/pack_type/;


my $invoice_shema_file= "Invoice.xsd";

# get schema from file
my $schema = XML::Compile::Schema->new($invoice_shema_file);
$schema->importDefinitions( 'xmldsig-core-schema.xsd');

my $elem = pack_type 'http://www.ebinterface.at/schema/2p0/', 'Invoice';
my $read = $schema->compile(READER => $elem);
my $data = $read->( "invoiceExample.xml");

exit;

