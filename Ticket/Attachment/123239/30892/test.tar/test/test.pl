#!/usr/bin/env perl

use Verilog::Netlist;

my $nl = new Verilog::Netlist ();
for (@ARGV) {
  $nl->read_file (filename=>$_, is_libcell=>0);
}
