use strict;
use warnings;

use Log::Handler;

my $l1 = Log::Handler->new;
my $l2 = Log::Handler->new;
my $l3 = Log::Handler->new;
my $l4 = Log::Handler->new;

my ($file1, $file2, $file3, $file4) = qw/t1.txt t2.txt t3.txt t4.txt/;

my $opts = {
    mode     => 'append',
    maxlevel => 'debug',
    minlevel => 'warning',
    newline  => 1,

    message_layout => '%D %T %L %m %r %S',
};


$opts->{filename}=$file1;
$l1->add(file => $opts);

$opts->{filename}=$file2;
$l2->add(file => $opts);

$opts->{filename}=$file3;
$opts->{minlevel} = 'crit';
$l3->add(file => $opts);

$opts->{filename}=$file4;
$opts->{minlevel} = 'emerg';
$opts->{maxlevel} = 'emerg';
$l4->add(file => $opts);


for  my $logger  ($l1, $l2, $l3, $l4) {
    $logger->warn('warn');
    $logger->crit('crit');
    $logger->emerg('emerg');
}