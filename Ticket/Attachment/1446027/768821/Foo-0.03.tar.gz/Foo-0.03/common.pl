sub get_version { '0.03' }
sub process { my $v = get_version(); s/__VERSION__/$v/g; }

1;
