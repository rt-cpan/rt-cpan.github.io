#!/usr/bin/perl
# 
#   Print all known zoneinfo abbreviations and GMT offsets 
#   in a format suitable for DateManip .
#   Arguments:
#   -v : verbose: print info on zones found in each file
#   -g : order by gmt offset, not zone abbreviation
#   -z : use only zoneinfo base directory (eg. 'right', 'posix', 'Etc').
#
use Getopt::Std;

%zones=();

$year = (localtime(time()))[5]+1900;

%opts = ();

getopts("vgz:",\%opts);

$verbose = exists($opts{v});
$byoffset= exists($opts{g});
$ziBase=exists($opts{z}) && (-e '/usr/share/zoneinfo/'.$opts{z}) ? '/'.$opts{z} : '';

sub zfile
{
    (( -d $_ ) || ( $_ =~ /Factory$/ ) || ( $_ =~ /.tab$/ )) && return; 
    $verbose && print STDERR $_,"\n";
    my $zoneFound=0;
    open(ZD, '/usr/sbin/zdump -v '.$_.'|') || die("Cannot get zone info for $_: $! $?");
    while ( <ZD> )
    {
	if ( /^\/usr\/share\/zoneinfo\/([^\s]+)\s+([^=]+)\s+\=\s+([^=]+)\s+([^\s]+)\s+(isdst=\d)\s+(gmtoff=[\-]?\d+)$/ && ( $4 ne 'page' )
	   )
	{
	    my ($n, $t1, $t2, $abbr, $dst, $gmt) = ( $1, $2, $3, $4, $5, $6 );
	    if ( ( $t2 =~ /$year$/ ) || ( ($zoneFound == 0) && ( $t2 =~ /2038$/ ) ) )
	    {		
		my $z = $abbr . ($gmt =~ /([\-]?\d+)$/)[0] ;
		$n=~s/^right\///;
		$n=~s/^posix\///;
		$verbose && print STDERR $z,' ', exists( $zones{$z}),"\n";
		$zoneFound = 1;
		if( ! exists( $zones{$z} ) )
		{
		    $zones{$z}[ ($dst =~ /(\d)$/)[0] ] = { n=>{$n=>1}, abbr => $abbr, gmtoff=>($gmt =~ /([\-]?\d+)$/)[0] }; 
		}else
		{
		     ${${@{ $zones{$z} } [ ($dst =~ /(\d)$/)[0] ]}{n}}{$n}=1;
		};
	    };
	};	
    };    
    close ZD;
}

# Using File::Find does not work for this purpose ! (hardlink duplicate removal) .
open( ZI, '/usr/bin/find /usr/share/zoneinfo'.$ziBase.'|' ) || die("Can't find zoneinfo");
while(<ZI>)
{
    $_ =~ s/\n$//;
    zfile($_);
};

foreach $z ( sort { $byoffset ? ($a=~/([\-]?\d+)$/)[0] <=> ($b=~/([\-]?\d+)$/)[0] : $a cmp $b }  keys %zones )
{
    if( @{$zones{$z}}[0] )
    {
	print( '"',"\L${@{$zones{$z}}[0]}{abbr}\E\t", 
	       sprintf( "%0.2d%0.2d", ${@{$zones{$z}}[0]}{gmtoff} / 3600, (${@{$zones{$z}}[0]}{gmtoff} % 3600)/60),
	       '".',"\t",'# ',join(" ", keys %{${@{$zones{$z}}[0]}{n}}),
	       "\n"
	      );
    };
    if( @{$zones{$z}}[1] )
    {
	print( '"',"\L${@{$zones{$z}}[1]}{abbr}\E\t", 
	       sprintf( "%0.2d%0.2d", ${@{$zones{$z}}[1]}{gmtoff} / 3600, (${@{$zones{$z}}[1]}{gmtoff} % 3600)/60),
	       '".',"\t",'# (DST) ',join(" ", keys %{${@{$zones{$z}}[1]}{n}}),
	       "\n"
	      );
    };
};
