package Foo::Role;
use Moose::Role;

1;

