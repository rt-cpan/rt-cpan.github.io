use feature 'say';

#=============
package Bar;
#=============
use Moose;

#=============
package Baz_1;
#=============
use Moose;
extends 'Bar';

#=============
package Baz_2;
#=============
use Foo;

#=============
package Baz_3;
#=============
use Foo;
extends 'Bar';

#=============
package Baz_4;
#=============
use Foo;
extends 'Bar';
with 'Foo::Role';


#=============
package main;
#=============

for (1..4) {
    my $class = "Baz_$_";
    say   "$class does Foo::Role - "
        . ($class->does('Foo::Role') ? 'Yes' : 'No')
}

