package Foo;

use Moose();
use Moose::Exporter;

Moose::Exporter->setup_import_methods(
    base_class_roles => ['Foo::Role'],
    also => 'Moose',
);

1
