#!/usr/bin/perl


  use MIME::Explode;

  my $explode = MIME::Explode->new(
    output_dir         => "tmp",
    #mkdir              => 0755,
    decode_subject     => 1,
    check_content_type => 1,
    content_types      => ["application/x-zip-compressed"],
    types_action       => "include"
  );

  

  my $fd=&parseaArgumentos();

  open(MAIL, "<$fd") or   die("Couldn't open file.mbox for reading: $!\n");
  open(OUTPUT, ">file.tmp") or die("Couldn't open file.tmp for writing: $!\n");
  my $headers = $explode->parse(\*MAIL, \*OUTPUT);
  print "Number of messages: ", $explode->nmsgs, "\n";
  #my $headers = $explode->parse(\*MAIL);
  close(OUTPUT);
  close(MAIL);

 
 
# ------------------- Fin ejecucion

 ##/
 # Captura los argumentos pasados al script, si no hay, devuelve 1
 # @param	void
 # @return	int - argumento pasado o bien el valor "1". Representa numero de dias del informe
 #/
 sub parseaArgumentos{
	return (@ARGV == 0 ? 1 : $ARGV[0]) ;
 }
