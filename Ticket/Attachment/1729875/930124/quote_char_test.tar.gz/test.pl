#!/usr/bin/perl

use strict;
use warnings;
no warnings 'once';

use utf8;
binmode(STDOUT,':utf8');

use Text::CSV;
use File::Spec;
use File::Basename;

my $basedir =  dirname(File::Spec->rel2abs(__FILE__));
# CSV field separator
my $csvsep = "\t";
# CSV output EOL
my $csveol = "\r\n";

my $csv = Text::CSV->new
	or die "Cannot use CSV: " . Text::CSV->error_diag();
$csv->auto_diag(1);
$csv->binary(1);
$csv->sep_char($csvsep);
$csv->column_names('date', 'sum', 'description');

sub input {
	my $name = $_[0];
	my $path = $basedir . "/" . $name . ".csv";

	open my $fh, "<:encoding(utf8)", $path or die $path . ": $!";
	$csv->eol($\);
	my $rows = $csv->getline_hr_all($fh, -1, 1);
	close $fh;

	if ((ref($rows) ne 'ARRAY') ||
		(keys (%{$rows->[0]}) != 3)) {
		die "inconsistent data in file $path\n";
	}

	print "input: <" . $rows->[0]{'date'} . "> <" . $rows->[0]{'sum'} .
	   "> <" . $rows->[0]{'description'} . ">\n";
}

sub output {
	my $name = $_[0];
	my $data = $_[1];
	my $path = $basedir . "/" . $name . ".csv";

	open my $fh, ">>:encoding(utf8)", $path or die $path . ": $!";
	$csv->eol($csveol);
	foreach my $row ( @$data )	{
		$csv->print_hr($fh, $row);
	}

	print "output is appended to $name.csv\n"; 

	close $fh;
}

my @data = (
  {
    "date" => '2017-05-26T16:03:38',
    "sum" => -29.43,
    "description" => 'test description 3'
  },
  {
    "date" => '2017-05-26T06:35:44',
    "sum" => -31.65,
    "description" => 'test description 4'
  },
);

#$csv->quote_char(undef);
input("data");

$csv->quote_char(undef);
output("data", \@data);
