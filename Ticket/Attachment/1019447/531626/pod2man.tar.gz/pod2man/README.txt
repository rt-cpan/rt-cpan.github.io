

latin1.pod    : Pod file, Latin-1 encoded.

latin1.1      : Wrong output.

latin1-cor.1  : Manually corrected output.



make clean
make
make install prefix=...
man latin1
man latin1-cor


Erwin Waterlander <waterlan@xs4all.nl>

