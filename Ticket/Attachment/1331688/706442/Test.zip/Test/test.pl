#!/usr/bin/env perl

use strict;
use warnings;
use Test::More;
use Test::Exception;

use Test::Schema;

my $db = Test::Schema->connect_do;
$db->storage->debug(0);

# use case is processing rows in batches
# Perhaps we call a url that accept multiple ids and return data for all those ids
# To minimise network calls we batch call on a resultset

$db->resultset('Stuff')->delete;
is($db->resultset('Stuff')->count, 0, "Cleared DB");

for my $i(1..10) { $db->resultset('Stuff')->create({id => $i}); }
is($db->resultset('Stuff')->count, 10, "Rows created");

# we must <process> in batches

my $BATCH_SIZE = 4;
my $rs = $db->resultset('Stuff')->search({},{ rows => $BATCH_SIZE, page => 1 });

for my $page(1..$rs->pager->last_page) {

	my $batch_rs = $rs->page($page);
	lives_ok( sub { $batch_rs->update_multiple }, 'Method call successful on resultset #'.${page});
}
