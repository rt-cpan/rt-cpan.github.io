package Test::Schema::ResultSet::Stuff;

use strict;
use warnings;
use base 'DBIx::Class::ResultSet';

sub update_multiple {
	my($self) = @_;

	my @ids = $self->get_column('id')->all;

	# <code> perhaps we call a url to verify our data

	# so now let's update our rows with what was returned
	for my $id(@ids) {

		# grab the row, we want to update
		my $row = $self->find($id);

		# did we get a row?
		$row->id;
	}
	
}

1;