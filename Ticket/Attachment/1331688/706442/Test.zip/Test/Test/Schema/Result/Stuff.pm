package Test::Schema::Result::Stuff;
use strict;
use warnings;
use base 'DBIx::Class::Core';

__PACKAGE__->table("stuff");
__PACKAGE__->add_columns("id", { data_type => "integer" }, );
__PACKAGE__->set_primary_key("id");

1;