package Test::Schema;
use strict;
use warnings;
use base 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces;

use File::Basename;
use Cwd 'abs_path';

my $here = dirname(abs_path(__FILE__));

my @dsn = (
	"DBI:SQLite:database=${here}/Test.db",
	undef,
	undef,
	{
	'AutoCommit' => 1,
	'sqlite_see_if_its_a_number' => 1,
	'RaiseError' => 1,
	'sqlite_unicode' => 1
	},
	{}
);
sub connect_do { shift->connect( @dsn ); }

1;