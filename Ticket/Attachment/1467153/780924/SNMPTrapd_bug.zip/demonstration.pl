#!/usr/local/bin/perl


use Net::SNMPTrapd;

my $snmptrapd = Net::SNMPTrapd->new();
if (! $snmptrapd) {
    printf "$0: Error creating Net::SNMPTrapd listener: %s", Net::SNMPTrapd->error;
    exit 1;
}
printf "Listening on %s:%i\n", $snmptrapd->server->sockhost, $snmptrapd->server->sockport;

while (1) {
    my $trap = $snmptrapd->get_trap();

    if (! defined($trap)) {
        die "Error in Net::SNMPTrapd: " . Net::SNMPTrapd->error;
    } elsif ($trap == 0) {
        next;
    }

    my $real_version = ($trap->version == 0) ? '1' : '2c';
    my $hex_trap_dump = $trap->datagram(1);
}


