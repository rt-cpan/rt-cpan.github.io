<?php
phpInfo();
?>