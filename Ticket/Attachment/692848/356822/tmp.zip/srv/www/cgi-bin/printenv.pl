## #!/usr/bin/perl
##
##  printenv -- demo CGI program which just prints its environment
##
use strict;
print "Content-type: text/html\n\n";
print "<HTML><BODY><H3>Environment variables</H3><UL>";
foreach (sort keys %ENV) {
    my $val = $ENV{$_};
    $val =~ s|\n|\\n|g;
    $val =~ s|"|\\"|g;
    print "<LI>$_ = \"${val}\"</LI>\n";
}
print "</UL></BODY></HTML>";