use strict;
use warnings;

package main {
    use ConcreteClass;

    my $concrete_object = ConcreteClass->new();

    $concrete_object->say_something();
}
