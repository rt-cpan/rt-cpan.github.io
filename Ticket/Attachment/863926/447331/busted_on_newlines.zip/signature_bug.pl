#!/db/perf/bin/perl -w

use not_busted;
use busted;


my $not_busted = not_busted->new();
my $busted     =     busted->new();

print "Not busted:\n"; STDOUT->flush();
$not_busted->one_arg("not busted");

print "Busted:\n"; STDOUT->flush();
$busted->one_arg("busted");
