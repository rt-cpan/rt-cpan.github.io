package not_busted;

use Moose;
use MooseX::Method::Signatures;

method one_arg ($one) {
    print "one_arg($one)\n";
}

method two_args ($one, $two) {
    print "two_args($one, $two)\n";
}

1;
