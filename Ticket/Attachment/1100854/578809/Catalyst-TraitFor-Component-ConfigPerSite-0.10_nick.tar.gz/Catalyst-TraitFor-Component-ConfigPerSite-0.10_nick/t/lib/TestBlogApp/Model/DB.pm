package TestBlogApp::Model::DB;
use strict;

use Moose;


extends 'Catalyst::Model::DBIC::Schema';
with qw(Catalyst::TraitFor::Model::DBIC::ConfigPerSite);

__PACKAGE__->config(
    traits       => 'SchemaProxy',
);

around 'COMPONENT' => sub {
    my ($orig, $class, $app, $args) = @_;
    my $self = $class->$orig($app, $args);
    $self->schema->source('User')->column_info('filename')->{fs_column_path} = $self->schema->file_path();
    return $self;
};

1;
