package TestBlogApp::Schema;

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces;

use Moose;
has 'file_path' => (
    is => 'rw',
);


1;

