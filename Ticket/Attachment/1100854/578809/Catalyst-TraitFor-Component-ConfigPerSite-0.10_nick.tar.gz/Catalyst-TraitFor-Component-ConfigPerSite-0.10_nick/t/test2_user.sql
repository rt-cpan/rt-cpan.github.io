PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE user (
        id                              int                             not null ,
        username                varchar(50)             not null,
        password                varchar(200)    not null,
        email                   varchar(200)    not null,

        firstname               varchar(50)             ,
        surname                 varchar(50)             ,

        display_name    varchar(100)    ,
        display_email   varchar(200)    ,

        website                 varchar(200)    ,
        profile_pic             varchar(100)    ,
        bio                             text                    ,

        location                varchar(100)    ,
        postcode                varchar(10)             ,

        admin_notes             text                    ,

        active                  int                             not null default 1,
		filename				varchar(200)    ,

        primary key ( id )
);
INSERT INTO "user" VALUES(1,'testuser','password','test@test','Test','User','Emmanuel Goldstein',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'testfile2.txt');
COMMIT;
