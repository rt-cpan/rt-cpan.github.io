package stub;

use strict;
use threads;

use TextControlDemo;

my $form = TextControlDemo->new;

my $displayLoop = threads->create(\&displayLoop, $form)->detach;

$form->MainLoop;

sub displayLoop {
	my $form = shift;
	
	my $counter = 0;
	while (1) {
		$form->printText("Test: $counter"."\n");
		$counter++;
	}
}
