package TextControlDemo;

use warnings;
use strict;
use bytes;
use English;
use Wx qw(wxDefaultPosition wxDefaultSize wxTE_READONLY wxTE_MULTILINE wxVERTICAL wxGROW);
my $textCtrl;
use base 'Wx::App';

sub OnInit {
	my $form = shift;
	
	my $frame = Wx::Frame->new(undef, -1, "GUI Test", wxDefaultPosition, wxDefaultSize);
	
	# Bottom right section
	my $panel = Wx::Panel->new($frame, -1, wxDefaultPosition, wxDefaultSize);
	my $box = Wx::StaticBox->new($panel, -1, "TextCtrl");
	my $sizer = Wx::StaticBoxSizer->new($box, wxVERTICAL);
	$textCtrl = Wx::TextCtrl->new($box, -1, "", wxDefaultPosition, wxDefaultSize, wxTE_READONLY | wxTE_MULTILINE);
	
	$sizer->Add($textCtrl, 1, wxGROW);
	$panel->SetAutoLayout(1);
	$panel->SetSizer($sizer);
	$sizer->Fit($panel);
	$sizer->SetSizeHints($panel);
	
	# Add windows to form for later modification
	$form->{frame} = $frame;
	$form->{box} = $box;
	$form->{sizer} = $sizer;
	$form->{textCtrl} = $textCtrl;
	
	# Maximize frame then display it
	$frame->Maximize(1);
	$frame->Show(1);
	
	return $form;
}

sub printText {
	my $form = shift;
	my $message = shift;
	$textCtrl->AppendText($message);
}

1;
