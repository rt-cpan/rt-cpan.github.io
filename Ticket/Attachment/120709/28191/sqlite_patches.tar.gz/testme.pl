
use strict;

use DBI;

my $database_path = '/var/www/cgi-bin/cache/requests/00.sqlite.db';

system("ls /proc/$$/fd");

my $DATABASE_CONNECTION = DBI->connect
(
  "dbi:SQLite:dbname=${database_path}",'','',
  {
   AutoCommit => 1,
   PrintError =>1
  }
);

print "AFTER CONNECTION\n";

system("ls /proc/$$/fd");

$DATABASE_CONNECTION->prepare('select * from requests');

print "AFTER PREPARE\n";

system("ls /proc/$$/fd");

$DATABASE_CONNECTION->disconnect;

print "AFTER DISCONNECT\n";

system("ls /proc/$$/fd");
