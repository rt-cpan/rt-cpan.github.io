package TestFixture;
use base 'Test::Class';
use base 'Fixture';
use Class::C3;


1;
