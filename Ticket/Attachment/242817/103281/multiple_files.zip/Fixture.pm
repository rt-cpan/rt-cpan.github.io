package Fixture;
use base 'Class::Accessor';
use Class::C3;
sub update_all { 
	# This is the only one that gets called.
	# It should be called third.
	print __PACKAGE__ . " called for update_all\n\n"; 
}

1;