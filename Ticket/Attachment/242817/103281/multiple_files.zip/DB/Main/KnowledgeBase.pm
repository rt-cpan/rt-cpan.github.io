package DB::Main::KnowledgeBase;
use strict;
use warnings;
use base qw/ DBIx::Class /;

__PACKAGE__->load_components(qw/ ResultSetManager InflateColumn::DateTime PK::Auto::MySQL Core /);

__PACKAGE__->table('knowledgebase');
__PACKAGE__->add_columns(qw/ id name /);

1;
