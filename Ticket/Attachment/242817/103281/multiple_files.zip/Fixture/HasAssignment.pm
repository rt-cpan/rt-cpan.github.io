package Fixture::HasAssignment;
use base 'Fixture::HasKBSet';
use Class::C3;

1;
