package Fixture::HasStudent;
use base 'Fixture::HasKBSet';
use Class::C3;

1;