package Fixture::HasSubmission;
use base 'Fixture::HasAssignmentInstance';
use base 'Fixture::HasStudent';
use Class::C3;

INIT {
	print STDERR "ISA FOR HasSubmission: ".(join ', ', @ISA)."\n";
}

1;

