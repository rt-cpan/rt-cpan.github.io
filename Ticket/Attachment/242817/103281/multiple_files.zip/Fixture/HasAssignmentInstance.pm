package Fixture::HasAssignmentInstance;
use base 'Fixture::HasAssignment';
use base 'Fixture::HasStudent';
use Class::C3;

1;
