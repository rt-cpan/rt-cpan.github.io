#!/usr/bin/perl -w
use strict;
use Convert::ASN1;
use Convert::ASN1 qw(:io);
use Convert::ASN1 qw(:debug);
use Data::Dumper;

my $file=$ARGV[0];
die "I need a file!!!"  unless($file);

my $asn_rules_file="./tap3.asn";
my $asn = Convert::ASN1->new;

### load the rules
if($asn->prepare_file($asn_rules_file)) {
  print "rules ok\n";
#  print Dumper($asn)."\n";
  }
else {
  print "rules error:".$asn->error."\n";
  exit 1;
  }

### open data file
open FILE,"$file" or die "open $file failed:$!";

my $buffer;
my $offset=0;
my $old=0;
my $ret;

### read and parse data
while(1) {
  $ret=asn_read(*FILE,$buffer,$offset);
  if(!(defined($ret))) {
    printf STDERR $asn->error."\n";
    exit 0;
    }
  elsif ($ret==-1) {
    $offset=length($buffer)+1;
    next;
    }    
  else {
    printf STDERR "size:$ret\n";
    asn_hexdump($buffer);
    asn_dump($buffer);
    my $a=$asn->decode($buffer);
    if(!defined($a)) {
      print $asn->error."\n";
      }
    else {
      print Dumper($a)."\n";
      }
    undef $buffer;
    }
  }

