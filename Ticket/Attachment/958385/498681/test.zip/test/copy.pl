#!/usr/bin/perl

use strict;
use warnings;

use Carp qw(croak);
use English qw(-no_match_vars $OS_ERROR $INPUT_RECORD_SEPARATOR);
use File::Slurp 9999.19 qw(read_file write_file);

my $filename_from = 'iso-8859-2.txt';
my $filename_to1  = 'utf-8.txt';
my $filename_to2  = 'slurp_out.txt';

{
    open my $read_fh, '< :encoding(iso-8859-2)', $filename_from
        or croak $OS_ERROR;
    my $content = do {
        local $INPUT_RECORD_SEPARATOR = ();
        <$read_fh>;
    };
    () = close $read_fh;

    open my $write_fh, '> :encoding(utf-8)', $filename_to1
        or croak $OS_ERROR;
    print {$write_fh} $content
        or croak $OS_ERROR;
    close $write_fh
        or croak $OS_ERROR;
}

{
    my $content = read_file( $filename_from, binmode => ':encoding(iso-8859-2)' );
    write_file( $filename_to2, { binmode => ':encoding(utf-8)' }, $content );
}
