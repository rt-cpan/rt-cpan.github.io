#!/usr/bin/perl
use Net::FTP;

#  Test script for the following Net::FTP problems
#      - if the FTP data connection could not be opened, the NET::Ftp quits with an error
#              Can't use an undefined value as a symbol reference at .../Net/FTP/dataconn.pm line 54
#              Search google "Net/FTP/dataconn.pm line 54" for more reports about this
#
#      - when opening the data connection, NET::Ftp ignores the timeout value
#
#  Create a "www.ftpwt.com" account, and run the script like 10-15 times - sometimes the
#  data connection could not be opened, and after a long delay the script with quit with
#  the dataconn.pm line 54 error message
#
#  Also you can use the account below, it is still valid.
#

open (MYFILE, '>ftptest.txt');
print MYFILE "Test file";
close (MYFILE); 


    $ftp = Net::FTP->new("www.ftpwt.com", Debug => 1, Timeout => 10)
      or die "Cannot connect to some.host.name: $@";
    $ftp->login("perlftptest",'password')
      or die "Cannot login ", $ftp->message;
    $ftp->cwd("/")
      or die "Cannot change working directory ", $ftp->message;
    
    $ftp->put("ftptest.txt")
      or die "put failed ", $ftp->message;

    $ftp->get("ftptest.txt","ftpget.txt")
      or die "get failed ", $ftp->message;
    $ftp->quit;

