package Broken;
use App::Cmd::Setup -app;
1;
