package Broken::Command::say;
use Broken -command;
use 5.014;
sub opt_spec {}
sub validate_args {}
sub execute {
    say "foo bar";
    say "baz bat";
}
1;
