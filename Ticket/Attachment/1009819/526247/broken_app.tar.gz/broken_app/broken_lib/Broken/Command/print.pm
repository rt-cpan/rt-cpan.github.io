package Broken::Command::print;
use Broken -command;
sub opt_spec {}
sub validate_args {}
sub execute {
    print "foo bar\n";
    print "baz bat\n";
}
1;
