CREATE TABLE foo (
    id integer primary key not null,
    name varchar(30)
);
INSERT INTO foo VALUES(1, 'bar');
