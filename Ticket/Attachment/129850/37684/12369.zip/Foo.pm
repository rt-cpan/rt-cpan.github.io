package Foo;

use base 'Class::DBI';
use Class::DBI::Plugin::AbstractCount 0.04;
use Class::DBI::AbstractSearch 0.05;
use Class::DBI::Plugin::Pager 0.55;

__PACKAGE__->set_db('Main', 'dbi:SQLite2:dbname=foo.db');
__PACKAGE__->columns(Primary => qw/id/);

1;
