#!/usr/bin/perl

use strict;
use Foo;

my $class = Foo->retrieve(1);

my $pager = $class->pager;
$pager->per_page(10);
$pager->page(1);

# you're forced to set a where clause even if returning all data...
#$pager->where( { 1 => 1 } );
my $objects = [ $pager->search_where ];

print 'ok';
