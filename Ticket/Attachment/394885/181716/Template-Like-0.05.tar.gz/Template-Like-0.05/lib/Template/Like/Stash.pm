package Template::Like::Stash;

use strict;
use Data::Dumper;
my $DEBUG = 0;

sub new {
  my $class = shift;
  my $args  = shift || {};
  
  return bless $args, $class;
}

sub set {
  my $self = shift;
  my $key  = shift;
  my $val  = shift;

  warn 'stash set self ',Dumper $self if $DEBUG;
  warn 'stash set key ', Dumper $key  if $DEBUG;
  warn 'stash set val ', Dumper $val  if $DEBUG;

  if (@_) {
    return $_[0]->{ $key } = $val;
  }
  $self->{ $key } = $val;
  return ;
}

sub update {
  my $self = shift;
  my $vars = shift;
  @{ $self }{ keys %{ $vars } } = values %{ $vars };
}

sub clone {
  bless { %{ $_[0] } }, 'Template::Like::Stash';
}

sub get {
  my $self = shift;
  my $key  = shift;
  my $ret  = $self->{$key};

  warn 'stash get self ',Dumper $self if $DEBUG;
  warn 'stash get key ', Dumper $key  if $DEBUG;
  warn 'stash get ret ', Dumper $ret  if $DEBUG;
    
  if ( $key=~/([^\.]+)\.(.*)/ ) {
    return $self->next( $self->{$1}, $2, @_ );
  }
  
  # execute code ref.
  if ( UNIVERSAL::isa($ret, 'CODE') ) {
    return $ret->( @_ );
  }

  return $ret;
}

sub next {
  my $self = shift;
  my $val  = shift;
  my $key  = shift;

  warn 'stash next self ',Dumper $self if $DEBUG;
  warn 'stash next key ', Dumper $key  if $DEBUG;
  warn 'stash next val ', Dumper $val  if $DEBUG;

  #load the module
  require $self->{USE} if $self->{USE};

  my $module = $self->{PLUGIN_MODULE};
  if ( $module->can($key) ) {
    $val = $module->$key( @_ );
  }
  
  elsif ( UNIVERSAL::isa($val, "HASH") && exists $val->{$key} ) {
    $val = $val->{$key};
  }
  
  elsif ( UNIVERSAL::isa($val, 'ARRAY') && $key=~/^\d+$/ ) {
    $val = $val->[$key];
  }
  
  elsif ( Template::Like::VMethods->can($key, $val) ) {
    $val = Template::Like::VMethods->exec($key, $val, @_);
  }
  
  else {
    return undef;
  }
  
  # execute code ref.
  if ( UNIVERSAL::isa($val, 'CODE') ) {
    return $val->();
  }
  
  return $val;
}

1;
