use strict;
use warnings;

package TestSchema;

use parent 'DBIx::Class::Schema';

__PACKAGE__->load_classes;

1;
