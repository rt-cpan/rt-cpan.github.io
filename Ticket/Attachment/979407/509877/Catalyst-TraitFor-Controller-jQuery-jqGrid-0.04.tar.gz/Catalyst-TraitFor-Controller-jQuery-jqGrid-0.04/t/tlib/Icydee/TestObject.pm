package Icydee::TestObject;

use Moose;
use namespace::autoclean;

with 'Catalyst::TraitFor::Controller::jQuery::jqGrid';

1;
