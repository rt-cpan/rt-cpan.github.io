package My_App::Tests;

use strict;
use warnings;
use utf8;
use Mojo::Base 'Mojolicious::Controller';

sub form1 {
# print first form

	my $self = shift;
}

sub form1_insert_redis {
# insert value from first form into Redis

	my $self = shift;
	
	my $redis = MojoX::Redis->new(server => '127.0.0.1:6379', encoding=>'UTF-8');
	$redis->hset('111', 'first', $self->param('first'));
	$redis->quit;
	
	$self->redirect_to('http://127.0.0.1:3000/form2');
}

sub form2 {
# print second form

	my $self = shift;
}

sub form2_insert_redis {
# insert value from second form into Redis

	my $self = shift;

	my $redis = MojoX::Redis->new(server => '127.0.0.1:6379', encoding=>'UTF-8');
	$redis->hset('111', 'second', $self->param('second'));
	$redis->quit;
	
	$self->redirect_to('http://127.0.0.1:3000/form3');
}

sub form3 {
# print third form

	my $self = shift;
}

sub form3_insert_redis {
# nsert value from third form into Redis

	my $self = shift;
	
	my $redis = MojoX::Redis->new(server => '127.0.0.1:6379', encoding=>'UTF-8');
	$redis->hset('111', 'third', $self->param('third'));
	$redis->quit;

	$self->redirect_to('http://127.0.0.1:3000/report');
}

sub report {
# print data from Redis

	my $self = shift;

	my $data_out1 = '';
	my $data_out2 = '';
	my $data_out3 = '';
	
	my $redis = MojoX::Redis->new(server => '127.0.0.1:6379', encoding=>'UTF-8');
	$redis = $redis->ioloop(Mojo::IOLoop->new);
	
	$redis->hmget('111', 'first', 'second', 'third' => sub {
		my ($redis, $res) = @_;

		$data_out1 = $res->[0];
		$data_out2 = $res->[1];
		$data_out3 = $res->[2];

		$redis->stop;
		});
		
	$redis->start;

	$self->stash(
		first_field => $data_out1->[0],
		second_field => $data_out2->[0],
		third_field => $data_out3->[0]);

	$redis->quit;
}

1;
