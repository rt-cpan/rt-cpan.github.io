package My_App;

use strict;
use warnings;
use utf8;
use Mojo::Base 'Mojolicious';
use MojoX::Redis;

sub startup {
	my $self = shift;

	my $r = $self->routes;

	$r->route('/')->to('tests#form1');
	$r->route('/form1')->via('get')->to('tests#form1');
	$r->route('/form1')->via('post')->to('tests#form1_insert_redis');
	$r->route('/form2')->via('get')->to('tests#form2');
	$r->route('/form2')->via('post')->to('tests#form2_insert_redis');
	$r->route('/form3')->via('get')->to('tests#form3');
	$r->route('/form3')->via('post')->to('tests#form3_insert_redis');
	$r->route('/report')->via('get')->to('tests#report');

}

1;
