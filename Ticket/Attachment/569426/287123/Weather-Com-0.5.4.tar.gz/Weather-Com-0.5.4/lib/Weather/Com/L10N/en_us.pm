package Weather::Com::L10N::en_us;

use base 'Weather::Com::L10N';

# have a cvs driven version...
our $VERSION = sprintf "%d.%03d", q$Revision: 1.1 $ =~ /(\d+)/g;

%Lexicon = ( '_AUTO' => 1, );    

1;
