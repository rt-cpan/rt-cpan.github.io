# MidCOM Plucene Indexer Interface: Index Request
#
# $Id: IndexRequest.pm,v 1.3 2005/02/01 15:19:56 torben Exp $

package Midcom::Plucene::IndexRequest;

use strict;
use warnings;

use Midcom::Plucene::BaseRequest;
use Midcom::Plucene::DeleteRequest;
use Plucene::Document;
use Plucene::Document::Field;
use Plucene::Document::DateSerializer;


@Midcom::Plucene::IndexRequest::ISA = ('Midcom::Plucene::BaseRequest');


=head1 NAME

Midcom::Plucene::IndexRequest - Index request interface

=head1 SYNOPSIS

TBD

=head1 DESCRIPTION

This class serves as an interface between tha XML Comm driver, which creates
it, and the actual Plucene Backend.

Upon execution, it will add the document with all fields it currently holds 
to the index. It will create the Plucene::Document object on the fly while 
the fields are being added.

=head1 METHODS

TBD

=cut


#############
# Constructor
#
# Stores a reference to the XML Comm Driver.

sub new
{
	my $class = shift;
	my $self = $class->SUPER::new(@_);

	$self->type('index');
	$self->{_documentID} = undef;
	$self->{_document} = Plucene::Document->new();

	bless ($self, $class);
	return $self;
}

###########
# Accessors

sub documentID
{
	my $self = shift;
	if (@_) { $self->{_documentID} = shift; }
	return $self->{_documentID};
}


#####################
# Field adder methods

sub addDate
{
	my ($self, $name, $contents) = @_;
	$self->{_document}->add(Plucene::Document::Field->Keyword($name, freeze_date($self->mkDate($contents))));
}


sub addKeyword
{
	my ($self, $name, $contents) = @_;
	$self->{_document}->add(Plucene::Document::Field->Keyword($name, $contents));
}


sub addUnIndexed
{
	my ($self, $name, $contents) = @_;
	$self->{_document}->add(Plucene::Document::Field->UnIndexed($name, $contents));
}


sub addUnStored
{
	my ($self, $name, $contents) = @_;
	$self->{_document}->add(Plucene::Document::Field->UnStored($name, $contents));
}


sub addText
{
	my ($self, $name, $contents) = @_;
	$self->{_document}->add(Plucene::Document::Field->Text($name, $contents));
}


#################
# Execute Handler

# execute Plucene::Index::Reader $reader

sub execute
{
	my $self = shift;

	# First, try to delete the existing document
	
	my $delete_request = Midcom::Plucene::DeleteRequest->new($self->{_XMLComm});
	$delete_request->id($self->id());
	$delete_request->documentID($self->{_documentID});
	$delete_request->execute();

	# Add the document
	
	$self->addKeyword('__RI', $self->{_documentID});
	$self->{_processor}->indexWriter->add_document($self->{_document});
}


sub dump
{
	my $self = shift;
	$self->SUPER::dump();
	
	print "\tDocument ID: " . $self->{_documentID} . "\n";
	
	my @fields = $self->{_document}->fields();
	foreach my $field (@fields)
	{
		print "\tField " . $field->name . " [";
		if ($field->is_stored) { print "S"; }
		if ($field->is_indexed) { print "I"; }
		if ($field->is_tokenized) { print "T"; }
		if (length($field->string) > 25)
		{ 
			print "]: " . substr($field->string, 0, 25) . "...\n"; 
		}
		else
		{
			print "]: " . $field->string . "\n"; 
		}
	}
}


1;


