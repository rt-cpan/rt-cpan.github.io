# MidCOM Plucene Indexer Interface: Base Request Class
#
# $Id: BaseRequest.pm,v 1.3 2005/02/01 15:19:56 torben Exp $

package Midcom::Plucene::BaseRequest;

use strict;
use warnings;

use Time::Piece;

=head1 NAME

Midcom::Plucene::BaseRequest - Base request interface class

=head1 SYNOPSIS

TBD

=head1 DESCRIPTION

This class serves as an interface between tha XML Comm driver, which creates
it, and the actual Plucene Backend.

This is a base class used by the other request classes, collecting a few common
methods and data fields.

=head1 METHODS

TBD

=cut


#############
# Constructor
#
# Stores a reference to the XML Comm Driver.

sub new
{
	my $class = shift;
	my $self = {};

	$self->{_XMLComm} = shift;
	$self->{_processor} = $self->{_XMLComm}->processor;
	$self->{_id} = undef;
	$self->{_type} = undef;

	bless ($self, $class);
	return $self;
}

#########
# Helpers

# Parses an ISO-8601 (YYYY-MM-DDTHH:MM:SS) Timestamp to a Time::Piece

sub mkDate
{
	my ($self, $arg) = @_;
	if (UNIVERSAL::isa($arg, 'Time::Piece'))
	{
		return $arg; 
	}
	else
	{
		return Time::Piece->strptime($arg, "%Y-%m-%dT%H:%M:%S");
	}
}


###########
# Accessors

sub id
{
	my $self = shift;
	if (@_) { $self->{_id} = shift; }
	return $self->{_id};
}

sub type
{
	my $self = shift;
	if (@_) { $self->{_type} = shift; }
	return $self->{_type};
}


#################
# Execute Handler

sub execute { }


sub dump
{
	my $self = shift;
	print $self->{_type} . " REQUEST ID=" . $self->{_id} . "\n";
}


1;


