# MidCOM Plucene Indexer Interface: Base Request Class
#
# $Id: RequestProcessor.pm,v 1.4 2005/02/18 10:32:55 torben Exp $

package Midcom::Plucene::RequestProcessor;

use strict;
use warnings;

use Midcom::Indexer::XMLComm;
use Plucene::Analysis::SimpleAnalyzer;
use Plucene::Index::Reader;
use Plucene::Index::Writer;
use Plucene::QueryParser;
use Plucene::Search::IndexSearcher;

# Constructor
#
# Stores a reference to the XML Comm Driver.

sub new
{
	my $class = shift;
	my $self = {};

	$self->{_in} = shift;
	$self->{_out} = shift;
	$self->{_xmlComm} = Midcom::Indexer::XMLComm->new($self->{_in}, $self->{_out}, $self);

	$self->{_indexReader} = undef;
	$self->{_indexWriter} = undef;
	$self->{_queryParser} = undef;
	$self->{_indexSearcher} = undef;

	bless ($self, $class);
	return $self;
}


###########
# Accessors

sub indexReader
{
	my $self = shift;
	$self->CheckForIndex();
	if (! $self->{_indexReader})
	{
		$self->{_indexReader} = Plucene::Index::Reader->open($self->{_xmlComm}->indexName());
	}
	return $self->{_indexReader};
}

sub indexSearcher
{
	my $self = shift;
	$self->CheckForIndex();
	if (! $self->{_indexSearcher})
	{
		$self->{_indexSearcher} = Plucene::Search::IndexSearcher->new($self->indexReader());
	}
	return $self->{_indexSearcher};
}

sub indexWriter
{
	my $self = shift;
	$self->CheckForIndex();
	if (! $self->{_indexWriter})
	{
		$self->{_indexWriter} = Plucene::Index::Writer->new(
			$self->{_xmlComm}->indexName(),
			Plucene::Analysis::SimpleAnalyzer->new(),
			0
		);
	}
	return $self->{_indexWriter};
}

sub queryParser
{
	my $self = shift;
	if (! $self->{_queryParser})
	{
		$self->{_queryParser} = Plucene::QueryParser->new(
			{
				analyzer => Plucene::Analysis::SimpleAnalyzer->new(),
				default => 'content'
			}
		);
	}
	return $self->{_queryParser};
}


#################
# Execute Handler

sub Process 
{ 
	my $self = shift;
	
	$self->{_xmlComm}->ParseRequest();
}

sub close
{
	my $self = shift;
	if ($self->{_indexSearcher})
	{
		$self->{_indexSearcher}->close();
		$self->{_indexSearcher} = undef;
	}
	if ($self->{_indexReader})
	{
		$self->{_indexReader}->close();
		$self->{_indexReader} = undef;
	}
	if ($self->{_indexWriter})
	{
		$self->{_indexWriter}->optimize();
		$self->{_indexWriter} = undef;
	}
	if ($self->{_queryParser})
	{
		$self->{_queryParser} = undef;
	}
}

sub DropIndex
{
	my $self = shift;
	
	# Close all open handels, then recreate the index.
	#
	# Note, that this is not really protected against multiple simultaneous accesses.
	# You should avoid any indexing operation from other processes while dropping the
	# Index.
	
	$self->close();
	
	if (-e $self->{_xmlComm}->indexName())
	{
		system('rm -f ' . $self->{_xmlComm}->indexName() . '/*');
		rmdir($self->{_xmlComm}->indexName());
	}

	$self->CreateIndex();
	
}

sub CreateIndex
{
	my $self = shift;
	
	# Close all open handels first.
	$self->close();

	$self->{_indexWriter} = Plucene::Index::Writer->new(
		$self->{_xmlComm}->indexName(),
		Plucene::Analysis::SimpleAnalyzer->new(),
		1
	);
	
}


sub CheckForIndex
{
	my $self = shift;
	
	# Check if the index has already been created, if not, do it now:
	if (! -e $self->{_xmlComm}->indexName())
	{
		$self->CreateIndex();
	}
}


1;



