#!/usr/bin/perl
#
# Example, simple XMLShell indexer backend.
#
# Works in the scope of the current working directory.
#
# $Id: xmlshell.pl,v 1.1 2005/02/23 14:52:07 torben Exp $

use strict;
use warnings;

use open ':utf8', ':std';

use Midcom::Plucene::RequestProcessor;

my $proc = Midcom::Plucene::RequestProcessor->new(\*STDIN, \*STDOUT);

$proc->Process();
$proc->close();
