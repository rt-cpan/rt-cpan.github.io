use utf8;
package VRPipe::Persistent::Schema::Result::Pipeline;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

=head1 NAME

VRPipe::Persistent::Schema::Result::Pipeline

=cut

use strict;
use warnings;

use base 'DBIx::Class::Core';

=head1 TABLE: C<pipeline>

=cut

__PACKAGE__->table("pipeline");

=head1 ACCESSORS

=head2 id

  data_type: 'integer'
  is_auto_increment: 1
  is_nullable: 0

=head2 name

  data_type: 'varchar'
  is_nullable: 0
  size: 64

=head2 description

  data_type: 'text'
  is_nullable: 1

=head2 _num_steps

  data_type: 'smallint'
  default_value: 0
  is_nullable: 0

=cut

__PACKAGE__->add_columns(
  "id",
  { data_type => "integer", is_auto_increment => 1, is_nullable => 0 },
  "name",
  { data_type => "varchar", is_nullable => 0, size => 64 },
  "description",
  { data_type => "text", is_nullable => 1 },
  "_num_steps",
  { data_type => "smallint", default_value => 0, is_nullable => 0 },
);

=head1 PRIMARY KEY

=over 4

=item * L</id>

=back

=cut

__PACKAGE__->set_primary_key("id");

=head1 RELATIONS

=head2 pipelinesetups

Type: has_many

Related object: L<VRPipe::Persistent::Schema::Result::Pipelinesetup>

=cut

__PACKAGE__->has_many(
  "pipelinesetups",
  "VRPipe::Persistent::Schema::Result::Pipelinesetup",
  { "foreign.pipeline" => "self.id" },
  { cascade_copy => 0, cascade_delete => 0 },
);

# Created by DBIx::Class::Schema::Loader v0.07025 @ 2012-07-19 11:03:33
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:uwT7RLRqdCLcoAIhc0J86w


# You can replace this text with custom code or comments, and it will be preserved on regeneration
1;
