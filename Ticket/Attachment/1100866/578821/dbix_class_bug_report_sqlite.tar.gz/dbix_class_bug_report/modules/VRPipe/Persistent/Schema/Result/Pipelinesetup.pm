use utf8;
package VRPipe::Persistent::Schema::Result::Pipelinesetup;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

=head1 NAME

VRPipe::Persistent::Schema::Result::Pipelinesetup

=cut

use strict;
use warnings;

use base 'DBIx::Class::Core';

=head1 TABLE: C<pipelinesetup>

=cut

__PACKAGE__->table("pipelinesetup");

=head1 ACCESSORS

=head2 user

  data_type: 'varchar'
  default_value: 'vrpipe'
  is_nullable: 0
  size: 64

=head2 id

  data_type: 'integer'
  is_auto_increment: 1
  is_nullable: 0

=head2 pipeline

  data_type: 'integer'
  is_foreign_key: 1
  is_nullable: 0

=head2 name

  data_type: 'varchar'
  is_nullable: 0
  size: 64

=head2 active

  data_type: 'tinyint'
  default_value: 1
  is_nullable: 0

=head2 description

  data_type: 'text'
  is_nullable: 1

=head2 options

  data_type: 'text'
  is_nullable: 1

=head2 output_root

  data_type: 'text'
  is_nullable: 0

=head2 datasource

  data_type: 'integer'
  is_foreign_key: 1
  is_nullable: 0

=cut

__PACKAGE__->add_columns(
  "user",
  {
    data_type => "varchar",
    default_value => "vrpipe",
    is_nullable => 0,
    size => 64,
  },
  "id",
  { data_type => "integer", is_auto_increment => 1, is_nullable => 0 },
  "pipeline",
  { data_type => "integer", is_foreign_key => 1, is_nullable => 0 },
  "name",
  { data_type => "varchar", is_nullable => 0, size => 64 },
  "active",
  { data_type => "tinyint", default_value => 1, is_nullable => 0 },
  "description",
  { data_type => "text", is_nullable => 1 },
  "options",
  { data_type => "text", is_nullable => 1 },
  "output_root",
  { data_type => "text", is_nullable => 0 },
  "datasource",
  { data_type => "integer", is_foreign_key => 1, is_nullable => 0 },
);

=head1 PRIMARY KEY

=over 4

=item * L</id>

=back

=cut

__PACKAGE__->set_primary_key("id");

=head1 RELATIONS

=head2 dataelementstates

Type: has_many

Related object: L<VRPipe::Persistent::Schema::Result::Dataelementstate>

=cut

__PACKAGE__->has_many(
  "dataelementstates",
  "VRPipe::Persistent::Schema::Result::Dataelementstate",
  { "foreign.pipelinesetup" => "self.id" },
  { cascade_copy => 0, cascade_delete => 0 },
);

=head2 datasource

Type: belongs_to

Related object: L<VRPipe::Persistent::Schema::Result::Datasource>

=cut

__PACKAGE__->belongs_to(
  "datasource",
  "VRPipe::Persistent::Schema::Result::Datasource",
  { id => "datasource" },
  { is_deferrable => 1, on_delete => "CASCADE", on_update => "CASCADE" },
);

=head2 pipeline

Type: belongs_to

Related object: L<VRPipe::Persistent::Schema::Result::Pipeline>

=cut

__PACKAGE__->belongs_to(
  "pipeline",
  "VRPipe::Persistent::Schema::Result::Pipeline",
  { id => "pipeline" },
  { is_deferrable => 1, on_delete => "CASCADE", on_update => "CASCADE" },
);

# Created by DBIx::Class::Schema::Loader v0.07025 @ 2012-07-19 11:03:33
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:0IxsT9Bs4vjYeqDg0v0EsQ


# You can replace this text with custom code or comments, and it will be preserved on regeneration
1;
