use utf8;
package VRPipe::Persistent::Schema::Result::Datasource;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

=head1 NAME

VRPipe::Persistent::Schema::Result::Datasource

=cut

use strict;
use warnings;

use base 'DBIx::Class::Core';

=head1 TABLE: C<datasource>

=cut

__PACKAGE__->table("datasource");

=head1 ACCESSORS

=head2 id

  data_type: 'integer'
  is_auto_increment: 1
  is_nullable: 0

=head2 type

  data_type: 'varchar'
  is_nullable: 0
  size: 64

=head2 _changed_marker

  data_type: 'varchar'
  is_nullable: 1
  size: 255

=head2 source

  data_type: 'text'
  is_nullable: 0

=head2 options

  data_type: 'text'
  is_nullable: 1

=head2 _lock

  data_type: 'datetime'
  datetime_undef_if_invalid: 1
  is_nullable: 1

=head2 method

  data_type: 'varchar'
  is_nullable: 0
  size: 64

=cut

__PACKAGE__->add_columns(
  "id",
  { data_type => "integer", is_auto_increment => 1, is_nullable => 0 },
  "type",
  { data_type => "varchar", is_nullable => 0, size => 64 },
  "_changed_marker",
  { data_type => "varchar", is_nullable => 1, size => 255 },
  "source",
  { data_type => "text", is_nullable => 0 },
  "options",
  { data_type => "text", is_nullable => 1 },
  "_lock",
  {
    data_type => "datetime",
    datetime_undef_if_invalid => 1,
    is_nullable => 1,
  },
  "method",
  { data_type => "varchar", is_nullable => 0, size => 64 },
);

=head1 PRIMARY KEY

=over 4

=item * L</id>

=back

=cut

__PACKAGE__->set_primary_key("id");

=head1 RELATIONS

=head2 dataelements

Type: has_many

Related object: L<VRPipe::Persistent::Schema::Result::Dataelement>

=cut

__PACKAGE__->has_many(
  "dataelements",
  "VRPipe::Persistent::Schema::Result::Dataelement",
  { "foreign.datasource" => "self.id" },
  { cascade_copy => 0, cascade_delete => 0 },
);

=head2 pipelinesetups

Type: has_many

Related object: L<VRPipe::Persistent::Schema::Result::Pipelinesetup>

=cut

__PACKAGE__->has_many(
  "pipelinesetups",
  "VRPipe::Persistent::Schema::Result::Pipelinesetup",
  { "foreign.datasource" => "self.id" },
  { cascade_copy => 0, cascade_delete => 0 },
);


# Created by DBIx::Class::Schema::Loader v0.07025 @ 2012-07-19 11:03:33
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:hqvexXkW1V1GDQhAVXIJaw


# You can replace this text with custom code or comments, and it will be preserved on regeneration
1;
