package TestAppChainedFail::Controller::Foo::Bar;

use strict;
use warnings;

use base qw/TestAppChainedFail::Controller::Foo/;

sub baz : Chained('foo') CaptureArgs(0) { }

sub qux : Chained('baz') Args(0) { }

1;