package TestAppChainedFail::Controller::Foo;

use strict;
use warnings;

use base qw/Catalyst::Controller/;

sub foo : Chained('/') CaptureArgs(0) { }

sub bar : Chained('baz') Args(0) { }

1;