use strict;
use warnings;

package UsesTwig::Constant;

sub new($$$$) {
	my ($class, $value, $ltol, $utol) = @_;
	my $this = {};
	no warnings qw(numeric uninitialized);
	my $tmp = eval "0 + $value";
	$this->{_value} = $@ ? 'n/a' : $tmp;	# if value non-numeric, will resolve as 'n/a'
	$this->{_ltol} = 0 + $ltol;	# if value missing or non-numeric, will resolve as 0
	$this->{_utol} = 0 + $utol;	# if value missing or non-numeric, will resolve as 0;
	bless $this, $class;
}

sub trim {
	my $val = shift;
	$val =~ s/^\s+//;
	$val =~ s/\s+$//;
	return $val;
}

sub value {
	my ($this, $tol) = @_;
	defined $tol or $tol = '';
	no warnings qw(numeric);
	my $val = eval "0 + $this->{_value}";
	$@ and return 'n/a';
	$tol =~ /ltol/ and return $val + $this->{_ltol};
	$tol =~ /utol/ and return $val + $this->{_utol};
	return trim $val;
}

package UsesTwig;

use XML::Twig::XPath;

# generates bug
sub jointTypeStartHandler {
	my ($twig, $node) = @_;
	$twig->ignore if $node->att('generation') eq "old";
}

sub new($$) {
	my ($class, $geomFileName) = @_;
	my $this = {};
	$this->{_constants} = {};
	$this->{_joints} = [];	# array of (joint-name (joint sizes ...))
	my $jointSizes = [];

	my $jointTypeHandler = sub {
		my ($twig, $jointTypeNode) = @_;
		push @{$this->{_joints}}, [$jointTypeNode->att("name"), $jointSizes];
		$jointSizes = [];
		$twig->purge;
	};
	my $jointSizeHandler = sub {
		my ($twig, $jointSizeNode) = @_;
		push @$jointSizes, $jointSizeNode->att("name");
	};
	my $jointComponentHandler = sub {
		my ($twig, $jointComponentNode) = @_;
		#print STDERR "<@{[$jointComponentNode->tag]} name='@{[$jointComponentNode->att('name')]}' ...>\n";
		my $jointSizeNode = $jointComponentNode->parent(qr/JointSize/);
		#print STDERR "<@{[$jointSizeNode->tag]} name='@{[$jointSizeNode->att('name')]}' ...>\n";
		my $jointTypeNode = $jointSizeNode->parent(qr/JointType/);
		my $jointType = $jointTypeNode->att("name");
		#print STDERR "<@{[$jointTypeNode->tag]} name='$jointType' ...>\n";
		my $jointName = $jointType . $jointSizeNode->att("name");

		my $assignConst = sub {
			my ($constName) = @_;
			my ($node) = $jointComponentNode->findnodes("Const[\@name='$constName']");
			$node or do {warn "Failed to find <Const name='$constName' .../> for $jointName"; return;};
			defined $this->{_constants}->{$jointName}
				or $this->{_constants}->{$jointName} = {};
			$this->{_constants}->{$jointName}->{$constName} = 
				new UsesTwig::Constant $node->att('value'), $node->att('LTol'), $node->att('UTol');
		};
		my $jointComponentNameAttr = $jointComponentNode->att("name");

		if ($jointComponentNameAttr eq "shaft") {
			&$assignConst("RecessDiameter");
		} elsif ($jointComponentNameAttr eq "outerRace") {
			unless ($jointType =~ /^(VL|DO)/) {
				&$assignConst("ChamferGaugeDia");
				&$assignConst("ChamferAngle");
				&$assignConst("ChamferGaugeLength");
				&$assignConst("BearingAbuttmentToEndOfBell");
				&$assignConst("JointCLtoBearingAbbuttmentMIN");
			}
			&$assignConst("BoreDia");
		}
		return 1;
	};
	my $twig = XML::Twig::XPath->new(
		twig_roots => { 
			'JointComponent[@name="shaft"]' => \&$jointComponentHandler,
			'JointComponent[@name="outerRace"]' => \&$jointComponentHandler,
			'JointType/JointSize' => \&$jointSizeHandler,	
			'JointType' => \&$jointTypeHandler,	
		},
		start_tag_handlers => {
			'JointType' => \&jointTypeStartHandler
		}
	);
	$twig->parsefile($geomFileName);
	$twig->purge;
	bless $this, $class;
}

sub get() {
	my ($this, $jName, $jSize, $constName, $tol) = @_;
	my $const = $this->{_constants}->{$jName . $jSize}->{$constName};
	return (defined $const and defined $const->value) ? $const->value($tol) : 'n/a';
}

1;
