                   Description of Directory Contents
                   ---------------------------------

These directories contain the manuals, IVP programs, and binary modules
for the "U.S. Postal Service Four-State Customer Barcode Encoder"
Version 1, Release 1, Modification Level 0 (USPS4CB V1R1M0).

These files are for Windows NT/2000/XP.

The other supported platforms are:

AIX (IBM RS/6000)
Linux (IBM RS/6000)
Linux (Intel)
MVS (OS/390, z/OS)
OS/400 (AS/400,iSeries)
VSE (IBM mainframe)

The directories and files on the disk are as follows:
/WindowsZIP   Name of the directory to Identify Windows-C & Java environment
README        Text file description of the directory contents
  /V1R1M0     Windows-C-Java Version 1, Release 1, and Modification 0
      /IVP
         civp.c               Installation Verification Program for C
      /Modules                Directory for modules
         /C                   Directory for C
            libusps4cb.a      Lib file for linking C programs to usps4cb.dll
            usps4cb.dll       MS Windows dll encoder file
         /Java                Directory for Java files
            USPS4CB.java      Sample Java program
            IVP.java          Installation Verification Programs for Java
            usps4cb.dll       MS Windows dll encoder file
      /UserGuide              Directory for User Guide
         /pdf
            userguide.Windows for C & Java.pdf   pdf version of User Guide
         /Word
            userguide.Windows for C & Java.doc   MS Word version of User Guide

README - This flat text "read me" file.

\V1R1M0\UserGuide\pdf
This directory contains:
"User Guide for the Four-State Customer Barcode Encoder for Windows C and Java"
in Adobe 5.0 PDF format.

\V1R1M0\UserGuide\Word
This directory contains:
"User Guide for the Four-State Customer Barcode Encoder for Windows C and Java"
in Microsoft Word format.

\V1R1M0\IVP
This directory contains:
Installation Verification Program (IVP) for C.

\V1R1M0\Modules\C
This directory contains:
The USPS4CB encoding load module, in the form of a gcc-compiled dll module that
can be linked with your calling program.  A corresponding "lib" file is included
for linking a C program to the dll.

\V1R1M0\Modules\Java
This directory contains the USPS4CB encoding module callable from Java.  In fact, it
is identical to the dll callable from C, since the dll has two entry points, one for
Java, and on for C.  There are also two Java source programs, one as a sample
calling program, and one as an Installation Verification Program (IVP) that runs
11 test cases.

Please consult the User Guide for Windows C and Java for advice on using these files.



