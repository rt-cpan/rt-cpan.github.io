import java.util.*;
import java.io.*;

/**
 *@author     The Powell Group
 *@created    January 06, 2006
 *
 *            This class is designed for use by a java program to load
 *            and call the USPS 4-state-barcode encoder available as a
 *            compiled and linked module 'usps4cb.so'.
 *
 *            A java program would use USPS4CB as follows:
 *
 *            USPS4CB usps = new USPS4CB();                   define USPS4CB
 *            usps.setTrack( UPPSTrackNo );            set the tracking code
 *            usps.setRoute( USPSRouteNo );             set the routing code
 *            sr = usps.getBarCode();   obtain the resulting 4-state-barcode
 *
 *
 *            You can run this program standalone; it has one
 *            self-contained test-case and it displays the result values to
 *            the console as shown here:
 *
 *            USPS4CB usps = new USPS4CB();
 *            usps.setTrack("01234567094987654321");
 *            usps.setRoute("01234567891");
 *            String result = usps.getBarCode();
 *
 *            The above code sequence uses 'usps4cb.so' as the default
 *            executable, shared object, residing in the same directory
 *            as the compiled USPS4CB java class.
 *
 *            Alternative a setLibrary( String ) method is provided to
 *            allow specific setting of the library should it be named
 *            differenty than usps4cb.so and/or reside on a separate
 *            directory.
 *
 *            The String parameter must have an absolute path followed
 *            by the library name. The example above is equivalent to:
 *
 *            USPS4CB usps = new USPS4CB();                   define USPS4CB
 *            usps.setLibrary("/home/aDirectory/usps4cb.so");   load library
 *            usps.setTrack( UPPSTrackNo );            set the tracking code
 *            usps.setRoute( USPSRouteNo );             set the routing code
 *            sr = usps.getBarCode();   obtain the resulting 4-state-barcode
 *
 */
class USPS4CB {

    private native synchronized String jencode(String track, String route);
    // defines 'jencode' as a 'native' function resolved at run-time
    private String track                  = null;
    private String route                  = null;
    private String library                = null;
    private final static String cLibrary  = "usps4cb";
    private boolean libLoaded             = false;

    public USPS4CB setLibrary(String p) {
        this.library = p;
        return this;
    }

    public USPS4CB setTrack(String t) {
        this.track = (t == null) ? "" : t;
        return this;
    }

    public String getTrack() {
        return this.track;
    }

    public USPS4CB setRoute(String r) {
        this.route = (r == null) ? "" : r;
        return this;
    }

    public String getRoute() {
        return this.route;
    }

    public String getBarCode() {
        if (!this.libLoaded) {
            if( this.library == null ) {
                String s1 = new File(".").getAbsolutePath();
                String library = cLibrary + librarySuffix();
                this.setLibrary( s1.substring(0,s1.length()-1) + library);
            }
            System.load( this.library );
            this.libLoaded = true;
        }
        return jencode(this.track, this.route);
    }

    private static String librarySuffix() {
        String s1 = System.getProperty( "os.name" );
        return s1.matches(".*[W|w]indows.*") ? ".dll" : ".so";
    }

    // This method is used only by 'main' below for use in java 1.3.1
    // It is not used by an expernal caller; note method is 'private'
    private static String[] parse( String s, String t ) {
        String[] r = { "", "" };
        int k = s.indexOf( t );
        if( k>0 ) {
            r[0] = s.substring( 0,k );
            r[1] = s.substring( k+t.length() );
        }
        return r;
    }

    public static void main(String[] args) {

        USPS4CB usps = new USPS4CB();

        usps.setTrack("01234567094987654321");
        usps.setRoute("01234567891");
        String result = usps.getBarCode();

        String[] parseResult = result.split("\\.");       // java 1.4+
        //String[] parseResult = parse( result,"." );     // java 1.3

        System.out.println("trackNo:\t"         + usps.getTrack());
        System.out.println("routeNo:\t"         + usps.getRoute());

        System.out.println("ReturnCode:\t"      + parseResult[0]);
        System.out.println("EncodedBarCode:\t"  + parseResult[1]);
    }
}

