
import java.util.*;
import java.io.*;
import java.text.SimpleDateFormat;

/**
 *@author     The Powell Group
 *@created    January 06, 2006
 *
 *            This program is an example of calling the USPS c-routine,
 *            libusps4cb.so, through the supplied USPS4CB.java class.
 *
 *            See the source for USPS4CB.java file which is included in
 *            the download.
 *
 *            The key lines are found below under the zTest() function.
 *            They are:
 *
 *            USPS4CB usps = new USPS4CB();                   define USPS4CB
 *            usps.setTrack( UPPSTrackNo );            set the tracking code
 *            usps.setRoute( USPSRouteNo );             set the routing code
 *            sr = usps.getBarCode();   obtain the resulting 4-state-barcode
 *
 *            The program runs 11-self-contained test cases and
 *            prints to the console the expected and obtained values.
 *
 *            Several command-line switches are provided:
 *
 *            -l n The [-l|-L] is used for focing a loop-n-times
 *                 This switch allows the IVP program to loop n-times
 *                 calling the 11-self-contained test cases or processing
 *                 the data from an input file; it defaults to -l 1
 *
 *            -f fileName switch reads the referenced file and
 *                 processes included test cases.
 *
 *            -p 1 is the default; for a value other than "1" it supresses
 *                 printing the results of a test-case, eg: -p 0
 *
 *            -e 1 is the default; for a value other than "1" it supresses
 *                 calling the usps-encoder, eg. -e 0
 *
 *            -h switch prints a program usage line.
 *
 */
class IVP {

    private static int zCheckInputFile(String fileName) {
        // determines file-type provided by '-f  fileName'
        String s1;
        long maxFileSize = 1000000L;
        int rType = 0;
        int i = 0;
        try {
            File ifile = new File(fileName);
            if( !ifile.exists() ) return 0;
            if( ifile.length() > maxFileSize ) { rType += 10; }
            else {
                BufferedReader br = new BufferedReader(new FileReader(ifile));
                for (String in = br.readLine(); in != null && i < 5;
                                                in  = br.readLine(), i++) {
                    in = in.trim();
                    if (in.length() < 20) continue;
                    rType = (in.matches("^[ADFT]{65}.*")) ? 2 : 0;
                    rType = (in.matches("^TEST.*"))       ? 1 : rType;
                    if (rType > 0) break;
                }
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return rType;
    }

    private static void zReadTestCases2(List C, String fileName) {
        String[] entry   = null;
        String[] atr     = null;
        String doNotMail = "DO NOT MAIL!";
        int n = 0;
        try {
            File ifile = new File(fileName);
            BufferedReader br = new BufferedReader(new FileReader(ifile));
            for (String in = br.readLine(); in != null; in = br.readLine()) {
                in = in.trim();
                if (in.length() < 2) continue;
                if (in.matches("^[ADFT]{65}.*")) {
                    if (entry != null) {
                        for (int i = 0; i < entry.length; i++) {
                            C.add(entry[i]);
                        }
                    }
                    entry = new String[7];
                    entry[6] = in;
                    entry[0] = "" + ++n;
                    entry[5] = "00";
                    continue;
                }
                if (in.matches("^[0123456789]{20}.*")) {
                    if (in.indexOf("-") > 0) {
                        atr = in.split("-");
                        entry[3] = atr[0].trim();
                        entry[4] = atr[1].trim();
                    } else {
                        entry[3] = in.substring(0, 20);
                        entry[4] = in.substring(20);
                    }
                    continue;
                }
                if (in.matches(doNotMail)) {
                    entry[1] = doNotMail;
                } else {
                    entry[2] = (entry[2] == null) ? in : entry[2] + " | " + in;
                }
            }
        } catch (Exception e) { System.out.println(e.toString()); C.clear(); }

        if (entry != null) {
            for (int i = 0; i < entry.length; i++) C.add(entry[i]);
        }
    }

    private static void zReadTestCases1(List C, String fileName) {
        String s1;
        try {
            File ifile = new File(fileName);
            BufferedReader br = new BufferedReader(new FileReader(ifile));
            for (String in = br.readLine(); in != null; in = br.readLine()) {
                if (!in.matches("^\\*\\*\\*\\*\\*.*") && in.length() > 20) {
                    // ignre "****" and lines less than 20
                    s1 = in;
                    in = in.substring(19, in.length() - 1).trim();
                    // trim leading and trailing blanks
                    in = (in.length() == 0) ?
                         (s1.startsWith("Route") ? "" : " ") : in;
                    // if Route is Blanks fore ""
                    C.add(in);
                }
            }
        } catch (Exception e) {
            System.out.println(e.toString());
            C.clear();
        }
    }

    private static int zInit( Map M, String[] p) {
        M.put("-l", "1");   // loop n-times; defaults to 1
        M.put("-f", "" );   // input file
        M.put("-p", "1");   // printing; defaults to 1
        M.put("-e", "1");   // call encoder; defaults to 1
        int r = 0;
        boolean help = false;
        String hs = "\nUsage: java -cp . IVP [ [-f fileName] [-l n] ]\n";
        String k = "";
        for( int i=0;i<p.length;i+=2 ) {
            k = ( M.containsKey( p[i].toLowerCase() ) && p.length > i ) ?
                                                 p[i].toLowerCase() : "";
            if( M.containsKey( k ) ) M.put( k,p[i+1] );
            if( p[i].toLowerCase().equals("-h") ) help = true;
        }
        if( help ) {
            System.out.println( hs );
            r = -1;
        }
        return r;
    }

    private static boolean zValidate(String rs, String rc, String bc) {
        String[] sa = rs.split("\\.");
        boolean r = (sa.length < 2) ? false : true;
        if (!r) return r;
        r = rc.equals(sa[0]) ? bc.equals(sa[1]) : false;
        return r;
    }

    private static void zTest( USPS4CB usps, List C,boolean p, boolean e) {
        // USPS4CB is included separately; it is the interface to the c-rotine
        String sr;
        String[] sa;
        for (int i = 0; i < C.size(); i += 7) {
            if( !e ) continue;                      // skip calling the encoder
            if (p && i == 0) System.out.println( zLines( "-",90 ) );
            if( p ) {
                System.out.println("TestCase:    \t"  +  C.get(i).toString());
                System.out.println("Comment1:    \t"  +  C.get(i + 1).toString());
                System.out.println("Comment2:    \t"  +  C.get(i + 2).toString());
                System.out.println("TrackNo:     \t"  +  C.get(i + 3).toString());
                System.out.println("RouteNo:     \t"  +  C.get(i + 4).toString());
                System.out.println("Expected:    \t"  +  C.get(i + 5).toString() +
                                                "\t " +  C.get(i + 6).toString());
            }

            usps.setTrack(C.get(i + 3).toString());
            usps.setRoute(C.get(i + 4).toString());
            sr = usps.getBarCode();

            sa = sr.split("\\.");
            if( p ) {
                System.out.println("Result:      \t" + sa[0] + "\t " +
                                  ((sa.length > 1) ? sa[1] : " "));
                System.out.println("Verdict:     \t" +
                (zValidate(sr, C.get(i + 5).toString(), C.get(i + 6).toString()) ?
                                                               "SAME" : "DIFF"));
                System.out.println( zLines( "-",90 ) );
            }
        }
    }

    private static String zLines( String p, int n ) {
        StringBuffer sb = new StringBuffer();
        for(int i=0;i<n;i++) sb.append( p );
        return sb.toString();
    }

    private static String serverName() {
        StringBuffer sb  = new StringBuffer();
        try {
            java.net.InetAddress i  = java.net.InetAddress.getLocalHost();
            sb.append( i.getHostName() );
        } catch ( Exception e ) { e.printStackTrace();}
        return sb.toString();
    }

    private static String todayFormated( String dateFormat ) {
        java.util.Date currentDate  = new java.util.Date();
        SimpleDateFormat sdf        = new SimpleDateFormat( dateFormat );
        return sdf.format( currentDate );
    }

    private static String hostNameAndJava() {
        String tab = "\t";
        StringBuffer sb = new StringBuffer();
        sb.append(serverName()).append(tab);
        sb.append(System.getProperty("os.arch").replace(' ','.')).append(tab);
        sb.append(System.getProperty("os.name").replace(' ','.')).append(".");
        sb.append(System.getProperty("os.version").replace(' ','.')).append(tab);
        sb.append(System.getProperty("java.vendor").split("\\s+")[0]).append(".");
        sb.append(System.getProperty("java.version")).append(tab);
        return sb.toString();
    }

    public static void main(String[] args) {
        Map P = new TreeMap();
        if ( zInit( P,args) != 0 ) return;
        long startTime = System.currentTimeMillis();

        System.out.println( todayFormated( "yyyy.MMM.dd" ) );
        System.out.println( hostNameAndJava() + "\n" );

        boolean print   = P.get( "-p" ).toString().equals("1") ? true : false;
        boolean encoder = P.get( "-e" ).toString().equals("1") ? true : false;
        int loop = Integer.parseInt( P.get( "-l" ).toString() );

        String testFile = P.get( "-f" ).toString();

        List C = new ArrayList();
        int fileType = (testFile != null) ? zCheckInputFile(testFile) : 0;
        if (fileType > 0 && fileType < 3) {
            if (fileType == 1) zReadTestCases1(C, testFile);
            if (fileType == 2) zReadTestCases2(C, testFile);
        } else { zLoadTestCases(C); }

        USPS4CB usps = new USPS4CB();
        for(int i=0;i<loop && fileType < 3;i++) zTest(usps,C,print,encoder);
        System.out.println( "\nelapsedTime:\t" + (System.currentTimeMillis() - startTime) );
    }

    private static void zLoadTestCases(List Y) {
        Y.add("ivp001");
        Y.add("Valid Input:  20 digit Tracking Code, 11 digit Routing Code");
        Y.add("Valid Output: 65 character Bar Code String A,D,F,T");
        Y.add("53379777234994544928");
        Y.add("51135759461");
        Y.add("00");
        Y.add("DAFDTDAFFDFTDADTDDFTTFDTATATFFFDFTTFFFTFDDTDAAFATDFTFDFDTTTDTTFDA");

        Y.add("ivp002");
        Y.add("Valid Input:  20 digit Tracking Code, 11 digit Routing Code");
        Y.add("Valid Output: 65 character Bar Code String A,D,F,T");
        Y.add("53055494689272602879");
        Y.add("13765583689");
        Y.add("00");
        Y.add("AFDADAFTAFDTDFTFTFDAAFDDTAFDFDTTFADATAATAAAADDDFAAAAATDADAFADFTTT");

        Y.add("ivp003");
        Y.add("Valid Input:  20 digit Tracking Code, 11 digit Routing Code");
        Y.add("Valid Output: 65 character Bar Code String A,D,F,T");
        Y.add("40120111574675115924");
        Y.add("62176609110");
        Y.add("00");
        Y.add("DDAFFFDAFTFDFFAAATTTDDFFTFADDFAFTTDAAAAAADFTTFDTAFDDTDDADATDAFAFF");

        Y.add("ivp004");
        Y.add("Valid Input:  20 digit Tracking Code, 11 digit Routing Code");
        Y.add("Valid Output: 65 character Bar Code String A,D,F,T");
        Y.add("82205455868913559972");
        Y.add("54765515722");
        Y.add("00");
        Y.add("TTTADTFFADAFDTTFDTAADATFFFADFFTDDFFFATDADAATAAADDATFTAADFADTADADD");

        Y.add("ivp005");
        Y.add("Invalid Input: 2nd digit of Tracking Code is not 0 to 4");
        Y.add("Output: Should be error code 11");
        Y.add("57379777234994544928");
        Y.add("51135759461");
        Y.add("11");
        Y.add(" ");

        Y.add("ivp006");
        Y.add("Invalid Input: Routing Code must contain digits 0 to 9");
        Y.add("Output: Should be error code 13");
        Y.add("53055494689272602879");
        Y.add("137655B3689");
        Y.add("13");
        Y.add(" ");

        Y.add("ivp007");
        Y.add("Invalid Input: Tracking Code must contain digits 0 to 9");
        Y.add("Output: Should be error code 10");
        Y.add("4012X111574675115924");
        Y.add("62176609110");
        Y.add("10");
        Y.add(" ");

        Y.add("ivp008");
        Y.add("c-Self-Test 01: Tracking Code contains valid digits 0 to 9");
        Y.add("Output: Should be code 00");
        Y.add("01234567094987654321");
        Y.add("");
        Y.add("00");
        Y.add("ATTFATTDTTADTAATTDTDTATTDAFDDFADFDFTFFFFFTATFAAAATDFFTDAADFTFDTDT");

        Y.add("ivp009");
        Y.add("c-Self-Test 02: Track and Routing Codes contain valid digits 0 to 9");
        Y.add("Output: Should be code 00");
        Y.add("01234567094987654321");
        Y.add("01234");
        Y.add("00");
        Y.add("DTTAFADDTTFTDTFTFDTDDADADAFADFATDDFTAAAFDTTADFAAATDFDTDFADDDTDFFT");

        Y.add("ivp010");
        Y.add("c-Self-Test 03: Track and Routing Codes contain valid digits 0 to 9");
        Y.add("Output: Should be code 00");
        Y.add("01234567094987654321");
        Y.add("012345678");
        Y.add("00");
        Y.add("ADFTTAFDTTTTFATTADTAAATFTFTATDAAAFDDADATATDTDTTDFDTDATADADTDFFTFA");

        Y.add("ivp011");
        Y.add("c-Self-Test 04: Track and Routing Codes contain valid digits 0 to 9");
        Y.add("Output: Should be code 00");
        Y.add("01234567094987654321");
        Y.add("01234567891");
        Y.add("00");
        Y.add("AADTFFDFTDADTAADAATFDTDDAAADDTDTTDAFADADDDTFFFDDTTTADFAAADFTDAADA");
    }
}


