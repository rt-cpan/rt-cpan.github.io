#!/usr/bin/perl -w

# Usage:  see print_usage_and_die or run with -h option

# Written by J.D. Baldwin, November 2006
# Adapted from whereis.pl

# TODO list:
#

#### HOUSEKEEPING ####

use strict;

use XML::Simple;
use Spreadsheet::WriteExcel;
use Data::Dumper;
    
#### FUNCTIONS ####

# NONE

#### MAIN PROGRAM ####

my $ARGC = @ARGV;

if ( $ARGC != 1 )
{
    die "Usage:  $0 <xmlfile>\n";
}

my ( $infile ) = @ARGV;
chomp $infile;

if ( ! ( $infile =~ /\.xml$/ ) )
{
    die "Input file must be XML with .xml extension\n";
}

my $outfile = $infile;
$outfile =~ s/\.xml$/\.xls/;

die "File $infile is not readable:  $!" if ( ! -r $infile );

my $hashref = XMLin("$infile", forcearray => ['reference', 'compound'])
    or die "Cannot XMLin file $infile: $!";

my $workbook = Spreadsheet::WriteExcel->new("$outfile")
    or die "Cannot open $outfile: $!";

my $worksheet = $workbook->add_worksheet();

my $format = $workbook->add_format();

my $row = 0;

#print Dumper $hashref;

my $col = 0;

my $dests = '';

my @dst = @{$hashref->{'rule'}->{'reference'}};

my $d;

for $d (@dst)
{
    $dests .= "$d->{'Name'}\n";
}

$worksheet->write( $row++, $col, $dests, $format );

$workbook->close();
