package M3;

use strict;
use warnings;

sub bar {
    return;
}

1;

__END__

=head1 NAME M3 - has no method new

=head1 SUBROUTINES/METHODS

=head2 new

bla

=head2 bar

bla
