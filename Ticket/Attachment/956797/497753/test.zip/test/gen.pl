#!/usr/bin/perl

use strict;
use warnings;

require Pod::ProjectDocs;

my $pd = Pod::ProjectDocs->new(
    outroot => './doc',
    libroot => [qw( ./1/lib/ ./2/lib/ ./3/lib/ )],
    title   => 'test',
    desc    => 'test',
);
$pd->gen();
