package M1;

use strict;
use warnings;

use parent qw(M2);

sub foo {
    return;
}

1;

__END__

=head1 NAME M1 - has no method new

=head1 SUBROUTINES/METHODS

=head2 new

bla

=head2 foo

bla
