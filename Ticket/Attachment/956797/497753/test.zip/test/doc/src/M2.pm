package M2;

use strict;
use warnings;

sub new {
    return bless { m2 => undef }, shift;
}

1;

__END__

=head1 NAME M2 - has method new

=head1 SUBROUTINES/METHODS

=head2 new

bla
