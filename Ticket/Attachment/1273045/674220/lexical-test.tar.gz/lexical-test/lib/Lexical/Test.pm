package Lexical::Test;
use 5.018;
use warnings;

our $VERSION = '0.01';

use Devel::CallParser;
use XSLoader;
XSLoader::load(__PACKAGE__, $VERSION);

1;
