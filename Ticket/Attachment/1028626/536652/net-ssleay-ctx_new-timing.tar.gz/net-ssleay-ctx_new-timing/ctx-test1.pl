use threads;
use strict;
use warnings;

use Net::SSLeay;

my $start_time = time;

Net::SSLeay::randomize();
Net::SSLeay::load_error_strings();
Net::SSLeay::SSLeay_add_ssl_algorithms();

my $ctx = Net::SSLeay::CTX_new() or die "CTX_new failed";
Net::SSLeay::CTX_free($ctx);

print STDERR "Gonna start threads\n";
threads->new(\&do_check) for (1..50);
print STDERR "Waiting for all threads to finish\n";
do_sleep(50) while (scalar(threads->list(threads::running)) > 0);
print STDERR "Done!\n";

my $end_time = time;
print STDERR "Duration=", $end_time-$start_time, "\n";

exit(0);

sub do_sleep {
  my $miliseconds = shift;
  select(undef, undef, undef, $miliseconds/1000);
}

sub do_check {
  printf STDERR ("[thread:%04d] do_check started\n", threads->tid);
  
  my $c = Net::SSLeay::CTX_new() or die "CTX_new failed";
  Net::SSLeay::CTX_free($c);
  do_sleep(rand(2000));
    
  printf STDERR ("[thread:%04d] do_check finished\n", threads->tid);
  threads->detach();
}
