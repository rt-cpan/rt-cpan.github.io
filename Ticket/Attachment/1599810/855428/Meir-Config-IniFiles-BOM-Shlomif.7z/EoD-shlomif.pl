﻿
use strict;
use warnings;
use 5.018;
use utf8;

use File::BOM qw/open_bom/;
use Config::IniFiles;

binmode STDERR, ":encoding(UTF-8)";

our @interim_log;
# my $node_ini_fn  = "MEIR_2_params.ini";
my $node_ini_fn = shift(@ARGV);

my $node_ini_fh;
# open_bom() throws a fatal exception on error.
open_bom ($node_ini_fh, $node_ini_fn, ':encoding(utf-8)');

my $node_cfg = new Config::IniFiles( -file => $node_ini_fh) or do {
  my $err_message = join("\n", @Config::IniFiles::errors);
  die "Node INI file problems:\n$err_message\n";
};

my $node_root         = $node_cfg->val('general','node_root');
my $logDIRs_root      = $node_cfg->val('general','logDIRs_root');

say "Node root:\t$node_root\nLog DIR root:\t$logDIRs_root";

__END__
Console, WITH a BOM:
===================
D:\Meir\Temp\Config_IniFile>perl EoD.pl
Node INI file problems:
Line 1 in file GLOB(0x558030) is mal-formed:
        ∩╗┐[general]
2: parameter found outside a section

D:\Meir\Temp\Config_IniFile>

Console, WITHOUT a BOM:
======================
D:\Meir\Temp\Config_IniFile>perl EoD.pl
Node root:      D:/Meir
Log DIR root:   WorkLOGs

D:\Meir\Temp\Config_IniFile>
