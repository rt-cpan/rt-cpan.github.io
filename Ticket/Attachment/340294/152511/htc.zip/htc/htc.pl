use strict;
use warnings;

use HTML::Template::Compiled;

my $htc = HTML::Template::Compiled->new(
    path     => 'template/',
    filename => 'subdir/file.htc',
    tagstyle => [qw(-classic +asp)],
);

