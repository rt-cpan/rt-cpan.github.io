#!/usr/bin/perl -I .
require 5.001;
use strict;
use DBI;

MAIN:
{
    $|=1;

    print "Connected\n";
	my $connect_string = "dbi:ODBC:Driver={SQL Native Client};Server=dbserver;Database=perltest;Uid=sa;Pwd=plat6darf;";
    my $dbh = DBI->connect($connect_string, "","", {RaiseError=>1, PrintError=>0});
	my $sqlstmt = "SELECT AGEN_ID,  AGEN_AGENT_NAME FROM AGENTS ORDER BY AGEN_AGENT_NAME";
	my $sth = $dbh->prepare($sqlstmt);
	my $rc = $sth->execute;
	while (my($agent_id, $agent_name) = $sth->fetchrow_array) {
		print "$agent_id - $agent_name\n";
	}
    print "Finished...\n";
}