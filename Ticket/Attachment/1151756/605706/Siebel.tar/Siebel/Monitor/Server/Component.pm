package Siebel::Monitor::Server::Component;

use warnings;
use strict;
use XML::Rabbit;

has_xpath_value 'name'           => './@name';
has_xpath_value 'description'    => './@description';
has_xpath_value 'componentGroup' => './@ComponentGroup';
has_xpath_value 'OKStatus'       => './@OKStatus';
has_xpath_value 'criticality'    => './@criticality';

with 'Siebel::Srvrmgr::Daemon::Action::CheckComps::Component';

finalize_class();
