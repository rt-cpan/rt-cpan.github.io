package Siebel::Monitor::Config;
use XML::Rabbit::Root;

add_xpath_namespace 'ns1' => 'http://foobar.org';

has_xpath_value 'server' =>
  '/ns1:siebelMonitor/ns1:connection/ns1:siebelServer';
has_xpath_value 'gateway' =>
  '/ns1:siebelMonitor/ns1:connection/ns1:siebelGateway';
has_xpath_value 'enterprise'  => '/ns1:siebelMonitor/ns1:connection/ns1:siebelEnterprise';
has_xpath_value 'srvrmgrPath' => '/ns1:siebelMonitor/ns1:connection/ns1:srvrmgrPath';
has_xpath_value 'srvrmgrBin'  => '/ns1:siebelMonitor/ns1:connection/ns1:srvrmgrExec';
has_xpath_value 'user'        => '/ns1:siebelMonitor/ns1:connection/ns1:user';
has_xpath_value 'password'    => '/ns1:siebelMonitor/ns1:connection/ns1:password';

has_xpath_object_list 'servers' => '/ns1:siebelMonitor/ns1:servers/ns1:server' => 'Siebel::Monitor::Server';

finalize_class();
