package Siebel::Monitor::Server;

use warnings;
use strict;
use XML::Rabbit;

has_xpath_value 'name'             => './@name';
has_xpath_object_list 'components' => './ns1:components/ns1:component' =>
  'Siebel::Monitor::Server::Component';

finalize_class();
