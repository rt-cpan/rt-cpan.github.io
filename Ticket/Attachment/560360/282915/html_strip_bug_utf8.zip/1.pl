#!/usr/bin/perl

use strict;

use HTML::Strip;

use Encode ( 'encode', 'decode', 'is_utf8' );


my $fh = undef;
if( open( $fh, '<', '1.html' ) )
{
	my $data = '';
	binmode $fh, ':utf8';
	$data = join( '', <$fh> );
	close $fh;

	my $hs = HTML::Strip -> new();
	my $clean_text = $hs->parse( $data );
	$hs -> eof();


	print encode( 'UTF-8', $clean_text ), "\n";


} else
{
	die 'test file missing';
}

