use Mail::Sender;

# Create a message with two alternative parts.
# 1st - text/plain
# 2nd - html with inline image

eval {
	(new Mail::Sender)
	->OpenMultipart({
		smtp=> 'jenda.krynicky.cz',
		from => 'jan@krynicky.cz',
		To => 'jenda@krynicky.cz,Jan.Krynicky@tmp.com',
		subject => 'Mail::Sender.pm - test 3',
		debug => 'c:\temp\zkMailFlow.log',
		multipart => 'mixed',
	})
	->Part({ ctype => 'text/plain', disposition => 'NONE', msg => <<'*END*' })
A long
mail
message.
*END*
	->Part({ctype => 'multipart/alternative'})
		->Part({ctype => 'multipart/related'})
			->Part({ctype => 'text/html', disposition => 'NONE', msg => <<'*END*'})
<html><body><h1>A long</h1><p align=center>
mail
message.
<img src="cid:img1">
</p></body></html>
*END*
			->Attach({
				description => 'ed\'s jpg',
				ctype => 'image/jpeg',
				encoding => 'base64',
				disposition => "inline; filename=\"0518m_b.jpg\";\r\nContent-ID: <img1>",
				file => 'E:\pix\humor\0518m_b.jpg'
			})
		->EndPart("multipart/related")
	->EndPart("multipart/alternative")
	->Close();
} or print "Error sending mail: $Mail::Sender::Error\n";

