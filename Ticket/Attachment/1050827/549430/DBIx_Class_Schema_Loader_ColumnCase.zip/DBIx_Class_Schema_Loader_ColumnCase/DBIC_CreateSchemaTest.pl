use strict;
use warnings;
use DBI;
use DBIx::Class::Schema::Loader qw/ make_schema_at naming/;

#
# Testing Schema creation problems
#

my $user = 'eotg';
my $pwd = 'CMMS';
my $server = 'localhost';
my $port = '1433';
my $database = 'test';
my $dsn = get_dsn_ado($user, $pwd, $server, $port, $database);

# naming('v8');

make_schema_at(
      'Ep::Schema',
      { debug => 1,
        dump_directory => './lib',
#        dump_directory => '.',
		db_schema => 'dbo'
      },
      [ $dsn, $user, $pwd,
#         { loader_class => 'MyLoader' } # optionally
      ],
);


sub get_dsn_ado {
  my ($user, $pwd, $server, $port, $database) = @_;	
  my $dsn = "dbi:ADO:Provider=SQLNCLI10;Server=$server,$port;Database=$database;";
}
  
sub get_dbh_connection_ado {
	my ($user, $pwd, $server, $port, $database) = @_;	
	my $dsn = get_dsn_ado(@_);
 
  my $dbh = DBI->connect($dsn, $user, $pwd) or die $DBI::errstr;
	print "Connected\n" if ($dbh);
	
	return $dbh;
}

