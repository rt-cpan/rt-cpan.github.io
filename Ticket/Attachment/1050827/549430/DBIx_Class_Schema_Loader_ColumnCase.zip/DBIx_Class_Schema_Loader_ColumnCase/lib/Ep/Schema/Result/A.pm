package Ep::Schema::Result::A;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

use strict;
use warnings;

use base 'DBIx::Class::Core';


=head1 NAME

Ep::Schema::Result::A

=cut

__PACKAGE__->table("A");

=head1 ACCESSORS

=head2 id

  data_type: 'integer'
  is_auto_increment: 1
  is_nullable: 0

=head2 name

  data_type: 'varchar'
  is_nullable: 0
  size: 50

=head2 sqldate

  data_type: 'date'
  is_nullable: 1

=head2 utildate

  data_type: 'date'
  is_nullable: 1

=head2 sqldatetime

  data_type: 'datetime'
  is_nullable: 1

=cut

__PACKAGE__->add_columns(
  "id",
  { data_type => "integer", is_auto_increment => 1, is_nullable => 0 },
  "name",
  { data_type => "varchar", is_nullable => 0, size => 50 },
  "sqldate",
  { data_type => "date", is_nullable => 1 },
  "utildate",
  { data_type => "date", is_nullable => 1 },
  "sqldatetime",
  { data_type => "datetime", is_nullable => 1 },
);
__PACKAGE__->set_primary_key("id");


# Created by DBIx::Class::Schema::Loader v0.07010 @ 2012-03-16 10:14:37
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:TQboAdpHPIASDrMwgtgeog


# You can replace this text with custom code or comments, and it will be preserved on regeneration
1;
