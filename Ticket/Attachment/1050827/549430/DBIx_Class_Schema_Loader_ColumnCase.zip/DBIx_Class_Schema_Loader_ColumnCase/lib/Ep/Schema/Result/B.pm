package Ep::Schema::Result::B;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

use strict;
use warnings;

use base 'DBIx::Class::Core';


=head1 NAME

Ep::Schema::Result::B

=cut

__PACKAGE__->table("B");

=head1 ACCESSORS

=head2 b_id

  data_type: 'integer'
  is_nullable: 0

=head2 b

  data_type: 'nvarchar'
  is_nullable: 1
  size: 50

=cut

__PACKAGE__->add_columns(
  "b_id",
  { data_type => "integer", is_nullable => 0 },
  "b",
  { data_type => "nvarchar", is_nullable => 1, size => 50 },
);
__PACKAGE__->set_primary_key("b_id");


# Created by DBIx::Class::Schema::Loader v0.07010 @ 2012-03-16 10:10:34
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:1RHHYgW+ZPipi36V3xLZ3A


# You can replace this text with custom code or comments, and it will be preserved on regeneration
1;
