#!/usr/bin/perl

use Encode qw[];

sub show {
    my $t = shift;
    printf( "value: " . $t . "\n" );

    my $l = length( $t );
    printf( "length of $t is " . $l . "\n" );

    $i = 0;
    while ( $i < $l ) {
        printf "\\x{%.2x}" , ord( substr( $t , $i ) );
        $i++;
    }
    print "\n";
}

$a = "äöüéà";
show( $a );

$o = Encode::encode_utf8( $a );
show( $o );
