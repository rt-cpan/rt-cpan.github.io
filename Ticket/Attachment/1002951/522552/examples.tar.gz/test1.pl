#!/usr/bin/perl

$a = "äöüéà";
$l = length( $a );
printf( "length of \$a is " . $l . "\n" );

$i = 0;
while ( $i < $l ) {
    printf "\\x{%.2x}" , ord( substr( $a , $i ) );
    $i++;
}
print "\n";
