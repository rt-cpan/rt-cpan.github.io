package A;
use Class::C3;

1;

package B;
use Class::C3;

1;

package C;
use Class::C3;

1;

package D;
use base A;
use base B;
use base C;
use Class::C3;

1;

package E;
use base D;
use Class::C3;

1;

package F;
use base E;
use Class::C3;

1;

package G;
use base D;
use Class::C3;

1;

package H;
use base G;
use Class::C3;

1;

package I;
use base H;
use base F;
use Class::C3;

1;

package J;
use base F;
use Class::C3;

1;

package K;
use base J;
use base I;
use Class::C3;

1;
