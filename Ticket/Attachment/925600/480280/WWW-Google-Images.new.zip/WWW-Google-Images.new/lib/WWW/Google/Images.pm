# $Id$
package WWW::Google::Images;

=head1 NAME

WWW::Google::Images - Google Images Agent

=head1 VERSION

Version 0.6.5

=head1 DESCRIPTION

This module may be used search images on Google. Its interface is
heavily inspired from L<WWW::Google::Groups>.

=head1 SYNOPSIS

    use WWW::Google::Images;

    $agent = WWW::Google::Images->new(
        server => 'images.google.com',
        proxy  => 'my.proxy.server:port',
    );

    $result = $agent->search('flowers', limit => 10);

    while ($image = $result->next()) {
        $count++;
        print $image->content_url();
        print $image->context_url();
        print $image->save_content(base => 'image' . $count);
        print $image->save_context(base => 'page' . $count);
    }

=cut

use WWW::Mechanize;
use WWW::Google::Images::SearchResult;
use HTML::Parser;
use strict;
use warnings;
our $VERSION = '0.6.6';

=head1 Constructor

=head2 new(I<%args>)

Creates and returns a new C<WWW::Google::Images> object.

Optional parameters:

=over

=item server => I<$server>

use I<$server> as server.

=item proxy => I<$proxy>:I<$port>

use I<$proxy> as proxy on port I<$port>.

=back

=cut

sub new {
    my ($class, %arg) = @_;

    foreach my $key (qw(server proxy)){
        next unless $arg{$key};
        $arg{$key} = 'http://'.$arg{$key} if $arg{$key} !~ m,^\w+?://,o;
    }

    my $a = WWW::Mechanize->new(onwarn => undef, onerror => undef);
    $a->proxy(['http'], $arg{proxy}) if $arg{proxy};

    my $self = bless {
        _server => ($arg{server} || 'http://images.google.com/'),
        _proxy  => $arg{proxy},
        _agent  => $a,
    }, $class;

    return $self;
}

=head2 $agent->search(I<$query>, I<%args>);

Perform a search for I<$query>, and return a C<WWW::Google::Images::SearchResult> object.

Optional parameters:

=over

=item limit => I<$limit>

limit the maximum number of result returned to $limit.

=item min_width => I<$width>

limit the minimum width of result returned to $width pixels.

=item min_height => I<$height>

limit the minimum height of result returned to $height pixels.

=item min_size => I<$size>

limit the minimum size of result returned to $size ko.

=item max_width => I<$width>

limit the maximum width of result returned to $width pixels.

=item max_height => I<$height>

limit the maximum height of result returned to $height pixels.

=item max_size => I<$size>

limit the maximum size of result returned to $size ko.

=item ratio => I<$ratio>

limit the width/height ratio of result returned to $ratio (+/- tolerance).

=item ratio_delta => I<$ratio_delta>

set the tolerance limit for the ratio limit to $ratio_delta (default: 1.0).

=item regex => I<$regex>

limit the result returned to those whose filename matches case-sensitive
$regex regular expression.

=item iregex => I<$regex>

limit the result returned to those whose filename matches case-insensitive
$regex regular expression.

=item face|photo|clipart|lineart => 1

image type, same as in Google's advanced search

=item large|medium|icon => 1

image size, same as in Google's advanced search

=item color|gray => 1

image color, same as in Google's advanced search

=item nosafe|strict => 1

Google's search safety is moderate by default. You can turn on strict search, or
turn it completely off.

=item jpg|png|gif|bmp|svg => 1

image format, same as in Google's advanced search
    
=back

=cut

sub search {
    my ($self, $query, %arg) = @_;

    warn "No query given, aborting" and return unless $query;

    $arg{limit} = 10 unless defined $arg{limit};

    $self->{_agent}->get($self->{_server});

    my $refine = '';

    if ( $arg{format} ) {
        if ( $arg{format} =~  /^(jpg|png|gif|bmp|svg)$/ ) {
            $refine .= "ift:$arg{format},";
        }
        else {
            die "Unknown image format: $arg{format}\n";
        }
    }

    if ( $arg{large} ) {
        $refine .= 'isz:l,'
    }
    if ( $arg{medium} ) {
        $refine .= 'isz:m,'
    }
    if ( $arg{icon} ) {
        $refine .= 'isz:i,'
    }
    if ( $arg{face} ) {
        $refine .= 'itp:face,'
    }
    if ( $arg{photo} ) {
        $refine .= 'itp:photo,'
    }
    if ( $arg{clipart} ) {
        $refine .= 'itp:clipart,'
    }
    if ( $arg{lineart} ) {
        $refine .= 'itp:lineart,'
    }
    if ( $arg{color} ) {
        $refine .= 'ic:color,'
    }
    if ( $arg{gray} ) {
        $refine .= 'ic:gray,'
    }

    my $fields = {
        q => $query,
        tbs => 'isch:1,' . $refine,
    };
    if ($arg{nosafe}){
        $fields->{safe} = 'off';
    }
    if ($arg{strict}){
        $fields->{safe} = 'active';
    }
    
    $self->{_agent}->submit_form(
        form_number => 1,
        fields => $fields,
    );

    my @images;
    my $page = 1;

    LOOP: {
        do {
            push(@images, $self->_extract_images(($arg{limit} ? $arg{limit} - @images : 0), %arg));
            last if $arg{limit} && @images == $arg{limit};
        } while ($self->_next_page(++$page));
    }

    return WWW::Google::Images::SearchResult->new($self->{_agent}, @images);
}

sub _next_page {
    my ($self, $page) = @_;

    return $self->{_agent}->follow_link(text => $page)
}

sub _extract_images {
    my ($self, $limit, %arg) = @_;

    my @images;
    my @data;

    my @links = $self->{_agent}->find_all_links( url_regex => qr/imgurl/ );

    if (
        $arg{min_size}   ||
        $arg{max_size}   ||
        $arg{min_width}  || 
        $arg{max_width}  ||
        $arg{min_height} ||
        $arg{max_height} ||
        $arg{ratio}
    ) {
        my $parser = HTML::Parser->new();
        my $pattern = qr/
            ^
            (\d+) \s &times; \s (\d+)
            \s - \s (\d+)k
            (?:&nbsp; - &nbsp; \w*)?
            $
        /ox;
        my $callback = sub {
            my ($text) = @_;
            if ($text =~ $pattern) {
                push(@data, { width => $1, height => $2, size => $3 });
            }
        };
        $parser->handler(text => $callback, 'text');
        $parser->parse($self->{_agent}->content());
    }

    my ($upper, $lower);
    if ($arg{ratio}) {
        my $delta = $arg{ratio_delta} || 1.0;
        $lower = $arg{ratio} - $delta;
        $upper = $arg{ratio} + $delta;
    }

    for my $i (0 .. $#links) {
        next if $arg{min_size} && $data[$i]->{size} < $arg{min_size};
        next if $arg{max_size} && $data[$i]->{size} > $arg{max_size};
        next if $arg{min_width} && $data[$i]->{width} < $arg{min_width};
        next if $arg{max_width} && $data[$i]->{width} > $arg{max_width};
        next if $arg{min_height} && $data[$i]->{height} < $arg{min_height};
        next if $arg{max_height} && $data[$i]->{height} > $arg{max_height};
        if ($arg{ratio}) {
            my $ratio = $data[$i]->{width} / $data[$i]->{height};
            next if $ratio < $lower || $ratio > $upper;
        }
        $links[$i]->url() =~ /imgurl=([^&]+)&imgrefurl=([^&]+)/;
        my $content = $1;
        my $context = $2;
        next if $arg{regex} && $content !~ /$arg{regex}/;
        next if $arg{iregex} && $content !~ /$arg{iregex}/i;
        push(@images, { content => $content, context => $context});
        last if $limit && @images == $limit;
    }

    return @images;
}

=head1 Scripts

Two scripts come with WWW::Google::Images.

=over
    
=item fetch-google-images

Examples:

    cat query_list.txt | fetch-google-images [OPTIONS]
    echo tree | fetch-google-images --content --summary --limit 20

See the source for more options.

=item refined-image-search

Example:
    
    refined-image-search --query face \
                         --size medium \
                         --dir face \
                         --color gray \
                         --type face \
                         --safe strict \
                         --limit 50 \
                         --format svg \
                         --verbose

See
    
    refined-image-search --help

for more information.    

=back
    
=head1 SOURCE AVAILABILITY

This module is in Github:

    git://github.com/guillomovitch/WWW-Google-Images.git
    
=head1 COPYRIGHT AND LICENSE

Copyright (C) 2004-2006, INRIA.

This program is free software; you can redistribute it and/or modify it under the same terms as Perl itself.

=head1 AUTHOR

Guillaume Rousse <grousse@cpan.org>

=cut

1;
