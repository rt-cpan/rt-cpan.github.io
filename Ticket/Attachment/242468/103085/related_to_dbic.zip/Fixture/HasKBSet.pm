package Fixture::HasKBSet;
use base 'Fixture::HasKnowledgeBase';
use Class::C3;

1;