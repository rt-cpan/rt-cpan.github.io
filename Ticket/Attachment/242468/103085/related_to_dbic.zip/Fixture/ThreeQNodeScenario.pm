package Fixture::ThreeQNodeScenario;
use base 'Fixture::TwoQNodeScenario';
use Class::C3;

1;

