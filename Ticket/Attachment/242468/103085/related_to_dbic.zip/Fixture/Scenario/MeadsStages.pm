package Fixture::Scenario::MeadsStages;
use base 'Fixture::TwoQNodeScenario';
use base 'Fixture::HasEntry';
use Class::C3;
sub update_all { 
	# We'd expect this to be called first, but it isn't
	print __PACKAGE__ . " called for update_all\n\n"; 
	shift->next::method; 
}

1;

