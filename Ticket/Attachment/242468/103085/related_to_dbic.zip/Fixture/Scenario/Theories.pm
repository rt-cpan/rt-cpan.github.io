package Fixture::Scenario::Theories;
use base 'Fixture::ThreeQNodeScenario';
use base 'Fixture::Scenario::MeadsStages';
use Class::C3;

1;

