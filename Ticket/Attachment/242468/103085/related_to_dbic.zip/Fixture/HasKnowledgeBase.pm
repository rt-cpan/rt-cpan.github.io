package Fixture::HasKnowledgeBase;
use base 'Fixture';
use Class::C3;

BEGIN {
	use DB::Main;
}

1;
