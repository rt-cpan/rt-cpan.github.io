package Fixture::Scenario;
use base 'Fixture';
use Class::C3;

1;