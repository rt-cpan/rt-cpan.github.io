package Fixture::HasEntry;
use base 'Fixture::HasSubmission';
use base 'Fixture::OneQNodeScenario';
use Class::C3;

1;
