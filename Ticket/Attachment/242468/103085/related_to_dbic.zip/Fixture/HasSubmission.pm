package Fixture::HasSubmission;
use base 'Fixture::HasAssignmentInstance';
use base 'Fixture::HasStudent';
use Class::C3;

1;

