package Fixture::TwoQNodeScenario;
use base 'Fixture::OneQNodeScenario';
use Class::C3;

1;

