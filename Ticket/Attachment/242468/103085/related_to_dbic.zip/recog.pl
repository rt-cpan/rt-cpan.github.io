use Test::Recognition;

Class::C3::initialize();
my $obj = new Test::Recognition;
$obj->update_all;
