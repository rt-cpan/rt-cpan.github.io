package Test::Recognition;
use base 'TestFixture';
use base 'Fixture::Scenario::Theories';
use Class::C3;

1;
