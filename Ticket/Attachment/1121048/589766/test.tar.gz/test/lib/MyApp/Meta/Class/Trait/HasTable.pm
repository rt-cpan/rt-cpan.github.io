package MyApp::Meta::Class::Trait::HasTable;
use Moose::Role;
Moose::Util::meta_class_alias('HasTable');
 
has table => (
    is  => 'rw',
    isa => 'Str',
);
