# in lib/MyApp/User.pm
package MyApp::User;
use Moose -traits => 'HasTable';
 
__PACKAGE__->meta->table('User');
