#!/usr/bin/perl

use strict;
use warnings;

use XML::Compile::Schema;

my $schema = XML::Compile::Schema->new("test.xsd");
my $read = $schema->compile(READER => "{http://foo/bar}feed");
$read->("test.xml");

