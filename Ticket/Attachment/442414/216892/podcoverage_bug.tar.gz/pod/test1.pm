package test1;

=head2 myfunc

Does something

=cut
sub myfunc {
}

1;
