package test2;

sub myfunc {
}

1;
__END__
=head2 myfunc

Does something

=cut

