#!/bin/sh

cd /tmp

rm -rf src; rm -rf dst; mkdir src; mkdir dst
touch src/afile
echo; echo "****************************"
echo "Case 1: Copy file - will succeed"
./file_ncopy_fix.pl src dst

rm -rf src; rm -rf dst; mkdir src; mkdir dst
mkdir src/adir
touch src/adir/afile
touch src/adir/bfile
echo; echo "****************************"
echo "Case 2: Copy dir with files - will succeed"
./file_ncopy_fix.pl src dst

rm -rf src; rm -rf dst; mkdir src; mkdir dst
mkdir src/emptydir
echo; echo "****************************"
echo "Case 3: Copy empty dir - will succeed"
./file_ncopy_fix.pl src dst

rm -rf src; rm -rf dst; mkdir src; mkdir dst
mkdir src/adir
touch src/adir/afile
mkdir src/bdir
touch src/bdir/bfile
chmod -r-r-r src/bdir/bfile
echo; echo "****************************"
echo "Case 4: Copy dir where one file is not accessible - will properly report failure"
./file_ncopy_fix.pl src dst

rm -rf src
rm -rf dst