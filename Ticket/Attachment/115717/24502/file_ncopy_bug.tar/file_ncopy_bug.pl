#!/usr/bin/perl -w

# This is pared-down logic for recursive copy of directory trees
# from CPAN Perl module File::NCopy version 0.34
# It has 2 bugs, one of which obscures the other for all but the extreme case
# Find the bugs. Happy hunting! :-) [dmehra]

use strict;
use File::Copy;

my $from = shift;
my $to = shift;
my $res;

if (-f $from) { # file
    $res = File::Copy::copy($from, $to);
} elsif (-d $from) { # dir
    $res = _recurse_from_dir($from, $to);
} else {
    die "can't copy non-file, non-dir $from";
}

print ($res ? "\nSuccess \n" : "\nFailure \n");

print "\n Readdir $from : \n\n" . `ls -R $from`;
print "\n Readdir $to : \n\n" . `ls -R $to`;

sub _recurse_from_dir 
{
    my ($from_dir, $to_dir) = @_;

    opendir DIR, $from_dir or return 0;
    my @files = readdir DIR or return 0;
    closedir DIR;

    unless (-e $to_dir) {
	mkdir $to_dir, 0777 or return 0;
    }

    my $retval = 0;
    my $ret = 0;

    for (@files) {
	next if /^\.\.?$/;
	my $src = $from_dir."/".$_;
	my $dst = $to_dir."/".$_;
	if (-f $src) { # file
	    $ret = File::Copy::copy($src, $dst);
	}
	elsif (-d $src) { # dir
	    $ret = _recurse_from_dir($src, $dst);
	}
	else { # other - links are of no interest to us
	    print "can't deal with links - skipping $src \n";
	}
	$retval = $retval || $ret;
    }

    return $retval;
}
