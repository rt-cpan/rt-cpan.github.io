package Encode::entity;
our $VERSION = "1.0.0";
 
use Encode;
use XSLoader;
XSLoader::load(__PACKAGE__,$VERSION);

1;
__END__

=head1 NAME
 
Encode::Entity - New Encoding
 
=head1 SYNOPSIS

You got to fill this in!

=head1 SEE ALSO

L<Encode>

=cut
