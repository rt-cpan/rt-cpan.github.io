#!/usr/bin/perl
use warnings;
use strict;
use PDF::API2;

# Checking command line passed arguments

die "Bad usage.\n" unless @ARGV > 0;

# Setting command line passed arguments

my $opts = '';
$opts = shift if $ARGV[0] =~ /^-/;
my ($old_pdf,$new_pdf) = shift;
$old_pdf =~ /^(.+?)\.(?:pdf|PDF)$/;
$1 = "doc" unless defined $1;
$new_pdf = "$1-2up.pdf" unless defined $new_pdf;

# Opening source and new PDF

my $source = PDF::API2->open($old_pdf);
my $output = PDF::API2->new();

# Parameters definition

my @size = $source->openpage(2)->get_mediabox();
splice @size, 0, 2;
@size = reverse @size;
my $half = $size[0] / 2;
my $aspect = $size[1] / $size[0];
my $old_pages = $source->pages();
my $new_pages = $old_pages;
$new_pages += 4 - ($old_pages % 4)
  if $old_pages % 4;
my $blank_page = 'x';

# Preparing new PDF

$output->mediabox(@size);
my @sequence;

# Subroutines definition

sub sort_pages
{
  my $start = 1;
  my $end = $new_pages;
  
  for ($start..$end)
  {
    if ($_ % 4 == 2 or $_ % 4 == 3)
    {
      push @sequence, $start;
      $start++;
    }
    else
    {
      push @sequence, $end;
      $end--;
    }
  }
  
  $sequence[0] = $blank_page if $old_pages < $new_pages;
  $sequence[3] = $blank_page if $old_pages < $new_pages - 1;
  $sequence[4] = $blank_page if $old_pages < $new_pages - 2;
}

sub plot
{
  while (@sequence)
  {
    my @pair = splice @sequence, 0, 2;
    my $page = $output->page();
    if ($pair[0] ne $blank_page)
    {
      my $left_half = $output->importPageIntoForm($source,$pair[0]);
      $page->gfx()->formimage($left_half,0,0,$aspect);
    }
    if ($pair[1] ne $blank_page)
    {
      my $right_half = $output->importPageIntoForm($source,$pair[1]);
      $page->gfx()->formimage($right_half,$half,0,$aspect);
    }
  }
}

# Saving PDF or printing the sequence of pages

sort_pages();
if ($opts =~ /seq/)
{
  $" = ',';
  print "@sequence";
  exit;
}
plot();
$output->saveas($new_pdf);
