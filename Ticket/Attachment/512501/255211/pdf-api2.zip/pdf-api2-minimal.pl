#!/usr/bin/perl
use warnings;
use strict;
use PDF::API2;

my $pdf = shift @ARGV;
my $source = PDF::API2->open($pdf);
my $output = PDF::API2->new();
for (1..$source->pages())
{
  print "$_\n";
  my $halfpage = $output->importPageIntoForm($source,$_);
}
print "CHECK PASSED\n";
sleep(5);
