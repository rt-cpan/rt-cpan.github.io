I am having some trouble with the HTML::Diff.pm perl module.  After comparing
well for a short while, it starts reporting everything as changed between the
two inputs, even when that content is identical.

Package manifest:
   * 0_README.txt - This file

   * 0_TestIt.sh - Shell script to invoke the perl script, 1-TestCompare.pl,
     on the input files and produce the output and diagnostic files

   * 1-TestCompare.pl - The perl script that uses HTML::Diff.pm to compare two
     HTML files, add change markup, and produce a combined result.

   * 2-LeftInput.html - The left-hand (first) HTML data file to be compared

   * 3-RightInput.html - The right-hand (second) HTML data file to be compared

   * 4-Output.html - The combined output file with change markup

   * 5-DiagnosticInfo.txt - Text file produced by the 1-TestCompare.pl script
     to capture the exact output of HTML::Diff.pm and subsequent processing of
     it

   * 6a-Example.png - Screen snap of one place where the comparison goes off
     the rails.
        In the 5-DiagnosticInfo.txt file, Look at the entries for chunks
        numbered 26 and 34.  The HTML::Diff.pm is returning very different
        results for these two items.  For #26, it has nicely teased apart the
        sentences and reported only the one word as changed.  For #34, it
        returns the entire paragraph content from each side even though the
        first sentence is identical.

   * 6b-Example.png - Screen snap contrasting another pair of locations where
     one compares correctly and the next does not.

   * images/ and styles/ directories used by the HTML files.
