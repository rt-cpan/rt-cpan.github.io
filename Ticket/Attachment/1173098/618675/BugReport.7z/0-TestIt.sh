#!/bin/bash

perl ./1-TestCompare.pl ./2-LeftInput.html ./3-RightInput.html > 4-Output.html
