#!/home1/maps/tools/perl/bin/perl
# Rough, self-contained, test version of the CompareContent.pl script to
# compare two HTML files and output a combined report with change markup.
#
#		Howard E. Pierce		Thu, 06-dec-2012, 13:16 AEST


# Load perl modules
	require "utf8.pm" ;
	use HTML::Diff ;


# Output settings
	select((select(STDOUT), $| = 1)[0]) ;
	binmode(STDOUT, ":utf8") ;


################################################################################
# BEGIN DATA DEFINITIONS

	# Get script's basic file name for error messages
	($GLO_ScriptName = $0) =~ s#^.*[\\/]## ;
	$GLO_ScriptName =~ s#\.[^.]{1,4}$## ;

	# Define CSS to style changes
	@ChgStyles = (
		"\t<style type=\"text/css\">",
		"\t\t.added { background-color:#B7B7FF ; border-bottom:1px solid #3333FF ; line-height:2.0em }",
		"\t\t.deleted { background-color:#FFCCCC ; text-decoration:line-through ; line-height:2.0em }",
		"\t</style>",
	) ;

	# Define HTML tags that must get change-class attributes on them because
	# they produce visible content on their own
	@ChangeTags = ( "hr", "object" ) ;


	# Define standard page header stuff
	$Bom = chr(hex("feff")) ;
	$GLO_XhUtf8Head = $Bom . '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/xhtml+xml; charset=utf-8"/>
	<meta http-equiv="content-style-type" content="text/css"/>
	<title>#TITLE#</title>
</head>
' ;

	# Define standard, browser-initialization stuff
	if ($ENV{'HTTP_HOST'})
	{
		$GLO_BrowserInitUtf8 = 'Content-type: text/html; charset=utf-8
Cache-Control: no-store, no-cache, must-revalidate
Expires: Sun, 10 Feb 2002 16:00:00 GMT
Pragma: no-cache

' ;

		# Define web-error-page code from MAPS perl library
		$GLO_WebErrBegin =~ s/#TITLE#/Comparison/gs ;
		$GLO_WebErrBegin =~ s/#ACTION#/compare two objects/gs ;
	}

# END DATA DEFINITIONS
################################################################################



################################################################################
# Reads in a file as an array of lines
#	$1 = String of file path
#	$2 = Pointer to string or array to get file's content

sub ReadFile
{
	my ($FilePath, $Buff) = @_ ;
	my ($Success) ;

	$Success = 0 ;

	if (! -s "$FilePath")
	{
		if (! $FilePath)
			{ push (@GLO_Errs, "The '\$FilePath' parameter to \"" . (caller(0))[3] . "\" is undefined.\n") }
		else
			{ push (@GLO_Errs, "File '$FilePath' is empty (size = 0).\n") }
	}
	elsif (! open (FileMlibI, "$FilePath"))
		{ push (@GLO_Errs, "$GLO_ScriptName cannot read file '$FilePath'\n") }
	else
	{
		binmode(FileMlibI, ":utf8") ;
		if ($Buff =~ /^[^ -~]*ARRAY/)
		{
			chomp (@$Buff = <FileMlibI>) ;
			close (FileMlibI) ;
			if (! @$Buff)
				{ push (@GLO_Errs, "File '$FilePath' contains nothing.") }
			else
				{ $Success = 1 }
		}
		elsif ($Buff =~ /^[^ -~]*SCALAR/)
		{
			undef $/ ;
			$$Buff = <FileMlibI> ;
			close (FileMlibI) ;	# MUST COME BEFORE $/ IS RESET, ELSE binmode FAILS
			$/ = "\n" ;
			if ($$Buff =~ /^\s*$/s)
				{ push (@GLO_Errs, "File '$FilePath' contains nothing.") }
			else
				{ $Success = 1 }
		}
		else
			{ push (@GLO_Errs, "Buffer variable [$Buff] passed in to '" . (caller(0))[3] . "' routine is neither a 'SCALAR' nor an 'ARRAY'.") }
	}

	return $Success ;
}


################################################################################
# Writes out string or array to a file
#	$1 = String of file path
#	$2 = Pointer to string or array of content for the file

sub WriteFile
{
	my ($FilePath, $Content) = @_ ;
	my ($OK, $Success) ;

	if (! open(FileMlibO, ">> $FilePath") )
		{ push (@GLO_Errs, "$GLO_ScriptName cannot write file '$FilePath'.") }
	else
	{
		binmode(FileMlibO, ":utf8") ;
		if ($Content =~ /^[^ -~]*ARRAY/)
			{ print FileMlibO join ("\n", @$Content), "\n" }
		else
			{ print FileMlibO "$$Content" }
		close (FileMlibO) ;
		if (! -e "$$FilePath")
			{ push (@GLO_Errs, "$GLO_ScriptName failed to write file '$FilePath'.") }
		else
			{ $Success = 1 }
	}

	return $Success ;
}


################################################################################
# Exit routine
#	$1 - $n = OPTIONAL Array of messages to issue

sub Exit
{
	my (@Msgs, @Tmp, $Joint) ;

	# Save any diagnostics to a file
	if (@GLO_Diag)
	{
		if ($ENV{'PWD'})
			{ &WriteFile("$ENV{'PWD'}/5-DiagnosticInfo$$.txt", \@GLO_Diag) }
		elsif ($ENV{'CWD'})
			{ &WriteFile("$ENV{'CWD'}/5-DiagnosticInfo$$.txt", \@GLO_Diag) }
		else
		{
			($Fpath = $0) =~ s#([^\\/]+)\.[^.]{1,4}$#5-DiagnosticInfo$$.txt# ;
			&WriteFile($Fpath, \@GLO_Diag) ;
		}
	}

	# Build a list of all messages
	if (grep (/\S/, @GLO_Errs))
		{ push (@Msgs, grep (/\S/, @GLO_Errs)) }

	if (grep (/\S/, @_))
		{ push (@Msgs, grep (/\S/, @_)) }

	# Format and output the messages as required
	if (@Msgs)
	{	# Prevent duplicate page markup
		if ( grep(/<!DOCTYPE/, @Msgs)  &&  $GLO_WebErrBegin )
			{ undef $GLO_WebErrBegin }
		if ( grep(m#</html>#, @Msgs)  &&  $GLO_WebErrEnd ) 
		{	# Remove existing markup because it's probably not at the end
			@Tmp = grep (!m#^\s*</(body|html)>#, @Msgs) ;
			@Msgs = @Tmp ;
		}

		if ( ($ENV{'HTTP_HOST'})  &&
				(! grep (/<(?:h[0-9]|p|[ou]l|table)[\s>]/i, @Msgs)) )
			{ $Joint = "<br/>" }	# Add line breaks if message is unformatted
		else
			{ $Joint = "" }

		# Dump messages to STDOUT
		print STDOUT $GLO_BrowserInitUtf8, $GLO_WebErrBegin,
					join ("$Joint\n", @Msgs), "\n", $GLO_WebErrEnd ;
	}

	exit ;
}


################################################################################
# Builds a context stack of paired tags from an XML string, returning the stack
#	$1 = Pointer to string of left object's resolved XML

sub GetContextStack
{
	my ($XmlString) = @_ ;
	my ($Tag, @Context, $Tmp) ;

	# Go through all non-singleton/non-PI/non-comment tags
	while ($$XmlString =~ /<([^!\?><][^\s><\/]*)(?:[^>]+[^\s\/]\s*)?>/gs)
	{
		$Tag = $1 ;
		if ($Tag =~ m#^/(.+)#)
		{
			$Tag = $1 ;
			if ("$Context[-1]" eq "$Tag")
				{ pop @Context }
			# else NOTHING!  It's NOT an error if deleted PI content is unbalanced
		}
		else
			{ push (@Context, $Tag) }
	}

	return @Context ;
}


################################################################################
# Adds HTML change-markup to a chunk that's changed
#	$1 = Pointer to string of changed content
#	$2 = Pointer to string of change-type style name "added" or "deleted"
#	$3 = Pointer to array of HTML tags that need their own class attributes

sub AddChgMarkup
{
	my ($Chunk, $ChgType, $ChangeTags) = @_ ;
	my ($Regx, $FirstTag, $Item, @NewChunk, $Tag) ;

push(@GLO_Diag, "\t\t200:  Chunk={$$Chunk}.");
	# Define regex to match all tags that need their own change-class attribute
	$Regx = "(?:" . join ("|", @$ChangeTags) . ")" ;

	# Get first begin or singleton tag in the chunk
	if ($$Chunk =~ /<([^\s?><\/]+)/s)
		{ $FirstTag = $1 }

	# If the chunk is one+ complete element/s, just add a class attr to it/them
	if ($$Chunk =~ /^\s*<$FirstTag.*<\/$FirstTag>\s*$/s)
	{
		($Item = $$Chunk) =~ s/(\s*<$FirstTag)/$1 class="$$ChgType"/gs ;
		push (@NewChunk, $Item) ;
push(@GLO_Diag, "\t\t210:  NewChunk[-1]={$NewChunk[-1]}.");
	}
	# Otherwise, we must check every token in the chunk
	else
	{
		# Check all tags present in the input
		foreach $Item (grep(!/^$/, split(m#(<[^-!?><\s][^><]*>)#s, $$Chunk)))
		{
push(@GLO_Diag, "\t\t220:  Item={$Item}.");
			if ($Item =~ m#^</?([^\s?></]+)#s)
			{	# Process markup
				$Tag = $1 ;
				if ($Item =~ m#/\s*>#s)	# It's a singleton tag
				{
					$Item =~ s#(/\s*>)# class="$$ChgType"$1#s ;
					push (@NewChunk, $Item) ;
				}
				elsif ($Item =~ m#</#s)	# It's an end tag
					{ push (@NewChunk, $Item) }
				else	# It's a begin tag
				{
					if ($Tag =~ /^$Regx$/)
						{ $Item =~ s/(<$Tag)/$1 class="$$ChgType"/s }
					push (@NewChunk, $Item) ;
				}
			}
			else
			{	# process content
				if ($Item =~ /\S/s)
					{ push (@NewChunk, "<span class=\"$$ChgType\">$Item</span>") }
				else
					{ push (@NewChunk, $Item) }	# just whitespace of some kind
			}
push(@GLO_Diag, "\t\t230:  NewChunk[-1]={$NewChunk[-1]}.\n");
		}
	}

	return join ("", @NewChunk) ;
}


################################################################################
# Compares two strings, returning one merged string with change markup
#	$1 = Pointer to string of left object's file name
#	$2 = Pointer to string of right object's file name
#	$3 = Pointer to hash of data/info by side
#	$4 = Pointer to string of object type
#	$5 = Pointer to array of HTML tags that need their own class attributes

sub Compare
{
	my ($Lname, $Rname, $HtmlBySide, $ChangeTags) = @_ ;
	my ($Count, $Left, $Right, @Combo, $DiagDiv, $ChunkNum, $DifPtr, $Deleted,
		 @Context, $Tag, $Chunk, $DtdLine) ;

	$Count = 0 ;

	$Left = $$HtmlBySide{"Left"} ;
	$Right = $$HtmlBySide{"Right"} ;


	# html_word_diff returns a 3-element array of pointers to scalars:
	# 0 = one-character key that indicates the type of difference
	#     u = chunk is unchanged
	#     + = chunk exists in $Right, but NOT in $Left
	#     - = chunk exists in $Left, but NOT in $Right
	#     c = chunk is changed between L & R
	# 1 = Chunk of left-side difference
	# 2 = Chunk of right-side difference
	$DiagDiv = "-" x 80 ;
	$ChunkNum = 0 ;
	foreach $DifPtr (@{ &HTML::Diff::html_word_diff($Left, $Right) })
	{
		$ChunkNum++ ;
push(@GLO_Diag, "\n\n$DiagDiv\n100: Chunk #$ChunkNum,  DifPtr[0]={$$DifPtr[0]},\n*\tLeft={$$DifPtr[1]},\n*\tRight={$$DifPtr[2]}.\n");
		if ($$DifPtr[0] eq "u")
			{ push (@Combo, $$DifPtr[1]) }
		elsif ($$DifPtr[0] eq "+")
		{
			push (@Combo,
				&AddChgMarkup (\"$$DifPtr[2]", \"added", $ChangeTags),
			) ;
			$Count++ ;
		}
		elsif ($$DifPtr[0] eq "-")
		{
			$Deleted = $$DifPtr[1] ;
			@Context = &GetContextStack(\$Deleted) ;
			if (@Context)
				{ grep ($Deleted .= "</$_>", @Context) }
			push (@Combo,
				&AddChgMarkup(\$Deleted, \"deleted", $ChangeTags),
			) ;
			$Count++ ;
		}
		else
		{
			$Deleted = $$DifPtr[1] ;
			@Context = &GetContextStack(\$Deleted) ;
			if (@Context)
				{ grep ($Deleted .= "</$_>", @Context) }
			push (@Combo,
				&AddChgMarkup(\$Deleted, \"deleted", $ChangeTags),
				&AddChgMarkup (\"$$DifPtr[2]", \"added", $ChangeTags),
			) ;
			$Count++ ;
		}
	}


	# Count of differing regions must be LAST element of array
	push (@Combo, $Count) ;

	return @Combo ;
}


################################################################################
# Adds the page header and introductory information
#	$1 = Pointer to array of CSS style definitions for change markup
#	$2 = Pointer to scalar number of differences
#	$3 = Pointer to array of chunks of HTML report

sub AddIntro
{
	my ($ChgStyles, $Difs, $Report) = @_ ;
	my ($Heading, $S1, $S2, @Intro, $I, $Done, $Tmp) ;

	$Heading = "Content Comparison Results" ;

	if ($$Difs == 1)
	{
		$S1 = "" ;
		$S2 = "s" ;
	}
	else
	{
		$S1 = "s" ;
		$S2 = "" ;
	}

	@Intro = (
		"<h2>$Heading</h2>",
		"<h4>file $ARGV[0]</h4>",
		"<h4>Compared to:</h4>",
		"<h4>file $ARGV[1]</h4>",
		"<p>$$Difs region$S1 differ$S2.</p>",
		"<hr/>",
	) ;

	# Process report of NO differences
	if ($$Difs == 0)
	{
		($I = $GLO_XhUtf8Head) =~ s/#TITLE#/$Header/ ;
		$Tmp = join ("\n", @$ChgStyles) ;
		$I =~ s#(</head>)#$Tmp\n$1#s ;
		@$Report = (
			$I,
			"<body>",
			@Intro,
			"</body>",
			"</html>",
		) ;
	}
	# Process report of real differences
	else
	{
		$I = -1 ;
		$Done = 0 ;
		while ( ($Done < 3)  &&  (++$I < $#$Report) )
		{
			if ($$Report[$I] =~ m#<title>.*?</title>#s)
			{
				$$Report[$I] =~ s#<title>.*?</title>#<title>$Heading</title>#s ;
				$Done++ ;
			}
			if ($$Report[$I] =~ m#</head>#s)
			{
				$Tmp = join ("\n", @$ChgStyles) ;
				$$Report[$I] =~ s#(</head>)#$Tmp\n$1#s ;
				$Done++ ;
			}
			if ($$Report[$I] =~ m#<body(?:\s+[^>]+)?>#s)
			{
				$Tmp = join ("\n", @Intro) ;
				$$Report[$I] =~ s#(<body(?:\s+[^>]+)?>)#$1\n$Tmp#s ;
				$Done++ ;
			}
		}
		if ($Done < 3)
			{ push (@GLO_Errs, "$GLO_ScriptName failed to add headings to this report.") }
	}

	return ;
}


################################################################################
#####                                MAIN                                  #####
################################################################################


# Read sample input file
	if (&ReadFile($ARGV[0], \$Tmp))
		{ $HtmlBySide{"Left"} = $Tmp }
	else
		{ &Exit() }
	if (&ReadFile($ARGV[1], \$Tmp))
		{ $HtmlBySide{"Right"} = $Tmp }
	else
		{ &Exit() }


# Compare the two HTML-ified objects
	$Lname = "Left" ;
	$Rname = "Right" ;
	@Report = &Compare (\$Lname, \$Rname, \%HtmlBySide, \@ChangeTags) ;
	$Difs = pop @Report ;


# Add header and intro stuff to @Report
	&AddIntro(\@ChgStyles, \$Difs, \@Report) ;


# Spit out the results
	print STDOUT join ("\n", @Report), "\n" ;


&Exit() ;
