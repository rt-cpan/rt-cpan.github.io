#https://www.codingame.com/ide/puzzle/darts


use strict;
use warnings;
use Data::Dumper;
use colorize::stderr 'yellow';
use Win32::Console::ANSI;
#use diagnostics;
use 5.20.1;

select(STDOUT); $| = 1; # DO NOT REMOVE

# Auto-generated code below aims at helping you parse
# the standard input according to the problem statement.

my $tokens;
my %players;
my @sortplayers;

chomp(my $size = <DATA>);
warn "size: $size\n";

chomp(my $n = <DATA>);
warn "n: $n\n";

my $b = 10000;

for my $i (0..$n-1) {
    $b--;
    warn "i1: $i\n";
    my $s = sprintf('%05d', $b);
    chomp(my $name = <DATA>);
    push (@sortplayers, "$s#$name");
    warn "name: $name\n";
}

warn Dumper \@sortplayers;

chomp(my $t = <DATA>);
warn "t: $t\n";
for my $i (0..$t-1) {
    warn "i2: $i --------------------\n";
    chomp($tokens=<DATA>);
    warn "tokens: $tokens\n";
    my ($throwname, $x, $y) = split(/ /,$tokens);
    my $sname;
    if (my ($matched) = grep $_ =~ $throwname, @sortplayers) {
        $sname = $matched;
    }
    
    $x = abs($x);
    $y = abs($y);
    
    my $hypotenuse = ($x * $x + $y * $y) ** 0.5;
    warn "hypotenuse = $hypotenuse\n";
    
    if ($x + $y <= $size / 2) {
        warn "--> 15 scored\n";
        $players{$sname} += 15; 
    } elsif ($hypotenuse <= $size / 2) {
        warn "--> 10 scored\n";
        $players{$sname} += 10; 
    } elsif ($x <= $size / 2 and $y <= $size / 2) {
        $players{$sname} += 5;
        warn "--> 5 scored\n";
    } else {
        warn "---> 0 scored\n";
    }
}

warn Dumper \%players;

my @sorter;

while ((my $key, my $value) = each (%players))
{
  # do whatever you want with $key and $value here ...
  $value = $players{$key};
  warn "  $key has $value\n";
  push (@sorter, "$value|$key");
}

for my $v (reverse sort @sorter) {
    #warn "v: $v\n";
    my ($score, $name) = split(/\|/, $v);
    my ($d, $rname) = split(/\#/, $name);
    print "$rname $score\n";
}

__DATA__
100
4
Will
Bill
Jill
Rekt
8
Will -51 0
Bill 51 0
Jill 49 2
Rekt 0 0
Will 35 35
Bill -20 -21
Jill 1 50
Rekt -13 39
