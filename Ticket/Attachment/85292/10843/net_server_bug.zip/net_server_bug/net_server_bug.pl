#!/usr/bin/perl
use strict;
use RPC::XML::Server;
use RPC::XML::Procedure;
##
## Use Net::Server instead of HTTP::Daemon (see info RPC::XML::Server "no_http")
##
print "creating server object\n";
my $srv;
unless ( ref ( $srv = new RPC::XML::Server no_http => 1 ) ) { die "Unable to create server object: $srv, stopped"; }
$srv->add_method ( RPC::XML::Procedure->new ( { name => 'StructAdService', code => \&my_sub, signature => [ 'struct struct' ] } ) );
##
## Start the Net::Server (instead of HTTP::Daemon)
##
$srv->server_loop ( conf_file => "net_server_bug.conf" );
##
##
##
sub my_sub {
    return @_;
}
###END
