use XML::Rules;

my $parser = XML::Rules->new(
    style => 'filter',
    rules => [
        _default => 'content',
        ]);

$parser->filterfile( "test.xml" , "test_out.xml" ) or die;

