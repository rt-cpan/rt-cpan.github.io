#!/usr/bin/perl -w

#use open ':std', ':encoding(UTF-8)';
use open ':std', ':utf8';

open(my $IN, "<:encoding(UTF-8)", "test.txt")
#open(my $IN, "<", "test.txt")
	or die "Can't open < test.txt: $!";

print STDERR "Just opened: (".(tell($IN)).")\n";

while(read($IN, my $buffer, 1) > 0)
{
	print STDERR "(".(tell($IN)).")\n";
}
