use strict;

print "in slave\n";
print "slave answer?\n";
my $ans = <STDIN>; chomp $ans;

print "slave answer is: $ans\n";


