use strict;
use Term::ReadLine;
use IPC::Run;

### doesn't help
STDOUT->autoflush(1); STDERR->autoflush(1);

### this doesn't help either
*STDOUT_SAVE = *STDOUT;

my $tr = Term::ReadLine->new('master');

print "\nRun as IPC::Run\n";
IPC::Run::run([$^X,'slave2.pl'], \*STDIN, \&foo, \&foo); 
sub foo { print STDOUT_SAVE "@_" };

$tr->readline('in master');
