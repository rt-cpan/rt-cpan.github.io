package Foo::Bar;

$Foo::Bar::VERSION = '2.01';

#sub foobar {return "Hello from Foo::Bar";}

use Inline Config => NAME => 'Foo::Bar' => VERSION => '2.01';

use Inline C => <<'EOC';

SV * foobar() {
  return(newSVpv("Hello from Foo::Bar", 0));
}

EOC

1;
