package Foo;

$Foo::VERSION = '2.01';

sub foo {
  return "Hello from Foo";
}

1;
