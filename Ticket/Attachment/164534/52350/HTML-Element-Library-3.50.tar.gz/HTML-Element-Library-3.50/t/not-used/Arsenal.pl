use lib '.';
use Arsenal;

Arsenal->new->load_data;
