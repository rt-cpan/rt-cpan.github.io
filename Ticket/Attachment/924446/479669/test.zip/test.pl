#!/usr/bin/perl

use strict;
use warnings;

use lib "./lib";

use DBIx::Class::ResultSet::RecursiveUpdate;

use testDB::Schema;


my $schema = testDB::Schema->connect(
    'dbi:SQLite:sqlite3_test.db',
    '',
    '',
    { RaiseError => 1,
      on_connect_do => "PRAGMA foreign_keys = ON" } );



# OK, create dvd that belongs_to owner
my $dvd = $schema->resultset('Dvd')->create({

            title => 'Pirates of the Caribbean',
            owner => {name => 'Bob'} });

print 'Title: ' . $dvd->title . "\n";

# OK, Dvd has owner
print 'Owner: ' . $dvd->owner->name . "\n"
    if $dvd->owner;

# FAIL: trying to update dvd: set owner to NULL
DBIx::Class::ResultSet::RecursiveUpdate::Functions::recursive_update(
    resultset => $schema->resultset('Dvd'),
    updates => {
        title => 'Pirates of the Caribbean II',
        owner => undef
    },
    object => $dvd );
$dvd->discard_changes;

# OK, title updated correctly
print 'Title: ' . $dvd->title . "\n";

if ($dvd->owner) {
    # FAIL
    # Dvd still has the owner
    print 'Owner: ' . $dvd->owner->name . "\n";

} else {
    # OK
    # Dvd has no owner
    print "Dvd is free\n";
}

# clear db
$dvd->delete;
$schema->resultset('Owner')->delete;

exit;

__END__
