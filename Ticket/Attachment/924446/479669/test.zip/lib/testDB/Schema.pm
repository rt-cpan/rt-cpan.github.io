package testDB::Schema;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces;


# Created by DBIx::Class::Schema::Loader v0.07002 @ 2011-04-01 06:20:15
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:56y+zDedpdacMQ7Wli5TVw


# You can replace this text with custom content, and it will be preserved on regeneration
1;
