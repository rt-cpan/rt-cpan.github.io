PRAGMA foreign_keys = ON;

drop table if exists owner;
create table owner (
    id integer PRIMARY KEY,
    name text NOT NULL DEFAULT ''
);

drop table if exists dvd;
create table dvd (
    id integer PRIMARY KEY,
    title text NOT NULL DEFAULT '',
    owner_id INTEGER REFERENCES owner(id)
);

-- insert into owner values (1, 'Bob');
-- insert into dvd values (1, 'The Chronicles of Narnia', 1);
