package Test::Schema::Result::Entries;
use base qw(DBIx::Class::Core);

__PACKAGE__->table('entries');
__PACKAGE__->add_columns(qw(id debit credit));
__PACKAGE__->set_primary_key('id');
1;
