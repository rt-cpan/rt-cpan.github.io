#!/usr/bin/perl

use Test::Schema;
my $dsn = "dbi:mysql:test:localhost";
my $schema = Test::Schema->connect($dsn, 'root', undef);

my $rset = $schema->resultset('Entries');
my $res = $rset->search(
    {},
    {
	select => 'sum(debit) - sum(credit)',
	as => 'assets'
    }
);
my @x = $res->all;
