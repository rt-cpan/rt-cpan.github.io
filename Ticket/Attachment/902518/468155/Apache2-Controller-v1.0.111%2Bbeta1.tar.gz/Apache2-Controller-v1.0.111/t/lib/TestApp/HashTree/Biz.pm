package TestApp::HashTree::Biz;
use base qw( Apache2::Controller Apache2::Request );
sub allowed_methods {qw( default )}
sub default {
}
1;
