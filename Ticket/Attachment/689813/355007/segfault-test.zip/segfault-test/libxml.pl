#!/usr/bin/perl

use strict;
use warnings;

use XML::LibXML;
use XML::LibXML::Reader;
use XML::LibXSLT;
use Time::HiRes qw(time);
my $time;
BEGIN {
	$time = time;
}
END {
	warn sprintf "Elapsed time: %.2f seconds", time - $time;
}

my $xsl_file = shift || 'transform.xsl';
my $input_file = shift || 'input.xml';
my $reader = XML::LibXML::Reader->new(location => $input_file) or die "cannot read file: $input_file\n";
my $xslt = XML::LibXSLT->new->parse_stylesheet(XML::LibXML->load_xml(location => $xsl_file, no_cdata => 1));

while($reader->read){
	if($reader->name eq 'student'){
		my $salesOrderActivity = $reader->copyCurrentNode(1);
		my $result = $xslt->transform($reader->document);
		print $xslt->output_as_bytes($result);
	}
}
