package version::Builder;
use Module::Build;
@ISA = qw(Module::Build);

    sub ACTION_dist{
        my $self = shift;
    	$self->do_system('svk log -x | gnuify-changelog.pl > Changes');
	$self->SUPER::ACTION_dist();
	}
    
1;
