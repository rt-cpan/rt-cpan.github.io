#!/usr/bin/perl -w

use strict;
use Text::Template;

my $tpl = Text::Template->new(
	TYPE => 'FILE',
	SOURCE => "myleak.tpl",
	DELIMITERS => [ '<%', '%>' ],
	);

my $i = 0;
while (++$i) {
	my $data = {var1 => "$i"};
	my $result = $tpl->fill_in(HASH => $data, PACKAGE => 'MyLeak');
}

package MyLeak;

use strict;

use vars qw($var1 @var2);

sub testMethod {
	my $var3 = $var1;
	return $var3;
}

1;

