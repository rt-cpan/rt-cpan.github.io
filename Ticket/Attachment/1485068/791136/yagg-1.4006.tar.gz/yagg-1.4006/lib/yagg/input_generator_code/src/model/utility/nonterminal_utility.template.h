#ifndef [[[ $file_type ]]]_utility_h
#define [[[ $file_type ]]]_utility_h

[[[ $head ]]]

#endif // [[[ $file_type ]]]_utility_h
