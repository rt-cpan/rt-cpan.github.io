#ifndef LOGICAL_EXPRESSION_PARSER_INCLUDES_H
#define LOGICAL_EXPRESSION_PARSER_INCLUDES_H

// In case we need to declare any types used in yylval in the parser
#include <list>
#include <string>

using namespace std;

#endif // LOGICAL_EXPRESSION_PARSER_INCLUDES_H
