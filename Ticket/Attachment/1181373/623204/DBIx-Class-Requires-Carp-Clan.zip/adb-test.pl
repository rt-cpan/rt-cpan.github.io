use strict;
use warnings;
use lib 'AudioDB/lib';

use AudioDB::Schema;

my $schema = AudioDB::Schema->connect('dbi:SQLite:./test.db');