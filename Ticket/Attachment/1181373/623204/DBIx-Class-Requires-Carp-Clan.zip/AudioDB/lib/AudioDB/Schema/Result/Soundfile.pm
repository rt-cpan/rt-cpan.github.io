use strict;
use warnings;
package AudioDB::Schema::Result::Soundfile;
use base 'DBIx::Class::Core';
__PACKAGE__->table('soundfile');
__PACKAGE__->add_columns(id=>{
	file => {
		data_type => 'TEXT',
	}
});
__PACKAGE__->set_primary_key('id');
__PACKAGE__->has_many('infos' => 'AudioDB::Schema::Result::FileInfo', 'file');

1;