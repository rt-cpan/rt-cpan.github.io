use strict;
use warnings;
package AudioDB::Schema::Result::FileInfo;
use base 'DBIx::Class::Core';
__PACKAGE__->table('user_address');
__PACKAGE__->add_columns(
	infoId => {
		data_type => 'INTEGER',
		is_numeric => 1,
		is_auto_increment => 1,
	},
	dataset => {
		data_type => 'TEXT',
		size => 6
	},
	w => {
		data_type => 'TEXT',
	},
	pos => {
		data_type => 'TEXT',
	},
	region => {
		data_type => 'TEXT',
		size=>2,
	},
	pron => {
		data_type => 'TEXT',
	},
	file => {
		data_type => 'TEXT',
		is_foreign_key => 1
	},
);
__PACKAGE__->set_primary_key('infoId');
__PACKAGE__->belongs_to('file' => 'AudioDB::Schema::Result::Soundfile');

1;
