#!/usr/bin/perl -w

use Spreadsheet::ParseExcel;

$fileName = "./test2.xls";

# Open the sheet, read the range

$parser = new Spreadsheet::ParseExcel;
$reader = $parser->parse($fileName);
$reader || die "File $fileName not found";

# Report the active cell range

printf("The workbook contains %d sheets\n", $reader->worksheet_count());
printf("Worksheet 0 range - rows: (%d - %d), cols: (%d - %d)\n", 
       $reader->worksheet(0)->row_range(), $reader->worksheet(0)->col_range());
print "Active cell values:\n";

my ($i, $j);
for($i = ($reader->worksheet(0)->row_range())[0]; $i <= ($reader->worksheet(0)->row_range())[1]; $i++) {
    for($j = ($reader->worksheet(0)->col_range())[0]; $j <= ($reader->worksheet(0)->col_range())[1]; $j++) {
        $reader->worksheet(0)->get_cell($i, $j) &&
            printf("Cell[%d,%d] = %s\n", $i, $j, $reader->worksheet(0)->get_cell($i, $j)->value());
    }
}

__END__


print "\n    Perl version   : $]";
print "\n    OS name        : $^O";
print "\n    Module versions: (not all are required)\n";

my @modules = qw(
                      Spreadsheet::ParseExcel
                      Scalar::Util
                      Unicode::Map
                      Spreadsheet::WriteExcel
                      Parse::RecDescent
                      File::Temp
                      OLE::Storage_Lite
                      IO::Stringy
                    );

for my $module (@modules) {
    my $version;
    eval "require $module";

    if (not $@) {
        $version = $module->VERSION;
        $version = '(unknown)' if not defined $version;
    }
    else {
        $version = '(not installed)';
    }

    printf "%21s%-24s\t%s\n", "", $module, $version;
}
 __END__
