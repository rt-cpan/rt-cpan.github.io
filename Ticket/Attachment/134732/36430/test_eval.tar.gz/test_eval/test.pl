#!/mpi/tools/bin/perl -W

use 5.008;

use strict;
use vars qw( $REVISION $VERSION ) ;

use Getopt::Long;
use IO::File;
use Data::Dumper;

use Spreadsheet::ParseExcel;

use MPI::Util::ScriptHelper;

$REVISION = '$Revision:    /main/5    $ ';
( $REVISION ) =  map { s/^.Revision:\s*//; s/\s+\$\s*$//; $_ } $REVISION ;
$VERSION = $REVISION;

$| = 1;

my $helper = MPI::Util::ScriptHelper->new();

my $useage = '';
my $help = 0;
my $verbose = 0;
my $debug = 0;

my %SCRIPT_OPTIONS = ( 'verbose=i' => \$verbose,
		       'debug=i'   => \$debug,
		       'help'      => \$help );

unless ( &GetOptions(%SCRIPT_OPTIONS) ) { die "ERROR: invalid options or option values\n\n",&_usage(); }

if ($help) { print &_usage(); exit; }

print $helper->header();

my @files = @ARGV;

foreach my $file (@files)
{
    print "FILE: $file\n";


    my $oBook = Spreadsheet::ParseExcel::Workbook->Parse($file);

    warn "FILE: $file\n";
    warn Dumper($oBook);

    my($iR, $iC, $oWkS, $oWkC);
    foreach my $oWkS (@{$oBook->{Worksheet}}) {
	print "--------- SHEET:", $oWkS->{Name}, "\n";
	for(my $iR = $oWkS->{MinRow} ; defined $oWkS->{MaxRow} && $iR <= $oWkS->{MaxRow} ; $iR++)
	{
	    for(my $iC = $oWkS->{MinCol} ; defined $oWkS->{MaxCol} && $iC <= $oWkS->{MaxCol} ; $iC++)
	    {
		$oWkC = $oWkS->{Cells}[$iR][$iC];
		print "( $iR , $iC ) =>", $oWkC->Value, "\n" if($oWkC);
	    }
	}
    }
}

print $helper->stats();

exit;

##############

sub _usage
{
    my $usage;
    my @lines;
    push @lines,"Usage:\n";
    push @lines,"  $0 [-verbose=i] [-debug=i]\n";
    push @lines,"  $0 -help\n";
    $usage = join('',@lines);
    return $usage;
}

__END__

