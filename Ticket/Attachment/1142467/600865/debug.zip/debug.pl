#! /usr/bin/env perl
 
use strict;
use warnings;
use TAP::Parser::Iterator::Process;
my %args = (
   command  => ['C:\\Perl\\bin\\perl.exe', '-I', 'lib', 'test.t'],
   merge    => 0,
);
my $it   = TAP::Parser::Iterator::Process->new(\%args);
my $line = $it->next;
