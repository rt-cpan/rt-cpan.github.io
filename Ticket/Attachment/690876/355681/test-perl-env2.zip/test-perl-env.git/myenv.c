/* -*- c -*- 
 * File: myenv.c
 * Author: Igor Vlasenko <vlasenko@imath.kiev.ua>
 * Created: Sat Nov 14 23:33:50 2009
 *
 * $Id: newfile-template.el,v 1.4 2005/05/26 20:10:12 igor Exp $
 */

#include <stdlib.h>

const char* c_code_getenv(const char* name) {
  return getenv(name);
}


/*
 *  Local Variables:
 *  mode: c
 *  End:
 */
