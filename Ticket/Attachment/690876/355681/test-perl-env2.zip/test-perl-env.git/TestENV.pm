package TestENV;

use 5.005;
use strict;
use Carp;
require DynaLoader;
require Exporter;
use vars qw($VERSION @ISA);
@ISA = qw(DynaLoader);

$VERSION = '0.01';

bootstrap TestENV $VERSION;

