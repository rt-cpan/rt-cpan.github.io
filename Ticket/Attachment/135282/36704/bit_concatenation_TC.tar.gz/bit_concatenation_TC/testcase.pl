#!/usr/local/bin/perl

use strict;

use Verilog::Netlist;
use Verilog::Getopt;

# Setup options so files can be found

my $opt = new Verilog::Getopt;
$opt->parameter("+incdir+verilog", "-y", "verilog");

my $nl = new Verilog::Netlist (options => $opt, link_read_nonfatal => 1);

$nl->read_file (filename=>"testcase_in.v");

# Read in any sub-modules
$nl->link();
$nl->lint();
$nl->exit_if_error();

unless ( open( OUTFILE , ">testcase_out.v" ) )
{
	print ( "Can't open testcase_out.v ...\n" );
	exit( 3 );
	}

print OUTFILE $nl->verilog_text;

close OUTFILE;
