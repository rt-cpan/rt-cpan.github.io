# $Id: Hexdumper.pm,v 1.6 2009/03/03 20:18:06 drhyde Exp $
package Data::Hexdumper;

use strict;
use warnings;

our $VERSION = '2.01';

use Carp qw(confess);
use Perl6::Export::Attrs;
use Readonly;

Readonly my $BIGENDIAN             => unpack 'h*', pack 's', 1 =~ m{01}xms;
Readonly my $LITTLEENDIAN          => unpack 'h*', pack 's', 1 =~ m{\A 1}xms;
Readonly my $DEFAULT_OUTPUT_FORMAT => '  0x%a : %16C : %c';

my %number_format_of = qw(
    V  L<
    N  L>
    v  S<
    n  S>
);

# static data, tells us the length of each type of word
my %num_bytes_of = (
    'C'  => 1, # unsigned char
    'S'  => 2, # unsigned 16-bit
    'L'  => 4, # unsigned 32-bit
    'L<' => 4, # unsigned 32-bit, little-endian
    'L>' => 4, # unsigned 32-bit, big-endian
    'S<' => 2, # unsigned 16-bit, little-endian
    'S>' => 2, # unsigned 16-bit, big-endian
    'Q'  => 8, # unsigned 64-bit
    'Q<' => 8, # unsigned 64-bit, little-endian
    'Q>' => 8, # unsigned 64-bit, big-endian
);

sub hexdump :Export {
    my @params = @_;

    # first let's see if we need to massage the data into canonical form ...
    my %params
        = ( @params == 2 && ref $params[1] eq 'HASH')
        # two: hexdump($foo, {...})
        ? (
            data => $params[0],
            %{$params[1]}
        )
        # one param: hexdump($string)
        : (
            data => $params[0]
        );

    my ($data, $start_position, $end_position, $suppress_warnings, $space_as_space, $output_format)
        = delete @params{qw(data start_position end_position suppress_warnings space_as_space output_format)};
    %params
        and confess 'unknown params ' . join ', ', keys %params;

    my $address = $start_position ||= 0;
    $end_position ||= ( length $data ) - 1;

    # sanity-check the parameters
    defined $data
        or lengh $data
        or confess 'No data given to hexdump';
    $start_position =~ m{\D}xms
        and confess 'start_position must be numeric';
    $end_position =~ m{\D}xms
        and confess 'end_position must be numeric';
    $end_position < $start_position
        and confess 'end_position must not be before start_position';

    $output_format ||= $DEFAULT_OUTPUT_FORMAT;
    my ($chunksize, $number_format) = $output_format =~ m{
        \%
        (\d+)
        (
            [LSQ] [<>]?
            | [CSLVNvnQ]
        )
    }xms;
    $number_format
        or confess "Can not find output_format '$output_format'";
    if ( exists $number_format_of{$number_format} ) {
        $number_format = $number_format_of{$number_format};
    }
    0 + $chunksize
        or confess "Chunksize can not be 0 in output_format '$output_format'";

    my $num_bytes = $num_bytes_of{$number_format};

    # extract the required range and pad end with NULLs if necessary

    $data = substr $data, $start_position, 1 + $end_position - $start_position;
    if ( ( length $data ) % $num_bytes ) {
        $suppress_warnings
            or warn
                q{Data::Hexdumper: data doesn't exactly fit into an integer number }
                . qq{"of '$number_format' words,\nso has been padded }
                . qq{with NULLs at the end.\n};
        $data
            .= ( pack 'C', 0 )
            x do {
                my $modulo = ( length $data ) % $num_bytes;
                $modulo
                ? $num_bytes - $modulo
                : 0;
            };
    }

    my $mapper = sub {
        my $output = $output_format;
        $output =~ s{\% a}{$_->{address}}xms;
        $output =~ s{\% c}{$_->{chunk}}xms;
        $output =~ s{
            \%
            \d+
            (?:
                [LSQ] [<>]?
                | [CSLVNvnQ]
            )
        }{$_->{data}}xms;

        return "$output\n";
    };

    return join q{}, map {
        $mapper->()
    } _split_data({
        data           => $data,
        chunksize      => $chunksize,
        address        => $address,
        num_bytes      => $num_bytes,
        number_format  => $number_format,
        space_as_space => $space_as_space,
    });
}

sub _split_data {
    my $params = shift;

    my ($data, $chunksize, $address, $num_bytes, $number_format, $space_as_space)
        = @{$params}{qw(data chunksize address num_bytes number_format space_as_space)};

    my @output;

    while ( length $data ) {
        # Get a chunk
        my $chunk = substr $data, 0, $chunksize, q{};

        my %output = (
            address => ( sprintf '%04X', $address ),
            data    => q{},
            chunk   => q{},
        );

        # have to keep chunk for printing, so make a copy we
        # can 'eat' $num_bytes at a time.
        my $line = $chunk;

        while ( length $line ) {
            # grab a $num_bytes element, and remove from line
            my $this_element = substr $line, 0, $num_bytes;
            $line
                = length $line > $num_bytes
                ? substr $line, $num_bytes
                : q{};
            $output{data} .= _format_word($number_format, $this_element);
        }
        # replace any non-printable character with .
        $chunk =~ s{
            [^a-z0-9\\|,.<>;:'\@\[{\]}#`!"\$%^&*()_+=~?\/-]
        }{.}xmsgi;
        if ( ! $space_as_space ) {
            $chunk =~ s{[ ]}{.}xmsg;
        }
        $output{data}
            = join q{ }, $output{data} =~ m{(..)}xmsg;
        $output{data}
            .= q{ } x (
                (2 + 1) * $chunksize # 2 hex digits + 1 space
                - 1 # space
                - length $output{data}
            );
        $output{chunk} .= $chunk;
        $address += $chunksize;
        push @output, \%output;
    }

    return @output;
}

sub _format_word {
    my ($format, $data) = @_;

    # big endian
    my @bytes = map { ord $_ } $data =~ m{(.)}xmsg;
    # make little endian if necessary
    if ( $format =~ m{[<]}xms || $format !~ m{[>]}xms && $LITTLEENDIAN ) {
        @bytes = reverse @bytes;
    }

    return join q{ }, map { sprintf '%02X', $_  } @bytes;
}

1;

__END__

=head1 NAME

Data::Hexdumper - Make binary data human-readable

=head1 VERSION

2.01

=head1 SYNOPSIS

    use Data::Hexdumper qw(hexdump);
    $results = hexdump(
        data           => $data, # what to dump
        number_format  => 'S',   # display as unsigned 'shorts'
        start_position => 100,   # start at this offset ...
        end_position   => 148,   # ... and end at this offset
        output_format  => '  0x%a : %16C : %c',
                                 # optional output format
                                 # (this example shows the default)
                                 # %a   -> address
                                 # %16C -> 16 unsigned chars
                                 # %c   -> bytes in ascii
    );
    print $results;

=head1 DESCRIPTION

C<Data::Hexdumper> provides a simple way to format arbitary binary data
into a nice human-readable format, somewhat similar to the Unix 'hexdump'
utility.

It gives the programmer a considerable degree of flexibility in how the
data is formatted, with sensible defaults.  It is envisaged that it will
primarily be of use for those wrestling alligators in the swamp of binary
file formats, which is why it was written in the first place.

=head1 SUBROUTINES/METHODS

The following subroutines are exported by default, although this is
deprecated and will be removed in some future version.  Please pretend
that you need to ask the module to export them to you.

If you do assume that the module will always export them, then you may
also assume that your code will break at some point after 1 Aug 2012.

=head2 hexdump

Does everything.  Takes a hash of parameters, one of which is mandatory,
the rest having sensible defaults if not specified.  Available parameters
are:

=over

=item data

A scalar containing the binary data we're interested in.  This is
mandatory.

=item start_position

An integer telling us where in C<data> to start dumping.  Defaults to the
beginning of C<data>.

=item end_position

An integer telling us where in C<data> to stop dumping.  Defaults to the
end of C<data>.

=item number_format (use output_format instead!)

A string specifying how to format the data.  It can be any of the following,
which you will notice have the same meanings as they do to perl's C<pack>
function:

=over

=item C - unsigned char

=item S - unsigned 16-bit, native endianness

=item v or SE<lt> - unsigned 16-bit, little-endian

=item n or SE<gt> - unsigned 16-bit, big-endian

=item L - unsigned 32-bit, native endianness

=item V or LE<lt> - unsigned 32-bit, little-endian

=item N or LE<gt> - unsigned 32-bit, big-endian

=item Q - unsigned 64-bit, native endianness

=item QE<lt> - unsigned 64-bit, little-endian

=item QE<gt> - unsigned 64-bit, big-endian

=back

It defaults to 'C'.  Note that 64-bit formats are *always* available,
even if your perl is only 32-bit.  Similarly, using E<lt> and E<gt> on
the S and L formats always works, even if you're using a pre 5.10.0 perl.
That's because this code doesn't use C<pack()>.

=item output_format

This format is like sprintf. Here the placeholders as example.

 Address                              -> %a
 Bytes in ascii                       -> %c
 16 unsigned chars                    -> %16C
 8 unsigned 16-bit, native endianness -> %8S
 4 unsigned 16-bit, little-endian     -> %4v or %4SE<lt>
 2 unsigned 16-bit, big-endian        -> %2n or %2SE<gt>
 1 unsigned 32-bit, native endianness -> %1L
 2 unsigned 32-bit, little-endian     -> %2V or %2LE<lt>
 3 unsigned 32-bit, big-endian        -> %3N or %3LE<gt>
 4 unsigned 64-bit, native endianness -> %4Q
 5 unsigned 64-bit, little-endian     -> %5QE<lt>
 6 unsigned 64-bit, big-endian        -> %6QE<gt>

This is the default output format.

 '  0x%a : %16C : %c'

=item suppress_warnings

Make this true if you want to suppress any warnings - such as that your
data may have been padded with NULLs if it didn't exactly fit into an
integer number of words, or if you do something that is deprecated.

=item space_as_space

Make this true if you want spaces (ASCII character 0x20) to be printed as
spaces Otherwise, spaces will be printed as full stops / periods (ASCII
0x2E).

=back

Alternatively, you can supply the parameters as a scalar chunk of data
followed by an optional hashref of the other options:

    $results = hexdump($string);

    $results = hexdump(
        $string,
        { start_position => 100, end_position => 148 }
    );

=head1 DIAGNOSTICS

warn of size conflicts

confess for false parameters

=head1 CONFIGURATION AND ENVIRONMENT

nothing

=head1 DEPENDENCIES

Carp

L<Perl6::Export::Attrs|Perl6::Export::Attrs>

Readonly

=head1 SEE ALSO

L<Data::Dumper|Data::Dumper>

L<Data::HexDump|Data::HexDump> if your needs are simple

perldoc -f unpack

perldoc -f pack

=head1 INCOMPATIBILITIES

not known

=head1 BUGS AND LIMITATIONS

There is no support for syntax like 'S!' like what pack() has, so it's
not possible to tell it to use your environment's native word-lengths.

It formats the data for an 80 column screen, perhaps this should be a
frobbable parameter.

Formatting may break if the end position has an address greater than 65535.

=head1 FEEDBACK

I welcome constructive criticism and bug reports.  Please report bugs either
by email or via RT:
  L<http://rt.cpan.org/Public/Dist/Display.html?Name=Data-Hexdumper>

The best bug reports contain a test file that fails with the code that is
currently in CVS, and will pass once it has been fixed.  The CVS repository
is on Sourceforge and can be viewed in a web browser here:
  L<http://drhyde.cvs.sourceforge.net/drhyde/perlmodules/Data-Hexdumper/>

=head1 AUTHOR

David Cantrell E<lt>F<david@cantrell.org.uk>E<gt>

=head1 LICENSE AND COPYRIGHT

Copyright 2001 - 2009 David Cantrell E<lt>F<david@cantrell.org.uk>E<gt>

This software is free-as-in-speech software, and may be used,
distributed, and modified under the terms of either the GNU
General Public Licence version 2 or the Artistic Licence.  It's
up to you which one you use.  The full text of the licences can
be found in the files GPL2.txt and ARTISTIC.txt, respectively.

=head1 CONSPIRACY

This module is also free-as-in-mason software.

=head1 THANKS TO ...

MHX, for reporting a bug when dumping a single byte of data

Stefan Siegl, for reporting a bug when dumping an ASCII 0

=cut