package Test::Schema::EmailAddress;

use Moose;
extends 'DBIx::Class';

__PACKAGE__->load_components("Core");
__PACKAGE__->table('tblemail_address');

__PACKAGE__->add_columns(
    email_address_id                        => {},
    email_address                           => { data_type => 'varchar' },
    unwanted_time                           => { data_type => 'datetime', is_nullable => 1 },
    undeliverable_time                      => { data_type => 'datetime', is_nullable => 1 },
);

__PACKAGE__->set_primary_key('email_address_id');
__PACKAGE__->add_unique_constraint(['email_address']);

__PACKAGE__->might_have('user', 'Test::Schema::User',
        { 'foreign.email_address' => 'self.email_address',
        },{
          'cascade_delete' => 0,
        }
    );

no Moose;

1;
