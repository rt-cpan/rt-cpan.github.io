package Test::Schema::Publisher;

use 5.010;
use strict;
use warnings;
use base 'DBIx::Class';

__PACKAGE__->load_components("Core");
__PACKAGE__->table('tblpublisher');
__PACKAGE__->add_columns(
    publisher_id                    => {},
    name                            => {},
    suppress_user_emails            => {},
    has_non_branded_experience      => {},
);

__PACKAGE__->set_primary_key('publisher_id');
__PACKAGE__->add_unique_constraint(name => [qw(name)]);

1;

