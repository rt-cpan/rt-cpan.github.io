package Test::Schema;

use strict;
use warnings;

use parent 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces(
    result_namespace        => '+Test::Schema',
    resultset_namespace     => '+Test::ResultSet',
);

1;
