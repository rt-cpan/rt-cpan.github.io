package Test::ResultSet::User;

use strict;
use warnings;
use base 'DBIx::Class::ResultSet';

sub emailable {
    my ($class, %args) = @_;
    my $email_type_id = $args{email_type_id};
    my $schema = $class->result_source->schema;

    my $email_type = ($email_type_id) ?
        $schema->resultset('EmailType')->find($email_type_id) : undef;
    my $is_transactional = ($email_type) ?
        $email_type->is_transactional : undef;

    my $rs = $class->search({
        'email_unsub.unwanted_time'      => undef,
        'email_unsub.undeliverable_time' => undef,
    }, { join => ['email_unsub'] } );

    if ((defined($email_type) && ($email_type->identifier =~ m/welcome/i))
        || (defined($is_transactional) && !$is_transactional)
    ) {
        $rs = $rs->search({ 'me.suppressed_time' => undef });
        $rs = $rs->search({
            -or => [
                'me.publisher_id'   => undef,
                -and                => [
                    'me.publisher_id'                       => { '!=' => undef },
                    'publisher_left.suppress_user_emails'   => 0,
                ],
            ],
        }, {
            join => 'publisher_left',
        });
    } elsif (!$email_type_id || ($email_type_id != 3)) {
        $rs = $rs->search({
            -or => [
                'me.publisher_id'   => undef,
                -and                => [
                    'me.publisher_id'                       => { '!=' => undef },
                    'publisher_left.suppress_user_emails'   => { -in => [0, 1] },
                ],
            ],
        }, {
            join => 'publisher_left',
        });
    }

    $rs = $rs->search({
        -or => [
            'me.publisher_id'   => undef,
            -and                => [
                'me.publisher_id'                           => { '!=' => undef },
                'publisher_left.has_non_branded_experience' => 0,
            ],
        ],
    }, {
        join => 'publisher_left',
    });

    return $rs;
}

1;

