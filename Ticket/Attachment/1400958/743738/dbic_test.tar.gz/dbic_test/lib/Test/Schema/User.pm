package Test::Schema::User;

use strict;
use warnings;
use base 'DBIx::Class';

__PACKAGE__->load_components("Core");
__PACKAGE__->table('tbluser');

__PACKAGE__->add_columns(
    user_id        => {},
    email_address => {},
    publisher_id  => {},
    suppressed_time => {},
);

__PACKAGE__->set_primary_key('user_id');

__PACKAGE__->add_unique_constraint('email_address' => [ 'email_address' ]);

__PACKAGE__->might_have('email_unsub' => 'Test::Schema::EmailAddress',
    { 'foreign.email_address' => 'self.email_address' });

__PACKAGE__->belongs_to('publisher_left' => 'Test::Schema::Publisher',
    'publisher_id', { join_type => 'left' },
);

1;

