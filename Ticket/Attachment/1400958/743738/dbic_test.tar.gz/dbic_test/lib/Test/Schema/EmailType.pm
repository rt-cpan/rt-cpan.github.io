package Test::Schema::EmailType;

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");
__PACKAGE__->table('tblemail_type');
__PACKAGE__->add_columns(
    email_type_id       => {},
    identifier          => {},
    name                => {},
    is_transactional    => {},
);

__PACKAGE__->set_primary_key('email_type_id');

__PACKAGE__->add_unique_constraint(
    identifier => [ qw/identifier/ ],
);

1;
