#!/usr/bin/env perl

use strict;
use warnings;

use lib '../lib';

use Test::More;
use Data::Dumper;
use Path::Class;

use v5.10;
use Test::Schema;
use DateTime;
#use Path::Class;

my $db_file = file( 't', 'db', 'dbic_test.db');
my $sql_file = file( 't', 'db', 'dbic_test.sql' );

`rm $db_file`;

system( 'sqlite3', '-init', $sql_file, $db_file, '.q' );

my $schema = Test::Schema->connect('dbi:SQLite:t/db/dbic_test.db');

ok( $schema );

my $user = $schema->resultset('User')->find(600727);

ok( $user );

emailable();

done_testing;

sub emailable {

    my $test_d = 'emailable';

    # Test user suppression
    my $rs = $schema->resultset('User');
    my $user_count = $rs->emailable->count;
    is( $user_count, 12, 'initial emailable user count ok' );

    my ($user) = $rs->find({ user_id => 600727 });
#   $user->roles('abuser');
    # set suppresssed_time instead
    $user->suppressed_time(DateTime->now);
    $user->update;
    $user = $rs->find({ user_id => 600726 });
    $user->suppressed_time(DateTime->now);
    $user->update;

    is($rs->emailable(email_type_id => 9)->count, $user_count,
        "$test_d: emailable user count is not decreased after setting suppression for transactional email type");

    is($rs->emailable(email_type_id => 1)->count, $user_count - 2,
        "$test_d: emailable user count is decreased by 2 for welcome email types");

    is($rs->emailable(email_type_id => 6)->count, $user_count - 2,
        "$test_d: emailable user count is decreased by 2 for a non-transactional email type");

    # Test suppression by publisher
    my $user1 = $schema->resultset('User')->create({
        user_id => '99901',
        email_address => '99901@nowhere.com',
    });
    my $user2 = $schema->resultset('User')->create({
        user_id => '99902',
        email_address => '99902@nowhere.com',
    });
    my $user3 = $schema->resultset('User')->create({
        user_id => '99903',
        email_address => '99903@nowhere.com',
    });
    my $user4 = $schema->resultset('User')->create({
        user_id => '99904',
        email_address => '99904@nowhere.com',
    });

    is($rs->emailable(email_type_id => 9)->count, $user_count + 4,
        "$test_d: emailable user count increased by 4 after adding 4 users");


    my $pub2 = $schema->resultset('Publisher')->create({
        publisher_id => 88802,
        suppress_user_emails => 0,
        name => 'Publisher2',
    });
    my $pub3 = $schema->resultset('Publisher')->create({
        publisher_id => 88803,
        suppress_user_emails => 1,
        name => 'Publisher3',
    });
    my $pub4 = $schema->resultset('Publisher')->create({
        publisher_id => 88804,
        suppress_user_emails => 2,
        name => 'Publisher4',
    });


    $user2->publisher_id($pub2->publisher_id); $user2->update;
    $user3->publisher_id($pub3->publisher_id); $user3->update;
    $user4->publisher_id($pub4->publisher_id); $user4->update;
$DB::single=1;
    is($rs->emailable(email_type_id => 9)->count, $user_count + 3,
        "$test_d: emailable user count decreased by 1 for transactional email");
    is($rs->emailable(email_type_id => 6)->count, $user_count,
        "$test_d: emailable user count decreased by 2 for non-transactional email");
    is($rs->emailable(email_type_id => 3)->count, $user_count + 4,
        "$test_d: emailable user count stays the same for password reset email");

    # Test users from publishers configured for the non-branded experience
    my $start_count = $rs->emailable(email_type_id => 1)->count;
    my $user5 = $schema->resultset('User')->create({
        user_id => '99905',
        email_address => '99905@nowhere.com',
    });
    my $user6 = $schema->resultset('User')->create({
        user_id => '99906',
        email_address => '99906@nowhere.com',
    });
    is($rs->emailable(email_type_id => 1)->count, $start_count + 2,
        "$test_d: emailable count is correct before adding non-branded publishers");
    my $pub5 = $schema->resultset('Publisher')->create({
        publisher_id => 88805,
        has_non_branded_experience => 0,
    });
    my $pub6 = $schema->resultset('Publisher')->create({
        publisher_id => 88806,
        has_non_branded_experience => 1,
    });
    $user5->publisher_id($pub5->publisher_id); $user5->update;
    $user6->publisher_id($pub6->publisher_id); $user6->update;
    is($rs->emailable(email_type_id => 1)->count, $start_count + 1,
        "$test_d: emailable count decreased by one after adding 1 user from a non-branded publisher");

}
