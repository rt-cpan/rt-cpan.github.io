BEGIN TRANSACTION;

CREATE TABLE tbluser (
   user_id INTEGER PRIMARY KEY,
   email_address VARCHAR(255),
   publisher_id INTEGER,
   suppressed_time DATETIME NULL DEFAULT NULL
);

INSERT INTO "tbluser" VALUES ( 100000, 'technology@campusexplorer.com', NULL, NULL );
INSERT INTO "tbluser" VALUES ( 600221, 'jerry@campusexplorer.com', 17,  NULL );
INSERT INTO "tbluser" VALUES ( 600243, 'steve@campusexplorer.com', NULL, NULL );
INSERT INTO "tbluser" VALUES ( 600726, 'jflorin@madisonmedia.edu', NULL, NULL );
INSERT INTO "tbluser" VALUES ( 600727, 'frzntundraguy@msn.com',    NULL, NULL );
INSERT INTO "tbluser" VALUES ( 1448057, 'jwright@campusexplorer.com', NULL, NULL );
INSERT INTO "tbluser" VALUES ( 1544585, 'goldmine.leads@deltakedu.com', NULL, NULL );
INSERT INTO "tbluser" VALUES ( 1990482, 'jytka@yahoo.com', 64, NULL );
INSERT INTO "tbluser" VALUES ( 2141988, 'tannersvilleinfo@pegschools.com', NULL, NULL );
INSERT INTO "tbluser" VALUES ( 2141989, 'wilkes-barreCDEinfo@pegschools.com', NULL, NULL );
INSERT INTO "tbluser" VALUES ( 2141993, 'rdf21@aol.com', 17, NULL );
INSERT INTO "tbluser" VALUES ( 2141994, 'emily_dipietro@yahoo.com', 17, NULL );
INSERT INTO "tbluser" VALUES ( 2539417, 'bgehring@stahl.cc', NULL, NULL );
INSERT INTO "tbluser" VALUES ( 2754815, 'mhunter@campusexplorer.com', NULL, NULL );
INSERT INTO "tbluser" VALUES ( 2754840, 'amiribarksdale@gmail.com', NULL, NULL );


CREATE TABLE tblemail_address (
   email_address_id INTEGER PRIMARY KEY,
   email_address VARCHAR(255),
   unwanted_time DATETIME NULL DEFAULT NULL,
   undeliverable_time TIMESTAMP NULL DEFAULT NULL
);

INSERT INTO "tblemail_address" VALUES ( 1, 'technology@campusexplorer.com', NULL,  '2010-06-05 01:05:34');
INSERT INTO "tblemail_address" VALUES ( 5, 'steve@campusexplorer.com', NULL, '2011-03-01 10:29:50');
INSERT INTO "tblemail_address" VALUES ( 473, 'jflorin@madisonmedia.edu', NULL, NULL );
INSERT INTO "tblemail_address" VALUES ( 474, 'frzntundraguy@msn.com', NULL, NULL );
INSERT INTO "tblemail_address" VALUES ( 944332, 'goldmine.leads@deltakedu.com', NULL, NULL );
INSERT INTO "tblemail_address" VALUES ( 1390229, 'jytka@yahoo.com', NULL, NULL );
INSERT INTO "tblemail_address" VALUES ( 1541735, 'tannersvilleinfo@pegschools.com', NULL, NULL );
INSERT INTO "tblemail_address" VALUES ( 1541736, 'wilkes-barreCDEinfo@pegschools.com', NULL, NULL );
INSERT INTO "tblemail_address" VALUES ( 1541740, 'rdf21@aol.com', NULL, '2011-05-07 03:30:42');
INSERT INTO "tblemail_address" VALUES ( 1541741, 'emily_dipietro@yahoo.com',  NULL, NULL );
INSERT INTO "tblemail_address" VALUES ( 1939139, 'bgehring@stahl.cc', NULL, NULL );
INSERT INTO "tblemail_address" VALUES ( 2154495, 'mhunter@campusexplorer.com', NULL, NULL );


CREATE TABLE tblpublisher (
   publisher_id INTEGER PRIMARY KEY,
   name VARCHAR(64),
   suppress_user_emails INTEGER NOT NULL DEFAULT 0,
   has_non_branded_experience INTEGER NOT NULL DEFAULT 0
);

INSERT INTO "tblpublisher" VALUES (17, 'Alpha Publisher', 0, 0);
INSERT INTO "tblpublisher" VALUES (64, 'Beta Publisher', 0, 0);
INSERT INTO "tblpublisher" VALUES (3, 'Gamma Publisher', 1, 0);

CREATE TABLE tblemail_type (
   email_type_id INTEGER PRIMARY KEY,
   identifier VARCHAR(255) NOT NULL,
   name VARCHAR(255) NOT NULL,
   is_transactional INTEGER NOT NULL DEFAULT 0
);

INSERT INTO "tblemail_type" VALUES (1, 'welcome', 'Welcome', 1 );
INSERT INTO "tblemail_type" VALUES (3, 'password-reset', 'Password Reset', 1);
INSERT INTO "tblemail_type" VALUES (5, 'non-partner-lead-reqest', 'Non-Partner Lead Request', 1 );
INSERT INTO "tblemail_type" VALUES (6, 'college-picks-1', 'Upsell 1', 0 );
INSERT INTO "tblemail_type" VALUES (9, 'scholarship-application', 'Scholarship Application', 1 );


COMMIT;
