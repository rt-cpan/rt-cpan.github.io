# Copyrights 1998,2005-2011 by Mark Overmeer.
#  For other contributors see ChangeLog.
# See the manual pages for details on the licensing terms.
# Pod stripped from pm file by OODoc 2.00.
use warnings;
use strict;

package CPAN::Site;
use vars '$VERSION';
$VERSION = '1.09';


1;
