alter table "dbiv_test" add column (a_text_col varchar(3);
