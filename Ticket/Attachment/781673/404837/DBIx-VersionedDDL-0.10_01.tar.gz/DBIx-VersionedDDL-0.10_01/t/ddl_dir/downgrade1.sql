drop table "dbiv_test";
drop table comments_test;