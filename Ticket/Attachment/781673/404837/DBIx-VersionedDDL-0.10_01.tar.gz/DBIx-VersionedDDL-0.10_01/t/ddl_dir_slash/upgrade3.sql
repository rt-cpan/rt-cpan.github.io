create table max_test (id number)
/
