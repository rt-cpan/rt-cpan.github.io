create table dbiv_test(id number)
/
--
-- Add some comments
--

/*
   and some multipline comments 
*/
create table comments_test(
   id number, # surrogate key
   c1 varchar(1), // Another comment
   c4 integer /* These comments keep on coming */
)
/
