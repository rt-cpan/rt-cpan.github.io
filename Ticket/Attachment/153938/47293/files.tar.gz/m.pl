#!/usr/bin/perl

use strict;

use Data::Dumper;
use DBI;

my $dbh=DBI->connect("dbi:SQLite:dbname=foobar.sdb");

my $sql="SELECT * FROM testing";
my $sth=$dbh->prepare($sql);
$sth->execute();

print Dumper($sth->fetchall_arrayref);
