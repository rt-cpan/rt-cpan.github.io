#!/usr/bin/perl -w

use strict;

use Data::Dumper;

use Class::DBI::AutoLoader (
	dsn => 'dbi:SQLite:dbname=foobar.sdb',
	options => { RaiseError => 1 },
	namespace => 'POS'
);

print $Class::DBI::AutoLoader::VERSION."\n\n";
my @t=POS::Testing->retrieve_all();

print Dumper(@t);

