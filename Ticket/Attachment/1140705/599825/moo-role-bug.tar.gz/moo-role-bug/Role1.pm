package Role1;
use Moo::Role;
use Helper1;
sub r1 { 'r1' };
1;
