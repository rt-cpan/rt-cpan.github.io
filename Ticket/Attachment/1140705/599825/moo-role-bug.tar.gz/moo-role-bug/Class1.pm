package Class1;
use Moo;
with qw(Role1);
sub c1 { 'c1' };
1;
