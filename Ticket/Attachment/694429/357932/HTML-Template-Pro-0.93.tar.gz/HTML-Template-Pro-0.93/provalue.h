#ifndef _PROVALUE_H
#define _PROVALUE_H	1

#include<pabidecl.h>

TMPLPRO_LOCAL PSTRING _get_variable_value (struct tmplpro_param *param, PSTRING name);

#endif /* provalue.h */

/*
 * Local Variables:
 * mode: c
 * End:
 */
