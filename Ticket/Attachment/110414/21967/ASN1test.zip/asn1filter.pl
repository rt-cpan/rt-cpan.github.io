#!/usr/bin/perl -w

use Data::Dumper;
use Getopt::Std;
use Convert::ASN1 qw(:io :debug);

getopts('s:D', \%opts);
if (!defined($opts{'s'})) {
	print STDERR "Missing ASN.1 Specification file!\n";
	HELP_MESSAGE();
	exit 1;
}
$specfile	= $opts{'s'};
$DEBUG		= $opts{'D'};

$asn = Convert::ASN1->new;
$asn->configure('decode'=>{'time'=>'raw'});
$r   = $asn->prepare_file($specfile);

if (!defined($r)) { die "ERROR: " . $asn->error . "\n"; }

print "BEGIN SPECIFICATION:\n"	if $DEBUG;
$asn->dump						if $DEBUG;
print "END SPECIFICATION\n"		if $DEBUG;

exit;
#
# STOP HERE!
# JUST TO DEBUG IF ASN.1 spec gets parsed correctly...
#
while ( $readbytes = asn_read(STDIN, $buffer) ) {
	if ( $readbytes < 0 ) { die "ERROR: Not enough data!\n"; }
	asn_hexdump( $buffer )	if $DEBUG;
	asn_dump( $buffer )		if $DEBUG;
	$pdu = $asn->decode( $buffer ) or die "ERROR decoding: " . $asn->error . "\n";
	print Dumper($pdu)		if $DEBUG;
}
exit;

sub HELP_MESSAGE {
	print STDERR <<END;
Usage: asn1filter.pl -s <ASN.1SpecFile> [-D] < <DataFile>
Where:
	<ASN.1SpecFile>: is the file containing the ASN.1 specification of the data to be parsed.
	<DataFile>: is the Data file
	-D Activate Debug mode
END
	return;
}
