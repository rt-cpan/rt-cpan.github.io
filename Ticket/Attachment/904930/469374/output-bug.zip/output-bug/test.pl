#!/usr/bin/perl

use XML::Saxon::XSLT2;

# make sure to open filehandle in right encoding
open(my $input, '<:encoding(UTF-8)', 'in.xml') or die $!;
open(my $xslt, '<:encoding(UTF-8)', 'out.xsl') or die $!;

my $trans  = XML::Saxon::XSLT2->new($xslt);
my $output = $trans->transform($input);
print $output;
