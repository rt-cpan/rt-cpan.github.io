package FooBar::Bar;

use strict;
use warnings;

our $VERSION = '0.01';

require XSLoader;
XSLoader::load('FooBar::Bar', $VERSION);

1;

__END__
