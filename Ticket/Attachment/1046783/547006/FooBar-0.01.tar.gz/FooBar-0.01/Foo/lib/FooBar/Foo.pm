package FooBar::Foo;

use strict;
use warnings;

our $VERSION = '0.01';

require XSLoader;
XSLoader::load('FooBar::Foo', $VERSION);

1;

__END__
