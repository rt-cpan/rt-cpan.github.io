package MyApp::Controller::Root;

use strict;
use warnings;
use parent 'Catalyst::Controller';

#
# Sets the actions in this controller to be registered with no prefix
# so they function identically to actions created in MyApp.pm
#
__PACKAGE__->config->{namespace} = '';

sub index :Path :Args(0) {
    my ( $self, $c ) = @_;

    $c->response->body('No problem, now try /loader or /manual');
}

sub loader : Local {
    my ($self, $c) = @_;
    $c->model('Loader::Foo')->find(1);
    $c->response->body('No problem with DBIC-Loader');
}

sub manual : Local {
    my ($self, $c) = @_;
    $c->model('Manual::Foo')->find(1);
    $c->response->body('No problem with DBIC-Schema manually');
}

sub default :Path {
    my ( $self, $c ) = @_;
    $c->response->body( 'Page not found' );
    $c->response->status(404);
}

sub end : ActionClass('RenderView') {}

1;
