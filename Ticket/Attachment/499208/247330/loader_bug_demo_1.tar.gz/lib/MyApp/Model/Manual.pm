package MyApp::Model::Manual;

use strict;
use base 'Catalyst::Model::DBIC::Schema';

__PACKAGE__->config(
    schema_class => 'MyApp::SchemaManual',
    connect_info => [
        'dbi:Pg:dbname=tjc',
        'lighttpd',
        ''
    ],
);

1;
