package MyApp::Model::Loader;

use strict;
use base 'Catalyst::Model::DBIC::Schema';

__PACKAGE__->config(
    schema_class => 'MyApp::Schema',
    connect_info => [
        'dbi:Pg:dbname=tjc',
        'lighttpd',
        ''
    ],
);

1;
