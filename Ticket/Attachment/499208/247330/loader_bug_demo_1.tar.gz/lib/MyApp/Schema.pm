package MyApp::Schema;
use strict;
use warnings;

use base qw/DBIx::Class::Schema::Loader/;

1;
