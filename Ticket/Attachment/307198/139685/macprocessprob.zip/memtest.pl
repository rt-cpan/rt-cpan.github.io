#!/usr/bin/perl -w

use Mac::Processes;

while ( ($psn, $psi) = each(%Process) ) {
    print "$psn\t";
    print $psi->processName,       " ",
          $psi->processNumber,     "\n" if $psi;
}



