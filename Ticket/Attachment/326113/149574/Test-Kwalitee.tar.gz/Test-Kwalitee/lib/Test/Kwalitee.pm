package Test::Kwalitee;

use Cwd;
use Test::Builder;
use Module::CPANTS::Analyse;
use Module::CPANTS::Kwalitee;

use strict;
use warnings;

use vars qw( $Test $VERSION );
$VERSION = '0.31';

BEGIN { $Test = Test::Builder->new() }

my (%test_types, $mck, @always_excluded_tests);
BEGIN
{
	$mck = Module::CPANTS::Kwalitee->new;
	%test_types = %{$mck->get_indicators_hash};
	
	# maybe skip those indicators that are marked as "is_extra"
	@always_excluded_tests = qw(
		-extracts_nicely
		-has_version
		-has_proper_version
		-is_prereq
		-no_cpants_errors
		-manifest_matches_dist
	);
	
	while (my ($subname, $value) = each %test_types)
	{
		my $sub = sub
		{
			my ($dist, $metric) = @_;
			$Test->ok( $metric->{code}->( $dist ), $subname ) ||
				$Test->diag( @{ $metric }{qw( remedy error )} );
		};

		no strict 'refs';
		*{ $subname } = $sub;
	}
}

sub import
{
	my ($class, %args)   = @_;
	$args{basedir}     ||= cwd();
	$args{tests}       ||= [];
	my @tests            = @{ $args{tests} } ?
	                       @{ $args{tests} } : keys %test_types;
	@tests               = keys %test_types if grep { /^-/ } @tests;

	my %run_tests;

	for my $test ( @tests, @{ $args{tests} }, @always_excluded_tests )
	{
		if ( $test =~ s/^-// )
		{
			delete $run_tests{$test};
		}
		else
		{
			$run_tests{$test} = 1;
		}
	}

	my $analyzer = Module::CPANTS::Analyse->new({
		distdir => $args{basedir},
	});

	$Test->plan( tests => scalar keys %run_tests );
	for my $generator (@{ $analyzer->mck()->generators() } )
	{
		next if $generator =~ /Unpack/;
		next if $generator =~ /CPAN$/;
		next if $generator =~ /Authors$/;

		# no distname, so no warnings here
		{
			local $^W;
			$generator->analyse($analyzer);
		}

		for my $indicator (@{ $generator->kwalitee_indicators() })
		{
			next unless $run_tests{ $indicator->{name} };
			my $sub = __PACKAGE__->can( $indicator->{name} );
			next unless $sub;
			$sub->( $analyzer->d(), $indicator );
		}
	}
}

1;
__END__

=head1 NAME

  Test::Kwalitee - Test the Kwalitee of a distribution before you release it

=head1 SYNOPSIS

  # in a separate test file
  use Test::More;

  eval { require Test::Kwalitee; Test::Kwalitee->import() };

  plan( skip_all => 'Test::Kwalitee not installed; skipping' ) if $@;

=head1 DESCRIPTION

Kwalitee is an automatically-measurable gauge of how good your software is.
That's very different from quality, which a computer really can't measure in a
general sense.  (If you can, you've solved a hard problem in computer science.)

In the world of the CPAN, the CPANTS project (CPAN Testing Service; also a
funny acronym on its own) measures Kwalitee with several metrics.  If you plan
to release a distribution to the CPAN -- or even within your own organization
-- testing its Kwalitee before creating a release can help you improve your
quality as well.

C<Test::Kwalitee> and a short test file will do this for you automatically.

=head1 USAGE

Create a test file as shown in the synopsis.  Run it.  It will run all of the
potential Kwalitee tests on the current distribution, if possible.  If any
fail, it will report those as regular diagnostics.

If you ship this test and a user does not have C<Test::Kwalitee> installed,
nothing bad will happen.

To run only a handful of tests, pass their names to the module's C<import()>
method:

  eval
  {
      require Test::Kwalitee;
	  Test::Kwalitee->import( tests => [ qw( use_strict has_tests ) ] );
  };

To disable a test, pass its name with a leading minus (C<->) to C<import()>:

  eval
  {
      require Test::Kwalitee;
	  Test::Kwalitee->import( tests =>
	  	[ qw( -has_test_pod -has_test_pod_coverage ) ]
      );
  };



As of version 0.31, the tests include are dynamically generated from
C<Module::CPANTS::Kwalitee>. See C<Module::CPANTS::Kwalitee::*> module POD for
names of Kwalitee Indicators that are tested.

Some Kwalitee indicators are not applicable before a distribution is made, thus
these are not tested.

=head1 AUTHOR

chromatic, E<lt>chromatic at wgz dot orgE<gt>
Nathan S. Haigh E<lt>nathanhaigh at ukonline dot co dot ukE<gt>

With thanks to CPANTS and Thomas Klausner, as well as test tester Chris Dolan.

=head1 BUGS

No known bugs.

=head1 COPYRIGHT

Copyright (c) 2005 - 2007, chromatic.  Some rights reserved.

This module is free software; you can use, redistribute, and modify it under
the same terms as Perl 5.8.x.
