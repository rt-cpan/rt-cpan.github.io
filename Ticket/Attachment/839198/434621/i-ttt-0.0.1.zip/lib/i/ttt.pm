use strict;
use warnings;
package i::ttt;
BEGIN {
  $i::ttt::VERSION = '0.01';
}

use Text::CSV_XS;
use IO::Scalar;


my $csv_printer = Text::CSV_XS->new({
    always_quote        => 0,
    binary              => 1,
    eol                 => "\015\012",
})  or  die "There was an error creating the CSV printer module!\n";


sub go{
    my $handle = IO::Scalar->new;
    $csv_printer->print( $handle, [qw/ test test /] );
    return ${ $handle->sref };
}

1;
