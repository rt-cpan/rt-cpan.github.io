package TestOIO;

use version; $VERSION = qv('0.0.1');

use warnings;
use strict;


use Object::InsideOut;

my @normal :Field
    :Acc(normal)
    :Arg('Name' => 'normal', 'Default' => 23);

my @std_all :Field :Std_All(std_all);

my @acc_normal_arg_explicit :Field :Std(acc_normal_arg_explicit) :Arg('Name' => 'acc_normal_arg_explicit', 'Default' => 0);

1; # Magic true value required at end of module
