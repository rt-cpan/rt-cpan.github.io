package LWP::UserAgent::AG;


use base 'LWP::UserAgent';

#use LWP::Debug qw(+ -conns);
#use LWP::Debug qw(+);

sub new {
    my $class = shift;
    my %options = @_;
    my $self  = $class->SUPER::new;
    $self->timeout(10);
    $self->env_proxy;
    $self->default_header('Accept' => "application/json");
    if ($options{AUTHENTICATION}) {
	( $self->{USERNAME}, $self->{PASSWORD} ) = ($options{AUTHENTICATION} =~ /^(.+):(.*)$/);
    }
    return $self;
}

sub get_basic_credentials {
    my $self = shift;
    return ($self->{USERNAME}, $self->{PASSWORD});
}

package RDF::AllegroGraph::Server;

use strict;
use warnings;

require Exporter;
use base qw(Exporter);

=pod

=head1 NAME

RDF::AllegroGraph::Server - AllegroGraph server handle

=cut

our $VERSION  = '0.02';

=head1 SYNOPSIS

  #-- orthodox approach
  my $server = new RDF::AllegroGraph::Server (ADDRESS        => 'http://localhost:8080',
                                              TEST           => 0,
                                              AUTHENTICATION => 'joe:secret');
  my @catalogs = $server->catalogs;

  #-- commodity
  # get handles to all models (repositories) at the server
  my @models = $server->models;

  # get one in particular
  my $model  = $server->model ('/testcat/testrepo');

=cut

use Data::Dumper;
use HTTP::Request;
use HTTP::Status;
use JSON;
use POSIX;

use RDF::AllegroGraph::Catalog;

=pod

=head1 DESCRIPTION

Objects of this class represent handles to remote AllegroGraph HTTP server. Such a server can hold
several I<catalogs> and each of them can hold I<repositories>. Here we also use the orthodox concept
of a I<model> which is simply one particular repository in one particular catalog.

For addressing one model we use a simple path structure, such as C</testcat/testrepo>.

All methods die with C<protocol error> if they do not receive an expected success.

=head1 INTERFACE

=head2 Constructor

To get a handle to the AG server, you can instantiate this class. The following options are
recognized:

=over

=item C<ADDRESS> (no default)

Specifies the REST HTTP address. Must be an absolute URL, without trailing slash. The
constructor dies otherwise.

=item C<TEST> (default: 0)

If set, the client will try to test connectivity with the AG server.

=item C<AUTHENTICATION> (no default)

String which must be of the form C<something:somethingelse> (separated by C<:>). That will be interpreted
as username and password to do basic HTTP authentication against the server.

=back

=cut

sub new {
    my $class   = shift;
    my %options = @_;
    die "no HTTP URL as ADDRESS specified" unless $options{ADDRESS} =~ q|^http://|;
    my $self = bless \%options, $class;
    $self->{ua} = new LWP::UserAgent::AG (AUTHENTICATION => $options{AUTHENTICATION});
    $self->{TEST} and 
        ( $self->ping or die "server unreachable" );
    return $self;
}

=pod

=head2 Methods

=over

=item B<catalogs>

I<@cats> = I<$server>->catalogs

This method lists the catalogs available on the remote server. The result is a list of relative
paths. 

=cut

sub catalogs {
    my $self = shift;
    my $resp = $self->{ua}->get ($self->{ADDRESS} . '/catalogs');
    die "protocol error: ".$resp->status_line unless $resp->is_success;
    my $cats = from_json ($resp->content);
    # warn Dumper $cats;
    my $iVersion = $self->version;
    my @asNames = ($iVersion lt 4) ? 
    # For AGraph version 3.3, look at substrings:
    map { s|^/catalogs|| && $_ } @$cats : 
    # For AGraph version 4.1, pick apart the hash:
    map {
      # warn Dumper $_;
      q{/}. $_->{id}
      } @$cats;
    # warn Dumper \@asNames;
    return map { $_ => RDF::AllegroGraph::Catalog->new (NAME => $_,
                                                        SERVER => $self) } @asNames;
    } # catalogs

=item B<catalog>

I<$cata> = I<$cat>->catalog (I<$cata_id> [, I<$mode> ])

This method returns an L<RDF::AllegroGraph::Catalog> object for the catalog with
the provided id. That id always has the form C</catalogname>.

If that catalog does not exist on the server, then an exception C<cannot open> will be
raised. That is, unless the optional I<mode> is provided having the POSIX value C<O_CREAT>. Then the
catalog will be created.

=cut

sub catalog
  {
  my $self = shift;
  my $id   = shift;
  my $mode = shift || O_RDONLY;
  # warn " DDD Server::catalog($id, $mode)\n";
  if (my ($repo) = grep { ref $_ &&
                          # do { print STDERR " DDD   ". $_->id ."\n" } &&
                          ($_->id eq $id) } $self->catalogs)
    {
    return $repo;
    }
  elsif ($mode == O_CREAT)
    {
    my $requ = HTTP::Request->new (PUT => $self->{ADDRESS} . '/catalogs' . $id);
    # warn Dumper $requ;
    my $resp = $self->{ua}->request ($requ);
    # warn Dumper $resp;
    if (
        ($resp->code == RC_NO_CONTENT)
        ||
        ($resp->content =~ m/There is already/)
       )
      {
      return $self->catalog($id);  # recursive, but without forced create
      }
    die "protocol error: ".$resp->status_line;
    }
  else
    {
    die "cannot open catalog '$id'";
    }
  } # catalog

=item version

Returns the version of AllegroGraph running on this server, for example "3.3" or "4.1".
Returns zero (0) if the version can not be determined at the present time.

=cut

# TODO: memoize this value, so we don't fetch from the server every
# time it's needed.  And because in AGraph 3.3 we can only get the
# server version from the catalog level -- so we have to have a
# catalog first!
sub version
  {
    my $self = shift;
    my $sRet;
    # This is for AGraph 4:
    my $sURL = $self->{ADDRESS} . '/version';
    my $resp = $self->{ua}->get($sURL);
    if ($resp->is_success)
      {
      $sRet = eval $resp->content;
      } # if
    else
      {
      # If we get here, AGraph seems not to be version 4.  Make sure
      # there is an AGraph server listening here.  Unfortunately, ALL
      # requests start with the /catalogs protocol.  Ask for that and
      # just make sure we get a response.  By design, this version()
      # method needs to be as lightweight and independent as possible,
      # so we don't want to "waste time" looking for a particular
      # catalog and getting the version number from there.  In fact,
      # we need to know the version before we can even parse the
      # catalogs list!
      $sURL = $self->{ADDRESS} . '/catalogs';
      $resp = $self->{ua}->get($sURL);
      if ($resp->is_success)
        {
        $sRet = 3.3;
        } # if
      } # else
    $sRet ||= 0;
    print STDERR " DDD   return version=$sRet\n";
    return $sRet;
  } # version


=item B<ping>

I<$server>->ping

This method tries to connect to the server and will return C<1> on success. Otherwise an exception
will be raised.

=cut

sub ping {
    my $self = shift;
    $self->version and return 1;
}

=pod

=item B<models>

I<%models> = I<$server>->models

This method lists all models available on the server. Returned is a hash reference. The keys are the
model identifiers, all of the form C</somecatalog/somerepository>. The values are repository objects.

=cut

sub models {
    my $self = shift;
    my %cats = $self->catalogs; # find all catalogs
    # warn " DDD in Server->models, cats is ", Dumper %cats;
    return
	map { $_->id => $_ } # generate a hash, because the id is a good key
	map { $_->repositories }  # generate from the catalog all its repos
        values %cats;
}

=pod

=item B<model>

I<$server>->model (I<$mod_id>, I<option1> => I<value1>, ...)

This method tries to find an repository in a certain catalog. This I<model id> is always of the form
C</somecatalog/somerepository>. The following options are understood:

=over

=item C<MODE> (default: C<O_RDONLY>)

This POSIX file mode determines how the model will be opened.

=back

If the model does already exist, then an L<RDF::AllegroGraph::Repository> object will be
returned. If the specified catalog does not exist, then a C<no catalog> exception will be raised.
Otherwise, if the repository there does not exist and the C<MODE> option is C<O_CREAT>, then it will
be generated. Otherwise an exception C<cannot open repository> will be raised.

=cut

sub model {
    my $self = shift;
    my $id   = shift;
    my %options = @_;

    my ($catid, $repoid) = ($id =~ q|\A(/.+?)(/.+)\z|) or die "id must be of the form /catalogname/modelname";

    my $catalog = $self->catalog($catid, O_CREAT);
    die "no catalog '$catid'" unless $catalog;

    return $catalog->repository ($id, $options{mode});
}

=back

=head1 AUTHOR

Robert Barta, C<< <rho at devc.at> >>

=head1 COPYRIGHT & LICENSE

Copyright 200[9] Robert Barta, all rights reserved.

This program is free software; you can redistribute it and/or modify it under the same terms as Perl
itself.

L<RDF::AllegroGraph>

=cut

1;

__END__

#sub protocol {
#    my $self = shift;
#    my $resp = $self->{ua}->get ($self->{ADDRESS} . '/protocol');
#    die "protocol error: ".$resp->status_line unless $resp->is_success;
#    return $resp->content;
#}

