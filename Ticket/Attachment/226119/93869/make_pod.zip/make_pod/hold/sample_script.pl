#!perl -w

use strict;

print "This does nothing but contain some POD stuff.\n";

=head1 This is a sample of POD

=over

=item One

=item Two

=back

=cut
