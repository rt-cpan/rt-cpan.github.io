#
#  from ppm *
#  30. Pod-Simple              [3.04] framework for parsing Pod
#

use strict;
use Pod::Simple::HTMLBatch;

my $batchconv = Pod::Simple::HTMLBatch->new;
$batchconv->batch_convert("./hold", "./htm" );

__END__
Sample Error Output

D:\testing\jlpoole\make_pod>perl -v

This is perl, v5.8.4 built for MSWin32-x86-multi-thread
(with 3 registered patches, see perl -V for more detail)

Copyright 1987-2004, Larry Wall

Binary build 810 provided by ActiveState Corp. http://www.ActiveState.com
ActiveState is a division of Sophos.
Built Jun  1 2004 11:52:21

Perl may be copied only under the terms of either the Artistic License or the
GNU General Public License, which may be found in the Perl 5 source kit.

Complete documentation for Perl, including FAQ lists, should be found on
this system using `man perl' or `perldoc perl'.  If you have access to the
Internet, point your browser at http://www.perl.com/, the Perl Home Page.

D:\testing\jlpoole\make_pod>perl make_pod.pl
T+0s: = Fri Jul 21 14:22:59 2006
T+0s: Starting batch conversion to "./htm"
T+0s: 1 dirs to scan: ./hold
#0: Scanning D:\testing\jlpoole\make_pod\hold\sample_script.pl
Noted 1 Pod files total
T+0s: Found 1 modules.
T+0s: Done scanning.
T+0s: Now converting pod files to HTML.
Can't write-open htm\_black_with_blue_on_white.css: No such file or directory at
 make_pod.pl line 10

D:\testing\jlpoole\make_pod>dir
 Volume in drive D is Local Disk
 Volume Serial Number is EC18-B9FA

 Directory of D:\testing\jlpoole\make_pod

07/21/2006  02:07p      <DIR>          .
07/21/2006  02:07p      <DIR>          ..
07/21/2006  02:21p      <DIR>          hold
07/21/2006  02:22p      <DIR>          html
07/21/2006  02:20p               1,443 make_pod.pl
               1 File(s)          1,443 bytes
               4 Dir(s)  80,502,562,816 bytes free

D:\testing\jlpoole\make_pod>
