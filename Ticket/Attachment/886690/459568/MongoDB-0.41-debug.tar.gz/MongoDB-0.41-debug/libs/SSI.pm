package SSI;

use lib qw(../libs/lib/perl5);

use SSI::Log;
use WWW::Mechanize;

use Hash::Util;

use POE;
use POE::Session;

use Data::Dumper;

use strict;
use warnings;


our $VERSION = '1.00';
our $AUTOLOAD;
our %OBJECTCONFIG;
$SIG{__WARN__} = 
	sub
	{
		SSI::Log::Warning("SIGWARN: ", @_); Backtrace();
	};

$SIG{__DIE__} = 
	sub 
	{
		die @_ if ($^S); # If this is called within an eval, die like normal.
	
		SSI::Log::Fatal("SIGDIE:", @_) if (!$^S);
	};

use LWP::ConnCache;

use fields qw/classid/;



# setting $ENV{SSI_VALIDATE_FIELDS} = 0 will make 
# this 20% faster, but will not check for typos in fields!
use constant SSI_VALIDATE_FIELDS => (defined($ENV{SSI_VALIDATE_FIELDS}) ? $ENV{SSI_VALIDATE_FIELDS} : 1);


# These are not enumerated by SSI::keys.
#my @ignoredFields = qw/classid/;
my %ignoredFields = map { $_ => 1 } (qw/classid/); 

our $mech;
our %validFieldHashes; # holds a reference to the %SSI::Some::Package::Name::FIELDS variable by classname.

{ # NO WARNINGS REDEFINE
no warnings 'redefine';

our $classidcounter = 0;
sub new
{
	my ($class, %args) = @_;
	#SSI::Log::Debug("$class: $classidcounter");
	
	my $self;
	my $key;

	# Bring in the valid fields to our self.  This will generate an error 
	# if new is called passing defining arguments that are not defined above, 
	# or by the module that is inheriting this constructor.
	$self = fields::new($class);

	if (SSI_VALIDATE_FIELDS)
	{
		eval {	
			$self->{classid} = $classidcounter++;
		};
		
		if ($@) 
		{
			Fatal("unable to access self->{classid}.  have you loaded $class?", $@);
		}
	}
		
	# If we have read default values from a config file, 
	# use them upon instantiation.
	if (defined($OBJECTCONFIG{$class}))
	{
		my $conf = $OBJECTCONFIG{$class};
		foreach $key (CORE::keys(%$conf))
		{
			Fatal("invalid key=$key in OBJECTCONFIG for class=$class.") if (SSI_VALIDATE_FIELDS && !$self->validField($key));
			
			if (!exists($args{$key}))
			{				
				$args{$key} = $conf->{$key};
				#Debug("OBJECTCONFIG{$class}: $key=$args{$key}");
			} 
		}
	}
	
	foreach $key (CORE::keys(%args))
	{
		if (SSI_VALIDATE_FIELDS)
		{
			$@ = undef;
			eval {
				$self->{$key} = $args{$key};
			};
			if ($@)
			{
				my %fieldhash = eval('%' . ref($self) . "::FIELDS");
				my $valid = $self->validField($key);
		
				Fatal(ref($self) . ": $@; valid=$valid; key=$key class::FIELDS=", %fieldhash) if ($@);	
			}
		}
		else
		{
			$self->{$key} = $args{$key};
		}
	}


	$self->init(%args);
			
	return $self; 
}


sub DESTROY{}


our $autodepth = 0;
sub AUTOLOAD 
{
	$autodepth++;
	
	# This line performs an optimization of this code:
	#	my $name = $AUTOLOAD;
	#	$name =~ s/.*://;   # strip fully-qualified portion
	my $name = substr($AUTOLOAD, rindex($AUTOLOAD, ':')+1);
		
	my $self = shift;
	
	my $ret;
	
	
	#SSI::Log::Fatal("deep recursion ($autodepth): $type -> $name"), return if ($autodepth > 3);
	
	if (SSI_VALIDATE_FIELDS)
	{
		if ($autodepth > 3)
		{
			my $type = ref($self);
			SSI::Log::Fatal("deep recursion ($autodepth): $type -> $name");
		} 
		
		if ($autodepth > 1 && $name =~ /^(Fatal|Log|Debug|Error|Backtrace)$/)
		{
			SSI::Log::Fatal("strange recursion (field cannot be: Fatal|Log|Debug|Error|Backtrace): field=" . $name, @_);
		}
	
		#print STDERR ($autodepth) . "\n";
	
		if (!exists($self->{$name}) && !$self->validField($name))
		{
			my $type = ref($self);
		    SSI::Log::Fatal("Can't access `$name' field in class $type");
		}
		
		if (@_ && $self->islocked)
		{
			SSI::Log::Fatal("cannot write to read-only class value: $self -> $name");
		}
	}

	if (@_) 
	{
    	$ret = $self->{$name} = shift;
	} 
	else 
	{
	    $ret = $self->{$name};
	}

	$autodepth--;
	return $ret;
}  

sub setObjectConfig
{
	my $conf = shift;
	
	if (ref($conf) ne 'SSI::Config')
	{
		Fatal("setObjectConfig called with object of type SSI::Config:", $conf);
	}

	%OBJECTCONFIG = ();	
	foreach my $key (keys( %{ $conf->config->{object} } ))
	{
		$OBJECTCONFIG{$key} = $conf->config->{object}->{$key};
		#Debug("objectconfig for key=$key: ", $OBJECTCONFIG{$key});
	}
	
}

sub validField
{
	my ($self, $name) = @_;
	
	return 1 if (exists $self->{$name});
	
	my $type = ref($self);
	my $h = $validFieldHashes{$type};
	
	if (!defined($h))
	{
		# Access %CLASSNAME::FIELDS to see if the variable is valid.  
		$h = $validFieldHashes{$type} = { eval('%' . "$type" . "::FIELDS") }; 
	}
	
	return defined($h->{$name})
	;
}


# Return the keys accessible in this class.
sub keys 
{
	my $self = shift;
	 
	my $type = ref($self);
	my $h = $validFieldHashes{$type};
	if (!defined($h))
	{
		# Access %CLASSNAME::FIELDS to see if the variable is valid.  
		$h = $validFieldHashes{$type} = { eval('%' . "$type" . "::FIELDS") }; 
	}
	
	my @keys;
	# Try to use the 'fields' generated %PACKAGE::FIELDS value, if it exists.  If not, use
	# the keys of the field itself.  Always ignore the @ignoredFields field.
	@keys = grep { !exists($ignoredFields{$_}) } CORE::keys(%$h); 
	@keys = grep { !exists($ignoredFields{$_}) } CORE::keys(%$self) if (!@keys);
	return @keys; 
}

sub contains
{
	my ($v, @a) = @_;

	Error("this function is deprecated"); Backtrace();
	
	foreach (@a)
	{
		return 1 if ($v eq $_);
	}
	
	return 0;
}

sub get
{
	my ($self, $var, $ok) = @_;
	
	Debug("*********************** get is deprecated setting $var:", caller) if (!$ok);
	
	return $self->$var;
}

sub set
{
	my ($self, $var, $val, $ok) = @_;
	Debug("*********************** set is deprecated setting $var:", caller) if (!$ok);

	#Backtrace() if ($var eq 'lr');	
	$self->{$var} = $val;
}

sub init
{
	# my ($self, %args) = @_;
	# Debug("SSI.pm init()", %args);
}

sub initMech()
{
	if (!defined($mech))
	{
		$mech = WWW::Mechanize->new( autocheck => 0 );
	    $mech->conn_cache(LWP::ConnCache->new(total_capacity => 3));
		$mech->agent_alias('Windows IE 6');
		Debug("created mech.");
	}  else {}
	
	return $mech;
}

sub postUrl($$)
{
	my ($url, $content) = @_;

	initMech();
	
	my $req = HTTP::Request->new(POST => $url);
	$req->content($content);
	
	my $response = $mech->request($req);
	
	my $success = $mech->success;
	my $status = $mech->status;
	
	my $data;
	
	if ($success)
	{
		$data = $mech->content;
	}
	else
	{
		Warning("unable to fetch $url. status=" . $status) if ($status != 404);
		$data = undef;
	}
	
}

sub getUrlRaw($;$)
{
	my ($url, $outfn) = @_;
	
	my $data;
	
	my $success = 0;
	my $status = '';

	initMech();

	Debug($url);
	$mech->get($url);
	$success = $mech->success;
	$status = $mech->status;
	
	if ($success)
	{
		$data = $mech->content;
		if (defined($outfn) && open(GETURL, ">$outfn"))
		{
#			binmode(GETURL, ':utf8'); 
			print GETURL $data;
			close(GETURL);
		}		
	}
	else
	{
		#Debug("unable to fetch $url. status=" . $status) if ($url !~ /jpg/ || $status != 404);
		$data = undef;
	}
	
	return $data; 
}

sub getUrlStatus
{
		return "" . $mech->uri . ": success=" . $mech->success . ". status=" . $mech->status;
}

sub getUrlStatusCode
{
	if (defined($mech))
	{
		return $mech->status
	}
	else
	{
		Error("called without initializing the mech. Returning status=500"); Backtrace();
		return 500;
	}
}


sub getUrl($;$)
{
	my ($url, $outfn) = @_;
	
	my $data = getUrlRaw($url, $outfn);
	
	if (defined($data) && $mech->content_type =~ /text/i)
	{
		# Squish whitepsace, except for whitespace in quotes.
		my $count = 0;
		my $redospace = sub { $count++; my $m = shift; $m =~ s/ /<SPACE>/g; return $m; };
		$data =~ s/"([^"]*)"/'"' . &$redospace($1) . '"'/gse;
		#Debug($data) if ($url =~ /Promo/);
		$data =~ s/\s+/ /gs;
		
		$data =~ s/<SPACE>/ /g;
		
		Debug("Warning: $count <space> replacements on /text/ retrieval of $url.") if ($count);
		
	}
	else
	{
		1; Debug("content-type: " . $mech->content_type);
	}
	
	return $data;
}

sub hash()
{
	Fatal("Hash must be uniquely defined per type to be used.");
}

our $stringifyDepth = 0;
sub recursiveStringify
{
	my (@a) = @_;
	
	sub pad()
	{
		my $ret = '';
		if ($stringifyDepth)
		{
			$ret = "\n";
			$ret .= "    "x$stringifyDepth;
		}
		return $ret;
	}
		
	
	Fatal("too deep to stringify.") if ($stringifyDepth++ > 15);
	
	my $ret = ''; #pad(); 
	foreach my $obj (@a)
	{
		$ret .= pad();
		
		if (!ref($obj))
		{
			$ret .= "$obj";
		}
		elsif (ref($obj) =~ /^SSI::/)
		{
			$ret .= $obj->toString;
		}
		elsif (ref($obj) eq 'HASH')
		{
			my $notfirst = 0;
			foreach my $key (sort(CORE::keys(%$obj)))
			{
				my $val = $obj->{$key};
				$ret .= pad() if ($notfirst++);
				if (defined($obj->{$key}) && ref($obj->{$key}))
				{
					my ($l, $r) = qw/- -/;
					($l, $r) = qw/{ }/ if ref($obj->{$key}) eq 'HASH';
					($l, $r) = qw/[ ]/ if ref($obj->{$key}) eq 'ARRAY';
					
					
					if (ref($obj->{$key}) eq 'HASH' && !CORE::keys(%{ $obj->{$key} }))
					{
						$ret .= "'$key' => { },"
					}
					elsif (ref($obj->{$key}) eq 'ARRAY' && !scalar(@{ $obj->{$key} }))
					{
						$ret .= "'$key' => [ ],"
					}
					else
					{
						$ret .= "$key => " . pad() . "  $l";
						$val = recursiveStringify($obj->{$key}) if (ref($obj->{$key}));
						$ret .= " $val" . pad() . "  $r, ";
					}
				}
				elsif (defined($obj->{$key}))
				{
					$ret .= "'$key' => '$val', ";
				}
				else
				{
					$ret .= "$key => (undef), ";
				}

								
			}
			$ret =~ s/, $//;
		}
		elsif (ref($obj) eq 'ARRAY')
		{
			$ret .= pad() . "  [";
			$ret .= recursiveStringify(@$obj);
			$ret .= pad(). "  ], ";
		}
		elsif (ref($obj) eq 'SCALAR')
		{
			$ret .= '[$' . $$obj . ']';
		}
		else
		{
			$ret .= "[$obj]";
		}
		$ret .= ",";	
	} 
	$stringifyDepth--;
	#$ret =~ s/,\s*$//se if (defined($ret));
	
	
	return $ret;
}

sub toString()
{
	my ($self, $len) = @_;
	
	$len = 10 if (!defined($len));
	
	Debug(ref($self) . " needs a toString function."); Backtrace();
	
	my $ret = ref($self) . ": ";
	foreach my $key ($self->keys)
	{
		my $val = $self->{$key};
		
		if (defined($val))
		{
			$val =~ s/^(.{$len}).*$/$1/; 
		}
		else 
		{
			$val = ''; 
		}
			 
		$ret .= "$key=$val, "; 					
	}
	
	$ret =~ s/, $//;
	
	return $ret;
}

# return a list of differing keys.
sub diff
{
	my ($self, $them, $args) = @_;
	
	my $known_args = { 'ignore_case' => 1 };
	
	$args = {} if (!defined($args));
	foreach my $arg (CORE::keys(%$args))
	{
		if (!defined($known_args->{$arg}))
		{
			Fatal("unknown argument $arg.");
		}
	}
	
	
	if (ref($self) ne ref($them))
	{
		Fatal("can only compare diff on same object time.");
	}

	
	my @ret;
	
	foreach my $key ($self->keys)
	{
		my $different = 0;
		# Keys differ if:
		#   - one key is defined and the other is not.
		#   - the values are different.
		$different = 'defined-mismatch' if (defined($self->{$key}) ^ defined($them->{$key}));
		
		if (defined($self->{$key}) && defined($them->{$key}))
		{
			$a = $self->{$key};
			$b = $them->{$key};

			
			if (ref($a) || ref($b))
			{			
				$different = 'ref-mismatch' if (ref($a) ne ref($b));

				if (ref($a) eq 'ARRAY' && ref($b) eq 'ARRAY')
				{
					if (@{$a} != @{$b})
					{
						$different = 'array-count-mismatch'
					}
					else
					{ 
						$different = 'idx-mismatch-at:';
						for (my $i = 0; $i <= $#$a; $i++)
						{
							$different .= "$i," if ($a->[$i] ne $b->[$i]);
						}
					} 
				} 
				
				if (ref($a) eq 'HASH' && ref($b) eq 'HASH')
				{
					foreach my $k (CORE::keys(%$a))
					{
						Fatal("value of self->{$key}->{$k} must not be a hash", $self, $them) if (ref($a->{$k}) eq 'HASH');
						
						$different = 'hashref key mismatch' if (defined($a->{$k}) ^ defined($b->{$k}));
						$different = 'hashref value mismatch' if (defined($a->{$k}) && defined($b->{$k}) && $a->{$k} ne $b->{$k});	
					}
				}
			}
			else # not a ref.
			{			
				if ($args->{ignore_case})
				{
					$a =~ tr/A-Z/a-z/;
					$b =~ tr/A-Z/a-z/;
				}
				
				 
				# are both numbers?
				if ($a =~ /^\d+\.?\d*$/ && $b =~ /^\d+\.?\d*$/)
				{
					$different = 'numerical' if ($a != $b);
				}
				else
				{
					$different = 'strings' if ($a ne $b);
				}			
			}				 
			 
		}
		
		if ($different)
		{
			#Debug("key=$key: different=$different");
			push(@ret, $key);
		} 
	}
	return @ret;	
}

our $copydepth = 0;
sub copy
{
	
	my $self = shift;
	
	if (!defined($self))
	{
		Error("copy called with undefined \$self.");
		return undef;
	}
	
	my %newself;

	eval{
	
		$copydepth++;
		if ($copydepth > 5)
		{
			Fatal("deep copy depth ($copydepth) on: ", ref($self), $self);
		}
		
		foreach my $key ($self->keys)
		{
			if (ref($self->{$key}) eq 'HASH')
			{
				my %h = %{ $self->{$key} };
				$newself{$key} = \%h;
			}
			elsif (ref($self->{$key}) eq 'ARRAY')
			{
				my @a = @{ $self->{$key} };
				$newself{$key} = \@a;
			}
			elsif (!ref($self->{$key}))
			{
				$newself{$key} = $self->{$key};
			}
			elsif (ref($self->{$key}) =~ /^SSI:/) # Support recursion on the object being copied.  
			{
				#Debug("recursing[$copydepth] on " . ref($self). " => " . ref($self->{$key}));
				$newself{$key} = ($self->{$key})->copy;
			}
			else
			{
				Fatal("unable to copy key $key=$self->{$key} for reftype=" . ref($self->{$key}));
			}
		}
		
		$copydepth--;
	};
	Fatal ("$@", ref $self) if ($@);
	
	return new(ref($self), %newself);

}


sub HASHINVERSE($)
{
	my $h = shift;
	
	my %inv;
	
	foreach my $key (CORE::keys(%$h))
	{
		if (defined($inv{$h->{$key}}))
		{
			SSI::Log::Error("hash collision on key=$key.");
			SSI::Log::Backtrace();
		}
		$inv{$h->{$key}} = $key;
	}
	
	return  \%inv;
}

# Creates a hashref and creates a bijection out of it directly.
#  
sub BIJECTION($) 
{
	my $h = shift; 
	my @keys = CORE::keys(%$h); 
	foreach (@keys) 
	{
		if (defined($h->{$h->{$_}}))
		{
			SSI::Log::Fatal("bijections must be built on bijectionally unique hashes.");
		} 
		$h->{$h->{$_}} = $_;
	}
	
	# Visual verification:
	#foreach (CORE::keys(%$h))
	#{
	#	Debug("$_=$h->{$_}");
	#}
	
	return $h;
}

sub hash2str
{
	my ($h) = @_;
	
	if (!defined($h))
	{
		return undef;
	}
	
	if (ref($h) ne 'HASH')
	{
		SSI::Log::Fatal("this must be called with a hashref:", $h);
	}
	
	my $ret = 'SSI::hash2str!';
	foreach my $var (CORE::keys(%$h))
	{
		my $val = $h->{$var};
		
		$val =~ s/=/<EQUALS>/gs;
		$var =~ s/=/<EQUALS>/gs;

		$val =~ s/,/<COMMA>/gs;
		$var =~ s/,/<COMMA>/gs;

		$ret .= "$var=$val,";		
	}
	$ret =~ s/,$//;
	
	#Debug("$ret"); Backtrace();
	
	return $ret;
}

sub lock_values
{
	my $self = shift;
	
	if (defined($self))
	{
		#Internals::SvREADONLY(%$self, 1); # Not used in fields version 5.10
		foreach (values %$self)
		{
			Internals::SvREADONLY($_, 1);
		}
	}
}

sub islocked
{
	my $self = shift;
	
	# 'fields' in perl 5.10 flags all classes as readonly.  Instead of
	# checking to see if the class is readonly, check to see if the classid is.
	my $ret = Internals::SvREADONLY($self->{classid}); 
	return $ret;
}

sub unlock_values
{
	my $self = shift;
	if (defined($self))
	{
		#Internals::SvREADONLY(%$self, 0); # Not used in fields version 5.10
		foreach (values %$self)
		{
			Internals::SvREADONLY($_, 0);
		}
	}
}

sub str2hash
{
	my $s = shift;
	
	if (!$s)
	{
		return undef;
	}
	
	if (ref($s))
	{
		Fatal("this must be called with a scalar:", $s);
	}
	
	#Debug("$s"); Backtrace();
		
	if ($s !~ s/^SSI::hash2str!//)
	{
		Fatal("this is not a hash2str formatted string:", $s);
	}
	
	my %ret;
	
	my @records = split(/,/, $s);
	foreach my $rec (@records)
	{
		my ($var, $val) = split(/=/, $rec);
		
		$var =~ s/<EQUALS>/=/gs;
		$val =~ s/<EQUALS>/=/gs;

		$var =~ s/<COMMA>/,/gs;
		$val =~ s/<COMMA>/,/gs;
		
		$ret{$var} = $val;
	}
	
	return \%ret;
	
}


{
	our $snow = undef;
	our $unow = undef;
	
	sub setNow($$)
	{
		$snow = shift;
		$unow = shift;
		
		Warning("overriding SSI::unixnow=$unow") if (defined($unow));
		Warning("overriding SSI::sqlnow=$snow") if (defined($snow));
		
		if (ref $snow)
		{
			Fatal("do not call in a classful form ($snow)");
		} else {}
	}
		
	sub sqlnow()
	{
		if (defined($snow))
		{
			return $snow;
		}
		else
		{
			my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
		                                              
			$year += 1900;
			$mon++;
			
			$mday = "0$mday" if ($mday < 10);
			$mon = "0$mon" if ($mon < 10);
			$hour = "0$hour" if ($hour < 10);
			$min = "0$min" if ($min < 10);
			$sec = "0$sec" if ($sec < 10);
			
		
			return "$year-$mon-$mday $hour:$min:$sec";
		}
	}
	
	sub unixnow()
	{
		my $ret;
		if (defined($unow))
		{
			$ret = $unow;
		}
		else
		{
			$ret = scalar time;
		}
			
		
		return scalar time; # unix time (seconds since 1/1/1970).
	}
}



# This helps us safely traverse really ugly hashes, like those from XML.  
#   $h = hashDive($h, qw/a b c d e f g/)
# is the same as:
#   $h = $h->{a}{b}{c}{d}{e}{f}{g}
# but much safer since it does type and undef checking.
# Returns undef if there is an error.
sub hashDive
{
	my ($h, @a) = @_;

	my $path = '$h->';
	foreach (@a)
	{
		if (ref($h) ne 'HASH')
		{
			Error("$path is not a hash at \n");
			#Backtrace();
			return undef;
		}

		if (!defined($h->{$_}))
		{
			Error("$path" . "{$_} is not defined.\n"); 
			#Backtrace();
			return undef;
		}

		$h = $h->{$_};
		$path = "$path" . "{$_}";
	}
	
	return $h;
}

### This code breaks a string into an array of @segments. 
### A segment is either an HTML tag, or a "deduplicable" string, such as a sentance.
###
### After creating the segments, each segment is printed if:
###   1. It has not been seen before, or
###   2. is less than 15 charectars, or
###   3. contains [<>].
sub deduplicate
{
	my $s = shift;
	my %known;
	my $seg = '';
	my @segments;
	
	$s =~ s/(\d+)\.(\d+)/${1}__DECIMALPOINT__$2/gsi;
	$s =~ s/\.(com|net|org)/__ADDR${1}__/gsi;
	
	foreach my $c (split(//, $s))
	{
		if ($c =~ /[<]/)
		{
			push(@segments, $seg);
			$seg = $c;
		}
		elsif ($c =~ /[>]/)
		{
			$seg .= $c;
			push(@segments, $seg);
			$seg = '';
		}
		elsif ($c =~ /[!.;\r\n]/) # normal segment terminators
		{
			$seg .= $c;
			push(@segments, $seg);
			$seg = '';
		}
		else
		{
			$seg .= $c;
		}
	}

	my $out = '';
	foreach my $seg (@segments)
	{
		Warning("seg is undef; segments:", @segments) if (!defined($seg));
		next if (!defined($seg));
		
		if ($seg =~ /[<>]/)
		{
			$out .= $seg;
		}
		elsif ($seg =~ /[()]/s && !$known{deduplicatorHash($seg)}++) # No string length limits on de-duping parenthesized things.
		{
			$out .= $seg;
		}		
		elsif (!$known{deduplicatorHash($seg)}++ || length($seg) < 15) # only dedupe things that are longer than 15 chars.
		{
			$out .= $seg;
		}
	}

	$out =~ s/(\d+)__DECIMALPOINT__(\d+)/$1.$2/gsi;
	$out =~ s/__ADDR([a-z]+)__/.$1/gsi;
	return $out;
}

sub deduplicatorHash
{
	my $hash = shift;
	$hash =~ s/\s+/ /gs;
	$hash =~ s!<([^>]+)>[^<]+</([^>]+)>!!gs;
	$hash =~ s!<[^>]+>!!gs;
	$hash =~ tr/A-Za-z0-9 //cd;
	$hash = lc($hash);
	$hash =~ s/^\s+|\s+$//gs;
	return $hash;
}


} # END NO WARNINGS REDEFINE








use Time::HiRes;
our (%timers, %timers_start);

END {
	
	if (%timers)
	{
		$Data::Dumper::Sortkeys = 1;
		Debug("Timers:" . Dumper(\%timers)); 
		my $sum;
		$sum += $_ foreach (values(%timers));
		Debug("total: $sum");
	}
}

sub timerStart
{
	my ($timer_name) = @_;
	$timers_start{$timer_name} = Time::HiRes::time();
}

sub timerStop
{
	my ($timer_name) = @_;
	$timers{$timer_name} += Time::HiRes::time() - $timers_start{$timer_name};
}



1;



