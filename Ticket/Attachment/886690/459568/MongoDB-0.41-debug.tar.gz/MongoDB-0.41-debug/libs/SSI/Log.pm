package SSI::Log;

use lib '../../libs/lib/perl5';
use IO::File;

#use base 'SSI';

use strict;
use warnings;

my $nodebug = 0;
my %logfiles;

{ # NO WARNINGS REDEFINE
no warnings 'redefine';


END
{
	foreach (keys(%logfiles))
	{
		close($logfiles{$_});
	}
}

BEGIN {
	use Exporter ();

	our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

	$VERSION     = 1.00;
	# if using RCS/CVS, this may be preferred

	@ISA         = qw(Exporter);
	@EXPORT_OK   = qw(Log Debug Fatal Error Warning Backtrace ASSERT_DEFINED ASSERT_NONZERO ASSERTION_RESET);
	@EXPORT      = qw(Log Debug Fatal Error Warning Backtrace ASSERT_DEFINED ASSERT_NONZERO ASSERTION_RESET);
	%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

	foreach (qw/debug error warning log/)
	{
		$logfiles{$_} = *STDOUT;
	}
	$logfiles{fatal} = *STDERR;

}

sub resetLogOutput
{
	foreach (qw/debug error warning log/)
	{
		$logfiles{$_} = *STDOUT;
	}
	$logfiles{fatal} = *STDERR;
}


# Redirects stdout to some typeglob defined in a logfile.
sub setSTDOUT
{
	my $logtype = shift;
	
	$logtype = 'log' if (!defined($logtype));

	if (!defined($logfiles{$logtype}))
	{
		Fatal("unknown logtype: $logtype");
	}

	*STDOUT = $logfiles{log}; 
}

sub setSTDERR
{
	my $logtype = shift;
	
	$logtype = 'fatal' if (!defined($logtype));

	if (!defined($logfiles{$logtype}))
	{
		Fatal("unknown logtype: $logtype");
	}

	*STDERR = $logfiles{log}; 
}




# logfile( 
#   log => *STDOUT,
# 	debug => IO::Socket::INET->new( PeerAddr => "localhost:8080" ),
#   fatal => '/var/log/fatal.log'
#   error => '/var/log/fatal.log'
#   warning => IO::Socket::INET->new ( Proto=> "udp", PeerAddr => "localhost:syslog" ) 
# )
sub logfile
{
	my %files = @_;

	if (defined($files{all}))
	{
		my $all = $files{all};
		%files = map { $_ => $all } keys(%logfiles);
	}

	## build a reverse-mapping of filename==>(debug|fatal|...) from (debug|fatal|...)==>(ref|filename)
	## if $files{debug} is a ref, then assign it as the IO.  Perhaps it is a socket.
	my %rfiles;
	my $io;
	foreach $io (keys(%files))
	{
		if (!defined($logfiles{$io}))
		{
			$logfiles{$io} = *STDERR;
			Fatal("unknown io path '$io'.  expecting log|debug|warning|error|fatal.");
		}
		if (ref($files{$io}))
		{
			$logfiles{$io} = $files{$io};
		}
		else
		{
			push @{ $rfiles{$files{$io}} }, $io;
		}
	}

	foreach my $filename (keys(%rfiles))
	{	
		my $fh = IO::File->new(">>$filename");
		if (!defined($fh))
		{
			Fatal("Unable to write to log file $filename: $@ $!");
		}
	
		$fh->autoflush(1); 
		print $fh "\n" . (scalar localtime) . "\n";

		foreach $io (@{ $rfiles{$filename} })
		{
			$logfiles{$io}->close if (ref($logfiles{$io}) =~ /^IO/); # This now supports sockets?
			$logfiles{$io} = $fh;
		}
	}

	foreach (keys(%files))
	{
			Debug("writing $_ to $files{$_}:", $logfiles{$_});
	}
	
	return 1; 
}

sub noDebug
{
	$nodebug = 1;
}

our $deep_array2txt = 0;
sub array2txt
{
	my @a = @_;

	return '' if ($deep_array2txt > 10);
	
	my $ret = ''; 
	my $first = 1;
	foreach my $a (@a)
	{
		if (ref($a) =~ /^SSI::/)
		{
			$ret .= $a->toString . ", ";
		}
		elsif (ref($a) eq 'ARRAY')
		{
			$ret .= "\n    [" . array2txt(@$a) . "]"
		}
		else
		{
			$ret .= "$a, " if (defined($a));
			$ret .= "(undef), " if (!defined($a));
		}
	
		$ret =~ s/, $/ / if ($first);
		
		$ret .= "\n  " if (@a > 4);
	
		
		$first = 0; # Place the first entry without a comma.
	}
	$ret =~ s/, $//;
	
	return $ret;
}

sub Log
{
	my @a = @_;
	@a=('nil') if (!@a);
	my @c = caller;
	
	my @c1 = caller(0);
	my @c2 = caller(1);
	
	
	my $calling_sub;
	if (@c2)
	{
		$c2[3] =~ s/^.*:://;
		$calling_sub = "$c2[3]:";
	}
	else
	{
		$calling_sub = '';
	}
	
	my $fh = $logfiles{log};
	
	
	print $fh "L " . SSI::sqlnow() . " $calling_sub: ". array2txt(@a) . "\n";
}

sub Debug
{
	my @a = @_;
	@a=('nil') if (!@a);
	my @c = caller;
	
	my @c1 = caller(0);
	my @c2 = caller(1);
	
	
	my $calling_sub;
	if (@c2)
	{
		$c2[3] =~ s/^.*:://;
		$calling_sub = "($c2[3])";
	}
	else
	{
		$calling_sub = '';
	}
		
	$c[0] =~ s/::/\//g;
	my $fh = $logfiles{debug};
	print $fh "D " . SSI::sqlnow() . " $c[0]:$c[2]: " . "$calling_sub ". array2txt(@a) . "\n" if (!$nodebug);

}

sub Warning(@)
{
	my @a = @_;
	@a=('nil') if (!@a);
	my @c = caller;
	
	my @c1 = caller(0);
	my @c2 = caller(1);
	
	
	my $calling_sub;
	if (@c2)
	{
		$c2[3] =~ s/^.*:://;
		$calling_sub = "($c2[3])";
	}
	else
	{
		$calling_sub = '';
	}
		
	
		
	$c[0] =~ s/::/\//g;
	my $fh = $logfiles{warning};
	print $fh  "W " . SSI::sqlnow() . " $c[0]:$c[2]: $calling_sub ". array2txt(@a) . "\n";
}

sub Error
{
	my @a = @_;
	@a=('nil') if (!@a);
	my @c = caller;
	
	my @c1 = caller(0);
	my @c2 = caller(1);
	
	
	my $calling_sub;
	if (@c2)
	{
		$c2[3] =~ s/^.*:://;
		$calling_sub = "($c2[3])";
	}
	else
	{
		$calling_sub = '';
	}
		
	
	$c[0] =~ s/::/\//g;
	my $fh = $logfiles{error};
	print $fh "E " . SSI::sqlnow() . " $c[0]:$c[2]:$calling_sub ". array2txt(@a) . "\n";
	#Backtrace($logfiles{error});
}


sub Fatal
{
	my @a = @_;
	@a=('nil') if (!@a);
	my @c = caller;
	
	my @c1 = caller(0);
	my @c2 = caller(1);
	
	my $calling_sub;
	if (@c2)
	{
		$c2[3] =~ s/^.*:://;
		$calling_sub = "$c2[3]:";
	}
	else
	{
		$calling_sub = '';
	}
		
	
	$c[0] =~ s/::/\//g;
	
	my $fh = $logfiles{fatal};
	print $fh "Fatal: " . SSI::sqlnow() . " $c[0]:$c[2]: $calling_sub " . array2txt(@a) . " (errno=$! ret=$?) -- stack trace:\n";
	
	Backtrace($fh);
	
	exit(1);
}	

sub Backtrace
{
	my $fh = shift;
	$fh = $logfiles{debug} if (!defined($fh));

	my $i = 0;
	my @msg;
	while (my @c = caller($i++)) 
	{
		my @c0 = caller($i);
		my $caller = '';
		$caller = " ($c0[3])" if (@c0);
		push @msg, "  $i. $c[1]:$c[2]:$caller while calling $c[3]\n";
	}
	print $fh $_ foreach (reverse @msg);
}


our $ASSERTION_NONZERO_COUNT = 0;
our $ASSERTION_DEFINED_COUNT = 0;

sub ASSERTION_RESET
{
	$ASSERTION_NONZERO_COUNT = 0;
	$ASSERTION_DEFINED_COUNT = 0;
}

# This could really be called 'NOT_PERL_FALSE'.  
sub ASSERT_NONZERO($)
{
	my $a = shift;

	$ASSERTION_NONZERO_COUNT++;
	
	if (!$a)
	{
		Fatal("assertion failure. count=$ASSERTION_NONZERO_COUNT");
	}
	else
	{
		return $a;
	}	
}

sub ASSERT_DEFINED($)
{
	my $a = shift;

	$ASSERTION_DEFINED_COUNT++;

	if (!defined($a))
	{
		Fatal("assertion failure. count=$ASSERTION_DEFINED_COUNT");
	}
	else
	{
		#Debug($a);
		return $a;
	}	
}

} # END NO WARNINGS REDEFINE.

1;
