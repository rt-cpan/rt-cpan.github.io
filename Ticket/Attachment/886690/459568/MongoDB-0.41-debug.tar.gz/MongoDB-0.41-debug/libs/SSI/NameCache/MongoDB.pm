package SSI::NameCache::MongoDB;

use base 'SSI::NameCache';

use strict; 
use warnings;

use boolean qw/:all/;

use constant MAX_HASH_LENGTH => 7;

BEGIN {
	use Exporter;
	use base 'Exporter';
	our $VERSION = '1.00';
	use SSI::NameCache;
	our @EXPORT = qw(EXPIRE_NOW EXPIRE_NEVER);

}

use constant MONGODB_TIMEOUT => 60000;

use fields qw/ CollectionName db host port user pass collection namecache_id /;

use constant FORCE_INTEGER => 1;

use SSI::Log;
use MongoDB;
use MongoDB::Connection;

use Data::Dumper;


no warnings 'numeric';


sub init
{
	my ($self, %args) = @_;

    $MongoDB::Cursor::timeout = MONGODB_TIMEOUT;

	$self->{CollectionName} = 'NameCaches' if (!defined($self->{CollectionName}));
	
	if (!defined $self->{cacheFile})
	{
		Fatal("must define cacheFile");
	} 
	
	if (defined($args{memoryOnly}))
	{
		Fatal("memoryOnly caches are unsupported by ".ref($self)); 
	}
	
	if ($self->{cacheFile} =~ s!^.*/!!)
	{
		Warning("truncating $args{cacheFile} to " . $self->{cacheFile});
		$args{cacheFile} = $self->{cacheFile}
	}
	
	$self->{db} = MongoDB::Connection->new(auto_reconnect => 1, auto_connect => 1);#( host => $self->{host}, port => $self->{port});
	
	my $db = $self->{db};
	

	if (!defined($db))
	{
		Error("unable to connect to $args{host}.");
		return;
	}
	
	$db->query_timeout(MONGODB_TIMEOUT); # wait forever!

	my $nc = $db->NameCacheDB; ##  NameCache Database
	my $CollectionName = $self->{CollectionName};
	my $namecaches = $nc->$CollectionName; ## Collection

	my $id = $namecaches->find_one({ namecache_name => $self->{cacheFile} });
	if (!defined($id))
	{
		Debug("creating namecache.");
		$id = $namecaches->insert({namecache_name => $self->{cacheFile} });
	}
	else
	{
		$id = $id->{_id};
	}
	
	Fatal("cannot find id for namecache $self->{cacheFile}") if (!defined($id));
	
	$self->{namecache_id} = $id;

	$self->{collection} = $nc->$id;
	
	$self->{collection}->ensure_index({"key" => 1}, {"unique" => 1, name => "key", drop_dups => 1 });
}


sub keys
{
	my ($self) = @_;
	
	my $collection = $self->{collection};
	
	my $f = $collection->query( );
	$f->fields( { expr => 1, key => 1 } );
#	Debug(Dumper($f->all));
	my @keys;
	
	my $rec;
	while (defined($rec = $f->next))
	{	
		push (@keys, $rec->{key}) if (
			defined($rec) && ( $rec->{expr} > time() || $rec->{expr} == EXPIRE_NEVER ));
	} 
	
#	Debug("========= keys ", @keys);
	
	return @keys;
}

sub allKeys
{
	my ($self) = @_;
	
	my $collection = $self->{collection};
	
	my $f = $collection->query( );
	$f->fields( { key => 1 } );
	
#	Debug(Dumper($f->all));
	my @keys;
	
	my $doc;
	while (defined($doc = $f->next))
	{	
		push (@keys, $doc->{key});
	} 
	
#	Debug("========= keys ", @keys);
	
	return @keys;
}


sub sync { }

sub _exists
{
	my ($self, $var) = @_;

	# Fix string<-->integer mapping problems.
	$var = int($var) if (FORCE_INTEGER && int($var) eq $var);
	
	my $collection = $self->{collection};
	
	my $it = $collection->find( { key => $var } );	
	#$it->hint( { key => 1 } );
	$it->limit(1);	
	$it->fields( { _id => 1, expr => 1 } );
	my $rec = $it->next;

	$it->reset;	
	return defined($rec);
}

sub _set
{	
	my ($self, $var, $val, $expiration) = @_;

	# Fix string<-->integer mapping problems.
	$var = int($var) if (FORCE_INTEGER && int($var) eq $var);
	
	my $collection = $self->{collection};

	if ($self->_exists($var))
	{
#		Debug("exists: $var=$val expr=$expiration");
		$collection->update( { key => $var }, { key => $var, val => $val, expr => $expiration } );
#		Debug("post-update get($var): ", $self->_get($var));
	}
	else
	{
#		Debug("insert: $var=$val expr=$expiration");
		$collection->insert( { key => $var, val => $val, expr => $expiration } );
	}
	
	return $val;
}

sub _isValid
{
	my ($self, $var) = @_;

	# Fix string<-->integer mapping problems.
	$var = int($var) if (FORCE_INTEGER && int($var) eq $var);

	my $collection = $self->{collection};
	
	my $it = $collection->find( { key => $var } );
	#$it->hint( { key => 1 } );
	$it->limit(1);	
	$it->fields( { _id => 1, expr => 1 } );
	my $rec = $it->next;

	$it->reset;	

	
#	Debug Dumper $rec;
	
#	Fatal("undefined record on var/key=$var") if (!defined($rec));
	
	return defined($rec) && ( $rec->{expr} > time() || $rec->{expr} == EXPIRE_NEVER );
}
 
sub _get
{
	my ($self, $var, $no_decode) = @_; 

	# Fix string<-->integer mapping problems.
	$var = int($var) if (FORCE_INTEGER && int($var) eq $var);
	
	my $collection = $self->{collection};
	
	my $rec = $collection->find_one( { key => $var });
	
#	Debug Dumper($rec);
	if (defined($rec) && 
		($rec->{expr} > time() || $rec->{expr} == EXPIRE_NEVER) 
		)
	{
		#Debug("var=$var val=$rec->{val}, expr=$rec->{expr}");
		$rec = $rec->{val}
	}
	else
	{
#		Debug("var=$var val=$rec->{val}, expr=$rec->{expr} EXPIRED, now=" . time());
		$rec = undef;
	}
	
	return $rec;
	
}

sub _getExpiration
{
	my ($self, $var) = @_; 

	# Fix string<-->integer mapping problems.
	$var = int($var) if (FORCE_INTEGER && int($var) eq $var);
	
	my $collection = $self->{collection};

	my $it = $collection->find( { key => $var } );	
	#$it->hint( { key => 1 } );
	$it->limit(1);	
	$it->fields( { _id => 1, expr => 1 } );
	my $rec = $it->next;
	
	$it->reset;	
	
#	Debug(Dumper $rec);
	
	return (defined($rec) ? $rec->{expr} : undef );
}

sub _getExpired
{
	my ($self, $var, $no_decode) = @_;

	# Fix string<-->integer mapping problems.
	$var = int($var) if (FORCE_INTEGER && int($var) eq $var);


	my $collection = $self->{collection};
	my $rec = $collection->find_one( { key => $var });

	$rec = $rec->{val} if (defined($rec));
		

	return $rec;	
}

# Return the list of namecaches in this collection.
sub getNameCaches
{
	my $self = shift;

	my $db = $self->{db};	
	my $nc = $db->NameCacheDB; ##  NameCache Database
	
	my $CollectionName = $self->{CollectionName};
	my $namecaches = $nc->$CollectionName; ## Collection
	
	my $it = $namecaches->find();
	my @ret;
	
	push (@ret, $_->{namecache_name}) while($_ = $it->next);
	$it->reset;	
	
	return @ret;
}

sub _remove
{
	my $self = shift;
	return $self->expire(@_);
}

1;