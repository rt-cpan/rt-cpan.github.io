# To subclass and overload this package, you must
# redefine:
#    init
#    sync
#    _set
#    _get
#    _getExpired
#    getExpiration
#    keys

package SSI::NameCache;

use base 'SSI';
use SSI::Log;

use IO::File;
use Fcntl ':flock'; # import LOCK_* constants

use strict;
use warnings;

use Storable;

 

BEGIN {
	use Exporter;
	use base 'Exporter';
	our $VERSION = '1.00';
	our @EXPORT = qw(EXPIRE_NOW EXPIRE_NEVER);

}

use fields 
	'cacheFile',
	'nameMap',
	'expiredNameMap',
	'cacheUpdates',
	'expiredEntries',
	'resurectedEntries',
	'memoryOnly',
	'lastSync', # UNIX time of the last sync.
	'lastRead', # UNIX time of the last read (init, really).
	;

my $DELIM = '<DELIM>'; # Warning: This is used as a regex!

my $ENCODEDTYPE = '<=ENCODEDTYPE=>'; 
 
my $EQDELIM = '<=EQUALS=>';
my $COMMADELIM = '<=COMMA=>';
my $SCALARTYPE = '<=SCALAR=>';
my $ARRAYTYPE = '<=ARRAY=>';
my $HASHTYPE = '<=HASH=>';
my $SSITYPE = '<=SSITYPE=>';
my $UNDEF = '<=UNDEF=>';

my $CR = '<=CARRIAGERETURN=>';
my $LF = '<=LINEFEED=>';

my $RESERVED_WORD_REGEX = "$DELIM|$ENCODEDTYPE|$EQDELIM|$COMMADELIM|$SCALARTYPE|$ARRAYTYPE|$HASHTYPE|$SSITYPE|$UNDEF";

use constant EXPIRE_NOW => -1;
use constant EXPIRE_NEVER => 0;


sub keys()
{
	my $self = shift;
	Fatal("keys must be overridden in " . ref($self)) if (ref($self) ne __PACKAGE__);
	
	return CORE::keys(%{ $self->{nameMap} });
}

=pod
my $nc = SSI::NameCache->new(cacheFile => 't.ncache');

#$nc->set('array', [1, "2\n   2's newline", 3,]);
#$nc->set('hash', { a=>1, b=>2, c=>"3\n   new\n   lines\n   yay!"});
#$nc->set('scalar', \"a\n   newline");
#$nc->set('product', SSI::Product->new(vendor_code=>'asi', name => 'test', model => 'ultrascience3000', description => "amazing\n   gadget", image => [1,2,3]));
#$nc->set("normal\nfun", "foo\n   bar"); # Not directly supported; \n is munged out and the keyref still works, though it may collide!

Debug $nc->get('product')->SSI::toString;
Debug ${ $nc->get('scalar') };
Debug join(',', @{ $nc->get('array') });
Debug map { $_ . "=" . $nc->get('hash')->{$_}  } CORE::keys(%{ $nc->get('hash') });
Debug $nc->get("normal\nfun"); # Not directly supported; \n is munged out and they keyref still works, though it may collide! 

$nc->sync;

exit 1;
=cut

our $AUTOLOAD;
sub AUTOLOAD
{
	my $self = shift;
	print "Error: $AUTOLOAD\n";
	SSI::Log::Fatal("AUTOLOAD is not supported: [ updated=$self->{cacheUpdates} expired=$self->{expiredEntries} ] " . 
		($self->{cacheFile} ? $self->{cacheFile} : 'in-memory'), [ "$AUTOLOAD" ] );
	
}


sub _isValid($$)
{
	my ($self, $var) = @_;
	Fatal("_isValid must be overridden in " . ref($self)) if (ref($self) ne __PACKAGE__);
}

# Returns true if the variable is still valid (ie, not expired).
sub isValid($$)
{
	my ($self, $var) = @_;
	
	return $self->_isValid($var);
}


sub _getExpiration
{
	my $self = shift;
	Fatal("_getExpiration must be overridden in " . ref($self)) if (ref($self) ne __PACKAGE__);
}

sub getExpiration($$)
{
	my ($self, $var) = @_;
		
	return $self->_getExpiration($var);
}

sub set($$)
{

	my ($self, @args) = @_;
	my ($var, $val, $expiration) = @args;
	
	$expiration = EXPIRE_NEVER if (!defined($expiration));
	
	Fatal("var must be defined") if (!defined($var));
	
	if (ref($val))
	{
		$val = Storable::freeze($val)
	}
	
	return $self->_set($var, $val, $expiration);


	##############################################

	if (scalar(@args) < 2)
	{
		Fatal("Namecache requires a value for $var, even if the value is undef");
	}

	Fatal("key must by defined for val=$val") if (!defined($var));

	if ($expiration && $expiration != EXPIRE_NOW && $expiration < (time() - 10*3600*24*365))
	{
		Warning("$expiration is more than 10 years old.  This is probably an error.");
	}


	if ($var =~ /[\r\n]/s)
	{
		my $bn = $self->{cacheFile} ? $self->cacheFile : 'in-memory'; #basename
		$bn =~ s!.*/!!;
		Error("$bn: var='$var' contains carriage-return/line feed.  Deleting charectars in keyname!");
		$var =~ tr/\n\r//d;
	} 


	my $ref = ref($val);
	if (ref($val) && ref($val) !~ /^(CODE|REF|GLOB|LVALUE)$/)
	{
		my $ival = $ENCODEDTYPE;
				
		if ($ref eq 'SCALAR')
		{
			$ival .= $SCALARTYPE . $$val;
		}
		elsif ($ref eq 'ARRAY')
		{
			$ival .= $ARRAYTYPE;
			foreach my $e (@$val)
			{
				$e = $UNDEF if (!defined($e));
				if (!ref($e))
				{
					$ival .= "$e$COMMADELIM";	
				}
				else
				{
					my $iref = ref($e);
					Fatal("cannot store reference type for $var=[$iref]");  
				} 
			}
		}
		
		elsif ($ref eq 'HASH' || $ref =~ /^SSI::/)
		{
			my $ssi = 0;
			if ($ref =~ /^SSI/)
			{
				$ssi = 1;
				$ival .= $SSITYPE . $ref . $COMMADELIM;
			}
			else
			{
				$ival .= $HASHTYPE;
			}
			
			foreach my $k (CORE::keys(%$val))
			{
				my $hval = $val->{$k};
				
				$hval = $UNDEF if (!defined($hval));
				if (!ref($hval))
				{
					
					$ival .= $k . $EQDELIM . $hval . $COMMADELIM;
				}	
				else
				{
					my $iref = ref($hval);
					# Only fatal if this is a hash.  If this is SSI, then it is 
					Fatal("cannot store reference type for HASH:$var=[$k=>$iref]") if ($ref eq 'HASH'); 
					#Debug("cannot store reference type for HASH:$var=[$k=>$iref]") if ($ssi);
				} 
			}
			
		}
		else
		{
			Fatal("unhandled marshalling for $var=$ref.");
		}

		$ival =~ s/$COMMADELIM$//s;
		$val = $ival;
	}
	
	if (ref($val))
	{
		Fatal("cannot store reference type for $var=$ref"); 
	}

	$expiration = EXPIRE_NEVER if (!defined($expiration));
	
	return $self->_set($var, $val, $expiration);
	
	
}

# Low-level raw-n-dirty data storage.
sub _set
{
	my ($self, $var, $val, $expiration) = @_;
	Fatal("_set must be overridden in " . ref($self)) if (ref($self) ne __PACKAGE__);
	
	ASSERT_DEFINED $self->{nameMap};


	$self->{nameMap}->{$var} = SSI::Record->new( value => $val, expr => $expiration );
	
	# This will handle clearing expired variables if they are set and immediately expire. 
	if (defined($self->get($var, 'no-decode')))
	{
		$self->{cacheUpdates}++;
	}
	
	return $val;
}


sub _get
{
	my ($self, $var, $no_decode) = @_;
	Fatal("_get must be overridden in " . ref($self)) if (ref($self) ne __PACKAGE__);

	ASSERT_DEFINED $self->{nameMap};
	
	my $hvar = $self->{nameMap}->{$var};
	
	return undef if (!defined($hvar));
	 
	my $expr = $hvar->{expr};
	my $val = $hvar->{value};

	if (!defined($expr))
	{
		Fatal("expr must always be defined.");
	} 
	
	if (int($expr) <= time && $expr != 0)
	{
		#my $bn = $self->{cacheFile}; # basename
		#$bn =~ s!.*/!!;
		#Debug("$bn: $var expired, expr=$expr");
		
		$self->{expiredEntries}++;
		
		$self->{expiredNameMap}->{$var} = $self->{nameMap}->{$var}; # Save this just in case...
		#Debug("Expired entry, $var=", $self->{expiredNameMap}->{$var});
		$self->{nameMap}->{$var} = undef;
		delete $self->{nameMap}->{$var};
		
		return undef;	 	
	}

	
	return $val;
}

sub get($;$)
{
	my ($self, $var, $no_decode) = @_; 
	
# This is for pedantic testing.  We really don't need it.
#	if ($var =~ /[\r\n]/s)
#	{
#		my $bn = $self->{cacheFile} ? $self->cacheFile : 'in-memory'; #basename
#		$bn =~ s!.*/!!;
#		Error("$bn: $var contains carriage-return/line feed.  Deleting charectars in refname!");
#		$var =~ tr/\n\r//d;
#	} 

	my $val = $self->_get($var, $no_decode);
	
	$val = deSerialize($val) if (!$no_decode);
	
	return $val; 
}

sub deSerialize
{
	my $val = shift;
	if (defined(Storable::read_magic($val)))
	{
		return Storable::thaw($val);
	}
	
	## Here be slow dragons.
	#if (defined($val) && $val =~ /^$ENCODEDTYPE/s && !$no_decode)
	if (defined($val) 
		&& (substr($val, 0, 15) eq '<=ENCODEDTYPE=>') # This is an optimization of =~ /^$ENCODEDTYPE/ 
		)
	{
		$val = decodeRecord($val);
	}
	
	return $val;
}

sub expire($)
{
	my ($self, $var) = @_;

	my $val = $self->_get($var, 'no-decode');
	$self->_set($var, $val, EXPIRE_NOW);
}

sub _getExpired
{
	my ($self, $var, $no_decode) = @_;

	Fatal("getExpired must be overridden in " . ref($self)) if (ref($self) ne __PACKAGE__);
	
	if (defined($self->{expiredNameMap}->{$var}))
	{
		#$self->{nameMap}->{$var} = $self->{expiredNameMap}->{$var};
		
		$self->{resurectedEntries}++;
		return $self->{expiredNameMap}{$var}{value};
	}
	elsif (defined($self->{nameMap}{$var}))
	{
		return $self->{nameMap}{$var}{value};
	}
	
	return undef;
}

sub getExpired
{
	my ($self, $var, $no_decode) = @_;
	
	my $val = $self->_getExpired($var, $no_decode);
	
	$val = deSerialize($val) if (!$no_decode);

	return $val;	
}


sub decodeRecord($)
{
	my $val = shift;
	
	if ($val =~ s/^$ENCODEDTYPE//)
	{
		if ($val =~ s/^$SCALARTYPE//)
		{
			my $a = $val;
			$val = \$a;
		}
		elsif ($val =~ s/^$ARRAYTYPE//)
		{
			
			my @a = split(/$COMMADELIM/s, $val);
			my @b;
			foreach (@a)
			{
				if ($_ eq $UNDEF)
				{
					push(@b, undef);
				}
				else
				{
					push(@b, $_);
				}
			}
			$val = \@b;
		}
		elsif ($val =~ s/^$HASHTYPE// || $val =~ s/^$SSITYPE(.*?)($COMMADELIM|$)//)
		{
			my %h;
			my $ssitype = $1;
			
			foreach my $rec (split(/$COMMADELIM/s, $val))
			{
				my ($hvar, $hval) = split(/$EQDELIM/s, $rec);
			
				$hval = undef if ($hval eq $UNDEF);
				$h{$hvar} = $hval;
			}
			
			if ($ssitype)
			{
				$val = $ssitype->new(%h);
			}
			else
			{
				$val = \%h;
			}
		}
	}
	
	return $val;
}


sub remove($)
{
	my ($self, $var) = @_;

	$self->_remove($var);
}


# Semaphore lock a file.  Not that this does not actually lock the underlying file.
sub lockfile
{
	my ($fn) = @_;
	my $tries = 0;
	my $lock;
	do 
	{
			$tries++;
			$lock = IO::File->new(">>$fn.sem");
			while ($lock && !flock($lock, LOCK_EX)) # Block until it is unlocked.
			{
				Warning("$fn is locked; waiting...\n");
				sleep(1) # Try to lock this on 1s intervals.
			}
	} while (!$lock && $tries < 100);

	if (!$lock)
	{
		Fatal("unable to acquire lock on $fn");
	}

	
	return $lock;
}

sub unlockfile
{
	my ($fn, $lock) = @_;
	close($lock);
}

# Load cache file from $args{cacheFile}.
sub init
{
	my ($self, %args) = @_;
	Fatal("init must be overridden in " . ref($self)) if (ref($self) ne __PACKAGE__);
	
	if (defined($args{memoryOnly}))
	{
		Error("memoryOnly caches are deprecated.");
		Backtrace();		
		
	}
	
	my $line;
	my $expirations;
	
	$self->{nameMap} = {};
	$self->{cacheUpdates} = 0;
	$self->{expiredEntries} = 0;
	$self->{resurectedEntries} = 0;

	$self->{lastRead} = time;

	if (!defined($args{cacheFile}))
	{
		Fatal("please name all caches, even if they are memoryOnly caches.");
	} 
	
	if (defined($args{memoryOnly}))
	{
		Debug("using in-memory only cache: " . $args{cacheFile});
		return;
	}


	my $bn = $self->{cacheFile}; #basename
	$bn =~ s!.*/!!;

	my $lock = lockfile($args{cacheFile}); # Block until we get the lock.
	
	my $in = new IO::File $args{cacheFile};
	if ($in)
	{
		Debug("Opening NameCache $args{cacheFile}.");
		while (defined($line = <$in>))
		{
			chomp($line);
			my ($var, $val, $expr) = split(/<DELIM>/, $line);
			
			$val =~ s/$CR/\r/gs;
			$val =~ s/$LF/\n/gs;
			
			$val = undef if ($val eq $UNDEF);
			
			# This is safe for encoded/marshalled objects because at this point it is all code.	
			$self->set($var, $val, $expr); 
			if ($expr && $expr < time())
			{
				$expirations++;
			}
		}
		close($in);
		
		if (defined($expirations) && $expirations)
		{
			Debug("$bn: $expirations expirations.");
		}
	}
	else
	{
		Warning("unable to open $self->{cacheFile}.  Using empty cache.");
	}
	unlockfile($args{cacheFile}, $lock);
	
	# This needs reset because we use set internally to assign values, and it doesn't matter for memory-only caches.
	$self->{cacheUpdates} = 0; 
	
	
}

sub sync()
{
	my $self = shift;
	Fatal("sync must be overridden in " . ref($self)) if (ref($self) ne __PACKAGE__);
	
	
	my $nrec = scalar $self->keys;
	
	if (!defined($self->{cacheFile}) || $self->{memoryOnly})
	{
		Error("cannot sync a memory-only cache.");
		Backtrace();
		return;
	}	
	
	if ($self->{cacheUpdates} > 0 || $self->{expiredEntries} > 0 || $self->{resurectedEntries} > 0)
	{
		Debug("writing NameCache: [ records=$nrec updated=$self->{cacheUpdates} expired=$self->{expiredEntries} resurected=$self->{resurectedEntries} ] " . $self->{cacheFile});
		
		my $cache = $self->{cacheFile};
		
		my $lock = lockfile($cache);
		my $out = IO::File->new(">$cache");
		if ($out)
		{
			foreach my $var (sort(CORE::keys(%{$self->{nameMap}}))) # Keys are sorted by name.  
			{
				my $hvar = $self->{nameMap}->{$var};
				my $val = $hvar->{value};
				
				if (!defined($val))
				{
					$val = $UNDEF;
				}
				else
				{
					$val =~ s/\r/$CR/gs;
					$val =~ s/\n/$LF/gs;
				}
				
				print $out $var . $DELIM . $val . $DELIM . $hvar->{expr} . "\n";   
			}
			close($out);
		}
		unlockfile($cache, $lock);
		
	}
	else
	{
		Debug("skipping NameCache Update, already up-to-date with $nrec records.: " . $self->{cacheFile});
		
	}
	$self->{lastSync} = time;
}


1;
