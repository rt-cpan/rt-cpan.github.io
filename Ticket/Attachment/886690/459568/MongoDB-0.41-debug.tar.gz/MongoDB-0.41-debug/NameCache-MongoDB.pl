#!/usr/bin/env perl

use lib $ENV{PWD} . "/libs";
use strict; 
use SSI::Log;
use SSI::NameCache;
use SSI::NameCache::MongoDB;

use Time::HiRes ;
use Benchmark;
use constant SLEEP_TIME => 3;

my $p = 'PRODUCT';

my $nc = SSI::NameCache::MongoDB->new(cacheFile => 'test7',
	host => "127.0.0.1",
	user => "root",
	pass => 27017,
	);

Debug 'set("xxx", "yyy"):  ' . $nc->set('xxx', 'zzz');
Debug 'set("rrr", "zzz"):  ' . $nc->set('rrr', 'zzz');
Debug("before remove, get(xxx): ", $nc->get('xxx'));
Debug 'remove("rrr"): ' . $nc->remove('rrr');
Fatal( 'get(xxx): should be zzz!' , $nc->get('xxx')) if ($nc->get('xxx') ne 'zzz');
Fatal("rrr should be missing") if ($nc->isValid("rrr"));
