package SafeVPN::DB::Result;

use Modern::Perl;
use base 'DBIx::Class::Core';

use Data::Dump::Filtered;

my $filter =  sub {
	my( $obj, $cur ) =  @_;

	return { hide_keys => [ '_result_source', 'schema' ] };
};

sub die {
	shift; # Drop $self

	die '<pre>',  Data::Dump::Filtered::dump_filtered( @_, $filter );
}

1;
