package SafeVPN::DB::Result::Package;

use Modern::Perl;
use base 'SafeVPN::DB::Result';


__PACKAGE__->table('packages');
__PACKAGE__->add_columns(
	 id => { sequence => 'uid_seq' },
	 qw(
		tarif_id customer_id locality_id
		login password realm
		auto_renew state
		duration price setup_fee destination_price destination_setup_fee
		started changed expiry
		notes
	)
);
__PACKAGE__->set_primary_key('id');
__PACKAGE__->belongs_to('tarif' => 'SafeVPN::DB::Result::Tarif', 'tarif_id');
__PACKAGE__->has_many('destinations', 'SafeVPN::DB::Result::Destination', 'package_id', {cascade_delete => 0});

1;
