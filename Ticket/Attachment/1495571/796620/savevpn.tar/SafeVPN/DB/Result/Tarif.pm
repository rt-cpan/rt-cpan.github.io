package SafeVPN::DB::Result::Tarif;

use Modern::Perl;
use base 'SafeVPN::DB::Result';

__PACKAGE__->table('tarifs');
__PACKAGE__->add_columns(
    id => { sequence => 'uid_seq' },
    qw/
        site_id
        active priority type
        name description
        duration price setup_fee destination_price destination_setup_fee
    /
);
__PACKAGE__->set_primary_key('id');
__PACKAGE__->many_to_many('servers', 'tarifs_servers', 'server', {cascade_delete => 0});
__PACKAGE__->has_many('packages', 'SafeVPN::DB::Result::Package', 'tarif_id', {cascade_delete => 0});


1;

