package SafeVPN::DB::Result::Server;

use Modern::Perl;
use base 'SafeVPN::DB::Result';

__PACKAGE__->table('servers');
__PACKAGE__->add_columns(
 id => { sequence => 'uid_seq' },
 qw/
  active priority
	locality_id hostname
	ip nas dns
	description notes
  ca_certificate openvpn_static_key l2tp_key
 /
);
__PACKAGE__->set_primary_key('id');
__PACKAGE__->has_many('subnets', 'SafeVPN::DB::Result::Pool::Subnet', 'server_id', {cascade_delete => 0});
__PACKAGE__->many_to_many('tarifs', 'tarifs_servers', 'tarif', {cascade_delete => 0});

1;
