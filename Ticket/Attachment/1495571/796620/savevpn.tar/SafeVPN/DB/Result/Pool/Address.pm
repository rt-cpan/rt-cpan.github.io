package SafeVPN::DB::Result::Pool::Address;

use Modern::Perl;
use base 'SafeVPN::DB::Result';

__PACKAGE__->table('pool_addresses');
__PACKAGE__->add_columns(
 id => { sequence => 'uid_seq' },
 qw/subnet_id ip usage notes/
);
__PACKAGE__->set_primary_key(qw/id/);
__PACKAGE__->belongs_to('subnet' => 'SafeVPN::DB::Result::Pool::Subnet', 'subnet_id');
__PACKAGE__->might_have('destination' => 'SafeVPN::DB::Result::Destination', 'address_id', {join_type => 'left'});
__PACKAGE__->has_many('history' => 'SafeVPN::DB::Result::Pool::Address_History', 'address_id');
1;
