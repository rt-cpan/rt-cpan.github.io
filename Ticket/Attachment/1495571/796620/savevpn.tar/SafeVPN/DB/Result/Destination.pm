package SafeVPN::DB::Result::Destination;

use Modern::Perl;
use base 'SafeVPN::DB::Result';



__PACKAGE__->table('destinations');
__PACKAGE__->add_columns(
	id => { sequence => 'uid_seq' },
	qw(
		package_id address_id locality_id
		ssl_key ssl_certificate ssl_pkcs12
		listener1 listener2
		state notes
	)
);
__PACKAGE__->set_primary_key('id');
__PACKAGE__->belongs_to('package' => 'SafeVPN::DB::Result::Package', 'package_id');
__PACKAGE__->belongs_to('address' => 'SafeVPN::DB::Result::Pool::Address', 'address_id');


sub new {
my ( $class, $attrs ) =  @_;

my $self = $class->next::method($attrs);


if( !defined $self->address_id  &&  !exists $attrs->{address_id} ) {
	$self->address_id(
		$self->package->locality->addresses_view->free_ips('active')->first
		);
}
else {
	#TODO: check that addresses are from one server and match package.locality_id
}


if( !defined $self->locality_id  &&  !exists $attrs->{locality_id} ) {
	$self->locality_id( $self->address->subnet->server->locality_id );
}


#FIX: listener
if( !defined $self->listener1  &&  !defined $self->listener2 ) {
	my $method;
	for( $self->address->subnet->server->listeners({type => $self->package->tarif->type}) ) {
		$method =  'listener' . $_->number;
		$self->$method( $_->ip );
	}
}

return $self;
}



sub update {
my( $self, $attrs ) =  @_;

#FIX: listener
if( !defined $self->listener1  &&  !defined $self->listener2
  && !exists $attrs->{listener1}  &&  !exists $attrs->{listener2}
) {
	for( $self->address->subnet->server->listeners({type => $self->package->tarif->type}) ) {
		$attrs->{'listener' . $_->number} =  $_->ip;
	}
}

$self->next::method($attrs);

return $self;
}


1;

