package SafeVPN::DB::Result::Pool::Subnet;

use Modern::Perl;
use base 'SafeVPN::DB::Result';

__PACKAGE__->table('pool_subnets');
__PACKAGE__->add_columns(
 id => { sequence => 'uid_seq' },
 qw/server_id network notes gateway dns1 dns2/
);
__PACKAGE__->set_primary_key(qw/id/);
__PACKAGE__->belongs_to('server' => 'SafeVPN::DB::Result::Server', 'server_id');
__PACKAGE__->has_many('addresses', 'SafeVPN::DB::Result::Pool::Address', 'subnet_id', {cascade_delete => 0});
1;

