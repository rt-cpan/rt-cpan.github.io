﻿package MediaLandscape::Converter::I18N::ja;

use utf8;
use warnings;
use strict;
use base qw(MediaLandscape::Converter::I18N);

our %Lexicon = (

            "Cancel"  # Button label
                 => "取り消し",

                 # ...
            );

1;
