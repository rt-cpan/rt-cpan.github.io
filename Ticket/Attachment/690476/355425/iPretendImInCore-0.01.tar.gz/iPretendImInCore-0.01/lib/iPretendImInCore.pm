package iPretendImInCore;

use strict;
use warnings;

our $VERSION = '0.01';

sub new {
    my $class = shift;
    my $self  = bless {}, $class;

    $self;
}

1;

__END__

=head1 NAME

iPretendImInCore - iPretendImInCore

=head1 SYNOPSIS

    use iPretendImInCore;
    iPretendImInCore->new;

=head1 DESCRIPTION

=head1 METHODS

=head2 new

=head1 AUTHOR

author, E<lt>emailE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2009 by author.

This program is free software; you can redistribute it and/or
modify it under the same terms as Perl itself.

=cut
