
package MyTypemaps::BISAO Health Care Professional;
use strict;
use warnings;

our $typemap_1 = {
               'HealthCareProfessionals/Contact' => 'MyTypes::Contact',
               'HealthCareProfessionals/Contact/type' => 'SOAP::WSDL::XSD::Typelib::Builtin::string',
               'HealthCareProfessionals' => 'MyElements::HealthCareProfessionals',
               'HealthCareProfessionals/Contact/status' => 'SOAP::WSDL::XSD::Typelib::Builtin::string',
               'HealthCareProfessionals/Contact/regionalConcilNumber' => 'SOAP::WSDL::XSD::Typelib::Builtin::string',
               'Fault/faultcode' => 'SOAP::WSDL::XSD::Typelib::Builtin::anyURI',
               'Process_spcInstance_spcId' => 'MyElements::Process_spcInstance_spcId',
               'HealthCareProfessionals/Contact/lastName' => 'SOAP::WSDL::XSD::Typelib::Builtin::string',
               'Fault/faultstring' => 'SOAP::WSDL::XSD::Typelib::Builtin::string',
               'Fault' => 'SOAP::WSDL::SOAP::Typelib::Fault11',
               'HealthCareProfessionals/Contact/federativeUnity' => 'SOAP::WSDL::XSD::Typelib::Builtin::string',
               'Fault/faultactor' => 'SOAP::WSDL::XSD::Typelib::Builtin::token',
               'Fault/detail' => 'SOAP::WSDL::XSD::Typelib::Builtin::string',
               'Error_spcCode' => 'MyElements::Error_spcCode',
               'Error_spcMessage' => 'MyElements::Error_spcMessage',
               'Object_spcId' => 'MyElements::Object_spcId',
               'HealthCareProfessionals/Contact/firstName' => 'SOAP::WSDL::XSD::Typelib::Builtin::string',
               'Siebel_spcOperation_spcObject_spcId' => 'MyElements::Siebel_spcOperation_spcObject_spcId',
               'HealthCareProfessionals/Contact/primarySpecialty' => 'SOAP::WSDL::XSD::Typelib::Builtin::string'
             };
;

sub get_class {
  my $name = join '/', @{ $_[1] };
  return $typemap_1->{ $name };
}

sub get_typemap {
    return $typemap_1;
}

1;

__END__

__END__

=pod

=head1 NAME

MyTypemaps::BISAO Health Care Professional - typemap for BISAO Health Care Professional

=head1 DESCRIPTION

Typemap created by SOAP::WSDL for map-based SOAP message parsers.

=cut

