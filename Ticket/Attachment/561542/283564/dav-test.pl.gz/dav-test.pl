#!/usr/bin/perl

### Code begins here:

##############################################################################
####  User Options, Variables
##############################################################################
use strict;
use warnings;

use Getopt::Long qw(:config no_ignore_case bundling);
use HTTP::DAV;
use Data::Validate::URI;
use Term::ReadPassword;
use LWP::Debug qw(+);
use Data::Dumper;

local $HTTP::DAV::DEBUG = 3;

use constant DUMP_FILE => "/tmp/Comms.pm";
use constant TIMEOUT   => "5m";

my %OPT;
# Options
# h: help
# V: version information
# x: extended compare
# v: verbose
# f: write to dump file
# u: user name (for WebDAV)
# p: password (for WebDAV)
# d: directory to start searching
GetOptions(\%OPT,
	   'help|h|?',
	   'version|V',
	   'extended-checks|x',
	   'verbose|v',
	   'directory|d=s',
	   'file|f=s',
	   'user|u=s',
	   'password|p:s',
	   'base1|b1|left=s',
	   'base2|b2|right=s');

##############################################################################
####  Main
##############################################################################


# There are three ways to offer the password
# 1) write it at the command line
# 2) offer a file containing the password in the first line
# 3) enter it at the prompt
my $pwd = '';

if ( $OPT{user} && exists $OPT{password}  ) {

    if ( -f $OPT{password} ) {
	open(PWD, $OPT{password}) || die "unable to open $OPT{file} ($!)\n";
	$pwd = <PWD>;
	chomp $pwd;
	close PWD;

    } elsif ( ! $OPT{password} ) {
	$pwd = read_password('password: ');
    }

}

my $data = {};



# file to write the dump to
my $dump_file = $OPT{file} || DUMP_FILE;

# check if parameter is empty
warn "Using default dump file $dump_file" unless $OPT{file};


my $uri = Data::Validate::URI->new();

# Check if file is a valid HTTP(S) URI
# In case of an URI dump to a local file first and upload the file
# to a WebDAV enabled server and delete the local file afterwards
if ($uri->is_http_uri($dump_file) || $uri->is_https_uri($dump_file)) {

    my ($url) = $dump_file =~ m#^(.*/)#o;
    #print "pwd: $pwd**$url\n";

    my $dav = HTTP::DAV->new();
    #$dav->DebugLevel(3);
    $dav->credentials( -user  => $OPT{user},
		       -pass  => $pwd,
		       -url   => "storage.schnuckelig.eu:80",
		       -realm => 'DAV'
		     );
    #print Dumper($dav);

    $dav->open( -url => $url )
      or die("Couldn't open $url: " . $dav->message . "\n");

    #	$dav->lock(-url     => $dump_file,
    #		   -timeout => TIMEOUT ) ||
    #		     die "Unable to lock $OPT{file} for " . TIMEOUT;

    my $rv = $dav->put( -local => DUMP_FILE, -url => $dump_file );

    if ( $rv ) {
	print "Successfully put $OPT{file} to WebDAV server.\n" if $OPT{verbose};

    } else {
	die "Error putting $OPT{file} to server."
	  . $dav->message . "\n";
    }
} else {
    warn "$dump_file is no valid URI\n";
}


### mp3diff.pl ends here
