package Bar::Ab;

use Moose;


