package Foo;
# Foo

use Moose;


