package Bar::P;

use Moose;


