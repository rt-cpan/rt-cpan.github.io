package Foo::Bar;

use Moose;


