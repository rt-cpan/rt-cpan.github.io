package DBIx::LazyMethod::MSSQL;

use strict;
use warnings;
no warnings 'uninitialized';
use DBI;
use DBIx::LazyMethod;
use vars qw(@ISA @EXPORT);
@ISA = qw(DBIx::LazyMethod);
@EXPORT = @DBIx::LazyMethod::EXPORT;
my $PACKAGE 	= "[DBIx::LazyMethod::MSSQL]";

our (%TYPEMAP, %SIZEMAP);

sub new {
	my $class = shift;
	my %params = @_;

	my $methods = $params{methods};
	my %split_methods;

	foreach my $method (keys %$methods) {
		if (! ref($methods->{$method})) {
			$methods->{$method} = { ret => $methods->{$method}};
		}
		unless (exists $methods->{$method}{sql}) {
			# it's OK if the SQL is not specified, we are calling a stored proc
			$methods->{$method}{sql} = undef; # don't fill it in yet
			$methods->{$method}{args} = undef unless exists $methods->{$method}{args};
			if ($method =~ /\s/) { # spaces in a stored procedure name? Nope! It's a list.
				$split_methods{$_} = { %{$methods->{$method}} } for (split ' ', $method); # need a copy of the hash!!!
				delete $methods->{$method};
			}
		}
	}
	if (keys %split_methods) { # were there any lists of procedures?
		%$methods = (%split_methods, %$methods);
	}

	return $class->SUPER::new(%params);
}

sub _prepare {
	my ($self, $meth) = @_;
	return $self->{'statements'}{$meth} if exists $self->{'statements'}{$meth};
	my $Meth = $self->{'methods'}{$meth};
	my $sth;

	if (! $self->{'methods'}{$meth}{'sql'}) {

		if (! $Meth->{args}) {
			my $sth = $self->{'statements'}{_mssql_schema_sth};
			if (! $sth) {
				$sth = $self->{_dbh}->prepare(<<"*END*");
SELECT Parameter_name, Parameter_mode, Data_type, Character_maximum_length
  FROM INFORMATION_SCHEMA.PARAMETERS
 WHERE Specific_catalog = DB_NAME() and Specific_schema = 'dbo' and Specific_name = ?
   and Is_result = 'NO'
 ORDER BY Ordinal_position
*END*
				$self->{'statements'}{_mssql_schema_sth} = $sth;
			}
			$sth->execute($meth) or die "$meth is not an existing procedure!\n";
			my $params = $sth->fetchall_arrayref();

			$Meth->{'args'} = [];
			foreach my $param (@$params) {
				(my $name = lc($param->[0])) =~ s/^\@//;
				push @{$Meth->{'args'}}, $name;

				if ($param->[1] eq 'INOUT') {
					$self->_load_typemap() unless keys %TYPEMAP;
					$Meth->{'out_args'}->{$name} = [ (defined $param->[3] ? $param->[3]+0 : $SIZEMAP{$param->[2]}+1), $TYPEMAP{$param->[2]} || DBI::SQL_VARCHAR, undef, (defined $param->[3] ? "$param->[2]($param->[3])" : $param->[2])]; # [ maxlength, type, value(for binding), type_string]
				}
			}
		}

		my $count = scalar(@{$Meth->{args}});
		if ($count) {
			$Meth->{sql} = "EXEC dbo.$meth ?" . (", ?" x ($count-1));
		} else {
			$Meth->{sql} = "EXEC dbo.$meth";
		}
	}

	print STDERR "$PACKAGE DEBUG: preparing ".$Meth->{sql}."\n" if DBIx::LazyMethod::DEBUG;
	$sth = $self->{_dbh}->prepare($Meth->{sql}) or return $self->_error($meth." prepare failed");

	if (exists $Meth->{'out_args'}) { # there are out parameters, let's bind them already
		my $id = 0;
		foreach my $param (@{$Meth->{args}}) {
			$id++;
			next unless exists $Meth->{'out_args'}{$param};
			$Meth->{'out_args'}{$param}[2] = undef;
			$sth->bind_param_inout( $id, \$Meth->{'out_args'}{$param}[2],
				$Meth->{'out_args'}{$param}[0], { TYPE => $Meth->{'out_args'}{$param}[1] }
			);
		}
	}

	$self->{'statements'}{$meth} = $sth
}

sub _load_typemap {
	my $self = shift;
	my $info = $self->{_dbh}->type_info_all() or die "$PACKAGE: Can't load the type map!\n";

	my %map = %{shift(@$info)};
	foreach my $type (@$info) {
		$TYPEMAP{$type->[$map{TYPE_NAME}]} = $type->[$map{DATA_TYPE}];
		$SIZEMAP{$type->[$map{TYPE_NAME}]} = $type->[$map{COLUMN_SIZE}];
	}
}

1;

=head1 NAME

DBIx::LazyMethod::MSSQL - Simple 'database query-to-accessor method' wrappers. Quick and dirty OO interface to your data.

=head1 SYNOPSIS

  use DBIx::LazyMethod::MSSQL;

  my %methods = (
	set_people_name_by_id => {
		sql => "UPDATE people SET name = ? WHERE id = ?",
		args => [ qw(name id) ],
		ret => WANT_RETURN_VALUE,
	},
	FetchUsers => {
		ret => WANT_ARRAY_HASHREF,
	},
	'InsertUser DeleteUser' => {
		ret => WANT_RETURN_VALUE
	}
  );

  my $db = DBIx::LazyMethod->new(
		data_source  => "DBI:Proxy:hostname=192.168.1.1;port=7015;dsn=DBI:Oracle:PERSONS",
                user => 'user',
                pass => 'pass',
                attr => { 'RaiseError' => 0, 'AutoCommit' => 1 },
                methods => \%methods,
                );
  if ($db->is_error) { die $db->{errormessage}; }

=head1 DESCRIPTION

Please see the documentation for DBIx::LazyMethod!

The only additional thing provided by this module is that you do not have to specify the SQL and the arguments
if you want to call stored procedures in MS SQL Server. If you do not specify the C<sql> amd C<args> then the key in the
methods hash are supposed to be the name or a whitespace separated list of names of stored procedures.
The module fetches the information regarding the stored procedures from the database and finds out the arguments automaticaly.
Plus this way even the OUTPUT parameters are supported.

Then argument names are lowercased!

=head1 AUTHOR

Jenda Krynicky <Jenda@CPAN.org>

=head1 SEE ALSO

DBIx::LazyMethod

=cut
