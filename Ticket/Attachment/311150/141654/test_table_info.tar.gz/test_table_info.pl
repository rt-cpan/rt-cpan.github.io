#!/usr/bin/perl

use strict ;
use warnings ;
use DBI ;
use Data::Dumper ;

my $dsn = "dbi:Pg:dbname=prebilling;host=localhost" ;
my $user = "prebilling" ;
my $password = '' ;
my $sth ;


        my $dbh = DBI->connect($dsn,$user,$password,
                {PrintWarn => 1,
                 PrintError => 1,
                 ShowErrorStatement => 1,
                 AutoCommit => 0,
                 RaiseError => 1}) or
                die "Can't DBI->connect: $DBI::errstr" ;

$sth = $dbh->table_info(undef,undef,'merastat') ;
print "merastat table_info:\n" ;
while (my $ref = $sth->fetchrow_hashref()) {
	print Dumper ($ref) ;
}
$sth->finish() ;

$sth = $dbh->table_info(undef,undef,'clients') ;
print "clients table_info:\n" ;
while (my $ref = $sth->fetchrow_hashref()) {
	print Dumper ($ref) ;
}
$sth->finish() ;

$dbh->disconnect() or warn ;
