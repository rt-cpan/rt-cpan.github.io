#!/usr/local/bin/perl

use SQL::Translator::Producer::MySQL;
use SQL::Translator::Schema::Table;
use SQL::Translator::Schema::Constants;

my $table = SQL::Translator::Schema::Table->new(
    name   => 'table',
);

my $constraint = $table->add_constraint(
    fields => [ 'field' ],
    type   => PRIMARY_KEY,
);

print SQL::Translator::Producer::MySQL::alter_drop_constraint($constraint);

