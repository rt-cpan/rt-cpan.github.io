use strict;
use warnings;
use Pod::Usage;

#
#   Bug 1
#   =head2 messes with sectons
#
#   Following code does not display the BugHeader section
#

    pod2usage({-verbose => 99,
               -sections => 'BugHeader'} );

=pod

=head1 Heading-1

=head2 Heading 2

=head1 BugHeader

=head2 BugHeader2


