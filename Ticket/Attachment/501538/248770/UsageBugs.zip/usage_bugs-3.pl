use strict;
use warnings;
use Pod::Usage;

#
#   Bug
#   Support for multiple sections
#
#   Code requires fix in Usage.pm
#

    pod2usage({-verbose => 99,
               -sections => [qw(Heading-1 Heading-2/.*)] } );


=pod

=head1 Heading-1

=head2 Heading-1.1

=head1 Heading-2

=head2 Heading-2.2


