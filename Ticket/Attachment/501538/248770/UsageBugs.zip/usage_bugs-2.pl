use strict;
use warnings;
use Pod::Usage;

#
#   Bug 2
#   =over =back is broken
#
#   Following code shows items much to far to the right
#
    pod2usage({-verbose => 99,
               -sections => 'BugHeader/BugHeader2'} );

=pod

=head1 Heading-1

=over 100

=item One

=item Two

=back

=head2 Heading 2

=head1 BugHeader

=head2 BugHeader2

=over

=item More

=item Still More

=back


