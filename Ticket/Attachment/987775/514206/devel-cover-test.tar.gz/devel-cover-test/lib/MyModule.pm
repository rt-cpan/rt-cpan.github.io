package MyModule;

# comment the following line and no errors are displayed
use Moose;

1;
