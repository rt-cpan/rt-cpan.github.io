package OpenXPKI::TestModPerlHandler_pp;

use strict;
use warnings;

use Locale::Messages qw (:locale_h :libintl_h nl_putenv bind_textdomain_filter select_package gettext);
use POSIX qw (setlocale);
use Encode;

use Locale::gettext_pp;

sub handler {
    my $r = shift;

#    my $res = Locale::Messages::select_package("gettext_pp");
    my $res = Locale::Messages::select_package("asdf","gettext_pp");
    print "<p>Will call module: $res</p>";
    my $language = 'de_DE';
    my $locale_prefix = '/usr/local/share/locale';
    my $loc = "${language}.UTF-8";
    POSIX::setlocale(&POSIX::LC_MESSAGES, $loc);
    POSIX::setlocale(&POSIX::LC_TIME,     $loc);
    POSIX::setlocale(&POSIX::LC_ALL,      $loc);
    Locale::Messages::nl_putenv("LC_MESSAGES=$loc");
    Locale::Messages::nl_putenv("LC_TIME=$loc");
    Locale::Messages::nl_putenv("LC_ALL=$loc");
    Locale::Messages::nl_putenv("LANG=$loc");
    Locale::Messages::nl_putenv("LANGUAGE=$loc");

    my $eall = $ENV{'LC_ALL'};
    my $emessages = $ENV{'LC_MESSAGES'};
    my $elang = $ENV{'LANG'};
    my $elanguage = $ENV{'LANGUAGE'};

    print "<p>Before script works</p>";
    print "<p>LC_ALL: $eall</p>";
    print "<p>LC_MESSAGES: $emessages</p>";
    print "<p>LANG: $elang</p>";
    print "<p>LANGUAGE: $elanguage</p>";


    Locale::Messages::textdomain("openxpki");
    Locale::Messages::bindtextdomain("openxpki", $locale_prefix);
    Locale::Messages::bind_textdomain_codeset("openxpki", "UTF-8");
## This line calls gettext_pp via Messages::gettext and works ok with Apache-2.x on FreeBSD
    my $data = Locale::Messages::gettext("I18N_OPENXPKI_CLIENT_HTML_MASON_API_CERT_INFO_TITLE");
    Encode::_utf8_on($data);
    print "Perl gettext from Messages: $data<br/>";

    Locale::gettext_pp::textdomain("openxpki");
    Locale::gettext_pp::bindtextdomain("openxpki", $locale_prefix);
    Locale::gettext_pp::bind_textdomain_codeset("openxpki", "UTF-8");
## This line calls explicitly gettext_pp and works ok on FreeBSD Apache-2.x and mod_perl2
    my $data2 = Locale::gettext_pp::gettext("I18N_OPENXPKI_CLIENT_HTML_MASON_API_CERT_INFO_TITLE");
    my $data3 = Locale::gettext_xs::gettext("I18N_OPENXPKI_CLIENT_HTML_MASON_API_CERT_INFO_TITLE");
## The next line calls gettext from CL
    my $data_cmd = `export LANG=de_DE.UTF-8 && export LANGUAGE=de_DE.UTF-8 && /usr/local/bin/gettext -d openxpki I18N_OPENXPKI_CLIENT_HTML_MASON_API_CERT_INFO_TITLE`;
    Encode::_utf8_on($data2);
    Encode::_utf8_on($data3);
    print "Pure Perl gettext: $data2<br/>Command_line: $data_cmd <br/>";
    print "XS gettext: $data3<br/>Command_line: $data_cmd <br/>";


    print "<p>After script worked</p>";
    print "<p>LC_ALL: $eall</p>";
    print "<p>LC_MESSAGES: $emessages</p>";
    print "<p>LANG: $elang</p>";
    print "<p>LANGUAGE: $elanguage</p>";

    return 0;
}

1;
