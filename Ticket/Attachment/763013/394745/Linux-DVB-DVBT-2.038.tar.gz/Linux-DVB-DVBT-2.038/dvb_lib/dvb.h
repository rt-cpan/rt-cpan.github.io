#ifndef _DVB_INC
#define _DVB_INC

#include <inttypes.h>
#include <list.h>

#endif
