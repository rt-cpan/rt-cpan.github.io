package Bundle::Maypole;

use strict;

our $VERSION = '0.01';

=head1 NAME

Bundle::Maypole - All Maypole goodness

=head1 SYNOPSIS

C<perl -MCPAN -e 'install Bundle::Maypole'>

=head1 DESCRIPTION

Installs all the Maypole modules for you.  You won't need them all.

=head1 CONTENTS

Maypole

Maypole::Application

Maypole::Authentication::UserSessionCookie

Maypole::CLI

Maypole::Cache

Maypole::Component

Maypole::Config

Maypole::Constants

Maypole::FormBuilder

Maypole::FormBuilder::Model

Maypole::FormBuilder::Model::Base

Maypole::FormBuilder::Model::Plain

Maypole::FormBuilder::View

Maypole::HTTPD

Maypole::HTTPD::Frontend

Maypole::Headers

Maypole::Model::Base

Maypole::Model::CDBI

Maypole::Model::CDBI::Plain

Maypole::Plugin::Authentication::Abstract

Maypole::Plugin::Authentication::UserSessionCookie

Maypole::Plugin::Authorization

Maypole::Plugin::AutoUntaint

Maypole::Plugin::ColumnGroups

Maypole::Plugin::Component

Maypole::Plugin::Config::Apache

Maypole::Plugin::Config::YAML

Maypole::Plugin::Exception

Maypole::Plugin::FormBuilder

Maypole::Plugin::I18N

Maypole::Plugin::LinkTools

Maypole::Plugin::Loader

Maypole::Plugin::QuickTable

Maypole::Plugin::Relationship

Maypole::Plugin::Session

Maypole::Plugin::Transaction

Maypole::Plugin::Untaint

Maypole::Plugin::Upload

Maypole::Redirect

Maypole::Session

Maypole::View::Base

Maypole::View::Mason

Maypole::View::TT

Maypole::Virtual::Application

Test::WWW::Mechanize::Maypole

=head1 AUTHOR

Sebastian Riedel, C<sri@oook.de>

Fixed and updated a year later by Kieren Diment <kd@totaldatasolution.com>.

=head1 LICENSE

This library is free software. You can redistribute it and/or modify it under
the same terms as perl itself.

=cut

1;
