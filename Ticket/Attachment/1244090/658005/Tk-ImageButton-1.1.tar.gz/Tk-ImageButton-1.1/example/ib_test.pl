#!perl

use strict;
use warnings;
use diagnostics;
use Tk;
use Tk::ImageButton;

my $mw = new MainWindow();

my $norm_im = $mw->Photo(-file => "quit_normal.bmp");
my $over_im = $mw->Photo(-file => "quit_over.bmp");
my $click_im = $mw->Photo(-file => "quit_clicked.bmp");
my $disable_im = $mw->Photo(-file => "quit_disabled.bmp");

my $button_text = "Enable Quit";

my $button_im2 = $mw->ImageButton(	-imagedisplay => $norm_im,
					-imageover => $over_im,
					-imageclick => $click_im,
					-imagedisabled => $disable_im,
					-state => 'disabled',
					-command => [ sub {$mw->destroy} ]
				)->pack(-side => 'right');

my $button_no = $mw->Button(	-textvariable => \$button_text,
				-width => 10,
				-command => [ sub {$button_text = button_state($button_im2)} ]
				)->pack(-side => 'left');

MainLoop;

exit;

=head1 SUBS

=head2 button_state( $button )

TODO: add description of what this method does.

=cut

sub button_state {
	my $butt = shift;

	if ($butt->cget(-state) eq 'normal')
	{
		$butt->configure(-state => 'disabled');
		return("Enable Quit");
	}
	else
	{
		$butt->configure(-state => 'normal');
		return("Disable Quit");
	}
} # /button_state