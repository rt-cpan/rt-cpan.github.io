package Tk::ImageButton;

use 5.016003;
use strict;
use warnings;
use Tk;
require Tk::Label;
use base qw(Tk::Derived Tk::Label);

Construct Tk::Widget 'ImageButton';

our $VERSION = '1.1';

=head1 NAME

Tk::ImageButton - Customizable/Graphical button

=head1 SYNOPSIS

    use Tk::ImageButton;
    ...
    my $b = $mw->ImageButton(
        -imagedisplay  => "Tk::Photo variable",
        -imageover     => "Tk::Photo variable",
        -imageclick    => "Tk::Photo variable",
        -imagedisabled => "Tk::Photo variable",
        -state         => 'normal/disabled',
        -command       => [ sub {a callback} ],
    )->pack;
    ...
    MainLoop;

=head1 DESCRIPTION

L<Tk::ImageButton> allows the user to have a customised graphical button on
their GUI. 4 separate images can be used, one for the normal display, 
one when the mouse is over the button, one for when the mouse is clicked
over the button and finally one for when the button is disabled.


=head2 Images

There are 4 button states available.
1. Button without interaction - this is the default and is set by using
   the -imagedisplay option and passing a Tk::Photo object as it's
   argument. This image is displayed when the button is not in use.
2. Button with mouse over - this is when the mouse has been moved over
   the button. It is set by calling the -imageover option and passing
   a Tk::Photo object as it's argument.
3. Button when mouse click - this is when the left mouse button is clicked
   over the button. It is set by calling the -imageclick option and
   passing a Tk::Photo object as it's argument.
4. Button disabled - this is when the button has been disabled. It is set
   by calling the -imagedisabled option and passing a Tk::Photo object as
   it's argument.

When the options have been set, the widget will take care of changing the
displayed images when needed.

=head2 State / Command

As with usual buttons you can enable and disable them. To enable a button
(this is the default setting) you call the -state option and pass 'normal'
as the argument. To disable a button, call the -state option with
'disabled' as the argument.


=head1 OPTIONS

B<ImageButton> accepts all of the options that the B<Label> widget accepts.
In addition, the following options are recognised.

=over 4

=item B<-imagedisplay>

This sets the image to be displayed when the button is not in use. It takes
a Tk::Photo object as it's argument. It's default is 0.

=item B<-imageover>

This sets the image to be displayed when the mouse pointer moves over the
button. It takes a Tk::Photo object as it's argument. It's default is 0.

=item B<-imageclick>

This sets the image to be displayed when the left mouse button is clicked
over the button. It takes a Tk::Photo object as it's argument.
It's default is 0.

=item B<-imagedisabled>

This sets the image to be displayed when the button is disabled. It takes
a Tk::Photo object as it's argument. It's default is 0.

=item B<-state>

Can be one of 'normal' or 'disabled', as per usual buttons. If the button
is disabled, as per usual button widgets, the associated callback/-command
will not be executed. It's default is 'normal', I.E. enabled.

=item B<-command>

As with any -command, this takes a subroutine to call when the button widget
is clicked.

=back

B<NB:> If you wish to change and ImageButton object so that a previously set
    image is no longer used, make sure you re-set the required option to 0.
    B<E.G.> $ib->configure(-imageover => 0);


=head1 METHODS

=head2 ClassInit( $top )

Initialized class bindings for the events C<Enter>, C<Leave>, C<ButtonPress-1>, and C<ButtonRelease-1>.

Class method. Cf. L<Tk::mega/ClassInit>.

=cut

sub ClassInit
{
    my ($class, $mw) = @_;
    $class->SUPER::ClassInit($mw);

    $mw->bind($class, '<Enter>', \&_IBEnter);       # Call _IBEnter when the mouse moves over the button.
    $mw->bind($class, '<Leave>', \&_IBLeave);       # Call _IBLeave when the mouse moves off the button.
    $mw->bind($class, '<ButtonPress-1>', \&_IBPress);   # Call _IBPress when the left mouse button is pressed over the button.
    $mw->bind($class, '<ButtonRelease-1>', \&_IBRelease);   # Call _IBRelease when the left mouse button is released.
} # /ClassInit




=head2 Populate( \%args )

TODO: add description of the stuff that happens here

Class method. Cf. L<Tk::mega/Populate>.

=cut

sub Populate
{
    my ($widget, $args) = @_;

    # -imagedisplay  - Required - This option is used to define the image that will be used as the default image for the button.
    #                             This is also the fallback option should none of the other images be set.
    #                             Needs to be passed a Tk::Photo
    # -imageover     - Optional - This option is used to define the image that is used when the mouse pointer is over the button.
    #                             If this is not set then -imagedisplay will be used.
    #                             Needs to be passed a Tk::Photo
    # -imageclick    - Optional - This option is used to define the image that is used when the left mouse button is clicked
    #                             over the button. If this is not set then -imagedisplay will be set.
    #                             Needs to be passed a Tk::Photo
    # -imagedisabled - Optional - This option is used to define the image that will be used when the button is disabled.
    #                             If this is not set then -imagedisplay will be used.
    #                             Needs to be passed a Tk::Photo
    # -state         - Optional - This stores the state of the button, either 'normal' or 'disabled'. This defaults to 'normal'
    #                             which is why I've called it optional. Changing the state will automatically update the button.
    # -command       - Optional - When you set the command, when the mouse button is released then the command is run. If you're
    #                             going to be using a button, then you really should set a command!

    $widget->ConfigSpecs(
                -imagedisplay => [qw/METHOD imageDisplay ImageDisplay/, 0],
                -imageover => [qw/METHOD imageOver ImageOver/, 0],
                -imageclick => [qw/METHOD imageClick ImageClick/, 0],
                -imagedisabled => [qw/METHOD imageDisabled ImageDisabled/, 0],
                -state => [qw/METHOD state State/, 'normal'],
                -command => ["CALLBACK", "command", "Command", undef]
    );

    $widget->configure(-borderwidth => 0);
    $widget->SUPER::Populate;

    # This section sets up the variables we'll be using in this widget. They are pretty self-explanatory, each one corresponds
    # to an option (listed above). The 'image_*' vars store Tk::Photo data. The 'state' var stores the state of the button.

    $widget->{image_display} = 0;
    $widget->{image_click} = 0;
    $widget->{image_over} = 0;
    $widget->{image_disabled} = 0;
    $widget->{state} = 'normal';
} # /Populate




=head2 _IBEnter( \%args )

When the mouse pointer moves over the button, if the button is enabled and C<-imageover> has been set then we change the
visible image to that of the C<-imageover> option. If -imageover isn't set or the button is disabled then we don't change
the image from that of the default.

=cut

sub _IBEnter
{
    my ($widget, $args) = @_;

    if ($widget->{state} ne 'disabled')
    {
        if ($widget->{image_over} != 0)
        {
            $widget->configure(-image => $widget->{image_over});
            $widget->update;
        }
    }
} # /_IBEnter




=head2 _IBLeave( \%args )

When the mouse pointer moves from over the button to somewhere else, if the button isn't disabled then we
set the button image back to the -imagedisplay Tk::Photo.

=cut

sub _IBLeave
{
    my ($widget, $args) = @_;

    if ($widget->{state} ne 'disabled')
    {
        if ($widget->{image_display} != 0)
        {
            $widget->configure(-image => $widget->{image_display});
            $widget->update;
        }
    }
} # /_IBLeave




=head2 _IBPress( \%args )

When the mouse pointer is clicked over the button, if -imageclick has been set and the button is not disabled
then we change the button image to that of the -imageclick option.

=cut

sub _IBPress
{
    my ($widget, $args) = @_;

    if ($widget->{state} ne 'disabled')
    {
        if ($widget->{image_click} != 0)
        {
            $widget->configure(-image => $widget->{image_click});
            $widget->update;
        }
    }
} # /_IBPress




=head2 _IBRelease( \%args )

When the mouse button is released, if the button is not disabled and the option -imageover has been set then
the button image is changed to that of the -imageover option. If the -imageover option has not been set then
the button image is changed to that of the -imagedisplay option. The -command option is then called.

=cut

sub _IBRelease
{
    my ($widget, $args) = @_;

    if ($widget->{state} ne 'disabled')
    {
        if ($widget->{image_over} != 0)
        {
            $widget->configure(-image => $widget->{image_over});
            $widget->update;
        }
        elsif ($widget->{image_display} != 0)
        {
            $widget->configure(-image => $widget->{image_display});
            $widget->update;
        }

        $widget->Callback(-command => $widget);
    }
} # /_IBRelease




=head2 imagedisplay( \%args )

This sets the -imagedisplay option. It takes a Tk::Photo as it's argument.
It then sets the initial image of the button to that Tk::Photo.
If cget is called on the option then it's setting is returned.

=cut

sub imagedisplay
{
    my ($widget, $args) = @_;

    if ($#_ > 0)
    {
        $widget->{image_display} = $args;
        $widget->configure(-image => $widget->{image_display});
        $widget->update;
    }
    else
    {
        $widget->{image_display};
    }
} # /imagedisplay




=head2 imageover( \%args )

This sets the -imageover option. It takes a Tk::Photo as it's argument.
If cget is called on the option then it's setting is returned.

=cut

sub imageover
{
    my ($widget, $args) = @_;

    if ($#_ > 0)
    {
        $widget->{image_over} = $args;
    }
    else
    {
        $widget->{image_over};
    }
} # /imageover




=head2 imageclick( \%args )

This sets the -imageclick option. It takes a Tk::Photo as it's argument.
If cget is called on the option then it's setting is returned.

=cut

sub imageclick
{
    my ($widget, $args) = @_;

    if ($#_ > 0)
    {
        $widget->{image_click} = $args;
    }
    else
    {
        $widget->{image_click};
    }
} # /imageclick




=head2 imagedisabled( \%args )

This sets the -imagedisabled option. It takes a Tk::Photo as it's argument.
If cget is called on the option then it's setting is returned.

=cut

sub imagedisabled
{
    my ($widget, $args) = @_;

    if ($#_ > 0)
    {
        $widget->{image_disabled} = $args;
    }
    else
    {
        $widget->{image_disabled};
    }
} # /imagedisabled




=head2 state( \%args )

This sets the -state option. If the button is set to 'normal' then the -imagedisplay
image is set as the button image. If the button is set to 'disabled' then the
-imagedisabled option is set as the button image (if the option has been set).
If cget is called on the option then it's setting is returned.

=cut

sub state
{
    my ($widget, $args) = @_;

    if ($#_ > 0)
    {
        $widget->{state} = $args;

        if ($widget->{state} eq 'normal')
        {
            if ($widget->{image_display} != 0)
            {
                $widget->configure(-image => $widget->{image_display});
                $widget->update;
            }
        }
        elsif ($widget->{state} eq 'disabled')
        {
            if ($widget->{image_disabled} != 0)
            {
                $widget->configure(-image => $widget->{image_disabled});
                $widget->update;
            }
        }
    }
    else
    {
        $widget->{state};
    }
} # /state




=head1 EXAMPLES

See the ib_test.pl script included with this distribution.

In the distribution there is a directory called "example", in here you will find
the files:

  ib_test.pl
  quit_clicked.bmp
  quit_disabled.bmp
  quit_normal.bmp
  quit_over.bmp

Run the file "ib_test.pl" with Perl for a demonstration of a multi-image button. View the file
"ib_test.pl" for an example of how to use the widget in your own scripts.

=head1 NOTES

The user will need to load in the images themselves, into Tk::Photo objects
and then pass these objects to ImageButton.

=head1 CAVEATS

None.

=head1 BUGS

None known at this time.


=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

B<Dave Hickling> dhickling@eidosnet.co.uk

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2004, Dave Hickling  All rights reserved.

This module is free software; you can redistribute and/or modify
it under the same terms as Perl itself.


=cut


1;