#!/usr/local/bin/perl
use warnings;
use strict;
use Config::Std { def_gap => 0 };

read_config "test.cfg" => my %config;
$config{SECTION}{NewEntry} = 'NewValue';
write_config %config;
