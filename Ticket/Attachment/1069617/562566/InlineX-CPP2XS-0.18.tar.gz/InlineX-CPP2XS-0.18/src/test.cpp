simple_double  simple(simple_double);
extra_simple_double x_simple(extra_simple_double);