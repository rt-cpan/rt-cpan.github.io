#define simple_double double
simple_double simple(simple_double d);
