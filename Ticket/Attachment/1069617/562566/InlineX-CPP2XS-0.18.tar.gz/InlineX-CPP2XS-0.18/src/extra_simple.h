#define extra_simple_double double
extra_simple_double x_simple(extra_simple_double d);
