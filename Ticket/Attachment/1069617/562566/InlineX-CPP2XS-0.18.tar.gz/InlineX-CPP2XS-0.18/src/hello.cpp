void greet() { printf("Hello World\n");}

int Remove_me_foo(int x) {
    return x * 3;
}
