#!/usr/bin/perl

use strict;
use Data::Dumper;
use Memoize qw(memoize flush_cache unmemoize);

# make memoized methods
memoize('test1', INSTALL => 'fast_test1', LIST_CACHE => 'MERGE');
memoize('test2', INSTALL => 'fast_test2', LIST_CACHE => 'MERGE');

# call memoized methods a few times
print fast_test1('one');
print fast_test1('one');
print fast_test1('one');
print fast_test1('two');
print fast_test1('two');
print fast_test1('two');

print fast_test2('one');
print fast_test2('one');
print fast_test2('one');
print fast_test2('two');
print fast_test2('two');
print fast_test2('two');

# peek into what's cached
print "DEBUG: memoized, and called fast_test1 and fast_test2 with two values each.
DEBUG: SHOULD SEE:
    two entries in memotale, each with two values cached ('one','two').
    two entries in revmemotable, each with both RHS and LHS values.\n";
peek_at_data();

# flush cache, and then peek at data
flush_cache('fast_test1');
flush_cache('fast_test2');

# peek into what's cached
print "DEBUG: flushed cache for fast_test1 and fast_test2
DEBUG: SHOULD SEE:
    two entries in memotable, nothing cached.
    two entrise in revmemotable, each with both RHS and LHS values.\n";
peek_at_data();

# unmemoize, then peek at data
unmemoize('fast_test1');
unmemoize('fast_test2');

# peek into what's cached
print "DEBUG: unmemoized fast_test1 and fast_test2
DEBUG: SHOULD SEE:
    empty memotable
    empty revmemotable
    !!! this is where orig is leaking
    !!! the code does an 'undef' on the hash entry,
    !!! which only undef's the value, and won't delete
    !!! the key.\n";
peek_at_data();


# memoize again, and add two more items to cache
memoize('test1', INSTALL => 'fast_test1', LIST_CACHE => 'MERGE');
memoize('test2', INSTALL => 'fast_test2', LIST_CACHE => 'MERGE');

print fast_test1('three');
print fast_test1('three');
print fast_test1('three');
print fast_test1('four');
print fast_test1('four');
print fast_test1('four');

# peek into what's cached
print "DEBUG: re-memoized fast_test1 and fast_test2, and called fast_test1
       with options 'three' and 'four'.
DEBUG: SHOULD SEE:
    one entry in memotable, with two values cached ('three', 'four')
    second entry in memotable, with no cached values.
    one entry in revmemotable, with both RHS and LHR values.
    !!! instead, we see FOUR entries in revmemotable. Memory leak on two.
    !!! memotable looks ok, because the keys (likely) get reused\n";
peek_at_data();


# finally, let's unmemoize again, and peek again.
unmemoize('fast_test1');
unmemoize('fast_test2');

# peek into what's cached
print "DEBUG: unmemoized fast_test1 and fast_test2
DEBUG: SHOULD SEE:
    empty memotable
    empty revmemotable
    !!! again, revmemotable still has FOUR entries in unpatched version.
    !!! and memotable still has two entries.\n";
peek_at_data();



sub test1 {
    my @opts = @_;
    print "test1: not cached.\n";
    return "test1:".join(',', map { "[$_]" } @opts)."\n";
}

sub test2 {
    my @opts = @_;
    print "test2: not cached.\n";
    return "test2:".join(',', map { "[$_]" } @opts)."\n";
}

sub peek_at_data {
    my %memotable = Memoize::_peek_at_memotable();
    my %revmemotable = Memoize::_peek_at_revmemotable();
    print "\n\n".("-"x70)."\n";
    print "MEMOTABLE:\n";
    print Dumper(\%memotable);
    print "\n\n".("-"x70)."\n";
    print "REVMEMOTABLE:\n";
    print Dumper(\%revmemotable);
    print "\n\n".("-"x70)."\n"; 
}
