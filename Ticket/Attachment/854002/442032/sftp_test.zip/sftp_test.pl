use Net::SFTP::Foreign;
use Log::WarnDie;
use strict;
use warnings;

sub Log::WarnDie::FILENO { -1 }

$Net::SFTP::Foreign::debug = 1;

my $sftp;
if ($sftp = Net::SFTP::Foreign->new(
	'127.0.0.1',
	ssh_cmd => 'plink',
	user => 'test',
	port => 22,
	more => [qw(-i cert_test.ppk)]
	))
{
	#$sftp->setcwd('OUT') or die "unable to change cwd: ".$sftp->error;
	my $files = $sftp->ls( '', no_wanted => qr/^\.\.?/, wanted => qr/^bf/i ) or die "ls failed: ".$sftp->error;
	foreach my $filedata (@{$files})
	{
		print $filedata->{'filename'}."\n";
	}
	$sftp->disconnect();
}
else
{
	die "Unable to establish SFTP connection: ".$sftp->error;
}