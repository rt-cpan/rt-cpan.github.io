package X::B;

use CLI::Dispatch;

use base 'CLI::Dispatch::Command';

use X::B::X;


sub run {

    X::B::X->run;

}

1;

__END__

=head1 NAME

X::B - x::b
