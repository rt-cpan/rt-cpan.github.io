package X::A;
use strict;
use base 'CLI::Dispatch::Command';

sub run {

    print __PACKAGE__, "\n";

}
1;

__END__

=head1 NAME

X::A - x::a
