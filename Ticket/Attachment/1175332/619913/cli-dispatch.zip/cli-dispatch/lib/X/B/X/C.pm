package X::B::X::C;
use strict;
use base 'CLI::Dispatch::Command';

sub run {

    print __PACKAGE__, "\n";

}
1;


__END__

=head1 NAME

X::B::X::C  - x b x c
