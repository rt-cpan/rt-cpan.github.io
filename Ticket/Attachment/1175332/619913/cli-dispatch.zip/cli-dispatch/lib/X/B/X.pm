package X::B::X;
use strict;
use base 'CLI::Dispatch';


1;
