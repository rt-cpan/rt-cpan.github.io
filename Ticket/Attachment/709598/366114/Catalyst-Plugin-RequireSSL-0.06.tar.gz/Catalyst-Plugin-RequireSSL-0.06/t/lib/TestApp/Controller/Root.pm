package TestApp::Controller::Root;

use strict;
use base 'Catalyst::Controller';

sub default : Private {
    my ( $self, $c ) = @_;
}

1;
