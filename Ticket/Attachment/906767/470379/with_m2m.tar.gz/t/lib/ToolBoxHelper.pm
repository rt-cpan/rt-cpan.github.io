package ToolBoxHelper;

use strict;
use warnings;

use Exporter 'import';   
our @EXPORT = qw(get_test_schema);

sub get_test_schema {
    my ( $class, $dsn, $user, $pass ) = @_;
    $class ||= "ToolBoxDB::Schema";
    $dsn ||= 'dbi:SQLite:dbname=t/db/toolbox.db';
    my $schema = $class->connect( $dsn, $user, $pass, {} );
    my $deploy_attrs;
    $deploy_attrs->{add_drop_table} = 1 ;
    $schema->deploy( $deploy_attrs );
    $schema->populate('ToolBox', [
        [ qw/toolbox_id name/ ],
        [ '1', 'JoesBox'],
        [ '2', 'JohnsBox'],
        [ '3' , 'JacksBox'],
        ]
    );
    $schema->populate('Tool', [
        [ qw/ tool_id name / ],
        [ '1', 'shovel'],
        [ '2' , 'hammer' ],
        [ '3' , 'screwdriver'],
        [ '4' , 'saw'],
        [ '5' , 'collet'],
        ]
    );
    $schema->populate('ToolBoxTool', [
        [ 'toolbox_id', 'tool_id' ],
        [ 1, 1 ],
        [ 1, 2 ],
        [ 1, 3 ],
        [ 1, 4 ],  
        [ 1, 5 ],
       ]
    );
    return $schema;
}

1;
