package ToolBoxDB::Schema::Result::ToolBoxTool;

use strict;
use warnings;

use base 'DBIx::Class::Core';

__PACKAGE__->table('toolbox_tool');

__PACKAGE__->add_columns(
  "tool_id",
  {
    data_type => "INTEGER",
    is_nullable => 0,
  },
  "toolbox_id",
  {
    data_type => "INTEGER",
    is_nullable => 0,
  },
);
__PACKAGE__->set_primary_key("tool_id", "toolbox_id");

__PACKAGE__->belongs_to(
  "tool", 
  "ToolBoxDB::Schema::Result::Tool",
  {"foreign.tool_id" => "self.tool_id"},
);

__PACKAGE__->belongs_to(
  "toolbox", 
  "ToolBoxDB::Schema::Result::ToolBox",
  {"foreign.toolbox_id" => "self.toolbox_id"},
);
1;
