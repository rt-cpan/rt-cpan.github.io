package ToolBoxDB::Schema::Result::ToolBox;

use strict;
use warnings;

use base 'DBIx::Class::Core';

__PACKAGE__->table('toolbox');

__PACKAGE__->add_columns(
  "toolbox_id",
  {
    data_type => "INTEGER",
    is_nullable => 0,
  },
  "name",
  {
    data_type => "TEXT",
    default_value => 'unnamed',
    is_nullable => 0,
    size => 32,
  },
);
__PACKAGE__->set_primary_key("toolbox_id");
__PACKAGE__->add_unique_constraints(
	[qw/name/],
);

__PACKAGE__->has_many(
  "toolbox_tools", 
  "ToolBoxDB::Schema::Result::ToolBoxTool",
  {"foreign.toolbox_id" => "self.toolbox_id"},
);

__PACKAGE__->many_to_many(
   "tools" => "toolbox_tools", "tool"
);

1;
