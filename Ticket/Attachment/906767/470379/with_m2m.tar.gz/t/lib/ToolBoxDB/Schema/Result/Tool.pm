package ToolBoxDB::Schema::Result::Tool;

use strict;
use warnings;

use base 'DBIx::Class::Core';

__PACKAGE__->table('tool');

__PACKAGE__->add_columns(
  "tool_id",
  {
    data_type => "INTEGER",
    is_nullable => 0,
  },
  "name",
  {
    data_type => "TEXT",
    default_value => 'unnamed',
    is_nullable => 0,
    size => 32,
  },
);
__PACKAGE__->set_primary_key("tool_id");
__PACKAGE__->add_unique_constraints(
	[qw/name/],
);

__PACKAGE__->has_many(
  "toolbox_tools", 
  "ToolBoxDB::Schema::Result::ToolBoxTool",
  "tool_id",
);

__PACKAGE__->many_to_many(
  "toolboxes" => "toolbox_tools", "toolbox"
);

1;
