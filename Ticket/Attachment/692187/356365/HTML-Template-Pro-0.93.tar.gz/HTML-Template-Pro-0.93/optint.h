#include "pparam.h"

extern TMPLPRO_LOCAL void _reset_int_options_set_nonzero_defaults(struct tmplpro_param* param);
/*
  Local Variables:
  mode: c
  End:
*/
