﻿open F, '>', 'foo.xsd';
print F <<EOS;
<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0">
	<xsd:element name="WIP">
		<xsd:complexType mixed="false">
			<xsd:sequence>
				<xsd:element name="websiteID" type="IntOrParam" minOccurs="1" maxOccurs="1" />
				<xsd:element name="processID" type="IntOrParam" minOccurs="1" maxOccurs="1" />
				<xsd:element name="subphase" type="IntOrParam" minOccurs="1" maxOccurs="1" />
				<xsd:element name="test" type="Empty" minOccurs="0" maxOccurs="1" />
			</xsd:sequence>
		</xsd:complexType>
	</xsd:element>
	<xsd:complexType name="Empty">
	</xsd:complexType>
	<xsd:complexType name="IntOrParam">
		<xsd:choice minOccurs="0" maxOccurs="1">
			<xsd:element name="text" type="xsd:integer" minOccurs="1" maxOccurs="1" />
			<xsd:sequence minOccurs="1" maxOccurs="1">
				<xsd:element ref="text" minOccurs="0" maxOccurs="1" />
				<xsd:element ref="param" minOccurs="1" maxOccurs="1" />
				<xsd:element ref="text" minOccurs="0" maxOccurs="1" />
			</xsd:sequence>
		</xsd:choice>
	</xsd:complexType>
	<xsd:element name="param">
		<xsd:complexType mixed="false">
			<xsd:attribute name="name" type="xsd:string" use="required" />
		</xsd:complexType>
	</xsd:element>
	<xsd:element name="text" type="xsd:string" />
</xsd:schema>
EOS
close F;

open F, '>', 'foo.xml';
print F <<EOX ;
<WIP><websiteID><param name="websiteID" /></websiteID><processID>1</processID><subphase>100</subphase></WIP>
EOX
close F;

  use XML::SAX::ParserFactory;
  use XML::Validator::Schema;

  #
  # create a new validator object, using foo.xsd
  #
  $validator = XML::Validator::Schema->new(file => 'foo.xsd');

  #
  # create a SAX parser and assign the validator as a Handler
  #
  $parser = XML::SAX::ParserFactory->parser(Handler => $validator);

  #
  # validate foo.xml against foo.xsd
  #
  eval { $parser->parse_uri('foo.xml') };
  die "File failed validation: $@" if $@;
