package Package::Class;

use strict;
use warnings;

#** @method public new ()
# @brief Object constructor
# @return 42
#*
sub new {
    # do something
    return 42;
}

#** @method private get_answer ()
# @brief gets answer
# @return 42
#*
sub get_answer {
    # do something
    return 42;
}
1;

