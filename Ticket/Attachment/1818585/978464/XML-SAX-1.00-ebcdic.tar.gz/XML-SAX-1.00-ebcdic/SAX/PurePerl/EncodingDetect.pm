# $Id: EncodingDetect.pm,v 1.6 2018/11/07 08:50:14 huzeh00 Exp $

package XML::SAX::PurePerl; # NB, not ::EncodingDetect!

use strict;

my $ON_EBCDIC = ord 'A' == 193; # running on an EBCDIC (1047) platform

sub encoding_detect {
    my ($parser, $reader) = @_;
    
    my $error = "Invalid byte sequence at start of file";
    
    my $data = $reader->data;
#    hexdump($data);                                helpful debugging
    if ($data =~ /^\x00\x00\xFE\xFF/) {
        # BO-UCS4-be
        $reader->move_along(4);
        $reader->set_encoding('UCS-4BE');
        return;
    }
    elsif ($data =~ /^\x00\x00\xFF\xFE/) {
        # BO-UCS-4-2143
        $reader->move_along(4);
        $reader->set_encoding('UCS-4-2143');
        return;
    }
    elsif ($data =~ /^\x00\x00\x00\x3C/) {
        $reader->set_encoding('UCS-4BE');
        return;
    }
    elsif ($data =~ /^\x00\x00\x3C\x00/) {
        $reader->set_encoding('UCS-4-2143');
        return;
    }
    elsif ($data =~ /^\x00\x3C\x00\x00/) {
        $reader->set_encoding('UCS-4-3412');
        return;
    }
    elsif ($data =~ /^\x00\x3C\x00\x3F/) {
        $reader->set_encoding('UTF-16BE');
        return;
    }
    elsif ($data =~ /^\xFF\xFE\x00\x00/) {
        # BO-UCS-4LE
        $reader->move_along(4);
        $reader->set_encoding('UCS-4LE');
        return;
    }
    elsif ($data =~ /^\xFF\xFE/) {
        $reader->move_along(2);
        $reader->set_encoding('UTF-16LE');
        return;
    }
    elsif ($data =~ /^\xFE\xFF\x00\x00/) {
        $reader->move_along(4);
        $reader->set_encoding('UCS-4-3412');
        return;
    }
    elsif ($data =~ /^\xFE\xFF/) {
        $reader->move_along(2);
        $reader->set_encoding('UTF-16BE');
        return;
    }
    elsif ($data =~ /^\xEF\xBB\xBF/) { # UTF-8 BOM
        $reader->move_along(3);
        $reader->set_encoding('UTF-8');
        return;
    }
    elsif ($data =~ /^\x3C\x00\x00\x00/) {
        $reader->set_encoding('UCS-4LE');
        return;
    }
    elsif ($data =~ /^\x3C\x00\x3F\x00/) {
        $reader->set_encoding('UTF-16LE');
        return;
    }
    elsif ($data =~ /^\x3C\x3F\x78\x6D/) {
        # $reader->set_encoding('UTF-8');
        return;
    }
    elsif ($data =~ /^\x3C\x3F\x78/) {
        if ( $ON_EBCDIC ) { set_encoding('UTF-8'); }
        # $reader->set_encoding('UTF-8');
        return;
    }
    elsif ($data =~ /^\x3C\x3F/) {
        if ( $ON_EBCDIC ) { set_encoding('UTF-8'); }
        # $reader->set_encoding('UTF-8');
        return;
    }
    elsif ($data =~ /^\x3C/) {
        if ( $ON_EBCDIC ) { set_encoding('UTF-8'); }
        # $reader->set_encoding('UTF-8');
        return;
    }
    elsif ($data =~ /^[\x20\x09\x0A\x0D]+\x3C[^\x3F]/) {
        if ( $ON_EBCDIC ) { set_encoding('UTF-8'); }
        # $reader->set_encoding('UTF-8');
        return;
    }
    elsif ($data =~ /^[\x40\x41\x15\x12\x09\x05\x0D]*\x4C(\x5A|\x6F)/) {                   # <! or <?  ebcdic 1047 encoded
        $reader->set_encoding('EBCDIC');
        return;
    }
    
    warn("Unable to recognise encoding of this document");
    return;
}

sub hexdump{
  my $data = $_[0];  
  my $len = length($data);

  #hex, content
  my $buf_hex = uc(unpack('H*', $data));
  $buf_hex =~ s/\G(..)/$1 /g;
  my $buf_content = $data;
  $buf_content =~ s/[^a-z0-9\\|,.<>;:'\@[{\]}#`!"\$%^&*()_+=~?\/ -]/./gi;

  my $output = "\e[1;31m#0xADDRESS (00000) : 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F : ---DATA---\e[0m\n";
  for(my $offset=0,my $addr_start=0;$addr_start<$len;$offset+=16,$addr_start+=16){
    my $hex = '';
    my $content = '';
    for(my $i=0;$i<16;$i++){
      my $hex_tmp = substr($buf_hex, ($offset+$i)*3, 2);
      $hex .= ($hex_tmp)?sprintf("%s ", $hex_tmp):"   ";
      $content .= sprintf("%s",substr($buf_content, $offset+$i, 1));
    }
    $output .= sprintf("0x%08X (%05d) : ", $addr_start, $addr_start)."$hex: $content\n";
  }
  print $output;
}

1;

