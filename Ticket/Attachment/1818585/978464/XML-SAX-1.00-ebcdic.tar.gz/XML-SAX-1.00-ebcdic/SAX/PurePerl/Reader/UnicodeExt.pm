# $Id: UnicodeExt.pm,v 1.2 2018/09/12 11:38:33 huzeh00 Exp $

package XML::SAX::PurePerl::Reader;
use strict;

my $ON_EBCDIC = ord 'A' == 193; # running on an EBCDIC (1047) platform

# the purpose of this file is to convert the input data to the local perl codepage

use Text::Iconv;

use Encode ();

sub set_raw_stream {
    my ($fh) = @_;
    binmode($fh, ":bytes");
}

sub switch_encoding_stream {
    my ($fh, $encoding) = @_;

    if ($ON_EBCDIC) {
      # do not switch stream, but convert in read_more in Reader/Stream.pm
      return;
    }
    binmode($fh, ":encoding($encoding)");
}

sub switch_encoding_string {
    my $encoding= $_[1];
    if ($ON_EBCDIC) {
      if ( $encoding eq "EBCDIC" ) { $encoding="IBM1047"; return; } # no conversion needed
      my $converter = Text::Iconv->new($encoding, "IBM1047" );
      $_[0] = $converter->convert($_[0]);
      return;    
    }
    $_[0] = Encode::decode($encoding, $_[0]);
}


1;

