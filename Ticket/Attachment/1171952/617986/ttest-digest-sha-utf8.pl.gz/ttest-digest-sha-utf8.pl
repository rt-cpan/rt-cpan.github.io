#!/usr/bin/perl -w

use strict;
use utf8;
use Test::More;

binmode STDOUT, ':utf8';
binmode STDERR, ':utf8';

my @tests = <DATA>;
my @algos = qw/SHA::PurePerl SHA/;

plan tests => scalar @algos;

foreach my $algo (@algos) {
	subtest "check algo $algo" => sub {
		&test_algo($algo, @tests);
	};
}

sub test_algo {
	my ($algo, @tests) = @_;

	my $m = "Digest::$algo";
	eval "require $m";
	my $dgst = $m->new;

	plan tests => scalar @tests;
	foreach my $test (@tests) {
		chomp $test;
		subtest "check $algo on $test" => sub {
			&test_str($dgst, $test);
		};
	}
}

sub test_str {
	my ($dgst, $test) = @_;
	plan tests => 3;

	my ($str, $len, $hash) = split(/\t+/, $test);

	ok(utf8::is_utf8($str), "'$str' is utf8");
	is(length($str), $len, "length $len");

	# utf8::encode($str);

	$dgst->reset;
	$dgst->add($str);

	is($dgst->hexdigest, $hash, "hash $hash");
	# ok(utf8::is_utf8($str), "'$str' is still utf8");
	# is(length($str), $len, "length $len");
}
__DATA__
nonsense	8	cb1dc474e185777dad218b7d60f2781723d8190b
blödsinn	8	bd0f217087566043ca73d9e9ce81f7c9a4311872
廢話		2	aabc1a331f97ba4b4157abca134812992d22dccf
