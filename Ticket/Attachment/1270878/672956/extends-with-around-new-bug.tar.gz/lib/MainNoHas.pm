package MainNoHas;

use Moo;

with 'RoleAroundNew';    # around new happens once as expected

1;
