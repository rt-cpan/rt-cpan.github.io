package ExtendsMainHasBeforeWith;

use Moo;

has baz => ( is => "ro", "default" => sub { 23 } );    # take both has's away and it works like it should!!!

extends 'MainHasBeforeWith';

has bar => ( is => "ro", "default" => sub { 23 } );    # take both has's away and it works like it should!!!

1;
