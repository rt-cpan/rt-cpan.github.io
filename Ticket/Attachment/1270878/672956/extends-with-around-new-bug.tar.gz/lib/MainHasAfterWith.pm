package MainHasAfterWith;

use Moo;

with 'RoleAroundNew';

has 'foo' => ( is => 'ro' );    # around new not run

1;
