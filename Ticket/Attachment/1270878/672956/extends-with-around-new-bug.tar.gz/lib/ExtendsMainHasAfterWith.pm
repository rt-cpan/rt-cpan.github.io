package ExtendsMainHasAfterWith;

use Moo;

# still fails ot call around new w/ has before and/or after extends

extends 'MainHasAfterWith';

1;
