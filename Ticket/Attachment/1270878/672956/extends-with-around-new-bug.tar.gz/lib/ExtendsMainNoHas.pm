package ExtendsMainNoHas;

use Moo;

# still works w/ has before and/or after extends

extends 'MainNoHas';

1;
