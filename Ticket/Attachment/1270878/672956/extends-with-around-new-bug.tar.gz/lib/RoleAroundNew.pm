package RoleAroundNew;

# behaves the same if you change to Role::Tiny;
use Moo::Role;

around 'new' => sub {
    my ( $orig, $self, @args ) = @_;
    print "Debug: I am in the around->new\n";
    return $orig->( $self, @args );
};

1;
