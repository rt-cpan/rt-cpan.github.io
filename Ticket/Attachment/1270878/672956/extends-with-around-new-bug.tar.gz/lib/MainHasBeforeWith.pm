package MainHasBeforeWith;

use Moo;

has 'foo' => ( is => 'ro' );    # Deep recursion on subroutine "Y::new" at (eval 16) line 9.

with 'RoleAroundNew';

1;
