CREATE TABLE base (uuid char(36), title char(250));
CREATE TABLE child (summary char(250)) INHERITS (base);