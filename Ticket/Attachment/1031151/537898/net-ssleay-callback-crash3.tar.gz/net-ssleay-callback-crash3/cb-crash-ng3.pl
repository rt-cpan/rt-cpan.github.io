use threads;
use strict;
use warnings;

use FindBin;
use Net::SSLeay;

Net::SSLeay::load_error_strings();
Net::SSLeay::SSLeay_add_ssl_algorithms();
Net::SSLeay::randomize();

my $testid = 't3';
my $file = "$FindBin::Bin/pk_1024.key.pem";

print STDERR "Gonna start multi-threading part\n";
for (1..9999) {
  threads->new(\&do_check);
  warn "Threads currently running=", scalar(threads->list(threads::running)), "\n";
  do_sleep(50) while (scalar(threads->list(threads::running)) > 100); #do not start more than 100 threads concurrently
}

print STDERR "Waiting for all threads to finish\n";
do_sleep(50) while (scalar(threads->list(threads::running)) > 0);
print STDERR "Done!\n";
exit(0);

sub callback {
  printf STDERR ("[thread:%04d] Inside callback\n", threads->tid);
  return "12345678"; # password
}

sub do_sleep {
  my $miliseconds = shift;
  select(undef, undef, undef, $miliseconds/1000);
}

sub do_check {
  printf STDERR ("[thread:%04d test:$testid] do_check started\n", threads->tid);
  
  my $c = Net::SSLeay::CTX_new() or die "CTX_new failed";
  Net::SSLeay::CTX_set_default_passwd_cb($c, \&callback);
  Net::SSLeay::CTX_use_PrivateKey_file($c, $file, &Net::SSLeay::FILETYPE_PEM) or die "CTX_use_PrivateKey_file failed";
  Net::SSLeay::CTX_set_default_passwd_cb($c, undef);
  Net::SSLeay::CTX_free($c);
  do_sleep(rand(2000));
    
  printf STDERR ("[thread:%04d test:$testid] do_check finished\n", threads->tid);
  threads->detach();
}
