#!/usr/bin/env perl

use strict;
use warnings;
use LaTeX::Table;

my $header = [
	['w' , 'x' ],
];
  
  my $data = [
      ['y', 'z']
  ];

my $opts = {
	header      => $header,
	columns_like_header => [ 0 ],
	data        => $data,
};
my $table = LaTeX::Table->new({   
	filename    => 'test.tex.in',
	%$opts,
});
  
$table->set_theme('NYC');
$table->generate();
