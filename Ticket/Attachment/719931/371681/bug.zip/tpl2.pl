use strict;
use Getopt::Long;
use Data::Dumper;
use Template;
#
my $PRG_NAME = "tpl2.pl";
my $debug = 0;
my $input = '';
my $output = '';
my $tag_file = '';
my $opt_help = 0;
my @numbers = ();
my @content = ();
my @y = ();
#
my $build_dir;
my $tag;
#
my @help_msg = ( "Usage: $PRG_NAME [POSIX or GNU style options] file ...",
 "Options:",
 " -i FILE, --in=FILE      input FILE (default is '$input').",
 " -o FILE, --out=FILE     output FILE (default is '$output').",
 " -t FILE, --tag=FILE     tag FILE (default is '$tag_file')",
 " -d, --debug             Print variables namespace.",
 " -h, --help              Print this message and exit.",
);
#
if ($#ARGV < 0) { usage(); }
#
Getopt::Long::config("no_ignore_case");
#
my $ret = GetOptions(
	"debug|d",	\$debug,
	"help|h",		\$opt_help,
	"in|i=s",		\$input,
	"out|o=s",	\$output,
	"tag|t=s",	\$tag_file,
);
#
my %vars = ();
#
if ($opt_help || !$ret) { usage(); }
#
my $template = Template->new;
#
$vars{os}		= $^O;
$vars{host}	= $ENV{'COMPUTERNAME'};
$vars{user}	= $ENV{'USERNAME'};
#
if( $^O eq "MSWin32" ){
	$build_dir = Win32::GetCwd();
}
#! gestire anche gli altri OS !
$vars{build_dir} = $build_dir;
#
if( $var_file ne '' ){
}
#
if( $debug == 1 ){
	print Dumper(%vars);
}else{
	if( $input eq '' || $output eq '' ){ 
		print "missing I/O filename (in: $input, out: $output)\n";
	}else{
		$template->process($input,\%vars,$output) || die $template->error();
	}
}
#
#-----------------------------------------------------------------
#
sub usage {
  my $m;
  foreach $m ( @help_msg ) { print "$m\n"; }
  exit 0;
}
