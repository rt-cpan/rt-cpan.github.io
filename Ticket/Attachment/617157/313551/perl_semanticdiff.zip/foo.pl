#!/usr/bin/perl

# use module
use XML::Simple;
#use XML::SemanticDiff;
use Data::Dumper;

# create object
$xml = new XML::Simple;
#$xml = new XML::Simple(KeyAttr=>'sku');

# read XML file
$data = $xml->XMLin("file1.xml");
$file1 = $xml->XMLin("file1.xml");
$file2 = $xml->XMLin("file2.xml");


my $diff = XML::SemanticDiff->new();

foreach my $change ($diff->compare($file1, $file2)) {
      print "$change->{message} in context $change->{context}\n";
  }

# print the data output
# print Dumper($data);



#my $config = XMLin();
#print Dumper($config);
 
    #my $ref = XMLin([<xml file or string>] [, <options>]);

   # my $xml = XMLout($hashref [, <options>]);