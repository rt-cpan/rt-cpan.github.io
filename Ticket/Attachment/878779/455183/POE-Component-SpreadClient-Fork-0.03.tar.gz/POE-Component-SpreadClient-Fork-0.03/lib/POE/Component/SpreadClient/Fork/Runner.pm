package POE::Component::SpreadClient::Fork::Runner;
use strict; use warnings;

use vars qw($VERSION);
$VERSION = '0.03';

use POE;

use POE::Wheel::Run;
use POE::Filter::Reference;

use POE::Component::SpreadClient;

use Spread;

use constant DEBUG => 0;

sub spread_runner {
    POE::Kernel->stop();

    DEBUG and print STDERR "runner: forked\n";

    POE::Session->create
        ( inline_states =>
          {
           _start => sub {
               my ($kernel, $heap) = @_[KERNEL, HEAP];
               my $client = POE::Wheel::ReadWrite->new(
                                                       InputHandle  => \*STDIN,
                                                       OutputHandle => \*STDOUT,
                                                       InputEvent   => 'runner_input',
                                                       ErrorEvent   => 'runner_error',
                                                       Filter       => POE::Filter::Reference->new(),
                                                      );

               $heap->{client} = $client;

               # $kernel->sig(TERM => '_stop');
               $kernel->sig(TERM => 'shutdown');

               DEBUG and print STDERR "runner: session started\n";
           },

           shutdown => sub {
               delete $_[HEAP]->{client};

               $_[KERNEL]->sig_handled();
           },

           runner_input => sub {
               my ($heap, $kernel, $input) = @_[HEAP, KERNEL, ARG0];
               # WWW $input

               # my ($command, $data, $session) = @{$input}{qw/c d s/};

               if ($input->{c} eq 'connect') {
                   # set watcher for the given senderID
                   $kernel->state($input->{s}, \&send_upstream);
               }

               $kernel->yield($input->{c} => $input->{d} => $input->{s});

           },

           runner_error => sub {
               my ($heap, $op, $code) = @_[HEAP, ARG0, ARG1];
               warn "runner error: $op $code";
           },

           # run_command => \&run_command,

            connect => \&run_command,
            disconnect => \&run_command,
            subscribe => \&run_command,
            unsubscribe => \&run_command,
            publish => \&run_command,
            register => \&run_command,
            unregister => \&run_command,
            destroy => \&run_command,

            RW_Error  => \&run_command,
            RW_GotPacket => \&run_command,

          }
        ) or die "runner: can't POE::Session->create: $!";

  POE::Kernel->run();

  DEBUG and print STDERR "runner: done\n";

  return;
}

# special stub module
sub Sender::ID { ${+shift} }

sub run_command {
    my (@args) = @_;

    unless ($_[STATE] =~ /^RW_/) {
        # these events have the sender ID appended to the argument list.
        my $sender = pop @args;
        $args[SENDER] = bless ( \$sender, 'Sender'); # replace with object

        # and a listref where the args list goes
        push @args, @{ pop @args };
    }

    {
        no warnings "redefine";
        local *POE::Kernel::call = *POE::Kernel::post = \&POE::Kernel::yield;
        eval "POE::Component::SpreadClient::$_[STATE](\@args)"; # invoke state
    }

    $_[KERNEL]->yield('shutdown') if $_[STATE] eq 'destroy';
}

sub send_upstream {
    my ($kernel, $heap, $session, @data) = @_[KERNEL, HEAP, STATE, ARG0..$#_];

    ## We play a little trick here, and make the event name I was
    ## called by equal the original senderid that should get the data.

    # WWW { s => $_[ARG0], d => [ @_[ARG1..$#_] ] };

    $heap->{client}->put( { s => $session, d => \@data } );
}

1;
