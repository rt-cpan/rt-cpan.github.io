package POE::Component::SpreadClient::Fork;
use strict; use warnings;

use vars qw($VERSION);
$VERSION = '0.03';

use POE;

use POE::Filter::Reference;
use POE::Component::SpreadClient::Fork::Runner;

use constant DEBUG => 0;

sub spawn {
    my $type = shift;
    my $ALIAS = shift;

    POE::Session->create( inline_states => { _start => \&_start,

                                             # wheel::run
                                             handle_stdout => \&handle_stdout,
                                             handle_stderr => \&handle_stderr,
                                             handle_error => \&handle_error,
                                             handle_close => \&handle_close,
                                             sig_child => \&sig_child,

                                             # commands
                                             connect => \&send_command,
                                             disconnect => \&send_command,
                                             subscribe => \&send_command,
                                             unsubscribe => \&send_command,
                                             publish => \&send_command,
                                             register => \&send_command,
                                             unregister => \&send_command,
                                             destroy => \&send_command,

                                           },
                          heap => { ALIAS => $ALIAS },
                        ) or die "Can't POE::Session->create(): $!";
}

sub _start {
    my ($alias) = $_[HEAP]->{ALIAS};
    $_[KERNEL]->alias_set($alias);

    # my $child =
    $_[HEAP]->{child} =
      POE::Wheel::Run->new( Program => \&POE::Component::SpreadClient::Fork::Runner::spread_runner,
                            # Program => \&spread_runner,

                            StdioFilter => POE::Filter::Reference->new(),

                            # CloseOnCall => 1,
                            # CloseEvent => 'handle_close',
                            ErrorEvent => 'handle_error',

                            StdoutEvent => 'handle_stdout',
                            StderrEvent => 'handle_stderr',
                          ) or die "can't POE::Wheel::Run->create: $!";

    $poe_kernel->sig_child($_[HEAP]->{child}->PID, "sig_child");

}

sub send_command {
    $_[HEAP]->{child}->put( { s => $_[SENDER]->ID,
                              c => $_[STATE],
                              d => [ @_[ARG0..$#_] ]
                            }
                          );
}

sub sig_child {
    delete $_[HEAP]->{child};
}

## Runner states
sub handle_error {
    return if $_[ARG0] eq 'read' and $_[ARG1] == 0;

    warn "$_[STATE] => @_[ARG0..$#_]\n";
}

sub handle_stderr {
    print STDERR "| $_[ARG0]\n";
    # WWW { stderr => [ @_[ARG0..$#_] ] };
    my ($data, $wheel_id) = @_[ARG0, ARG1];
}

sub handle_stdout {
    my ($data, $wheel_id) = @_[ARG0, ARG1];

    $_[KERNEL]->post($data->{s}, @{$data->{d}});
}

1;
