#! /opt/perl/bin/perl
use strict;
use warnings;

use HTML::Template::Compiled;

my $basepath = '/home/voitvolk/htc';

my $htc1 = HTML::Template::Compiled->new(
    tagstyle => [qw(-classic -comment +asp)],
    path     => $basepath . '/test',
    filename => 'test.htc',
);
my $htc2 = HTML::Template::Compiled->new(
    tagstyle => [qw(-classic -comment +asp)],
    path     => $basepath,
    filename => '/test/test.htc',
);
my $htc3 = HTML::Template::Compiled->new(
    tagstyle => [qw(-classic -comment +asp)],
    path     => $basepath,
    filename => 'test.htc',
);
my $htc4 = HTML::Template::Compiled->new(
    tagstyle => [qw(-classic -comment +asp)],
    filename => 'test.htc',
);
my $htc5 = HTML::Template::Compiled->new(
    tagstyle => [qw(-classic -comment +asp)],
    filename => '/home/voitvolk/htc/test.htc',
);

print 'ouput htc1: ' . $htc1->output();
print 'ouput htc2: ' . $htc2->output();
print 'ouput htc3: ' . $htc3->output();
print 'ouput htc4: ' . $htc4->output();
print 'ouput htc5: ' . $htc5->output();

__END__

There are two template-files
/basepath/test.htc
/basepath/test/test.htc

This is the output of the sript:
ouput htc1: now output from /basepath/htc/test/test.htc

ouput htc2: now output from /basepath/htc/test/test.htc

ouput htc3: now output from /basepath/htc/test/test.htc

ouput htc4: now output from /basepath/htc/test/test.htc

ouput htc5: now output from /basepath/htc/test.htc

