package MB::Test;
1;
