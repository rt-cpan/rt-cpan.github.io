use threads;
use strict;
use warnings;

use Net::SSLeay;

Net::SSLeay::load_error_strings();
Net::SSLeay::SSLeay_add_ssl_algorithms();
Net::SSLeay::randomize();

print STDERR "Gonna start main thread part\n";
fake_job();

print STDERR "Gonna start multi-threading part\n";
for (1..9999) {
  threads->new(\&do_check);
  warn "Threads currently running=", scalar(threads->list(threads::running)), "\n";
  do_sleep(50) while (scalar(threads->list(threads::running)) > 100); #do not start more than 100 threads concurrently
}

print STDERR "Waiting for all threads to finish\n";
do_sleep(50) while (scalar(threads->list(threads::running)) > 0);
print STDERR "Done!\n";
exit(0);

sub fake_job {
  my $i = 0;
  $i += rand(5) for (1...100000);
  return $i;
}

sub do_sleep {
  my $miliseconds = shift;
  select(undef, undef, undef, $miliseconds/1000);
}

sub do_check {
  printf STDERR ("[thread:%04d] do_check started\n", threads->tid);
  
  fake_job();
  do_sleep(rand(2000));

  printf STDERR ("[thread:%04d] do_check finished\n", threads->tid);
  threads->detach();
}
