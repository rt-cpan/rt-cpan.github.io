package MyApp::Controller::Test;

use strict;
use warnings;

use base 'Catalyst::Controller::REST';

sub thing : Path('/test') : ActionClass('REST') { }

sub thing_POST
{
    my ( $self, $c ) = @_;

    my $text = sprintf("%d character(s)", length( $c->request->{data}->{'utf8-string'} ) );

    $c->response->body( $text );
}

=head1 AUTHOR

Erik Wasser

=head1 LICENSE

This library is free software, you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

1;
