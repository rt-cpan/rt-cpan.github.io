#Testfile
use strict;
use YAML;
use Encode qw/encode/;
use TestMG::I18N;
use vars qw($lh);

my $language = 'de';
$lh = TestMG::I18N->get_handle($language) || die "Language?";

print $lh->maketext("Hello world"),"\n";




