use strict;

use DBIx::Class::Schema::Loader;

package Tst::Schema;
use base qw/DBIx::Class::Schema::Loader/;

__PACKAGE__->loader_options(relationships => 1, 
    # that would solve the problem, but it's not a proper solution:
    # inflect_singular => {'obj_res' => 'obj_res'}
  );
1;
