#! /usr/bin/perl -w
use strict;
use Tst::Schema;

my $schema = Tst::Schema->connect("DBI:mysql:database=dbix_test;", 'user', 'user');
my $rs = $schema->resultset('Obj')->search('id' => 1);
my $a = $rs->first;

printf "DBIx::Class::Schema::Loader::VERSION = %s\n", 
    $DBIx::Class::Schema::Loader::VERSION;
print "\$a->obj_res: " . $a->obj_res . "\n"; # prints '1' !???
print "\$a->obj_aaa: " . $a->obj_aaa . "\n"; # prints 'Tst::Schema::ObjAaa=HASH(0xhhhhhhhh)'
