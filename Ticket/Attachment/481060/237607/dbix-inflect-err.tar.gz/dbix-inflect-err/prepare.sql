drop database if exists dbix_test;
create database dbix_test;
use dbix_test;

CREATE TABLE obj_res (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(80)
);

CREATE TABLE obj_aaa (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(80)
);

CREATE TABLE obj (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  obj_res INT UNSIGNED,
  obj_aaa INT UNSIGNED,
  FOREIGN KEY (obj_res) REFERENCES obj_res (id) ON DELETE CASCADE,
  FOREIGN KEY (obj_aaa) REFERENCES obj_aaa (id) ON DELETE CASCADE
);

INSERT INTO obj_res VALUES (NULL, 'Item1');
INSERT INTO obj_aaa VALUES (NULL, 'Item1');
INSERT INTO obj VALUES (NULL, 1, 1);
