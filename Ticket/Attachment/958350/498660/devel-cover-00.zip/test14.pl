use POSIX qw/LC_ALL LC_NUMERIC setlocale/;
setlocale( LC_ALL, 'ru_RU.UTF-8' );
