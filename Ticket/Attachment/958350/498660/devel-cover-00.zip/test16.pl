use strict;
use warnings;
use POSIX qw/setlocale LC_ALL/;
use Devel::Peek;

BEGIN{ setlocale( LC_ALL, "ru_RU.UTF-8" ) }
use Inline C => "SV* test_nv(){ return newSVnv(1.31023480790322e+15); }";
print Dump &test_nv;
