﻿#!/usr/bin/perl
use strict;
use encoding "utf8";
use open IO => ":utf8"; # These two by themselves should have been enough to support utf8
use LWP::UserAgent;
use HTML::TreeBuilder 3;	# make sure our version isn't ancient

my $browser = LWP::UserAgent->new();

# This is a Hebrew language site, the Israeli equivalent of the US SEC, from which I need to extract reports:
my $url_request = "http://www.magna.isa.gov.il/Pages/frmResults.aspx?en=1&pa=1&g=true&rn=510928237&rt=6&d1=17/05/2010&d2=17/05/2010&rpp=20&interactive=false";
my $response = $browser->get($url_request);

my $out_file = "Magna_spider_testing.html";
open (OUTFILE, ">:encoding(utf8)", $out_file) or die "Cannot open $out_file, $!\n"; # but here I added utf8 support explicitly 

if ($response->is_success) {
  my $tree = HTML::TreeBuilder -> new_from_content($response->content()) or die "*** Could not process URL";
  $tree->dump(*OUTFILE);
  $tree -> delete;
}
else {
  print "No success: ", $response->status_line, "\n";
}
close OUTFILE;


__END__
