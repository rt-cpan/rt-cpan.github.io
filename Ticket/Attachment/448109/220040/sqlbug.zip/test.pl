#!/usr/bin/perl -w

my $dbh = connect_to_db; # Replace this with connect to your DB account

my $str = "MED.IsraelInfo.ru - Медицина Израиля";

$dbh->do("INSERT test SET item=? ON DUPLICATE KEY UPDATE item=?", undef, $str, $str);

my ($new_item) = $dbh->selectrow_array("SELECT item FROM test");

print "Content-Type: text/plain; charset=utf-8\n\n";
print "[$new_item]";
