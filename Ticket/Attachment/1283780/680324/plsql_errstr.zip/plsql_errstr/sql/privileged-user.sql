create user myuser identified by mypswd;
grant create session to myuser;
grant create user to myuser;
grant drop user to myuser;
grant create any procedure to myuser;