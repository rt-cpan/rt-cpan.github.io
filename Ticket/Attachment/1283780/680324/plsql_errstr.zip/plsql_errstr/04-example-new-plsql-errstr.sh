./pl/04-example-new-plsql-errstr.pl 2>&1 | tee log/04-example-new-plsql-errstr.log
