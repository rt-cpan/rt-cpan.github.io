./pl/03-example-other-user.pl 2>&1 | tee log/03-example-other-user.log
