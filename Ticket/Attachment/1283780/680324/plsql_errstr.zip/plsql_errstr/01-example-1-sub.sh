./pl/01-example-1-sub.pl 2>&1 | tee log/01-example-1-sub.log
