To perform the tests you need to have user with proper privileges,
use script sql/privileged-user.sql to create user named 'myuser' with pwd 'mypswd'

04-example-new-plsql-errst creates user named 'test_user'

if the names conflicts with your database you must adapt script
sql/privileged-user.sql and package pl/DB.pm as well.

All .sh files call the proper pl/*.pl file ane tee output to log/*.log file

00-drop-subs-and-user.pl.sh     - drops all objects created by other scripts
01-example-1-sub.sh             - tests single procedure error message
02-example-2-subs.sh            - tests two procedures error message
03-example-other-user.sh        - tests procedure created in other schema
04-example-new-plsql-errstr.sh  - tests my plsql_errstr version

or you may execute 99-do-it-all.sh script

log/*log files are produced during my tests

 
