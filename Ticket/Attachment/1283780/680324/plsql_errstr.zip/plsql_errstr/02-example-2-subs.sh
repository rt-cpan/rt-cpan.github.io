./pl/02-example-2-subs.pl 2>&1 | tee log/02-example-2-subs.log
