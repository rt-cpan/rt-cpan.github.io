./pl/00-drop-subs-and-user.pl 2>&1 | tee -a log/00-drop-subs-and-user.pl.log
