#!/usr/bin/perl

# removes procedures which may have been created during former test session
use strict;
use warnings;

use FindBin qw{ $Bin};
use lib "$Bin";

use DB;
use DBI;

my $silent = 0;     # set to 0 or undef if you want to print sql errors 

sub out
{
    my( $no, $tx) = @_;
    print "out#$no\. $tx\n";
}

$ENV{ NLS_LANG} = 'American_America.UTF8';

my $dbh = DBI->connect( $DB::database, $DB::username, $DB::password);
die "Cannot connect to $DB::database" unless defined $dbh;

# Show the errors if CREATE PROCEDURE fails
$dbh->{RaiseError} = 0;

{
    local $SIG{ __WARN__} = sub {} if $silent;
    
    print STDERR '-' x 72, "\ndrop procedures, may print error message(s)\n", '-' x 72, "\n";
    eval{ $dbh->do( q{ DROP PROCEDURE perl_dbd_oracle_test } ); };
    eval{ $dbh->do( q{ DROP PROCEDURE perl_dbd_oracle_test_1st } ); };
    eval{ $dbh->do( q{ DROP PROCEDURE perl_dbd_oracle_test_2nd } ); };
}

{
    local $SIG{ __WARN__} = sub {} if $silent;
    print STDERR '-' x 72, "\ndrop test user, may print error message\n", '-' x 72, "\n";
    eval{ $dbh->do( qq{ DROP USER $DB::test_user CASCADE } ); };
}
