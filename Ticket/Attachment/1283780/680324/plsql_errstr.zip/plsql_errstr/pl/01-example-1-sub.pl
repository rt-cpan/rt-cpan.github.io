#!/usr/bin/perl

use strict;
use warnings;

use FindBin qw{ $Bin};
use lib "$Bin";

use DB;
use DBI;

sub out
{
    my( $no, $tx) = @_;
    print "out#$no\. $tx\n";
}

$ENV{ NLS_LANG} = 'American_America.UTF8';

my $dbh = DBI->connect( $DB::database, $DB::username, $DB::password);
die "Cannot connect to $DB::database" unless defined $dbh;

# Show the errors if CREATE PROCEDURE fails
$dbh->{RaiseError} = 0;
if ( $dbh->do( q{
    CREATE OR REPLACE PROCEDURE perl_dbd_oracle_test as
    BEGIN
        PROCEDURE filltab( stuff OUT TAB ); asdf
    END; } ) ) 
{
    out( 1, 'OK?????');
};   # Statement succeeded
my $err = $dbh->err;
if ( 6550 != $err && 24344 != $err) 
{ 
    out( 2, $dbh->errstr); 
}  # Utter failure
#else 
{
    my $msg = $dbh->func( 'exdba', 'perl_dbd_oracle_test', 'procedure', 'plsql_errstr' );
    out( 3, $dbh->errstr) if !defined $msg;
    out( 4, $msg) if $msg;
    out( 5, $err) if $err;
}


   