#!/usr/bin/perl

use strict;
use warnings;

use FindBin qw{ $Bin};
use lib "$Bin";

use DB;
use DBI;

#----------------------------------------------------------------------    

=begin
    name: plsql_errarray
    usage:
        my $msg_ref = plsql_errarray( $dbh, $owner, $name, $type);
        or
        my $msg_ref = plsql_errarray( $dbh, $name, $type);
    parameters:
        $dbh   - database connection handler, obligatory
        $owner - schema name, optional
        $name  - object name, obligatory
        $type  - object type, obligatory
    returns: reference to array containing
        0th element: header containing object type and name
        1st element and others: reference to array containing three elements:
            line, position and error text
=end
=cut
    sub plsql_errarray
    {
        my( $dbh, $owner, $name, $type) = @_ > 3 ? @_ : ( shift, undef, @_);
        return undef unless $name && $type;

        my $query = $owner
            ?   q   #   called with ( $dbh, $owner, $name, $type)
                {
                    SELECT line, position, text
                    FROM all_errors 
                    WHERE name = ? AND type = ? AND owner = ?
                    ORDER BY sequence
                }
            :   q   #   called with ( $dbh, $name, $type)
                {
                    SELECT line, position, text
                    FROM user_errors 
                    WHERE name = ? AND type = ?
                    ORDER BY sequence
                };
        
        my( $sth, @msg) = $dbh->prepare_cached( $query) or return undef;
        
        $sth->bind_param( 1, uc( $name ));
        $sth->bind_param( 2, uc( $type ));
        $sth->bind_param( 3, uc( $owner)) if( $owner);

        $sth->execute or return undef;
        
        while ( my( $line, $pos, $text ) = $sth->fetchrow_array ) 
        {
            next unless $text;
       
            $text =~ s/(warning:).*(\(DBD)/$1 $2/g;
            push @msg, [ $line, $pos, $text];
        }
        
        if( @msg)
        {
            $name = "$owner.$name" if $owner;
            unshift @msg, "Errors for $type $name:";
        }
        
        return \@msg;
    };
    
=begin
    name: plsql_errstr
    usage:
        my $txt = plsql_errstr( $dbh, $owner, $name, $type);
        or
        my $txt = plsql_errstr( $dbh, $name, $type);
        or
        my( $txt, $msg) = plsql_errstr( $dbh, $owner, $name, $type);
        or
        my( $txt, $msg) = plsql_errstr( $dbh, $name, $type);
    parameters:
        $dbh   - database connection handler, obligatory
        $owner - schema name, optional
        $name  - object name, obligatory
        $type  - object type, obligatory
    returns: depends on context
        in scalar context:
            string containing error message
        in list context:
            (string, msg_ref) 0th: error message, 1st: result returned by plsql_errarray
=end
=cut
    sub plsql_errstr
    {
        my $msg = plsql_errarray @_;
        return undef unless $msg;

        my $txt = join( "\n", map { ref $_ eq 'ARRAY' ? "$_->[0].$_->[1]: $_->[2]" : $_} @$msg);
        
        return wantarray ? ( $txt, $msg) : $txt;
    };
    
#----------------------------------------------------------------------    

sub oracle_plsql_errstr
{
    plsql_errstr @_;
};

sub out
{
    my( $no, $tx) = @_;
    print "out#$no\. $tx\n";
}

$ENV{ NLS_LANG} = 'American_America.UTF8';

my $dbh = DBI->connect( $DB::database, $DB::username, $DB::password);
die "Cannot connect to $DB::database" unless defined $dbh;

$dbh->do( qq{ CREATE USER $DB::test_user IDENTIFIED BY $DB::test_pswd } );

$dbh->{RaiseError} = 0;

if ( $dbh->do( qq{
    CREATE OR REPLACE PROCEDURE $DB::test_user.perl_dbd_oracle_test as
    BEGIN
        PROCEDURE filltab( stuff OUT TAB ); asdf
    END; } ) ) 
{
    out( 1, 'OK?????');
};   # Statement succeeded
my $err = $dbh->err;
if ( 6550 != $err && 24344 != $err) 
{ 
    out( 2, $dbh->errstr); 
}  # Utter failure
#else 
{
    my $msg = oracle_plsql_errstr( $dbh, $DB::test_user, 'perl_dbd_oracle_test', 'procedure' );
    out( 3, $dbh->errstr) if !defined $msg;
    out( 4, $msg) if $msg;
    out( 5, $err) if $err;
}


   