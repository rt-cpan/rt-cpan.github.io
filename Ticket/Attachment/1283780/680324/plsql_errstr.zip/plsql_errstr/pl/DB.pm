package DB;
our $database="dbi:Oracle:host=localhost;sid=mydb";

our $username  = 'myuser';
our $password  = 'mypswd';
our $test_user = 'test_user';
our $test_pswd = 'test_pswd';

