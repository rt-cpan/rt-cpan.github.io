#!/usr/bin/perl

use strict;

use HTML::Strip;

use Encode ( 'encode', 'decode', 'is_utf8' );


my $fh = undef;
if( open( $fh, '<', $ARGV[ 0 ] ) )
{
	my $data = '';
	binmode $fh, ':utf8';
	$data = join( '', <$fh> );
	close $fh;

	my $hs = HTML::Strip -> new();
	my $clean_text = $hs -> parse( encode( 'UTF-8', $data ) );
	$hs -> eof();

	unless( is_utf8( $clean_text ) )
	{
		$clean_text = decode( 'UTF-8', $clean_text );
	}


	print encode( 'UTF-8', $clean_text ), "\n";


} else
{
	die 'test file missing';
}

