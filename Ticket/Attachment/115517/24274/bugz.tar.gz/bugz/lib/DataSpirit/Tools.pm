# $Id: Tools.pm,v 1.46 2004/10/25 08:35:19 egor Exp $ 
#

package DataSpirit::Tools;

use vars qw(%mime_types $default_binary_charset $VERSION);
use strict;
use Encode qw(from_to);
use Image::Info qw(image_info dim);
use CGI::Util qw(escape unescape);
use Email::Valid;

BEGIN {
	$VERSION="0.5";

        use Exporter ();
        use vars qw(@EXPORT %EXPORT_TAGS @ISA);

	use constant READ_FILE_BINARY		=> '1';
	use constant HTMLIZE_FULL_QUOTES	=> '2';
	use constant HTMLIZE_QUOTES		=> '1';
	use constant DEFAULT_BINARY_CHARSET	=> 'utf-8';
	use constant METANAMIZE_KEEPCASE	=> '1';

        @ISA = qw(Exporter);   %EXPORT_TAGS = ();
	@EXPORT = qw(
		$VERSION 

		READ_FILE_BINARY
		HTMLIZE_FULL_QUOTES
		HTMLIZE_QUOTES
		DEFAULT_BINARY_CHARSET
		METANAMIZE_KEEPCASE

		&split_uri
		&split_uri_last
		&add_slash
		&assemble_uri
		&file_suffix
		&file_basename
		&file_dirname

		&return_error_page
		&return_moved_page
		&return_auth_page

		&read_mime_types
		&guess_mime_type
		&return_binary_data
		%mime_types

		&set_default_binary_charset
		$default_binary_charset

		&normalize_path
		&normalize_spaces
		&url_escape
		&url_unescape
		&htmlize

		&resize_image
		&fix_file_name

		&fix_images_in_content
		&download_file
		
		&from_entities

		&last_insert_id
		&read_file

		&metanamize
		&translit

		&check_empty_html
		&check_string
		&check_number
		&fix_weird_string

		&get_image_boundaries

		&generate_password

		&monetary_round 

		&find_file

		&validate_email

		&ds_version

	);

	$default_binary_charset=DEFAULT_BINARY_CHARSET;
};

use CGI qw(:standard);

use LWP;
use LWP::UserAgent;
use GD;
use File::Temp qw/ :mktemp  /;



=pod

=head1 Tools.pm

Small tools and utilities for the DataSpirit package. 

=head2 &split_uri($path)

Divides path into two elements: the first path element and everything else. 

In scalar context, will return only the first path element. In list context
will return first path element and the rest. 

Will return undef if $path is not defined.

=cut

sub split_uri() { 
	my ($path)=@_;
	return undef if (not defined $path);
	my $p1=""; my $p2="";
	my $firstslash;

	if ($path=~s/^\///) { 
		$firstslash=1;
	}
	return "" if ($path eq '');
	($p1, $p2) = $path=~/^([^\/]+)\/(.+)$/ or $p1 = $path;
	$p1="/".$p1 if ($firstslash && $p1);
	$p1=~s/\/$//g;

	if (wantarray) { return ($p1,$p2); } 
	return $p1;
}

=pod 

=head2 &add_slash($path)

Will add tailing slash to path if there is no. Will return modified string. 

Will return undef if $path is not defined.

=cut


sub add_slash() { 
	my ($path)=@_;
	return undef if (not defined $path);
	$path.="/" if ($path!~/\/$/);
	return $path;
}

=pod 

=head2 &guess_mime_type($filename)

Will try to guess mime type from file name. 

Note: mime types are read on the script start by &read_mime_types function. If they aren't read, 
&guess_mime_type() will always return undef. 

Will return scalar with mime type or undef if couldn't guess.
Will return undef if $filename is not defined.

=cut

sub guess_mime_type() { 
	my ($filename)=@_;
	return undef if (not defined $filename);
	$filename=lc($filename);
	if ($filename=~/\.([A-Za-z0-9]+)$/) { 
		if (my $k=$mime_types{$1}) { 
			return $k;
		} 
	} else { 
		if (my $k=$mime_types{$filename}) { 
			return $k;
		} 
	}
	return undef;

}

=pod

=head2 file_dirname($filename)


=cut

sub file_dirname($) {
	my $filename = shift;
	return undef if (not defined $filename);
	my (undef,$dirname,undef) = File::Spec->splitpath($filename);
	return $dirname;
}

=pod

=head2 file_basename($filename)


=cut

sub file_basename($) {
	my $filename = shift;
	return undef if (not defined $filename);
	my (undef,undef,$basename) = File::Spec->splitpath($filename);
	return $basename;
}

=pod 

=head2 &file_suffix($filename)

Will return file suffix in scalar context.

Will return undef if $filename is not defined.

=cut


sub file_suffix($) { 
	my ($filename)=@_;
	my $basename = file_basename($filename);
	return undef if (not defined $basename);
	return "" if (rindex($basename,".")==-1);
	return substr($basename,rindex($basename,".")+1);
}

=head2 &split_uri_last($path)

Divides path into into two elements: the last path element and the rest. 
In scalar context, will return the last path element. In list context, will return 
the prepending path and the last element. 

I.e.

 ('Lars/von','Trier') == &split_uri_last("Lars/von/Trier");

 'Trier' == scalar &split_uri_last("Lars/von/Trier");

Will return undef if $path is not defined

=cut

sub split_uri_last() { 
	my ($path)=@_;
	return undef if (not defined $path);
	my $p1; my $p2;

	return "" if ($path=~/\/$/); 

	$p2="";
	($p1, $p2) = $path=~/^(.+)[\/\\]([^\/\\]+)$/ or $p2 = $path;
	$p2=~s/^\///g;

	if (wantarray) { return ($p1,$p2); } 
	return $p2;
}



=pod

=head2 &assemble_uri($path, $metaname)

Will add  $metaname to $path. Will return correct absolute path with $metaname added. 

Will return undef if $path is not defined. Probably, this function looks more like 
internal, as it does some conversions with path, not really suitable for general usage.
Take a look at the source code. 

And guess what it returns if $path is not defined. 

=cut


sub assemble_uri() { 
	my ($path, $metaname)=@_;
	return undef if (not defined $path);
	my $current_path="";

	$path=~s/^\///g;
	if ($path ne '') { $current_path.="/".$path; } 
	if ($metaname ne '') {
		$current_path.="/".$metaname;
	}
	if ($current_path eq "") { $current_path="/"; } 
	return $current_path;
}


=pod

=head2 &normalize_path($path)

Will normalize the path, stripping out leading and tailing slashes, html/xml suffixes 
and also "index.html" and "index.xml" path elements at the end. 

I.e.

 zuka/buka == &normalize_path("/zuka/buka/");
 zuka/buka == &normalize_path("/zuka/buka/index.html");
 zuka/buka == &normalize_path("/zuka/buka.html");

This is mostly needed in DataSpirit's internals, because this is now the CGI request path info
(SCRIPT_NAME) is transformed to real page path. 

Will return undef if $path  is not defined. 

=cut

sub normalize_path() {
	my ($path)=@_;
	return undef if (not defined $path);
	$path=~s/\/\/+/\//g;
	$path=~s/index\.html$//g;
	$path=~s/index\.xml$//g;
	$path=~s/\.html$//g;
	$path=~s/\.xml$//g;
	$path=~s/\/$//g;
	$path=~s/^\///g;
	return $path;
}


=pod

=head2 &return_error_page($code, $diagnostics, $charset) 

Will print responce headers and error page with code $code, additional 
diagnostics $diagnostics and in charset $charset. 

Will try to load a template for error page from file "FTP/error_pages/$code.html". 
If no such  file found then it will use internal ugly template. 

You can supply &diagnostics and then this scalar will be put on the error response 
page providing user with some additional info. 

If defined $charset, then the charset will be put in content-type response header. 

The template convention used here is very simple: extended entities are replaced
with corresponding values: 

=over

=item &servername;

The server's fqdn as in $ENV{'SERVER_NAME'}

=item &version;

DataSpirit's version.

=item &errorcode;

Error code

=item &diagnostics;

Content of the $diagnostics variable

=back

If the HTTP status code is 206, then no content will be sent to browser. 

=cut

sub return_error_page() { 
	my ($code, $diagnostics, $charset)=@_;
	my $buffer;

	my $errors = {
		404	=> 'Not found',
		403	=> 'Permission denied',
		302	=> 'Moved',
		500	=> 'Internal application error',
		200	=> 'OK',
		206	=> 'OK No content'
		};

	if (not defined $errors->{$code})  { 
		print "Status: 200 OK\n";
	}  else { 
		print "Status: $code $errors->{$code}\n";
	}
	
	print "Content-Type: text/html";
	if (defined $charset) { 
		print "; charset=$charset";
	}
	print "\n";

	if (-r "FTP/error_pages/$code.html") { 
		open F, "FTP/error_pages/$code.html";
		sysread F, $buffer, 200000;
		close F;
	} else { 
		$buffer="<html><head><title>Error</title></head><body><h1>Error</h1><p>Something got wrong. <p>Here is the diagnostics: <p>&diagnostics;\n";
	}

	my $servername=$ENV{'SERVER_NAME'};
	$servername="somehost" if (not defined $servername); 
	if (not defined $diagnostics) { $diagnostics = ""; } 
	$buffer=~s/&diagnostics;/$diagnostics/g;
	$buffer=~s/&servername;/$servername/g;
	$buffer=~s/&version;/$VERSION/g;
	$buffer=~s/&errorcode;/$code/g;
	if ($code == 206) { 
		print "\n";
	} else { 
		print "Content-length: ".length($buffer)."\n\n";
		print $buffer;
	}
}


=pod

=head2 &return_auth_page($realm) 

Will print responce headers and error page with code 401. Will put Authentication
header in HTTP response headers with realm $realm. 

Will try to load a template for error page from file "FTP/error_pages/401.html". 
If no such  file found then it will use internal ugly template. 

The template convention used here is very simple: extended entities are replaced
with corresponding values: 

=over

=item &servername;

The server's fqdn as in $ENV{'SERVER_NAME'}

=item &version;

DataSpirit's version.

=item &realm;

Content of the $realm variable

=back

=cut

sub return_auth_page() { 
	my ($realm)=@_;
	my $buffer;

	print "Status: 401 Auth required\nWWW-Authenticate: Basic realm=\"$realm\"\nContent-Type: text/html\n";

	if (-r "FTP/error_pages/401.html") { 
		open F, "FTP/error_pages/401.html";
		sysread F, $buffer, 200000;
		close F;
	} else { 
		$buffer="<html><body><h1>Auth required</h1><p>This page requires authorisation.\n";
	}
	$buffer=~s/&servername;/$ENV{'SERVER_NAME'}/g;
	$buffer=~s/&version;/$VERSION/g;
	$buffer=~s/&realm;/$realm/g;
	print "Content-Length: ".length($buffer)."\n\n";
	print $buffer;
	
}

=pod

=head2 &return_moved_page($location) 

Guess what? Will redirect user to somewhere else. 
Function prints http response headers with status 302, the Location
header and a small HTML snippet with META HTTP-EQUIV=REFRESH for 
God knows what kind of purposes. 

=cut

sub return_moved_page() { 
	my ($location)=@_;

	if (defined $ENV{'HTTP_HOST'} && $location=~/^\//) { 
		$location="http://".$ENV{'HTTP_HOST'}.$location;
	}
	my $meta_page = qq{

<HTML>
<HEAD>
<TITLE>Moved</TITLE>
<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"0; URL=$location\">
</HEAD>
<BODY>
<H1>Moved</H1>
<P>The document now lives here: <A HREF=\"$location\">$location</A></P>
</BODY>
</HTML>
	};
	print "Status: 302 Moved\nLocation: $location\n\n";
	print $meta_page;
}

=pod

=head2 &htmlize($data, $quotes) 

Replaces chars <. >, & with corresponding HTML entities. Will return the string. 

If $quotes == HTMLIZE_QUOTES then " will be replaced with &quot; 
If $quotes == HTMLIZE_FULL_QUOTES then ' and ` will also be escaped. 

Will return undef if $data is not defined.

=cut

sub htmlize() { 
	my ($data, $quotes)=@_;
	return undef if (not defined $data);
	$data=~s/&/\&amp;/g;
	$data=~s/</\&lt;/g;
	$data=~s/>/\&gt;/g;
	if (defined $quotes) { 
		$data=~s/"/\&quot;/g;
		if ($quotes eq HTMLIZE_FULL_QUOTES) { 
			$data=~s/'/\&apos;/g;
			$data=~s/`/\&rsaquo;/g;
		}
	}
	return $data;
}


=pod

=head2 &return_binary_data($filename, $data, $arguments) 

This function will return binary data with HTTP response headers. The data itself is
returned as in $data variable. 

$filename is used to determine neccessary information for HTTP headers and could be 
a raw mime-type or file name. This is detected by a presence of "/" in $filename. If 
the slash is found, then it is mime type, if not - a file name. 

In later case &guess_mime_type will be used to extract mime type information. You can
hardcode a suffix if you are sure about the content you send to browser:

 &return_binary_data(".jpg", $imageData);

is equal to
 
 &return_binary_data("image/jpeg", $imageData);

If mime type could not be guessed, then "application/octet-stream" is returned.

$arguments is a hashref. The following keys are recognized: 

=over

=item charset

The charset to put in content-type field. Ignored if mime type is not textual (doesn't begins with "text/") and defaults to $default_binary_charset if not supplied. FIXME/TODO: should I just shut up and tell no charset if no charset is supplied?

=item expires

Whatever is suitable for CGI to put in Expires: header. 

=back

FIXME: how to get rid of CGI's "header" function here? 

=cut

sub return_binary_data() { 
	my ($filename,$data,$arguments)=@_;
	if (not defined $arguments) { 
		$arguments={};
	}
	my $type;

	if ($filename=~/\//) { 
		$type=$filename;
	} elsif ($filename=~/^.+\.([^\.]+)$/) { 
		$type=$mime_types{lc($1)};
	}

	if (not defined $type) { 
		$type="application/octet-stream";
	}
	my $charset;
	if ($type=~/^text\//) { 
		if (not defined $arguments->{'charset'}) { 
			$charset=$default_binary_charset;
		} else { 
			$charset=$arguments->{'charset'};
		}
	} else {  
		$charset=undef;
	} 
	print header(-type=>$type, -charset=>$charset,
		-expires=>$arguments->{'expires'},-Content_length=>length($data));
	print $data;
}

=pod

=head2 &set_default_binary_charset($charset)

Sets the "default binary charset" variable ($default_binary_charset) used in this module. By default it's 
set to DEFAULT_BINARY_CHARSET. 

=cut

sub set_default_binary_charset() { 
	my ($charset)=@_;
	$default_binary_charset=$charset;
}

=pod

=head2 &read_mime_types($filename)

Will read the mime.types file, path to which is specified in 
the variable $filename and will populate the &mime_types hash, 
needed for &guess_mime_type function. 

if $filename is not defined, then it defaults to "FTP/mime.types". 

=cut

sub read_mime_types() { 
	my ($filename)=@_;
	if (not defined $filename) { $filename = "FTP/mime.types"; } 
	
	open F, $filename or return undef;
	%mime_types=();
	while (<F>) { 
		chomp; 
		next if (/^#/);
		if (/^([^ \t]+)[ \t]+(.+)$/) { 
			my $type=$1;
			my $suffixes=$2;
			$suffixes=~s/\t/ /g;
			$suffixes=~s/  +/ /g;
			foreach my $suffix (split(/ /,$suffixes)) { 
				$mime_types{$suffix}=$type;
			}
		}
	}
	close F;
}

=pod 

=head2 &url_unescape($string)

=head2 &url_escape($string)

It is right what you think it is.  Actually they are just stubs calling &escape and &unescape
so they might disappear in future versions. 

TODO/FIXME: yeah, get rid of them. 

=cut

sub url_unescape {
	my ($string)=@_;
	return undef if (not defined $string);
	return &unescape($string);
}

sub url_escape {
	my ($string)=@_;
	return undef if (not defined $string);
	return &escape($string);

}

=pod

=head2 &resize_image($imageData, $filename, $x, $y, $arguments)

This is a universal image resizing function designed for thumbnails. Image is passed in 
$imageData and $filename is only used to determine the image type. Supported image types 
are: jpeg, png. Gif support will suddenly appear in the beginning of July 2004. 

$x and $y are the new image's size. You can only define one of them and the other side
will be automatically calculated. If you define both - then the resulting image size will
be shrunk to fit both sides. 

Will return resulting image data in the original (or forced format of jpegOnly of pngOnly 
specified) or undef if something goes wrong. 

$arguments is a hashref. The following keys are recognized: 

=over

=item jpegQuality

A number 0..100 determining resulting jpeg quality of resized image if target image type
is jpeg. 

=item recompress

Set this to recompress jpeg or png image if the resulting size is the same as original size. 
This is mostly used when uploading images from digital cameras. They are 100% quality rarely 
needed on the web and just by recompressing them you can gain hundreds of percents of size. 

=item jpegOnly
=item pngOnly

Set this to force output format. 

=item fillSpace

Make an image sized exactly as specified in $x and $y and put the shrunk image in center of 
the white space.

=item sizeOnly

Do not perform the real resize of the image but instead return the calculated domensions of the 
resized image. Will return (undef, $width, $height). 

=item crop

TODO: NOT IMPLEMENTED YET. The image will be cropped according to internal rules to exactly fit 
the specified size at both sides. This is mostly needed in web image galleries when you 
want all of the thumbnails to look consistent (landscape 4:3) and would like to crop 
portrait thumbnail to become landscape.

=back 

=cut

sub resize_image() { 
	my ($indata,$fname,$x,$y,$arguments)=@_;
	my ($maxx,$maxy, $a, $b, $imagex, $imagey);
	my $jpegCompression=75;
	my $mimeType;

	if (	$fname eq "image/jpeg" || 
		$fname eq "image/png") { 
		$mimeType=$fname;
	} else { 
		$mimeType=&guess_mime_type(lc($fname));
	}

	return undef if (not defined $mimeType);

	if (not defined $arguments) { $arguments={}; } 
	$jpegCompression=$arguments->{'jpegQuality'} if (defined $arguments->{'jpegQuality'});
	

	GD::Image->trueColor([0,1]);

	return undef if (not defined $indata);
	my $image;
	if ($mimeType eq "image/jpeg") {
		$image = GD::Image->newFromJpegData($indata, 1);
	} elsif ($mimeType eq "image/png") { 
		$image = GD::Image->newFromPngData($indata, 1);
	} else { return undef; } 
	return undef if (not defined $image);
	my ($width,$height) = $image->getBounds();
	$maxx=$width;
	$maxy=$height;



	my $r_image; # this will hold resized image

	if (defined $x && $width>$x) { $maxx=$x; } 
	if (defined $y && $height>$y) { $maxy=$y; } 


	if ($maxx==$width and $maxy==$height and not defined $arguments->{'fillSpace'}) { 
		if ($arguments->{'sizeOnly'}) { 
			return (undef, $width,$height);
		}
		if ($arguments->{'recompress'}) { 
			my $newData;
			if ($arguments->{'jpegOnly'}) { 
				if (wantarray) { 
					return ($image->jpeg($jpegCompression),$width,$height);
				} else { 
					return $image->jpeg($jpegCompression);
				}
			} elsif ($arguments->{'pngOnly'}) { 
				if (wantarray) { 
					return ($image->png(),$width,$height);
				} else { 
					return $image->png();
				}
			} else { 
				if (wantarray) { 
					if ($mimeType eq "image/jpeg") { 
						return ($image->jpeg($jpegCompression),$width,$height);
					} elsif ($mimeType eq "image/png") { 
						return ($image->png(),$width,$height);
					}
				} else { 
					if ($mimeType eq "image/jpeg") { 
						return $image->jpeg($jpegCompression);
					} elsif ($mimeType eq "image/png") { 
						return $image->png();
					} 
				}
			}
		} else { 
			if (wantarray) { 
				return ($indata,$width,$height);
			} else { 
				return $indata;
			}
		}
	}

	$imagex=$maxx;
	$imagey=$maxy;
	
	$a=$width/$maxx;
	$b=int($height/$a);
	$imagey=$b;

	if  ($b>$maxy) { 
		$b=$height/$maxy;
		$a=int($width/$b);
		$imagex=$a;
		$imagey=$maxy;
	}
	#$a=int($a);
	#$b=int($b);

	
	my $newI;

	if ($arguments->{'fillSpace'} && (defined $x) && (defined $y)) {
		if ($arguments->{'sizeOnly'}) { 
			return (undef, $x,$y);
		}
		$newI = new GD::Image($x,$y,1);
		my $white = $newI->colorAllocate(255,255,255);
		$newI->fill(1,1,$white);
		my $offsetx=int(($x-$imagex)/2);
		my $offsety=int(($y-$imagey)/2);
		$newI->copyResampled($image,$offsetx,$offsety,0,0,$imagex,$imagey,$width,$height);
		$imagey=$y;
		$imagex=$x;
	} elsif ($arguments->{'crop'} && (defined $x) && (defined $y)) {
		# todo! ;-(  fixme
	} else { 
		if ($arguments->{'sizeOnly'}) { 
			return (undef, $imagex,$imagey);
		}
		$newI = new GD::Image($imagex,$imagey,1);
		$newI->copyResampled($image,0,0,0,0,$imagex,$imagey,$width,$height);
	}
	

	if ($arguments->{'jpegOnly'}) { 
		if (wantarray) { 
			return ($newI->jpeg($jpegCompression), $imagex,$imagey);
		} else { 
			return $newI->jpeg($jpegCompression);
		}
	} elsif ($arguments->{'pngOnly'}) { 
		if (wantarray) { 
			return ($newI->png(), $imagex,$imagey);
		} else { 
			return $newI->png();
		}
	} else { 
		if (wantarray) { 
			if ($mimeType eq "image/jpeg") { 
				return ($newI->jpeg($jpegCompression), $imagex,$imagey);
			} elsif ($mimeType eq "image/png") { 
				return ($newI->png(), $imagex,$imagey);
			} else { 
				return undef;
			}
		} else { 
			if ($mimeType eq "image/jpeg") { 
				return $newI->jpeg($jpegCompression);
			} elsif ($mimeType eq "image/png") { 
				return $newI->png();
			} else { 
				return undef;
			}
		}
	}
}
=pod

=head2 &fix_file_name($filename)

Will fix the file name uploaded by Microsoft Internet Exploder. 
Returns undef if $filename is not defined. 

TODO: add support for cyrillic-named files which stupid users will upload
anyway. 

=cut

sub fix_file_name() {
        my ($filename)=@_;
	return undef if (not defined $filename);

        $filename = &unescape($filename);
        $filename = &split_uri_last($filename);
	$filename=~s/[^A-Za-z0-9_\d\.%-]+/ /g;
	#$filename=~tr/\[\]~`!@#\$%\^\*=+\\\|:;",\//                    /;
	$filename=~s/ *$//g;
	$filename=~s/  */_/g;
        $filename=&escape($filename);
	return $filename;
}


=pod

=head2 &normalize_spaces($name)

Will compress all whitespaces, tabs and newlines in a single whitespace. 

Returns compressed string. 
Returns undef if $name is not defined. 

=cut

sub normalize_spaces() { 
	my ($name)=@_;
	return undef if (not defined $name);
	$name=~tr/\t\n\r/   /;
	$name=~s/  +/ /g;
	$name=~s/^\s//g;
	$name=~s/\s$//g;
	return $name;
}


=pod

=head2 &fix_images_in_content($content,$identifier,$dbh,&sub_insert_new_image, &sub_get_old_image, &sub_get_image, &sub_download_image)

It's hard to explain. This is an internal function needed for Structure Editor. 

In two words: when HTML content is uploaded, it may contain references to images in "MyPictures" folder because images in visual editor
are taken from there. The problem is that the images needs to be resized, compiled and put into folder where the page actually lives. 
More, the content itself needs to be reformated to take images from current location, not from the CMS. 

Example. Suppose the following HTML code is uploaded by user for page /aboutus/partners.html

	<img src="http://www.site.com/CMS/MyPictures/embed_pictures/showpicture/office.jpg" 
	   style="width:250px; height:250px">


We have to get the office.jpg from MyPictures folder, resize it to 250x250, put the image in /aboutus/partners/ folder
(FTP/files/about/partners in filesystem actually), then fix the content to look like: 

	<img src="office.jpg" width="250" height="250">

A count of other conversions are made. You better take a look at the source code. 

TODO/FIXME: invent a wheel and replace this ugly hack with something beautiful. 

Callbacks: 
 sub_insert_new_image($newimagename,$newimage,$title)
 sub_get_old_image($name);
 sub_get_image($name);
 sub_download_image($url);

=cut


sub fix_images_in_content() { 
	my ($content,$sub_insert_new_image, $sub_get_old_image, $sub_get_image, $sub_download_image)=@_;


	my @entries=split(/<img/i, $content);
	my $result="";

	foreach my $k (@entries) { 
		my $first="";
		my $second="";
		my ($width,$height,$imagename,$suffix);
		my $style="";
		if (not $k=~/^[^<]+>/) { $result.=$k; next; } 
	
		if ($k=~/^([^>]+)>(.+)$/s) { 
			$first=$1;
			$second=$2;
		} else { 	
			$first=$k;
		}
		$first=~s/>$//gm;
	
		if ($first=~/[ =\"\']([A-Za-z0-9_%\:\/\.-]+)\.(gif|png|jpg)/i) {
			$imagename=$1;
			$suffix=$2;
			if ($first=~/\.(jpg|gif|png)\?([^ \"\'\>]+)/) { 
				my $argument=$2;
				$first=~s/\.(jpg|gif|png)\?[^ \"\'\>]+/\.$1/gi;
				if ($argument=~/x=(\d+)/) { $width=$1; } 
				if ($argument=~/y=(\d+)/) { $height=$1; } 
			}
		
			if ($first=~/width[ =:\"\']+(\d+)/ ) { 
				$width=$1;
			}
			if ($first=~/height[ =:\"\']+(\d+)/ ) { 
				$height=$1;
			}
			if ($imagename=~/MyPictures\/embed_pictures\/showpicture\/(.+)$/) {  # new picture
				my $newimagename=$1;

				my $row=&$sub_get_image($newimagename.".".$suffix);
				my ($newimage,$newx,$newy)=&DataSpirit::Tools::resize_image($row->{'data'}, 
					$newimagename.".".$suffix, $width,$height);

				if (not defined $width) {$width=$newx; } 
				if (not defined $height) {$height=$newy; } 
				$newimagename.="-".$width."x".$height.".".$suffix;
				$first=~s/$imagename.$suffix/$newimagename/g;

				&$sub_insert_new_image($newimagename,$newimage,$row->{'title'});

			} elsif (not $imagename=~/\//) { # local picture
				my $row=&$sub_get_old_image($imagename.".".$suffix);
				my ($newimage,$newx,$newy)=&DataSpirit::Tools::resize_image($row->{'content'}, 
					$imagename.".".$suffix, $width,$height);

				if (not defined $width) {$width=$newx; } 
				if (not defined $height) {$height=$newy; } 

				my $newimagename=$imagename;
				$newimagename=~s/^(.+)-(\d+)x(\d+)$/$1-${width}x${height}\.$suffix/g;
				$first=~s/$imagename\.$suffix/$newimagename/g;

				&$sub_insert_new_image($newimagename,$newimage, $row->{'title'});
			} elsif ($imagename=~/^http:\/\// &&  defined $sub_download_image) { 
				# downloadable picture
				my  $imageData = &$sub_download_image($imagename.".".$suffix);
				if (defined $imageData) { 
					my $newimagename=&DataSpirit::Tools::fix_file_name(
						$imagename.".".$suffix);
					my ($newimage,$newx,$newy)=&DataSpirit::Tools::resize_image($imageData,
						$newimagename, $width,$height);
	
					if (not defined $width) {$width=$newx; } 
					if (not defined $height) {$height=$newy; } 
	
					$newimagename=~s/^(.+)\.(gif|jpeg|jpg|png)$/$1-${width}x${height}.$2/g;
					$first=~s/$imagename\.$suffix/$newimagename/g;
	
					&$sub_insert_new_image($newimagename,$newimage, "");
				}
			}
		}
		$result.="<IMG $first>$second";
	}
	
	return $result;
}

=pod

=head2 &download_file($url,$timeout)

Will download $url and return the content or undef if something is wrong. If $timeout is
not defined it will default to 60 (it is in seconds). Timeouts less than 10s will be
rounded to 10s. 

=cut

sub download_file() {
	my ($filename, $timeout)=@_;
	$timeout=60 if (not defined $timeout);	
	$timeout=10 if ($timeout<10);	
	return undef if (not defined $filename);
	return undef if (not ($filename=~/^http:\/\// || $filename=~/^file:\//));
	my $req	 = HTTP::Request->new(GET => $filename);
	my $ua = LWP::UserAgent->new;
	$ua->agent("DataSpirit CMS");
	$ua->timeout($timeout);
	my $res = $ua->request($req);

	if ($res->is_success) {
		return $res->content;
	} else {
		return undef; 
	}
}

=pod

=head2 &from_entities($string)

Will convert cyrillic entities (&Acy; etc) into UTF8 cyrillic letters. Even more, 
entities like &amp;Acy; are also converted into cyrillic letters. This is needed
to fix broken ALT for IMGs when uploaded from Firefox/Mozilla. 

All visual HTML content is to be filtered thru this function when uploaded bu user. 

Will return undef if not defined $string or converted string. 

TODO: Replace raw UTF8 here with 0xXXX. 

=cut

sub from_entities() { 
	my ($data)=@_;
	return undef if (not defined $data);

	my %entities=(
	'acy'	=>	"а",
	'Acy'	=>	"А",
	'bcy'	=>	"б",
	'Bcy'	=>	"Б",
	'vcy'	=>	"в",
	'Vcy'	=>	"В",
	'gcy'	=>	"г",
	'Gcy'	=>	"Г",
	'dcy'	=>	"д",
	'Dcy'	=>	"Д",
	'iecy'	=>	"е",
	'IEcy'	=>	"Е",
	'iocy'	=>	"ё",
	'IOcy'	=>	"Ё",
	'zhcy'	=>	"ж",
	'ZHcy'	=>	"Ж",
	'zcy'	=>	"з",
	'Zcy'	=>	"З",
	'icy'	=>	"и",
	'Icy'	=>	"И",
	'jcy'	=>	"й",
	'Jcy'	=>	"Й",
	'kcy'	=>	"к",
	'Kcy'	=>	"К",
	'lcy'	=>	"л",
	'Lcy'	=>	"Л",
	'mcy'	=>	"м",
	'Mcy'	=>	"М",
	'ncy'	=>	"н",
	'Ncy'	=>	"Н",
	'ocy'	=>	"о",
	'Ocy'	=>	"О",
	'pcy'	=>	"п",
	'Pcy'	=>	"П",
	'rcy'	=>	"р",
	'Rcy'	=>	"Р",
	'scy'	=>	"с",
	'Scy'	=>	"С",
	'tcy'	=>	"т",
	'Tcy'	=>	"Т",
	'ucy'	=>	"у",
	'Ucy'	=>	"У",
	'fcy'	=>	"ф",
	'Fcy'	=>	"Ф",
	'khcy'	=>	"х",
	'KHcy'	=>	"Х",
	'tscy'	=>	"ц",
	'TScy'	=>	"Ц",
	'chcy'	=>	"ч",
	'CHcy'	=>	"Ч",
	'shcy'	=>	"ш",
	'SHcy'	=>	"Ш",
	'shchcy'=>	"щ",
	'SHCHcy'=>	"Щ",
	'hardcy'=>	"ъ",
	'HARDcy'=>	"'",
	'ycy'	=>	"ы",
	'Ycy'	=>	"Ы",
	'softcy'=>	"ь",
	'SOFTcy'=>	"Ь",
	'ecy'	=>	"э",
	'Ecy'	=>	"Э",
	'yucy'	=>	"ю",
	'YUcy'	=>	"Ю",
	'yacy'	=>	"я",
	'YAcy'	=>	"Я",
	'numero'=>	"&#8470,",
	);

	$data=~s/(&(\w+);?)/$entities{$2} || $1/eg;
	$data=~s/(&amp;(\w+);?)/$entities{$2} || $1/eg;
	return $data;
}

=pod

=head2 &lad_insert_id($dbh)

This incredible award-winning innovative function will return the result of SELECT LAST_INSERT_ID() 
SQL statement, ran in $dbh handle. 

Will return undef if $dbh is undef or something else is wrong. 

This function is needed because sometimes the corresponding DBI function is not working properly at least
on MySQL. :( 

TODO/FIXME: Investigate!

=cut

sub last_insert_id() { 
	my ($dbh)=@_;
	return undef if (not defined $dbh);
        my $ID=$dbh->selectcol_arrayref("select last_insert_id()");
	return undef if (not defined $ID);
	return $ID->[0];
}

=pod

=head2 &read_file($path,$binary)

Will read the file $file and return it's content. 

Will return undef if something goes wrong. 

If $binary is defined then the file will be read as binary. Use READ_FILE_BINARY constant for that: 

 $data=&read_file("/bin/bash", READ_FILE_BINARY);

=cut

sub read_file() { 
	my ($filename, $binary)=@_;
	my $data;
	return undef if (not defined $filename);
	open F, $filename or return undef;

	if (defined $binary)  { 
		my $bytes=0;
		do {
			my $buffer;
			$bytes=sysread(F, $buffer, 102400);
			$data.=$buffer;
		} while ($bytes > 0);
	} else { 
		local $/;
		undef $/;
		$data=<F>;
	}

	close F;
	return $data;
}

=pod

=head2 &metanamize($data, $encoding, $keepcase)

Will make a metaname (that's it: only latin chars, no symbols, no spaces, only allowed: 0-9_:-)  from anything. Will even transliterate cyrillic as defined in $encoding. If $encoding is not defined then it's assumed to be $default_binary_charset. If $keepcase is defined (use METANAMIZE_KEEPCASE for that) then no lowercase will be done on variable. 

Will return undef if something is wrong or the resulting string. 

=cut

sub metanamize() { 
	my ($data,$encoding,$keepcase)=@_;
	return undef if (not defined $data);
	$data=&translit($data,$encoding);
	$data=~s/[^A-Za-z0-9_:-]+//g;
	return undef if ($data eq '');
	if (defined $keepcase) { return $data; } 
	return lc($data);
}

=pod

=head2 &translit($data,$encoding)

Will transliterate cyrillic from $encoding. If $encoding is not defined then it's assumed to be $default_binary_charset.
Will return undef or transliterated string. 

Warning: this function will return string containing only latin characters
(upper and lower case). Letters are not suffixed with a single quote even when
it's needed. 

=cut

sub translit() { 
	my ($data, $encoding)=@_;
	return undef if (not defined $data);
	if (not defined $encoding) { 
		$encoding=$default_binary_charset;
	}
	from_to($data,$encoding, "koi8-u");
	
	$data=~tr/����������������������/ABVGDEZIYKLMNOPRSTUFEY/;
	$data=~tr/����������������������/abvgdeziyklmnoprstufey/;

	$data=~s/�/YO/g;
	$data=~s/�/ZH/g;
	$data=~s/�/KH/g;
	$data=~s/�/TS/g;
	$data=~s/�/CH/g;
	$data=~s/�/SH/g;
	$data=~s/�/SCH/g;
	$data=~s/�/YU/g;
	$data=~s/�/YA/g;

	$data=~s/�/yo/g;
	$data=~s/�/zh/g;
	$data=~s/�/kh/g;
	$data=~s/�/ts/g;
	$data=~s/�/ch/g;
	$data=~s/�/sh/g;
	$data=~s/�/sch/g;
	$data=~s/�/yu/g;
	$data=~s/�/ya/g;

	$data=~s/[����]+//g;

	$data=~s/�/ye/g;
	$data=~s/�/i/g;
	$data=~s/�/yi/g;
	$data=~s/�/YE/g;
	$data=~s/�/I/g;
	$data=~s/�/YI/g;

	return $data;
}

=pod

=head2 &check_string($string,$alternate)

A handy code safety function. 

Will return $string if $string is defined. If not, will return $alternate if $alternate is defined or "". 

=cut


sub check_string() { 
	my ($string, $alternate)=@_;
	$alternate="" if (not defined $alternate);
	return $alternate if (not defined $string);
	return $string;
}

=pod

=head2 &check_number($string,$alternate)

A handy code safety function. 

Will return int($string) if $string is defined and it's really a number. If
not, will return $alternate if $alternate is defined or 0.

=cut


sub check_number() { 
	my ($number, $alternate)=@_;
	$alternate=0 if (not defined $alternate);
	return $alternate if (not defined $number);
	return $alternate if (int($number) != $number);
	return int($number);
}

=pod

=head2 &get_image_boundaries($data);

Will return ($width,$height)  of an image contained in $data. 

=cut


sub get_image_boundaries() {
	my ($data)=@_;
	return undef if (not defined $data);
	my $info = image_info($data);
	my ($w,$h)=dim($info);
	return ($w,$h);
}

=pod

=head2 &check_empty_html($data);

Will try to guess if the supplied HTML code has human-readable content or it is really empty. 
Will return undef if it is NOT empty and 1 otherwise. 

=cut

sub check_empty_html() { 
	my ($html)=@_;
	return undef if (not defined $html);

	my $originalhtml=lc($html);
	$originalhtml=~s/< */</g;
	if ($originalhtml=~/<img /) { return undef; } 
	if ($originalhtml=~/<object /) { return undef; } 
	if ($originalhtml=~/<iframe /) { return undef; } 
	if ($originalhtml=~/<script /) { return undef; } 

	while ($html=~s/<[^\>]+>//gs)  { 1; }
	$html=~tr/\n\r\t /    /;
	$html=~s/ //g;
	if ($html eq '') { return 1; } 
	return undef; 
}

=pod

=head2 &generate_password($len);

Will return generated string suitable for password. The string length is $len
+- 3 chars. If $len is not defined then it defaults to 7. 

=cut

sub generate_password() {
	my ($len)=@_;
	$len=7 if (not defined $len);
        my @letters=qw(B C D F G H J K L M N P Q R S T V W X Y Z b c d f g h j k l m n p q r s t v w x y z);
        my @vowels=qw(a e i o u A E I O U);
        my $i;
        my $p;

        my $l=int(rand(3))+($len-3);
        $p="";
        for ($i=1;$i<=$l;$i++) {
                $p.=$letters[int(rand($#letters))] . $vowels[int(rand($#vowels))];
        }
        return $p;
}

=pod

=head2 &monetary_round($value);

Will return rounded value suitable for monetary calculations and presentations. Actually it's a sprintf %.2f. 

Of course will return undef if $value is not defined.

=cut

sub monetary_round() { 
	my ($money)=@_;
	return undef if (not defined $money);

	return sprintf("%.2f", $money);
}

=pod

=head2 &find_file($directory,$path,$file_name,$default_file_name, $enc)=@_;

Will try to investigate directories from specified and upstairs looking for
file. This function is mostly used by Folio to find [default] templates,
layouts, constructions. 

$directory is the path to the "root" directory where the find process should stop
and go no further. 

$path is the relative to $directory path where we expect to find $file_name or $default_file_name. 

If $directory.$path.$default_file_name or $directory.$path.$file_name is found - then we've got 
it.  If not, find_file will cut off the last $path element and try to find again, but from now on 
will only look for $file_name. up to $path eq ''. 

$encoding specifies the source file encoding. If it is defined then file content will be converted
FROM than specified encoding TO $default_binary_charset. 

Will return hashref containing  following keys:

=over

=item content

File's content.

=item path

$path where we've found the file.

=item defaulted

it is defined is we haven't found $directory.$path.$default_file_name

=back

An example. Given, we call the function like that: 

 &find_file('/home/vasya','OpenOffice.org1.1.1/share/samples','Special.ico','Anything.ico');

Here is the order in which &find_file will try to find the file: 

 /home/vasya/OpenOffice.org1.1.1/share/samples/Special.ico
 /home/vasya/OpenOffice.org1.1.1/share/samples/Anything.ico
 /home/vasya/OpenOffice.org1.1.1/share/Anything.ico
 /home/vasya/OpenOffice.org1.1.1/Anything.ico
 /home/vasya/Anything.ico

=cut

sub find_file() { 
	my ($directory,$path,$file_name,$default_file_name, $enc)=@_;
	my $data;
	my $result;

	$path=&normalize_path($path);
	if (defined($default_file_name) && -f $directory."/".$path."/".$default_file_name) { 
		$result = {
			'content'	=> &read_file($directory."/".$path."/".$default_file_name),
			'path'		=> $path
		};
	} elsif (defined $file_name) { 
		do {
			my $filename=$directory."/".$path."/".$file_name;
			if (-f $filename) {
				$data=&read_file($filename);
				$result = {
					'content'	=> $data,
					'path'		=> $path,
					'defaulted'	=> 1
				}; # fixme, ��� ����� $path ������������ ��� ������� �����, 
			   	# � ����������� ��������� ���� � ������ � �������� ��������� - ��� �� _�_ ������ ������
				$path=undef;
			}
			($path,undef)=&split_uri_last($path);
		} while (defined $path);
		
		if (not defined $result) { 
			if (-f $directory."/".$file_name) { 
				$data=&read_file($directory."/".$file_name);
				$result = {
					'content'	=> $data,
					'path'		=> '/',
					'defaulted'	=> 1
				};
			}
		} 
	}

	if (defined $enc) { 
		if ($enc ne $default_binary_charset) {
			from_to($result->{'content'}, $enc, $default_binary_charset);
		}
	}
	return $result;
}
=pod

=head2 &validate_email($email)

Shurtcut for fully loaded Email::Valid->address invocation. Will try to check if the Email is valid. 

Will return 1 if yes and undef if not or not $email is not defined. 

=cut

sub validate_email() { 
	my ($email)=@_;
	return undef if (not defined $email);
	
	my $addr = Email::Valid->address(
		-address => $email,
		-mxcheck => 1,
		-rfc822	 => 1,
		-fqdn    => 1,
		-tdlcheck=> 1
	);
	if ($addr) { 
		return 1;
	} else { 
		return undef;
	}
}

sub fix_weird_string() { 
	my ($string)=@_;

	open F, "<", \$string;
	binmode F;
	local $/;
	undef $/;
	my $bytes=<F>;
	close F;
	return $bytes;
}


1;

