package DataSpirit::Way;
use XML::LibXML;
use DataSpirit::Tools;
use Digest::MD5 qw(md5 md5_hex md5_base64);


sub new() { 
	my $class=shift;
	my $info=shift;
	my $self = { 
		'structure'	=> {},
		'tag'		=> undef,
		'parent'	=> undef,
		'path'		=> '',
		'info'		=> $info,
		'id'		=> undef,
	};
	return bless $self, $class;
}

sub construction() { 
	my $self=shift;
	my ($construction, $private)=@_;
	if (defined $construction) { 
		my $key='constructions';
		if (defined $private && $private>0) { 
			$key="private_constructions" 
		}
		$self->{'info'}->{$key}->{$self->id()}=$construction;
		return 1;
	} else { 
		if (defined $self->{'info'}->{'private_constructions'} &&
			defined $self->{'info'}->{'private_constructions'}->{$self->id()}) {
			return  $self->{'info'}->{'private_constructions'}->{$self->id()};
		} else {
			return undef if (not defined $self->{'info'}->{'constructions'});
			my $stack=$self->stack();
			foreach my $entry (reverse @$stack) { 
				if (defined $self->{'info'}->{'constructions'}->{$entry}) {
					return $self->{'info'}->{'constructions'}->{$entry};
				}

			}
			return undef;
		}
	}
}

sub unserializeXML() { 
	my $self=shift;
	my ($xml, $oldKind)=@_;
	
	my @itemsList=$xml->getChildrenByTagName("item");
	foreach my $node (@itemsList) { 
		my $_infoHash={};
		my @attributes=$node->attributes();

		foreach my $attr (@attributes) { 
			$_name=$attr->nodeName();
			next if ($_name eq "tag" || 
				$_name eq "id" || 
				$_name eq "href" ||
				$_name eq "special" ||
				$_name eq "shown" ||
				$_name eq "enabled");
			$_infoHash->{$_name}=$attr->value();
		}
		my $entry;

		my $tag;
		if ($oldKind) {
			$tag=scalar &split_uri_last(&normalize_path($node->getAttribute("href")));
		} else { 
			$tag = $node->getAttribute("tag");
		}
		
		if ($oldKind) { 
			my $shown=$node->getAttribute("shown");
			if (defined $shown && $shown == 0) { 
				$_infoHash->{'hidden'}=1;
			}
			$_infoHash->{'title'}=$node->getAttribute("tag");
		}
		$entry=$self->add($tag, $_infoHash, $node->getAttribute("id"));
		$entry->unserializeXML($node, $oldKind);
	}

	my @constructions = $xml->getChildrenByTagName("XML");
	foreach my $construction (@constructions) { 
		my $private=$construction->getAttribute("private");
		$private=0 if (not defined $private);
		my @body = $construction->getChildrenByTagName("page");
		next if (not @body);
		$self->construction($body[0]->toString(2), $private);
	}
	
	if (defined $self->{'tag'}) { 
		$self->{'info'}->{'_xml_trees'}->{$self->id()}=1;
	} else { 
		delete $self->{'info'}->{"_xml_trees"};
	}
}

sub _toXML() { 
	my $self=shift;
	my ($xml, $fullTree)=@_;
	my $_workerXML;

	return if (defined $self->{'info'}->{"_xml_trees"}->{$self->id()} &&
		not $fullTree);
	if (defined $self->{'tag'}) { 
		my $_xml=XML::LibXML::Element->new("item");
		$_xml->setAttribute("tag", $self->{'tag'});
		$_xml->setAttribute("id", $self->{'id'});
		$_xml->setAttribute("href", $self->fullPath());
		my $info=$self->info();

		foreach my $_i (keys %$info) { 
			next if ($_i=~/^_/);
			$_xml->setAttribute($_i, $info->{$_i});
		}
		$_workerXML=$_xml;
	} else { 
		$_workerXML=$xml;
	}

	if (defined $self->{'info'}->{'private_constructions'} && 
		defined $self->{'info'}->{'private_constructions'}->{$self->{'id'}}) { 
		
		my $_xml = XML::LibXML::Element->new("XML");
		$_xml->setAttribute("private", "1");

		# First way to do it:
		my $parser=XML::LibXML->new();
		my $doc=$parser->parse_string($self->{'info'}->{'private_constructions'}->{$self->{'id'}});
		my $element=$doc->documentElement();
		$_xml->appendChild($element); 
		
		# Second way to do it: 
		#$_xml->appendWellBalancedChunk(
		#	$self->{'info'}->{'private_constructions'}->{$self->{'id'}});

		$_workerXML->appendChild($_xml);
	}

	if (defined $self->{'info'}->{'constructions'} && 
		defined $self->{'info'}->{'constructions'}->{$self->{'id'}}) { 

		my $_xml = XML::LibXML::Element->new("XML");

		# First way to do it: 
		my $parser=XML::LibXML->new();
		my $doc=$parser->parse_string($self->{'info'}->{'constructions'}->{$self->{'id'}});
		my $element=$doc->documentElement();
		$_xml->appendChild($element); 

		# Second way to do it: 
		#$_xml->appendWellBalancedChunk(
		#	$self->{'info'}->{'constructions'}->{$self->{'id'}});

		$_workerXML->appendChild($_xml);
	}

	foreach my $node ($self->children()) { 
		next if ($node eq $self);
		$node->_toXML($_workerXML);
	}
	if (defined $self->{'tag'}) { 
		$xml->appendChild($_workerXML);
	}
	return $xml;
}

sub serializeXML() { 
	my $self=shift;
	my ($xml,$fullTree)=shift;
	$DB::single=2;
	$self->_toXML($xml,$fullTree);
	return 1;
}

sub stack() {
	my $self=shift;
	my @stack=();
	my $me=$self;
	do {
		@stack=($me->id(), @stack);
		$me=$me->{'parent'};
	} while ($me);
	return \@stack; 
}

sub level() {
	my $self=shift;
	my $level=0;
	my @stack=@{$self->stack()};
	return $#stack+1; 
}

sub move() { 
	my $self=shift;
	my $newChild=shift;
	return undef if (not defined $newChild);

	my $_parent=$newChild->{'parent'};
	$self->{'structure'}->{$newChild->tag()}=$newChild->{'structure'};
	delete $_parent->{'structure'}->{$newChild->tag()};

	$newChild->{'path'}=$self->_path(); 
	$self->{'info'}->{'_p_i'}->{$newChild->normalizedPath()}=$newChild->id();
	$self->{'info'}->{'_i_p'}->{$newChild->id()}=$newChild->normalizedPath();
	
	return $newChild;
}

sub rename() {
	my $self=shift;
	my ($oldName, $newName)=@_;
	return undef if (not defined $self->{'structure'}->{$oldName});
	return undef if (defined $self->{'structure'}->{$newName});

	my $_old=$self->child($oldName);
	my $_info=$_old->info();
	my $_id=$_old->id();
	$self->kill($oldName);
	my $_new=$self->add($newName, $_info, $_id);
	return $_new;
}

sub kill() { 
	my $self=shift;
	my ($pagename)=@_;
	return undef if ($pagename eq '' || $pagename=~/\//);
	my $node=$self->child($pagename);
	return undef if (not defined $node);
	$node->clean();
	delete $self->{'structure'}->{$pagename};
	return undef;
}

sub clean() { 
	my $self=shift;
	foreach my $node ($self->children()) { 
		delete $self->{'info'}->{$node->id()};
		delete $self->{'info'}->{'_p_i'}->{$node->normalizedPath()};
		delete $self->{'info'}->{'_i_p'}->{$node->id()};
		$node->clean();
	}
	delete $self->{'info'}->{$self->id()};
	delete $self->{'info'}->{'_p_i'}->{$self->normalizedPath()};
	delete $self->{'info'}->{'_i_p'}->{$self->id()};
	return 1;
}

sub seek_id() { 
	my $self=shift;
	my ($id)=@_;
	return undef if (not $id);
	my $path = $self->{'info'}->{'_i_p'}->{$id};
	if (not defined $path) { 
		$path="";
	}
	return $self->seek("/".$path);
}

sub eotArgument() { 
	my $self=shift;
	return $self->{'pathArgument'};
}

sub seek() {
	my $self=shift;
	my ($pagepath)=@_;

	# short way -> single path requested, so we can simply return child
	# or self (if eot)
	if (index($pagepath, "/") == -1) { 
		my $_child=$self->child($pagepath);
		if ($self->{'info'}->{$self->id()}->{'eot'}) { 
			if (not defined $_child) { 
				return $self; 
			}
		}
		return $_child;
	}


	my $root=$self;

	# find our root 
	if ($pagepath=~/^\//) {
		do { 
			if ($root->{'parent'}) { 
				$root=$root->{'parent'}
			}
		} while ($root->{'parent'});
		$pagepath=~s/^\///;
	}
	my $slashEnded = $pagepath=~/\/$/;

	if ($pagepath eq '' ||  $pagepath eq '.') { 
		#if (defined $self->{'parent'}) {
		#return $self->{'parent'};
		#} else { 
			return $root;
			#}
	}

	$pagepath=&normalize_path($pagepath);

	if (index($pagepath, "/") == -1) { 
		my $_child=$root->child($pagepath);
		if ($self->{'info'}->{$root->id()}->{'eot'}) { 
			if (not defined $_child) { 
				return $root;
			} 
		}
		return $_child;
		#return $root->child($pagepath);
	}

	my @elements=split('/',$pagepath);
	while (my $element=shift @elements) {
		my $_k=$root->child($element);
		if (defined $_k) { 
			$root=$_k;
		} else { 
			if ($self->{'info'}->{$root->id()}->{'eot'}) { 
				unshift(@elements,$element);
				$root->{'pathArgument'}=join('/',@elements);
				$root->{'pathArgument'}.="/" if ($slashEnded);
				return $root; # alright, we stop looking further
			}
			return undef; 
		}
	}
	return $root;
}

sub childrenNames() { 
	my $self=shift;
	return keys %{$self->{'structure'}};
}

sub children() { 
	my $self=shift;
	my %sortedChildren;
	my @children;
	foreach my $_c (keys %{$self->{'structure'}}) { 
		my $child=$self->child($_c);
		push (@children, $child);
		$sortedChildren{$child->id()}=$child->order();
	}
	return sort {
		return $sortedChildren{$a->id()} <=> $sortedChildren{$b->id()};
	} @children;
}

sub child() { 
	my $self=shift;
	my ($pagepath)=@_;
	$pagepath=&normalize_path($pagepath);
	if ($pagepath eq '.') { 
		return $self;
	}
	if ($pagepath eq '' && not $self->{'structure'}->{''}) { 
		return $self;
	}

	if ($pagepath eq '..') { 
		if (defined $self->{'parent'}) { 
			return $self->{'parent'};
		} else { 
			return $self;
		}
	}

	if ($self->{'structure'}->{$pagepath}) { 
		my $_new=bless {
			'structure'	=> $self->{'structure'}->{$pagepath},
			'tag'		=> $pagepath,
			'parent'	=> $self,
			'path'		=> $self->_path(),
			'info'		=> $self->{'info'},
		}, "DataSpirit::Way";
		$_new->{'id'}=$self->{'info'}->{'_p_i'}->{$_new->normalizedPath()};
		return $_new;
	}
	return undef;
}

sub add() {
	my $self=shift;
	my ($pagename,$info,$newId)=@_;
	return undef if (defined $self->{'structure'}->{$pagename});
	$self->{'structure'}->{$pagename}={};

	my $_new=bless { 
		'structure'	=> $self->{'structure'}->{$pagename},
		'tag'		=> $pagename,
		'parent'	=> $self,
		'path'		=> $self->_path(),
		'info'		=> $self->{'info'},
		'id'		=> $newId,
	}, "DataSpirit::Way";

	$self->{'info'}->{$_new->id()}=$info;
	$self->{'info'}->{'_i_p'}->{$_new->id()}=$_new->normalizedPath();
	$self->{'info'}->{'_p_i'}->{$_new->normalizedPath()}=$_new->id();
	return $_new;
}

sub info() { 
	my $self=shift;
	my $info=$self->{'info'}->{$self->id()};
	if (not defined $info) { 
		return {};
	} else { 
		return $info;
	}
}


sub doorName()  { 
	my $self=shift;
	my $door=$self->door();

	return undef if (not defined $door);
	my $check=$self->seek_id($door);
	return undef if (not defined $check);
	return $check->tag();
}

sub door()  { 
	my $self=shift;
	my $stack=$self->stack();
	foreach my $id (reverse @$stack) { 
		return $id if ($self->{'info'}->{$id}->{'entrance'});
	}
	return undef;
}

sub doorNames()  { 
	my $self=shift;
	my $doors=$self->doors();
	my @doorList;
	foreach my $_k (@$doors) { 
		push(@doorList, $self->{'info'}->{'_i_p'}->{$_k});
	}
	return \@doorList;
}

sub doors()  { 
	my $self=shift;
	my $info=$self->{'info'}; 
	my @entrances;

	foreach my $_k (keys %$info) { 
		next if ($_k=~/^_/);
		push(@entrances, $_k) if ($info->{$_k}->{'entrance'});
	}
	return \@entrances;
}


sub entrance()  { 
	my $self=shift;
	my $info=$self->info();
	return 1 if ($info->{'entrance'});
	return 0;
}

sub order()  { 
	my $self=shift;
	my $info=$self->info();
	return $info->{'order'} if ($info->{'order'});
	return 99999; # HACK: a guaranteed last position
}

sub eot()  { 
	my $self=shift;
	my $info=$self->info();
	return 1 if ($info->{'eot'});
	return 0;
}

sub title() { 
	my $self=shift;
	my $info=$self->info();
	foreach my $_k ("fullTitle", "title") { 
		if (defined $info->{$_k}) { 
			return $info->{$_k};
		}
	}
	return undef;
}

sub _path() { 
	my $self=shift;
	my $path=$self->{'path'};
	if (defined $self->{'tag'}){ 
		if ($self->{'tag'} ne '') { 
			if ($path ne '') { $path.="/"; }
			$path.=$self->{'tag'};
		}
	}
	return $path;
}

sub id() { 
	my $self=shift;
	$self->{'id'}=$self->_id() if (not defined $self->{'id'});
	return $self->{'id'};
}

sub _id() { 
	my $self=shift;
	my $t = time;
	my $pid = $$;
	my $random = int(rand(10000000));
	return md5_base64($t.$pid.$random);
}


sub tag() { 
	my $self=shift;
	return $self->{'tag'};
}

sub fullPath() { 
	my $self=shift;
	my $path="/".$self->_path();
	my @_k = keys %{$self->{'structure'}};
	if ($self->{'info'}->{$self->id()}->{'eot'}) { 
		return $path."/";
	}
	if (defined $self->{'tag'} && $self->{'tag'} ne '') { 
		if ($#_k > -1) { 
			return $path."/";
		} else { 
			return $path.".html";
		}
	} else { 
		return $path;
	}
}

sub normalizedPath() { 
	my $self=shift;
	return &normalize_path($self->fullPath());
}


1;
