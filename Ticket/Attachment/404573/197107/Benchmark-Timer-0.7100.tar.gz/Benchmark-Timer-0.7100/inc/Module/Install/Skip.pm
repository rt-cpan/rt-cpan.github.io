#line 1
package Module::Install::Skip;
use strict;

use vars qw( @ISA $VERSION );
use Module::Install::Base;
@ISA = qw(Module::Install::Base);

$VERSION = 0.01;

#line 31

sub skip
{
	my ($self, $regexp) = @_;

	my $callback = <<END;

package MY;

sub libscan
{
	my \$keeper = shift->SUPER::libscan(\@_);

	return '' if( \$keeper =~ /$regexp/ );
	return \$keeper;
};
1;
END

	eval "$callback";
	die $@ if( $@ );

	return;
}

#line 90

1;
__END__

