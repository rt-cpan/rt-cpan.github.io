#!/usr/bin/perl
use HTTP::AppServer;
use IO::Socket::IP -register;
  
my $server = HTTP::AppServer->new( StartBackground => 0, ServerPort => 3000 );
 
$server->handle('^\/$', '/index.html');

$server->plugin('FileRetriever', DocRoot => '/tmp');

$server->start; 
