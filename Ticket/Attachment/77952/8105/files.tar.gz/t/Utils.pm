package main;

use HTTP::Daemon;
use HTTP::Status;

# check that the web connection is working
sub web_ok {
    return LWP::UserAgent->new( env_proxy => 1 )
      ->request( HTTP::Request->new( GET => 'http://www.google.com/intl/en/' ) )
      ->is_success;
}

# start a web server
sub start_web {
    my $count = shift || 1;

    # create a HTTP::Daemon (on an available port)
    my $daemon = HTTP::Daemon->new(
        LocalHost => 'localhost',
        ReuseAddr => 1,
      )
      or die "Unable to start web server";

    # fork a child server
    my $pid = fork;
    die "Could not fork" if not defined $pid;
    if ($pid) {
        return ( $daemon, $pid );
    }
    else {
        my %files = (
            '/'                       => 't/google/en.html',
            '/intl/en/'               => 't/google/en.html',
            '/news/'                  => 't/google/news.html',
            '/help/'                  => 't/google/help.html',
            '/help/basics.html'       => 't/google/basics.html',
            '/help/refinesearch.html' => 't/google/refinesearch.html',
            '/images/logo.gif'        => 't/google/logo.gif',
            '/search'                 => 't/google/foo.html',
        );
        my $c;
        while ( $count and $c = $daemon->accept ) {
            while ( my $r = $c->get_request ) {
                $count--;
                if ( $r->method eq 'GET' and exists $files{ $r->url->path } ) {
                    $c->send_file_response( $files{ $r->url->path } );
                }
                else {
                    $c->send_error(RC_NOT_FOUND);
                }
                last unless $count;
            }
            $c->close;
            undef($c);
        }

    }

    # end the child
    exit;
}

1;

