package MyModule;

our $VERSION = '1.00';
