package MyModule::Build;

require Module::Build;
our @ISA = qw( Module::Build );

sub ACTION_hello {
    print "Hello World\n";
}
