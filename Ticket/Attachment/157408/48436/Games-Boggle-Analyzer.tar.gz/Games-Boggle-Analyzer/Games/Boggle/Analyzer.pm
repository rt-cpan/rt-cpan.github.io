package Games::Boggle::Analyzer;

use warnings;
use strict;

use Carp;
use Search::Dict;

our $VERSION = '0.01';

=head1 NAME

Games::Boggle::Analyzer - Analyze a game of Boggle to find all words that can
possibly be formed.

=head1 VERSION

Version 1.00

=head1 SYNOPSIS

  use Games::Boggle::Analyzer;

  my $ba = Games::Boggle::Analyzer->new("LMSO DEYC VHLA BSLU", "dict");
  foreach my $word ($ba->find_all_words()) {
    print "$word\n" if length $word > 3;
  }

=head1 DESCRIPTION

This module allows the creation and analysis of a game of Boggle, using a 
dictionary to find all words that can be formed.

=head1 METHODS

=head2 new

  my $ba = Games::Boggle::Analyzer->new("LMSO DEYC VHLA BSLU", "dict");

or if you have Games::Boggle::Board installed and want a random board:

  my $board = Games::Boggle::Board->new();
  my $ba = Games::Boggle::Analyzer->new( $board->as_string, "dict" );

The game is initialized with a string containing the blocks on the Boggle board
to use and the dictionary file to use to lookup words. The dictionary file 
should have one word per line and be in alphabetical order. On most Unix-like
machines, the mostly standard /usr/share/dict/words will work just fine. 

=cut

sub new
{
   my ($class, $letters, $dict_fn) = @_;
   local *DICT;

   my @blocks = grep /\S/, split //, lc $letters;

   # The main data structure for the board is a hash with the keys being
   # the coordinate (ie. 00 or 13) with row as the first number and the
   # column as the second.
   my %board = ();
   my $const = 0;
   foreach my $row (0..3) {
      foreach my $col (0..3) {
         $board{$row.$col} = $blocks[$row + $col + $const];
      }
      $const += 3;
   }

   open(my $dict, $dict_fn) or croak "Couldn't read dictionary $dict_fn: $!";

   return bless {
      _board => \%board,
      _dict  => *$dict,
   }, $class;
}

=head2 find_all_words

find_all_words returns a sorted list of all unique words that can be found in
this instance of Boggle. It does not return the same word multiple times if
there are multiple ways of forming the word.

=cut

sub find_all_words
{
   my ($self) = @_;

   my @words = ();
   foreach ($self->_get_all_coords()) {
      $self->_find_words_at($_, undef, \@words, "", "");
   }

   # We'll get words repeated in the array if there are multiple
   # ways to form one word.
   my %seen = ();
   my @unique_words = grep { ! $seen{$_}++ } @words;
   return sort @unique_words;
}

# The recursive subroutine that does all the work of finding the words.
sub _find_words_at
{
   my ($self, $coord, $string, $words, %touched) = @_;

   # We can't re-use the same block when making a word, so mark this block used.
   $touched{$coord} = 1;
   
   # Concatenate this block onto the current string we've made so far.
   $string .= $self->{_board}{$coord};

   if ($self->_lookup_word($string)) {
      # Cool, we got a word match.
      push(@$words, $string);
   }

   # End this branch no words can be created with the string so far.
   return unless $self->_lookup_starts_with($string);

   # Branch to each adjecent block...
   foreach my $adj_coord ($self->_get_adj_coords($coord)) {
      next if $touched{$adj_coord};
      # ... and call this function recursively.
      $self->_find_words_at($adj_coord, $string, $words, %touched);
   }
}

sub _get_all_coords
{
   my @all_coords;
   foreach my $row (0..3) {
      foreach my $col (0..3) {
         push(@all_coords, "$row$col");
      }
   }
   return @all_coords;
}
   
sub _get_adj_coords
{
   my ($self, $coord) = @_;

   croak "Bad coord format: $coord" unless $self->_is_valid_coord($coord);   

   my $row = substr($coord, 0, 1);
   my $col = substr($coord, 1, 1);
   
   my @adj_coords = ();

   foreach my $adj_row (-1, 0, 1) {
      foreach my $adj_col (-1, 0, 1) {

         next if $adj_row == 0 and $adj_col == 0;
         next if ($adj_row + $row > 3) || ($adj_row + $row < 0);
         next if ($adj_col + $col > 3) || ($adj_col + $col < 0);

         push(@adj_coords, ($row+$adj_row) . ($col+$adj_col));
      }
   }

   return @adj_coords;
}

sub _is_valid_coord
{
   my ($self, $coord) = @_;
   return $coord =~ /^[0-3]{2}$/;
}

sub _lookup_starts_with
{
   my ($self, $word_start) = @_;

   my $dict_fh = $self->{_dict};

   my @words = ();
   look($dict_fh, $word_start, 0, 0);
   while (<$dict_fh>) {
      last unless /^$word_start/;
      chomp;
      push(@words, $_);
   }

   return @words;
}

sub _lookup_word
{
   my ($self, $word) = @_;

   my $dict_fh = $self->{_dict};

   look($dict_fh, $word, 0, 0);
   chomp(my $looked_up = <$dict_fh>);
   
   return $looked_up eq $word;
}

sub DESTROY
{
   close $_[0]->{_dict};
}

=head1 AUTHOR

Joe Oppegaard, C<< <joe at radiojoe.org> >>

=head1 BUGS

Please report any bugs or feature requests to
C<bug-games-boggle-analyzer at rt.cpan.org>, or through the web interface at
L<http://rt.cpan.org/NoAuth/ReportBug.html?Queue=Games-Boggle-Analyzer>.
I will be notified, and then you'll automatically be notified of progress on
your bug as I make changes.

=head1 SUPPORT

You can find documentation for this module with the perldoc command.

    perldoc Games::Boggle::Analyzer

You can also look for information at:

=over 4

=item * AnnoCPAN: Annotated CPAN documentation

L<http://annocpan.org/dist/Games-Boggle-Analyzer>

=item * CPAN Ratings

L<http://cpanratings.perl.org/d/Games-Boggle-Analyzer>

=item * RT: CPAN's request tracker

L<http://rt.cpan.org/NoAuth/Bugs.html?Dist=Games-Boggle-Analyzer>

=item * Search CPAN

L<http://search.cpan.org/dist/Games-Boggle-Analyzer>

=back

=head1 ACKNOWLEDGEMENTS

=head1 COPYRIGHT & LICENSE

Copyright 2006 Joe Oppegaard, all rights reserved.

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.

=cut

1; # End of Games::Boggle::Analyzer
