#!/usr/bin/perl -w
use strict;

use Games::Boggle::Board;
use Games::Boggle::Analyzer;

my $board = Games::Boggle::Board->new();
my $ba = Games::Boggle::Analyzer->new( $board->as_string, "/usr/share/dict/words" );
#my $ba = Games::Boggle::Analyzer->new( "LMSO DEYC VHLA BSLU", "words" );

print $board->as_formatted_string() . "\n";

#$ba->_get_adj_coords("22");
#$ba->_get_adj_coords("00");
#$ba->_get_adj_coords("33");
#$ba->_get_adj_coords("03");
#$ba->_get_adj_coords("10");
#$ba->_get_adj_coords("23");

#print "is_valid_coord(11)\n" if $ba->is_valid_coord("11");
#print "is_valid_coord(42)\n" if $ba->is_valid_coord("42");

#foreach my $word ($ba->_lookup_starts_with("good")) {
#   print "$word\n";
#}

#my @list;
#$ba->find_words_at("00", "bad", \@list);
#print "$_\n" foreach @list;

foreach my $word ($ba->find_all_words()) {
   print "$word\n" if length $word > 3;
}

