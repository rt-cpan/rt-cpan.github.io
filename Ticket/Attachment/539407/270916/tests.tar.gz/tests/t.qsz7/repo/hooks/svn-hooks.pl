#!/usr/bin/perl
use strict;
use warnings;
use lib 'blib/lib';
use SVN::Hooks;
use SVN::Hooks::CheckLog;

run_hook($0, @ARGV);
