#!/usr/bin/perl
use strict;
use warnings;
use lib 'blib/lib';
use SVN::Hooks;
use SVN::Hooks::CheckMimeTypes;
use SVN::Hooks::DenyChanges;
use SVN::Hooks::CheckMimeTypes;
use SVN::Hooks::CheckProperty;
use SVN::Hooks::CheckStructure;
use SVN::Hooks::DenyFilenames;
use SVN::Hooks::JiraAcceptance;
use SVN::Hooks::Mailer;
use SVN::Hooks::UpdateConfFile;

run_hook($0, @ARGV);
