package Simple;

1;
__END__
