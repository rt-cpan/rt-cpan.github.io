use Module::Build::ModuleInfo;
use File::Spec;

print "This is not a case insensitive filesystem.
tests must be performed on a case insensitive filesystem to show up the issue in Module::Build::ModuleInfo v0.2808.\n\n" if !File::Spec->case_tolerant();

my $module_info = Module::Build::ModuleInfo->new_from_file('simple.pm'); # note filename is all lower case
die "Module::Build::ModuleInfo error: $!" unless defined($module_info);
if (defined($module_info->name())) {
    print "Found module with name: ".$module_info->name()." for simple.pm\n";
} else {
    print "Couldn't find module name for simple.pm\n";
}


$module_info = Module::Build::ModuleInfo->new_from_file('Simple.pm'); # note filename is NOT all lower case
die "Module::Build::ModuleInfo error: $!" unless defined($module_info);
if (defined($module_info->name())) {
    print "Found module with name: ".$module_info->name()." for Simple.pm\n";
} else {
    print "Couldn't find module name for Simple.pm\n";
}