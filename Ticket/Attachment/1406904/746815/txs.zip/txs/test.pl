package Blurg;

use My::XS::Blurg;

blat;

package Blarg;

use My::XS::Blarg;

blat;
