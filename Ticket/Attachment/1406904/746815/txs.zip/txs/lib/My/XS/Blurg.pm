package My::XS::Blurg;

require Exporter;
require DynaLoader;
@ISA    = qw(Exporter DynaLoader);
@EXPORT = qw( blat );

bootstrap My::XS::Blurg;
1;

