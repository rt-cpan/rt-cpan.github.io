package Foo;

use Foo::Bar;
use Foo::Bar::Baz;

$Foo::VERSION = '2.1';

#sub foo {return "Hello from Foo";}

use Inline C => <<'EOC';

SV * foo() {
  return(newSVpv("Hello from Foo", 0));
}

EOC

*foobar = \&Foo::Bar::foobar;
*foobarbaz = \&Foo::Bar::Baz::foobarbaz;

1;
