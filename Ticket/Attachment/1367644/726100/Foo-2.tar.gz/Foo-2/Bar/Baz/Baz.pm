package Foo::Bar::Baz;

$Foo::Bar::Baz::VERSION = '2.1';

#sub foobarbaz {return "Hello from Foo::Bar::Baz";}

use Inline C => <<'EOC';

SV * foobarbaz() {
  return(newSVpv("Hello from Foo::Bar::Baz", 0));
}

EOC

1;
