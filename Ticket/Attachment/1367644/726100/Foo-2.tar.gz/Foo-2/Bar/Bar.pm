package Foo::Bar;

$Foo::Bar::VERSION = '2.1';

#sub foobar {return "Hello from Foo::Bar";}

use Inline C => <<'EOC';

SV * foobar() {
  return(newSVpv("Hello from Foo::Bar", 0));
}

EOC

1;
