#!/usr/bin/perl -w
use strict;
use HTML::Strip;

open FH, "<:utf8", $ARGV[0] or die "Can't open file! $!";

# two outputs, one to show the origional read is not corupting the utf8, ie. the
# output is the same as the input
open OUT_NO_PARSE, ">:utf8", "out_no_parse" or die "Can't open out_no_parse for output! $!";
# and the second to show the parsing is returning double encoded
open OUT_PARSE, ">:utf8", "out_parse" or die "Can't open out_parse for output! $!";


my $hs = HTML::Strip->new();

while ( my $line = <FH> ) {
	print OUT_NO_PARSE $line;	
	
	my $clean = $hs->parse ( $line);
	print OUT_PARSE $clean;
}

