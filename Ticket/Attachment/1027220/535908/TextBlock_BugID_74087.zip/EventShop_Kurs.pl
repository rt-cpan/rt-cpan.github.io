#!/usr/bin/perl
############################################################################
# EventShop Kurs-Printer : Generiert Kursbest�tigungen
############################################################################
my $v = "1.00 T";
############################################################################
# Module laden ..
############################################################################
use strict;
use warnings;
use Config::IniFiles;						# Konfiguration
#use MIME::Lite;									# Mailversand
#use DBI;												# Datenbankverbindung
use Date::Calc qw(:all);				# Datumsberechnungen
use Compress::Zlib;							# F�r PDF Erstellung
use PDF::API2;									# F�r PDF Erstellung
use PDF::TextBlock;							# F�r PDF Erstellung
#use Date::ICal;									# F�r ICAL-File
#use Data::ICal;									# F�r ICAL-File
#use Data::ICal::Entry::Event;		# F�r ICAL-File
############################################################################
# Globale Variablen
############################################################################
my $DebRaster				= 0;				# Elementegitter anzeigen 0 | 1
my $i								= 1;				# Allegmeiner Z�hler starte bei 1
my $dbh;												#	Datanbank Connect
my $cmd;												# SQL-Komando

DoLog("Starte Kurs-Anmeldung");
############################################################################
# dummy data; comes later from database
############################################################################
my $DAME_N 					= "�Dame_NN�";
my $DAME_V 					= "�Dame_VN�";
my $HERR_N 					= "�Herr_NN�";
my $HERR_V 					= "�Herr_VN�";
my $STRASSE					= "�STRASSE�";
my $PLZ		 					= "�PLZ�";
my $ORT		 					= "�ORT�";
my $KURSTYP					= "Fortschrittskurs Rumba";
my $KURS_ID					= "RU201201";
my $ANZAHL					= 4;
my $KURSSTART				= "10.02.2012";
my $KURSZEIT				= "17:30";
my $LESSIONS				= "8";
my $SAAL						= "Mittelpunkt der Erde";
my $SAAL_ANSCHRIFT	= "Mahlsdorfer Str.2, 15366 H�now";
my $WERT						= 50;
############################################################################
# will be computed
############################################################################
my $WOCHENTAG;
my $ZAHLBAR;
############################################################################
# Konfigutaion aus INI lesen
############################################################################
if (! -e "EventShop.ini" ){&MissingConfig;exit;}
my $cfg = Config::IniFiles->new( -file => "EventShop.ini" );
if (lc($cfg->val( 'Application', 'Silent' ))eq "false"){AppInfo();}
#
############################################################################
## Main
############################################################################
for($i = 1; $i <= $cfg->val( 'Server', 'Anzahl' ); $i++) {Mandant();};
DoLog("Ende Kurs-Anmeldung\n");
############################################################################
# Mandanten-Durchlauf
############################################################################
sub Mandant {
	$ZAHLBAR = ZahlZiel(-7,$KURSSTART);
	$WOCHENTAG = Wochentag($KURSSTART);
	Ticket_mod();
}
############################################################################
# PDF generieren
############################################################################
sub Ticket_mod {
	my $pdf = PDF::API2->open('template.pdf');
	   $pdf->info(
								'Author'       => "Andreas Kr�ger",
								'CreationDate' => "D:".myTimer()."+01'00'",
								'ModDate'      => "D:".myTimer()."+01'00'",
								'Creator'      => "TicketLux v.".$v,
								'Producer'     => "TicketLux v.".$v." (PDF-API2)",
								'Title'        => "Ihre Swing & Move - Kursanmeldung",
								'Subject'      => "Kursanmeldung",
								'Keywords'     => 'Swing & Move, Kursanmeldung, Best�tigung'
							 );
	my @directories = PDF::API2::addFontDirs('C:/WINDOWS/Fonts/');
	my $page = $pdf->openpage(0);
	my $font = $pdf->ttfont('comic.ttf');
# Adressfeld
# default API2 call does use the defined font
#
	my $text = $page->text();
	$text->font($font, 10);
	$text->translate(48, 585);											# Name Dame
	$text->text($DAME_V.' '.$DAME_N);
	$text->translate(48, 573);											# Name Herr
	$text->text($HERR_V.' '.$HERR_N);
	$text->translate(48, 549);											# Anschrift 1
	$text->text($STRASSE);
	$text->font($font, 11);
	$text->translate(48, 534);											# Anschrift 2
	$text->text($PLZ.' '.$ORT);
#
# Textblock 1
# Textblock ignores the defined font complete
#
	my $tb1  = PDF::TextBlock->new({
		pdf		=> $pdf,
		page	=> $pdf->openpage(0),
		x			=> 40,
		y			=> 490,
		w			=> 510,
		h			=> 500,
		align	=> 'left',
		fonts	=> {
			b			=> PDF::TextBlock::Font->new({
				pdf		=> $pdf,
				font	=> $pdf->ttfont('C:/WINDOWS/Fonts/comic.ttf'),
			}),
		},
	});
	$tb1->text(
		"Sehr geehrte\/r Frau\/Herr ".$DAME_N." \/ ".$HERR_N."," .
		"\n\n" .
		"wir bedanken uns f�r Ihre Anmeldung zum ".$KURSTYP." ".$KURS_ID." f�r ".$ANZAHL." Personen und w�nschen beim Erlernen der T�nze in geselliger Runde viel Spa�." .
		"\n\n" .
		"Dieser ".$KURSTYP." wird Sie nicht �berfordern, auch wenn z.B. der Kopf verstanden hat, welche Schritte gleich folgen sollen, doch die Beine noch ganz anders wollen." .
		"\n\n" .
		"Hier noch einmal die Eckdaten zu Ihrem ".$KURSTYP.":\n" .
		"Der Kurs beginnt am ".$KURSSTART." um ".$KURSZEIT." Uhr und findet in den Folgewochen dann jeweils am gleichen Wochentag (".$WOCHENTAG."), zur gleichen Zeit an ".$LESSIONS." Kurstagen, im Saal �".$SAAL."� ".$SAAL_ANSCHRIFT." statt." .
		"\n\n" .
		"Anbei die n�tigen Zahlungsmodalit�ten:\n" .
		"Wir bitten die Kursgeb�hr in H�he von ".($WERT * $ANZAHL).",- � (".$WERT.",- � pP) bis zum ".$ZAHLBAR." auf unser Konto:\n"
	);
	$tb1->apply;
# Textblock 2
# use the font if text ist marked as bold typ. based of your sample
# from http://search.cpan.org/~jhannah/PDF-TextBlock-0.04/lib/PDF/TextBlock.pm
#
# font was be used correctly
#
	my $tb2 = PDF::TextBlock->new({
		pdf		=> $pdf,
		page	=> $pdf->openpage(0),
		x			=> 80,
		y			=> 264,
		w			=> 200,
		h			=> 120,
		align	=> 'left',
		fonts	=> {
			b			=> PDF::TextBlock::Font->new({
				pdf		=> $pdf,
				font	=> $pdf->ttfont('comic.ttf'),
			}),
		},
	});
	$tb2->text(
		"<b>Bank <b>.........................</b>\n" .
		"<b>BLZ <b>...........................</b>\n" .
		"<b>Kto <b>............................</b>\n" .
		"<b>Verwendungszweck <b>.\n"
	);
	$tb2->apply;
# Textblock 3
# same as block 2 but used the font "comic bold" if text is inside <b></b> markup
#
# font was be used correctly
#
	my $tb3 = PDF::TextBlock->new({
		pdf		=> $pdf,
		page	=> $pdf->openpage(0),
		x			=> 180,
		y			=> 264,
		w			=> 200,
		h			=> 120,
		align	=> 'left',
		fonts	=> {
			b			=> PDF::TextBlock::Font->new({
				pdf		=> $pdf,
				font	=> $pdf->ttfont('comicbd.ttf'),
			}),
		},
	});
	$tb3->text(
		"<b>: my Bank</b>\n" .
		"<b>: 100 200 30</b>\n" .
		"<b>: 1234567890</b>\n" .
		"<b>: ".$HERR_N." - ".$KURS_ID."</b>"
	);
	$tb3->apply;
# Textblock 4
# my understanding was that the font is used constantly, and the <b> tag allows truly bold writing
# I have set the <b> tag from start to end of my text and it was ignored
# in the subsequent row I've opened the tag but doesn't closed it again
# therefore it does not work by line break. sorry my cup
#
# layer eight error ;-)
#
	my $tb4 = PDF::TextBlock->new({
		pdf		=> $pdf,
		page	=> $pdf->openpage(0),
		x			=> 40,
		y			=> 205,
		w			=> 510,
		h			=> 120,
		align	=> 'left',
		fonts	=> {
			b			=> PDF::TextBlock::Font->new({
				pdf		=> $pdf,
				font	=> $pdf->ttfont('comic.ttf'),
			}),
		},
	});
	$tb4->text(
		"<b>zu �berweisen." .
		"\n\n" .
		"<b>Sollte es bei Ihnen zu einer �nderung der Anmeldung kommen, bitten wir um rechtzeitige Information, ansonsten ist die Reservierung von unserer Seite aus als best�tigt anzusehen." .
		"\n\n" .
		"Mit freundlichen Gr��en," .
		"\n\n" .
		"<b>IHR SWING & MOVE TEAM</b>"
	);
	$tb4->apply;
#
	if($DebRaster == 1){
		my $Raster = $page->gfx;
		   $Raster->strokecolor('yellow');
		#	Vertikales Raster
		my $RasterNul='0';
		do {
			   $Raster->move( $RasterNul , 842 );
			   $Raster->line( $RasterNul , 0 );
			   $Raster->stroke;
				 $RasterNul=$RasterNul+10;
			 } while ($RasterNul < 600);
		#	Horizontales Raster
		$RasterNul='0';
		do {
			   $Raster->move( 595.27, $RasterNul );
			   $Raster->line( 0, $RasterNul );
			   $Raster->stroke;
				 $RasterNul=$RasterNul+10;
			 } while ($RasterNul < 840);
		 # Raster Center
		$Raster->strokecolor('violet');
		$Raster->move( 0 , 420.94 );
		$Raster->line( 595.27 , 420.94 );
		$Raster->stroke;
		$Raster->move( 297.63 , 0 );
		$Raster->line( 297.63 , 841.88 );
		$Raster->stroke;
	}
	$pdf->saveas('test.pdf');
}
############################################################################
# Wochentag errechnen
############################################################################
sub Wochentag {
	my $AbDatum = shift;				# Manuelle Berechnungsgrundlage
	if (defined($AbDatum)) {
		my $year      = int(substr($AbDatum, 6,4));
		my $month     = int(substr($AbDatum, 3,2));
		my $day				= int(substr($AbDatum, 0,2));
		return Day_of_Week_to_Text(Day_of_Week($year,$month,$day),3);
	}
}
############################################################################
# Zahlungsziel errechnen
############################################################################
sub ZahlZiel {
	my @zziel;
	my $monatstag;
	my $monat;
	my $jahr;
	my $sekunden;
	my $minuten;
	my $stunden;
	my $wochentag;
	my $jahrestag; 
	my $sommerzeit;
#
	my $MyDelta = shift;				# Anzahl der Delta Tage ...
	my $AbDatum = shift;				# Manuelle Berechnungsgrundlage
	if (defined($AbDatum)) {
		$jahr      = int(substr($AbDatum, 6,4));
		$monat     = int(substr($AbDatum, 3,2));
		$monatstag = int(substr($AbDatum, 0,2));
	} else {
		($sekunden, $minuten, $stunden, $monatstag, $monat, $jahr, $wochentag, $jahrestag, $sommerzeit) = localtime(time);
		$jahr = $jahr + 1900;
		$monat+=1;
		$jahrestag+=1;
	}
	if (defined($MyDelta)) {
		@zziel = Add_Delta_Days($jahr,$monat,$monatstag,$MyDelta);
	} else {
		@zziel = Add_Delta_Days($jahr,$monat,$monatstag,0);
	}
	$zziel[2] = $zziel[2] < 10 ? $zziel[2] = "0".$zziel[2] : $zziel[2];
	$zziel[1] = $zziel[1] < 10 ? $zziel[1] = "0".$zziel[1] : $zziel[1];
	return $zziel[2].".".$zziel[1].".".$zziel[0];
}
############################################################################
# TimeStamp erstellen
############################################################################
sub myTimer {
	my ($sekunden, $minuten, $stunden, $monatstag, $monat, $jahr, $wochentag, $jahrestag, $sommerzeit) = localtime(time);
	$jahr = $jahr + 1900;
	$monat+=1;
	$jahrestag+=1;
	$monat = $monat < 10 ? $monat = "0".$monat : $monat;
	$monatstag = $monatstag < 10 ? $monatstag = "0".$monatstag : $monatstag;
	$stunden = $stunden < 10 ? $stunden = "0".$stunden : $stunden;
	$minuten = $minuten < 10 ? $minuten = "0".$minuten : $minuten;
	$sekunden = $sekunden < 10 ? $sekunden = "0".$sekunden : $sekunden;
	return $jahr.$monat.$monatstag.$stunden.$minuten.$sekunden;
}
############################################################################
# Sub Missing INI
############################################################################
sub MissingConfig {
	print "Missing Config-File ... !!\n";
	DoLog("FATAL ... Missing Config-File !!");
}
############################################################################
# Sub AppInfo
############################################################################
sub AppInfo {
print <<"EOM" ;
**** TicketLux Printer ********************************************************
*                                                                             *
*      Erstelle und versende Kursbestaetigungen                               *
*                                                               v. $v     *
*******************************************************************************
EOM
}
############################################################################
# Sub Logeintrag schreiben
############################################################################
sub DoLog {
	my $LogText = shift;
	my ($sekunden, $minuten, $stunden, $monatstag, $monat, $jahr, $wochentag, $jahrestag, $sommerzeit) = localtime(time);
	$jahr = $jahr + 1900;
	$monat+=1;
	$jahrestag+=1;
	$monat = $monat < 10 ? $monat = "0".$monat : $monat;
	$monatstag = $monatstag < 10 ? $monatstag = "0".$monatstag : $monatstag;
#	open(FILE_OUT, ">>E:/LogFiles/Eventshop/".$jahr."/".$jahr.$monat.$monatstag."-Kurs.log") || die "can't open: $!";
#		print FILE_OUT myTimer()." - ".$LogText."\n";
#	close(FILE_OUT);
}
