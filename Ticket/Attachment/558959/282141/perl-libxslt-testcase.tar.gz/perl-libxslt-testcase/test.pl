#!/usr/bin/perl

use XML::LibXML;
use XML::LibXSLT;

my $parser = XML::LibXML->new();
my $xslt = XML::LibXSLT->new();
my $stylesheet = $xslt->parse_stylesheet_file('test.xsl');
my $result;

print "test 1\n";
$result = $stylesheet->transform_file('test.xml');
print $stylesheet->output_string($result);

print "\ntest 2, parse an unrelated XML doc\n";
$parser->parse_file('unrelated.xml');
$result = $stylesheet->transform_file('test.xml');
print $stylesheet->output_string($result);

print "\ntest 3, parse another doc with keep_blanks(0)\n";
$parser->keep_blanks(0);
$parser->parse_file('unrelated.xml');
$result = $stylesheet->transform_file('test.xml');
print $stylesheet->output_string($result);

