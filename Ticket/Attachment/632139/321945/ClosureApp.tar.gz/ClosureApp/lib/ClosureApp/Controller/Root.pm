package ClosureApp::Controller::Root;

use Moose;

use namespace::autoclean;
BEGIN {
    extends 'Catalyst::Controller';
    with 'Catalyst::Component::ContextClosure';
}
__PACKAGE__->config->{namespace} = '';

sub auto : Private {
    my ( $self, $c ) = @_;
    $c->stash(
        closure => $self->make_context_closure(sub {
            $c->res->body('OK');
        }, $c),
    );
}
sub index :Path :Args(0) {
    my ( $self, $c ) = @_;

    # Hello World
    $c->response->body( $c->stash->{closure}->() );
}
1;
