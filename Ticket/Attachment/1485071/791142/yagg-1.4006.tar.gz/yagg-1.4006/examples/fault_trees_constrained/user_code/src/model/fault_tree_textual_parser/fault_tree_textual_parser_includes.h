#ifndef FAULT_TREE_TEXTUAL_PARSER_INCLUDES_H
#define FAULT_TREE_TEXTUAL_PARSER_INCLUDES_H

#include "basic_types/natural.h"
#include "basic_types/integer.h"
#include "fault_tree/fault_tree.h"

#endif // FAULT_TREE_TEXTUAL_PARSER_INCLUDES_H
