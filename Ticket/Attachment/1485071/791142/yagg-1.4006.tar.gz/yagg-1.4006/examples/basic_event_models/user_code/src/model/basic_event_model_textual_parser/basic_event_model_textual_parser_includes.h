#ifndef BASIC_EVENT_MODEL_PARSER_INCLUDES_H
#define BASIC_EVENT_MODEL_PARSER_INCLUDES_H

#include "basic_types/natural.h"
#include "basic_types/real.h"

#include <string>

using namespace std;

#endif // BASIC_EVENT_MODEL_PARSER_INCLUDES_H
