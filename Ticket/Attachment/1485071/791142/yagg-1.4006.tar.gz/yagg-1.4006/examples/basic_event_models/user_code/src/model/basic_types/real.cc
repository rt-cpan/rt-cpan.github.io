#include "basic_types/real.h"

const double Real::EPSILON = 1E-14;
