#!/usr/bin/perl -l

use MyPerl::Project::Template;
use MyPerl::Project;

print "project = ".($project = MyPerl::Project->new(pk => 1));
print "template = ".($template = $project->Template);
