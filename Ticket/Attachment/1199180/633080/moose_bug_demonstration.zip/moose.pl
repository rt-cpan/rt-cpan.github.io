#!/usr/bin/perl

use MyMoose::Project::Template;
use MyMoose::Project;

print "project = ".($project = MyMoose::Project->new(pk => 1));
print "template = ".($template = $project->Template);
