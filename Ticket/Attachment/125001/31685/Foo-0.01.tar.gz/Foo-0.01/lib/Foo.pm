package Foo;
our $VERSION = '0.01';
require XSLoader;
XSLoader::load('Foo', $VERSION);
1;
