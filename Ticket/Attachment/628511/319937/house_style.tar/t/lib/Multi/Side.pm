package Multi::Main;

=head2 three_sub

Three subroutine.

=cut

sub three_sub { "sub 3" }

=head2 four_sub

Four subroutine.

=cut

sub four_sub { "sub 4" }

1;
