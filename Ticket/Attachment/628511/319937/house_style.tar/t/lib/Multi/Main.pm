package Multi::Main;

use Multi::Side;

=head2 one_sub

One subroutine.

=cut

sub one_sub { "sub 1" }

=head2 two_sub

Two subroutine.

=cut

sub two_sub { "sub 2" }

1;
