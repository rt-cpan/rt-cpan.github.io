#!perl

package AL_Base;

use AutoLoader qw(AUTOLOAD);

sub new {
  my $class = shift;
  return bless({}, $class);
}

sub A_static {
  my __PACKAGE__ $this = shift;
  return "from A_static";
}

1;

