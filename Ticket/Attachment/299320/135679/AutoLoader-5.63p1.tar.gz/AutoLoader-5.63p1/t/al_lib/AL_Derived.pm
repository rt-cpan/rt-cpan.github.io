#!perl

package AL_Derived;

use AutoLoader qw(AUTOLOAD);
use base qw(AL_Base);

sub B_static {
  my __PACKAGE__ $this = shift;
  return "from B_static, " . $this->A_static;
}

1;

