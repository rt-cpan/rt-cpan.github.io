#!/usr/bin/perl -w

use strict;

use HTML::Template;


sub opentemplate {
    my $filename = shift;
    return  HTML::Template->new(
    filename=>"/tmp/test/templates/".$filename,    
    loop_context_vars=>1,
    die_on_bad_params=>0,
    global_vars=>1,
    cache=>1,
    case_sensitive => 0
    );
};

print "H:T version is: ".$HTML::Template::VERSION."\n\n";
    
opentemplate("work.tmpl") && print "work.tmpl - OK\n";
opentemplate("wrong_but_work.tmpl") && print "wrong_but_work.tmpl - OK\n";


eval { opentemplate("dontwork1.tmpl"); } or print "dontwork1.tmpl - error: ".$@."\n";
eval { opentemplate("dontwork2.tmpl"); } or print "dontwork1.tmpl - error: ".$@."\n";

