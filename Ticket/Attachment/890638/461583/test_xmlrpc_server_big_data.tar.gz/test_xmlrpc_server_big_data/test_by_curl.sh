http_proxy='' curl -d @"test_xmlrpc_server_big_data.xml" http://127.0.0.1:9002
