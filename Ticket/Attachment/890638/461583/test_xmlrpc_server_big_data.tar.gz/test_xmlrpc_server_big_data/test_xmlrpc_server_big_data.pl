#! /usr/bin/perl

use strict;
use warnings;
use RPC::XML::Server;

my $srv = RPC::XML::Server->new(port => 9002);

$srv->add_method({
name => 'test',
signature => [ 'string' ],
code => \&mysub
});

$srv->server_loop();

exit;

sub mysub {
    my ($server) = @_;

    my $in_file = "./test.bin";


    open  my $IN, '<', $in_file
        or die  "$0 : failed to open input file $in_file : $!\n";

    binmode $IN;

    local $/ = '';
    my $context = '';
    my $buf;

    while ( read($IN, $buf, 8 * 2**10) ) {
        $context .= $buf;
    }

    close  $IN
        or warn "$0 : failed to close input file $in_file : $!\n";


    my $bindata = new RPC::XML::base64($context);

    return $bindata;
}


