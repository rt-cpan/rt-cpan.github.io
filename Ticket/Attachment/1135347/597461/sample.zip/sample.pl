package Sample::WSDLService;

use strict;
use utf8;
use warnings;

use POSIX qw(strftime);
use String::Random qw(random_string);
use Digest::SHA qw(sha1);
use MIME::Base64 qw(encode_base64);
use XML::LibXML;
use Data::Dumper;

use XML::Compile::WSDL11;
use XML::Compile::SOAP11;
use XML::Compile::SOAP::WSS;
use XML::Compile::Transport::SOAPHTTP;
use XML::Compile::WSS::Util qw(:wss11 :utp11);

our $VERSION = '1.0.3';

sub _auth {
	my $self = shift;
	#warn __PACKAGE__, "::_auth($self->{url})\n";
	my $security     = XML::Compile::SOAP::WSS->new(
		version => '1.1',
		schema  => $self->{wsdl}
	);
	my $schema       = $security->schema;

	my $pwtype       = $schema->findName('wsse:Password');
	my $untype       = $schema->findName('wsse:UsernameToken');
	my $noncetype    = $schema->findName('wsse:Nonce');
	my $createdtype  = $schema->findName('wsu:Created');

	my $created      = strftime("%FT%TZ", gmtime);
	my $nonce        = random_string('s' x 20);
	my $nonce_encoded= encode_base64($nonce, '');
	my $digest       = encode_base64(sha1( $nonce . $created . $self->{password} ), '');

	my $doc          = XML::LibXML::Document->new('1.0', 'utf-8');

	my $pwnode       = $schema->writer($pwtype, include_namespaces => 0)->($doc, { _ => $digest, Type => UTP11_PDIGEST });
	my $noncenode    = $schema->writer($noncetype, include_namespaces => 0)->($doc, { _ => $nonce_encoded, EncodingType => "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary" });
	my $creatednode  = $schema->writer($createdtype, include_namespaces => 0)->($doc, { _ => $created });
	my $token        = $schema->writer($untype, include_namespaces => 1)->($doc, { wsse_Username => $self->{username}, $pwtype => $pwnode, $noncetype => $noncenode, $createdtype => $creatednode });

	return { $untype => $token };
}
sub load_xml {
	my $self     = shift;
	my $location = shift;

	return XML::LibXML->load_xml(
		location => $location
	);
}
sub new {
	my $class = shift;
	my $self = {
		base_url => undef,
		wsdl_url => undef,
		username => undef,
		password => undef,
		ua	 => undef,
		timeout  => 10,
	};

	while (my($name, $value) = splice(@_, 0, 2)) {
		$self->{$name} = $value if (exists $self->{$name});
	}

	bless($self, $class);

	my @urls = @{ $self->{wsdl_url} };
	while (my $url = shift(@urls)) {
		my $xml = eval { $self->load_xml($url) };
		if ($@) {
			die __PACKAGE__, "->new (load_xml): $@\n";
		}
		if ($self->{wsdl}) {
			$self->{wsdl}->addWSDL( $xml );
		}
		else {
			$self->{wsdl} = XML::Compile::WSDL11->new( $xml );
		}
	}

	$self->{url} = join(
		"/",
		$self->{base_url},
		(split("/", $self->{wsdl}->endPoint))[-1]
	);
	$self->{transport} = XML::Compile::Transport::SOAPHTTP->new(
		address    => $self->{url},
		user_agent => $self->{ua},
		timeout    => $self->{timeout},
	);
	$self->{auth} = $self->_auth;
	$self->{call} = {};

	return $self;
}

package Sample::Service;

use LWP;

sub new {
	my $class = shift;
	my $self = {
		url      => undef,
		username => undef,
		password => undef,
		timeout  => 30,
	};

	while (my($name, $value) = splice(@_,0,2)) {
		$self->{$name} = $value if (exists $self->{$name});
	}

	bless($self, $class);

	$self->{ua} = LWP::UserAgent->new(
		parse_head => 0,
		keep_alive => 1,
		ssl_opts => {
			verify_hostname => 0,
			keep_alive => 1
		},
		timeout => $self->{timeout},
	);
	$self->{order} = Sample::WSDLService->new(
		base_url => $self->{url},
		wsdl_url => [qw(OrderingService.wsdl OrderingService.2.wsdl)],
		username => $self->{username},
		password => $self->{password},
		ua       => $self->{ua},
		timeout  => $self->{timeout},
	);
	warn "OrderingService - ok\n";
	$self->{venue} = Sample::WSDLService->new(
		base_url => $self->{url},
		wsdl_url => [qw(VenueService.wsdl VenueService.2.wsdl)],
		username => $self->{username},
		password => $self->{password},
		ua       => $self->{ua},
		timeout  => $self->{timeout},
	);
	warn "VenueService - ok\n";
	$self->{scheme} = Sample::WSDLService->new(
		base_url => $self->{url},
		wsdl_url => [qw(SchemeService.wsdl SchemeService.2.wsdl)],
		username => $self->{username},
		password => $self->{password},
		ua       => $self->{ua},
		timeout  => $self->{timeout},
	);
	warn "SchemeService - ok\n";
	return $self;
}

package main;

my $service = Sample::Service->new(
	url      => 'http://172.27.36.211:8080/kassirgate',
	username => 'agtest1',
	password => 'e16b2ab8d12314bf4efbd6203906ea6c',
);

print "OK\n";

