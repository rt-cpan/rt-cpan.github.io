#!/usr/bin/perl

use strict;
use warnings;
use Artifactory::Client;
use autodie;
use Data::Printer;
use Data::Dumper;
use File::Spec;
use AgentP;

my $ua   = AgentP->new();
my $args = {
    artifactory => 'http://localhost',
    port        => 8081,
    repository  => 'dave-snapshot-local',
    ua          => $ua
};

p $ua;
my $client = Artifactory::Client->new($args);
p $client;
my $path = '/test/foo';    # path on artifactory

my $properties = {
    one => ['two'],
    baz => ['three'],
};

my $file = File::Spec->rel2abs(__FILE__);
p $file;
my $filesize = -s $file;
p $filesize;

my $resp = $client->deploy_artifact( path => $path, properties => $properties, file => $file );
print Dumper($resp);

$resp = $client->get('http://localhost:8081/artifactory/dave-snapshot-local/test/foo');
p $resp;
