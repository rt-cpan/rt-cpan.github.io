#! perl -w
use strict;
use XML::Twig;

sub hex_dump($) {
    my $input = shift;
    my $result = "Input: <\n$input\n>\nHex dump:\n";
    while ($input =~ /./gs) {
        $result .= "<$&>" . sprintf "%02X ", ord($&);
    }
    return $result;
}

my $filename = shift;
open my $file_out, '>:raw', "$filename.out.xml";

# parse the UTF-8-encoded XML
my $twig= XML::Twig->new(
    keep_encoding => 0  # the default; '1' fixes the issue
);
$twig->parsefile($filename);

# dump element text
print $file_out "Element text dump:\n";
foreach my $elt ($twig->get_xpath('//seg')) {
    print $file_out ($elt->text), "\n";
}

# dump twig
print $file_out "\n\nTwig print:\n";
$twig->print($file_out);

# read the XML file with the UTF-8 discipline, and pass it through to the ':raw' output file
open my $file_in, '<:utf8', $filename or die $!;
undef $/; print $file_out "\n\nPass-through:\n", <$file_in>;
