package simplified;

use strict;

use filter;

sub simple ( $var1, $var2 ) {}

simple (<<EOT, '')
 A simple test.
EOT

1;
