#!/usr/bin/perl -w

use strict;

use Text::Balanced 'extract_multiple';

open S, "<simplified.pm" or die "Can't: $!\n";
my $t = do { local $/ = undef ; <S> };
close S;

for ( extract_multiple($t) ) {
  print "test: $_\n";
}
