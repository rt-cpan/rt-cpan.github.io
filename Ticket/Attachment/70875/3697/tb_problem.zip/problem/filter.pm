package filter;

$DB::single = 1;

use strict;

use Filter::Simple;

# Works fine
#FILTER { s/TESTFOR/REPLACEWITH/g };

# Fails with error 'substr outside of string'
FILTER_ONLY code => sub { s/TESTFOR/REPLACEWITH/g };

1;
