#!/usr/bin/perl -w

use strict;

use simplified;
