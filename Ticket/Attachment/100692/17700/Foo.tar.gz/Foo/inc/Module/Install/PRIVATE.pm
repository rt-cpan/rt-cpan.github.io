package Module::Install::PRIVATE;
use strict;
use warnings;
use Module::Install::Base;
BEGIN { our @ISA = qw(Module::Install::Base) }
sub get_private_obj { return shift }
sub greeting { print "Hello, world.\n" }
1;
