package Module::Install::PRIVATE::Foo;
use strict;
use warnings;
use Module::Install::PRIVATE;
BEGIN { our @ISA = qw(Module::Install::PRIVATE) }
sub get_private_foo_obj { return shift }
1;
