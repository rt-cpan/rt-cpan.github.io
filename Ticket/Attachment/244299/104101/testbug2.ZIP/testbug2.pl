#!/usr/bin/perl

use strict;
use OpenOffice::OODoc;
use Data::Dumper;

my $filepath = $ARGV[0];
my $sheets = $ARGV[1];

if (!defined $filepath || !defined $sheets) {
	die "Usage: $0 <path_to_OpenDocumentSpreadsheet> <sheet1>[,<sheet2[,sheet3[...]]]";
}

my $doc = ooDocument(file => $filepath);
my @sheets = split /,/,$sheets;

foreach my $sheet (@sheets) {
	my @rows = $doc->getTableRows($sheet);			# loading the sheet
	foreach my $row (@rows) {
		my @row;
	        my @cells = $doc->getRowCells($row);            # getting cells from the row
		foreach my $cell (@cells) {
			my $value = $doc->cellValue($cell);     # getting the value of the cell
			push @row, $value;
		}
		warn join ' ',@row;
	}
}

