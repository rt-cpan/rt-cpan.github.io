#! perl

package MyApp::Cmd::doit;

use Moo;
use MooX qw[ Options ];

use Data::Dumper;

option value => (
    short   => 'v',
    is      => 'ro',
    format  => 's',
);

sub execute {

    my $self = shift;
    print Dumper $self->value;
}

1;
