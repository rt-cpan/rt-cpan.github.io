package My::Module;

use strict;
use warnings;

# ABSTRACT: some abstract here

# VERSION


1;

=pod

=pkgroup A Group

=pkg DataFlow 1.111620 OMG this version number!

=pkg Moose 2.0010 For some reason

=cut

