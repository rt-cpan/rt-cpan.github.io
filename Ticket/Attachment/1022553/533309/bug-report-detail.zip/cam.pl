    use CAM::PDF;
    my $pdf = CAM::PDF->new($ARGV[0]);
    
#    my $page1 =  $pdf->getPageContent(1);
  #  [ ... mess with page ... ]
#    $pdf->setPageContent(1, $page1);
  #  [ ... create some new content ... ]
  #  $pdf->appendPageContent(1, $newcontent);
    
#    my $anotherpdf = CAM::PDF->new('test2.pdf');
#    $pdf->appendPDF($anotherpdf);
    
    my @prefs = $pdf->getPrefs();
   $prefs[$CAM::PDF::PREF_OPASS] = 'mypassword';
    $pdf->setPrefs(@prefs);
    
    $pdf->cleanoutput('out1.pdf');
#    print $pdf->toPDF();
