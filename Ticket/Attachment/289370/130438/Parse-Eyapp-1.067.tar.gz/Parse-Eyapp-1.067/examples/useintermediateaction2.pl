#!/usr/bin/perl -w

use intermediateaction2;

$parser = new intermediateaction2();
$parser->Run;
