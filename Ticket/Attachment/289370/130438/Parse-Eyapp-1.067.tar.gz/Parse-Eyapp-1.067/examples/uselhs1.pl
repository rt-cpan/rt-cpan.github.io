#!/usr/bin/perl -w
use Lhs1;

$parser = new Lhs1();
$parser->Run;
