#!/usr/bin/perl -w
use strict;
use TSwithtreetransformations3;
use Parse::Eyapp::Treeregexp;

my $parser = TSwithtreetransformations3->new();
$parser->Run;
