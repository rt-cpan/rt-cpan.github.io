#!/usr/bin/perl -w
use strict;
use TSwithtreetransformations;
use Parse::Eyapp::Treeregexp;

my $parser = TSwithtreetransformations->new();
$parser->Run;
