#!/usr/bin/perl -w
use strict;
use TSPostfix2;

my $parser = new TSPostfix2();
$parser->Run;
