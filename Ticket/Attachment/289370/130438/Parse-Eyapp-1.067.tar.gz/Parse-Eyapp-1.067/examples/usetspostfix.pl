#!/usr/bin/perl -w
use strict;
use TSPostfix;

my $parser = new TSPostfix();
$parser->Run;
