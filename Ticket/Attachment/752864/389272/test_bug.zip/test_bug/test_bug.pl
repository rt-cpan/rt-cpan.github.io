#!/usr/bin/env perl
if (unpack("h*", pack("s", 1)) =~ /01/) {
	print "Your system is big endian.\n";
}
if (unpack("h*", pack("s", 1)) =~ /^1/) {
	print "Your system is little endian.\n";
}
open(FF, '<', 'test.bin') or die 'Could not open file';
read(FF, $fourteen, 4);
print unpack('N', $fourteen), "\n";
read(FF, $fourteen, 4);
print unpack('n', $fourteen), "\n";
close(FF);
exit(0);
