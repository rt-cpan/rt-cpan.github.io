# by Frank Poggio
# 11 Aug 2011
# estimates the material consumption and run time of an STL file submitted to modelman
use Win32::File;
use strict;
use File::DosGlob 'glob';
use Math::ConvexHull qw/convex_hull/;
use Math::Vector::Real;
opendir(WORKDIR,"D:/convex-hull-testing/rounding/temp");
my @stls = grep(/(stl)$/,readdir(WORKDIR));
closedir(WORKDIR);
chdir("D:/convex-hull-testing/rounding/temp") || die "Couldn't chdir to D:/convex-hull-testing";
foreach(@stls){
  my ($badfile,$buf,$facets,$j,%no_duplicates,$p,@y_hull,@z_hull,@x_pts,@y_pts,@z_pts);
  print "processing $_\n";
  ## THIS SECTION FINDS THE EXTENTS AND BUILDS X,Y, Z ARRAYS ##  
  open(STLFILE,$_) || die "Couldn't open $_";
  $p = 0;
  (-B $_) || die "File is not in a binary STL format";
  binmode(STLFILE); #switches to binary input mode
  read (STLFILE,$buf,80); #each binary STL file has an 80 byte text header.
  $buf =~ /(solid)|(STL)/ || die "$_ is not a proper STL file\n";
  # check header solid is in files from SW and ProE, STL is in files from Inventor
  read (STLFILE, $buf, 4); #this 4 byte section is the number of triangles
  $facets = unpack ("V", $buf); #read # of facets and discard
  # arguments for unpack are (TEMPLATE, LIST)
  # the V is a long in VAX little endian order 
  while ($p < $facets){   
    read (STLFILE, $buf, 8); #read normal vector x & y component and discard
    read (STLFILE, $buf, 4); #read normal vector z component 
    my $z_normal = unpack ("f", $buf); #convert to binary to text format
    for (my $j =0; $j <= 2; $j++){
      read (STLFILE, $buf, 4); #read vertex 1 x coordinate
      $x_pts[$p+$j] = unpack ("f", $buf);  #convert to binary to text format   
      # the f is for single precision floating point numbers 
      read (STLFILE, $buf, 4); #read vertex 1 y coordinate
      $y_pts[$p+$j] = unpack ("f", $buf);
      read (STLFILE, $buf, 4); #read vertex 1 z coordinate
      $z_pts[$p+$j] = unpack ("f", $buf);
    }    
    read (STLFILE, $buf, 2);
    $p = $p + 3;
  }
  my @y_hull_pts = @y_pts; my @z_hull_pts = @z_pts;
 # for ($p = 0; $p <= @x_pts;$p++){
  # NUMBERS NEED TO BE TRIMMED SO THE CONVEX HULL MODULE WORKS
  # TRIMMING THEM TO 2 DECIMAL PLACES DID NOT ALWAYS WORK. THIS SACRIFICES
  # SOME ACCURACY BUT IS NECESSARY.  
 # if (abs($y_hull_pts[$p]) < 1){$y_hull_pts[$p] = sprintf("%.2f",$y_hull_pts[$p])}
 # if (abs($z_hull_pts[$p]) < 1){$z_hull_pts[$p] = sprintf("%.2f",$z_hull_pts[$p])}
 # if (abs($y_hull_pts[$p]) > 1){
 #   if (abs($y_hull_pts[$p]) < 10){$y_hull_pts[$p] = sprintf("%.1f",$y_hull_pts[$p])}
 # }
 # if (abs($z_hull_pts[$p]) > 1){
 #   if (abs($z_hull_pts[$p]) < 10){$z_hull_pts[$p] = sprintf("%.1f",$z_hull_pts[$p])}
 # }  
 # if (abs($y_hull_pts[$p]) > 10){$y_hull_pts[$p] = sprintf("%.0f",$y_hull_pts[$p])}
 # if (abs($z_hull_pts[$p]) > 10){$z_hull_pts[$p] = sprintf("%.0f",$z_hull_pts[$p])}
#} 
  ## CONVEX HULLS CANNOT WORK WITH DUPLICATE POINTS ##
  for (my $i = 0; $i <= @y_hull_pts;$i++){ # hash keys will not have duplicates 
    $no_duplicates{"$y_hull_pts[$i] $z_hull_pts[$i]"} = 1; # the values are arbitrary
  }
  my $i = 0;
  my (@points2D);
  foreach (keys %no_duplicates){
    if (/\d/){# for an unknown reason it is putting a in blank key
      # this will mess up the convex hull module 
      (my $point1,my $point2) = split; # split keys into flat arrays 
      $points2D[$i] = [$point1,$point2,]; # then build 2D array from flat arrays  
      $i++;
    }
  }
  s/\.stl//;
  open(OUTFILE,">$_-yz.txt");
  foreach (@points2D){print OUTFILE "@$_[0]\t@$_[1]\n";}
  my $conv_pnts  = convex_hull(\@points2D);
  # convex hull module receives an array reference as an argument and reports 
  # back an array reference
 # foreach (@$conv_pnts){print OUTFILE "@$_[0]\t@$_[1]\n";}
  close(OUTFILE);
}
#chdir("C:/Program Files (x86)/Microsoft Office/Office14");
#system("excel.exe d:/perl-scripts/$ARGV[0].txt");




