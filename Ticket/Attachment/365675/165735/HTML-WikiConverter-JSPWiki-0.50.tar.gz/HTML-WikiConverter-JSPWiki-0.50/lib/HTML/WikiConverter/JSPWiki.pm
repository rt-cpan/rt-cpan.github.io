package HTML::WikiConverter::JSPWiki;

use warnings;
use strict;

use base 'HTML::WikiConverter';

our $VERSION = '0.50';

=head1 NAME

HTML::WikiConverter::JSPWiki - Convert HTML to JSPWiki markup

=head1 SYNOPSIS

  use HTML::WikiConverter;
  my $wc = new HTML::WikiConverter( dialect => 'JSPWiki' );
  print $wc->html2wiki( $html );

=head1 DESCRIPTION

This module contains rules for converting HTML into JSPWiki
markup. See L<HTML::WikiConverter> for additional usage details.

=cut

sub rules {
  my %rules = (
    b => { start => '__', end => '__' },
    strong => { alias => 'b' },
    i => { start => '\'\'', end => '\'\'' },
    em => { alias => 'i' },
    strike => { start => '--', end => '--' },
    blockquote => { start => '{{{', end => '}}}' },

    p => { block => 1, trim => 'both', line_format => 'multi' },
    hr => { replace => "\n\n----\n\n" },
    br => { replace => '\\\\' },

    a => { replace => \&_link },
    img => { replace => \&_img },
    blockquote => { start => '{quote}', end => '{quote}' },

    ul => { line_format => 'multi', block => 1 },
    ol => { alias => 'ul' },
    li => { start => \&_li_start, trim => 'leading' },

    table => { start => "", end => '', block => 1, line_format => 'multi' },
    tr => { line_format => 'single', end => "\n" },
    td => { start => "|", end => \&_td_end },
    th => { start => '||', end => \&_td_end },

    h1 => { start => '!!!', block => 1 },
    h2 => { start => '!!', block => 1 },
    h3 => { start => '!', block => 1 },
    h4 => { start => '!', block => 1 },
    h5 => { start => '!', block => 1 },
    h6 => { start => '!', block => 1 },
  );


  return \%rules;
}

sub _td_end {
  my( $self, $node, $rules ) = @_;
  my @right_cells = grep { $_->tag && $_->tag =~ /th|td/ } $node->right;
#  return ' | ' if @right_cells;
  return '';
}

sub _link {
  my( $self, $node, $rules ) = @_;
  my $url = $node->attr('href') || '';
  my $text = $self->get_elem_contents($node) || '';

  if( my $title = $self->get_wiki_page($url) ) {
    $text =~ s~\+~ ~g;
    return "[$text]" if lc $text eq lc $title;
    return "[$text|$title]";
  } else {
    return "[$url]" if $url eq $text;
    return "[$text|$url]";
  }
}

sub _img {
  my( $self, $node, $rules ) = @_;
  my $src = $node->attr('src') || '';
  my $align = $node->attr('align') || '';
  my $height = $node->attr('height') || '';
  my $width = $node->attr('width') || '';
  my $alt = $node->attr('alt') || '';
  my $border = $node->attr('border') || '';
  my $style = $node->attr('style') || '';
  my $title = $node->attr('title') || '';
  my $tag = '';
	
	$tag .= " src='" . $src . "'" if ! ($src eq '');
	$tag .= " align='" . $align . "'" if ! ($align eq '');
	$tag .= " height='" . $height . "'" if ! ($height eq '');
	$tag .= " width='" . $width . "'" if ! ($width eq '');
	$tag .= " alt='" . $alt . "'" if ! ($alt eq '');
	$tag .= " border='" . $border . "'" if ! ($border eq '');
	$tag .= " style='" . $style . "'" if ! ($style eq '');
	$tag .= " caption='" . $title . "'" if ! ($title eq '');

	return "[{Image" . $tag . "}]";

}

sub _li_start {
  my( $self, $node, $rules ) = @_;

  my $bullet = $node->parent->tag eq 'ol' ? '#' : '*';
  my @parents = $node->look_up( _tag => qr/ul|ol/ );
  my $prefix = ( $bullet ) x @parents;
#  $prefix .= '.' if $node->parent->tag eq 'ol';

  return "\n$prefix ";
}

=head1 AUTHOR

Stephen Brandon, based on SnipSnap dialect (C) 2006 David J. Iberri, C<< <diberri at cpan.org> >>

=head1 BUGS

Please report any bugs or feature requests to
C<bug-html-wikiconverter-snipsnap at rt.cpan.org>, or through the web
interface at
L<http://rt.cpan.org/NoAuth/ReportBug.html?Queue=HTML-WikiConverter-JSPWiki>.
I will be notified, and then you'll automatically be notified of
progress on your bug as I make changes.

=head1 SUPPORT

You can find documentation for this module with the perldoc command.

    perldoc HTML::WikiConverter::JSPWiki

You can also look for information at:

=over 4

=item * AnnoCPAN: Annotated CPAN documentation

L<http://annocpan.org/dist/HTML-WikiConverter-JSPWiki>

=item * CPAN Ratings

L<http://cpanratings.perl.org/d/HTML-WikiConverter-JSPWiki>

=item * RT: CPAN's request tracker

L<http://rt.cpan.org/NoAuth/Bugs.html?Dist=HTML-WikiConverter-JSPWiki>

=item * Search CPAN

L<http://search.cpan.org/dist/HTML-WikiConverter-JSPWiki>

=back

=head1 COPYRIGHT & LICENSE

Copyright (C) 2007 Stephen Brandon, based on SnipSnap dialect (C) 2006 David J. Iberri 

This program is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

1;
