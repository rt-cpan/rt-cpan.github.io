package OIOExampleClass;

use strict;

use Object::InsideOut;

my @test_field :Std_All(test_field);

1;
