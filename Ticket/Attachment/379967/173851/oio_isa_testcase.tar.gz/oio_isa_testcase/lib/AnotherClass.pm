package AnotherClass;

use strict;

sub new {
    return bless {}, shift;
}

1;
