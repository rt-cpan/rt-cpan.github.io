#!/usr/bin/env perl

use strict;

use FindBin;

use lib "$FindBin::Bin/lib";

use OIOExampleClass;
use AnotherClass;

my $another_class = AnotherClass->new();

if (UNIVERSAL::isa($another_class, undef)
        || UNIVERSAL::isa($another_class, 'AnotherClass') ) {
    print "ok - test passes\n";
}
else {
    print "not ok - test fails\n";
}
