#!/usr/bin/perl

use strict;
use warnings;

use Time::Local;
use POSIX 'strftime';


my $startDate = date2epoch('3-11-14');
my $endDate   = date2epoch('11-11-14');
my @weekday={"Monday","tuesday","wednusday","thursday","friday"};
my @weekend={"satarday","sunday"};
my @alldays={"Mon","tue","wed","thu","fri","sat","sun"};
my @options={"@weekday","@weekend","@alldays"};
my $currDate = $startDate;
while ($currDate <= $endDate) {
  print strftime "%Y-%m-%d\n", localtime($currDate);
my  $myDate=get_day($startDate);                    #func call..
    if(@options == @weekday)
my    $currDate += 24 * 60 * 60;
}

sub date2epoch {
  my ($d, $m, $y) = split /-/, shift;

  return timelocal(0, 0, 12, $d, $m - 1, $y - 1900);
}
sub get_day {
my $date = shift || return(0);
my ($mon,$mday,$year) = $date =~ /(\d+)-(\d+)-(\d+)/;
my $epochtime = timelocal_nocheck(0, 0, 0, $mday, $mon-1, $year);
my $day = (localtime($epochtime))[6];
return $weekday[$day];
}

