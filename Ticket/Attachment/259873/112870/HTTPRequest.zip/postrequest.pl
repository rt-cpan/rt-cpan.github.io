#!d:/perl/bin/perl -w

use strict;
use HTTP::Request::Common qw(POST);
require LWP::Parallel::UserAgent;
use Config::IniFiles;
use Data::Dumper;
my $ret;
my $timeout=10;
my $h_ref;
my $URL = 'http://mass3:99';
my $MaxRequests=1;
my $reqCount=1;
my $SleepTime=0.5;
my $fileload=0;
my $req;

sub ReadParam
{
	my $Numparams=1;
	my $count=1;
	my $parm="";
	my $val="";
	my $type="";
	print "Reading paramters ...\n";
	my $file=$ARGV[0] || "postrequest.conf";
	my $cfg = new Config::IniFiles( -file => $file );
	$Numparams=$cfg->val( 'General', 'Numparameters' ) || die "Parameter \"Numparameters\" in Section [General] wrong.\n";
	$URL=$cfg->val( 'General', 'URL' ) || die "Parameter URL in section [General] wrong.\n";
	$MaxRequests=$cfg->val( 'General', 'MaxRequests' ) if $cfg->val( 'General', 'MaxRequests' );
	$SleepTime=$cfg->val( 'General', 'SleepTime' ) if $cfg->val( 'General', 'SleepTime' );
	$timeout=$cfg->val( 'General', 'UATimeOut' ) if $cfg->val( 'General', 'UATimeOut' );
	while($count<=$Numparams)
	{
		$parm="Param$count";
		$val="Value$count";
		$type="Type$count";
		$h_ref->{ $cfg->val('Parameters', $parm) }=$cfg->val('Values', $val);
		if($cfg->val('Types', $type)) {
			if($cfg->val('Types', $type) eq "FILE")  { $fileload=1; }
		}
		$count++;
	}
}

# reading configuration file
&ReadParam();

#my $request=HTTP::Request->new(POST, $URL, 
my $ua = LWP::Parallel::UserAgent->new();

print "The Timeout: $timeout\n";
$ua->wait ( $timeout );
$ua->max_hosts(5);
$ua->max_req(5);

print "Makeing $MaxRequests requests ...\n";
	
while ($reqCount<=$MaxRequests) {
	my $file="temp$reqCount.log";
	my $o_file="temp$reqCount.dat";
	$req = POST ($URL, [ $h_ref ]);
	#if($fileload) { $req->content_type(); }
	print "Posting request ...\n";
	$ret = $ua->request($req );
	print "Writing Logfile $file ...\n";
	open(FH, ">$file");
	open(OFH, ">$o_file");
	binmode(OFH);
	print FH "Request: " . $ret->as_string . "\n";
	print OFH $ret->content . "\n";
	print FH "Content Type: " . $req->content_type() . "\n";
	print "Closing Logfile...\n";
	close FH;
	close OFH;
	$reqCount++;
	# Sleeping
	print "Sleeping $SleepTime secound(s) ...\n";
	select(undef,undef,undef, $SleepTime);
}




