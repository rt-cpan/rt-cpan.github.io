package Local::Bug;

use base 'Devel::Declare::MethodInstaller::Simple';

sub import {
    my $class = shift;
    my $caller = caller;

    $class->install_methodhandler(
        into            => $caller,
        name            => 'test',
    );
}

sub get_linestr {
    my $self = shift;
    my $line = Devel::Declare::get_linestr();

    use Devel::Peek;
    print Dump $line;

    return $line;
}

1;
