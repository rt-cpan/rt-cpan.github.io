#!/bin/sh

for DEF in '' -DIDLE_TXN;
  do 
    cat <<SQL | /opt/firebird/bin/isql -q
CREATE DATABASE "/tmp/test.gdb" user "sysdba" password "masterke"; 
quit;
SQL

    sudo gstat -h /tmp/test.gdb |egrep -i 'trans|active'

    gcc -Wall -I/opt/firebird/examples $DEF -o test single.c  -lfbclient

    for ((i=0; i<10; i++)); do ./test; done

    sudo gstat -h /tmp/test.gdb |egrep -i 'trans|active'

    cat <<SQL | /opt/firebird/bin/isql /tmp/test.gdb
DROP DATABASE;
SQL

    echo =================================================
  done

