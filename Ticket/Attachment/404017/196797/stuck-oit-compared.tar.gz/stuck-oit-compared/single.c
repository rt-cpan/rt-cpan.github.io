#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ibase.h>
#include <include/example.h>

int main (int argc, char** argv)
{
    long                    a_constant = 0;
    short                   flag0 = 0;
    isc_stmt_handle         stmt = NULL;                /* statement handle */
    isc_db_handle           DB = NULL;                  /* database handle */
    isc_tr_handle           trans = NULL;               /* transaction handle */
#ifdef IDLE_TXN
    isc_tr_handle           D__trans = NULL;            /* idle transaction handle */
#endif
    ISC_STATUS_ARRAY        status;                     /* status vector */
    XSQLDA  *               sqlda;

    long                    fetch_stat;
    char                    dbname[128];
    char                    *sel_str = "SELECT 1 FROM RDB$DATABASE";

    strcpy(dbname, "/tmp/test.gdb");

    if (isc_attach_database(status, 0, dbname, &DB, 0, NULL))
    {
        ERREXIT(status, 1)
    }

    /* start transaction */
    if (isc_start_transaction(status, &trans, 1, &DB, 0, NULL))
    {
        ERREXIT(status, 1)
    }
#ifdef IDLE_TXN
    if (isc_start_transaction(status, &D__trans, 1, &DB, 0, NULL))
    {
        ERREXIT(status, 1)
    }
#endif
    
    /* Allocate an output SQLDA. */
    sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(1));
    sqlda->sqln = 1;
    sqlda->sqld = 1;
    sqlda->version = SQLDA_VERSION1;

    /* Allocate a statement. */
    if (isc_dsql_allocate_statement(status, &DB, &stmt))
    {
        ERREXIT(status, 1)
    }
    
    /* Prepare the statement. */
    if (isc_dsql_prepare(status, &trans, &stmt, 0, sel_str, 1, sqlda))
    {
        ERREXIT(status, 1)
    }
    
    /*
     *  Although all three selected columns are of type varchar, the
     *  third field's type is changed and printed as type TEXT.
     */
    sqlda->sqlvar[0].sqldata = (char*) &a_constant;
    sqlda->sqlvar[0].sqltype = SQL_LONG + 1;
    sqlda->sqlvar[0].sqlind  = &flag0;

    /* Execute the statement. */
    if (isc_dsql_execute(status, &trans, &stmt, 1, NULL))
    {
        ERREXIT(status, 1)
    }
            
    /*
     *    Fetch and print the records.
     *    Status is 100 after the last row is fetched.
     */
    while ((fetch_stat = isc_dsql_fetch(status, &stmt, 1, sqlda)) == 0)
    {
        printf("SELECT result: %ld\n", a_constant);
    }

    if (fetch_stat != 100L)
    {
        ERREXIT(status, 1)
    }

    /* Free statement handle. */
    if (isc_dsql_free_statement(status, &stmt, DSQL_close))
    {
        ERREXIT(status, 1)
    }

    if (isc_commit_transaction(status, &trans))
    {
        ERREXIT(status, 1)
    }
#ifdef IDLE_TXN
    if (isc_commit_transaction(status, &D__trans))
    {
        ERREXIT(status, 1)
    }
#endif
    if (isc_detach_database(status, &DB))
    {
        ERREXIT(status, 1)
    }

    free( sqlda);

    return 0;
}            

