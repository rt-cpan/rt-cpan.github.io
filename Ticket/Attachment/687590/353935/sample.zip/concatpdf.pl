#!/usr/bin/perl -w

package main;

use warnings;
use strict;
use CAM::PDF;

my $first = 1;
my ($doc, $out);

foreach my $file (@ARGV)
{
	if ($first) {
		$first = 0;
		$out = CAM::PDF->new($file, "", "", { 	prompt_for_password => 0, fault_tolerant => 1 }) || die "$CAM::PDF::errstr\n";
		next;
	}
	$doc = CAM::PDF->new($file, "", "", { 	prompt_for_password => 0, fault_tolerant => 1 }) || die "$CAM::PDF::errstr\n";
	$out->appendPDF($doc);
	undef $doc;
}


$out->cleanoutput();
