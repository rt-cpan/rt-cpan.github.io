package Foo;
our VERSION='1.234567';
use v5.006_000;
1
__END__

