package Bar;
our VERSION='1.234567';
no v5.006_000;
1
__END__

