package Foo;
our VERSION='1.234567';
use 5.888888;
1
__END__

