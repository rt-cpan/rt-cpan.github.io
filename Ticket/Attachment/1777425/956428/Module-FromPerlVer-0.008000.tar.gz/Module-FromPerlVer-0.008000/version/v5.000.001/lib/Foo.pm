package Foo;
our VERSION='1.234567';
use v5.000.001;
1
__END__

