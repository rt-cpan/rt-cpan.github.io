package Bar;
our VERSION='1.234567';
no v5.8.8;
1
__END__

