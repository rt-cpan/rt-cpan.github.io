package Bar;
our VERSION='1.234567';
no v5.6.0;
1
__END__

