package Foo;
our VERSION='1.234567';
use v5.6.0;
1
__END__

