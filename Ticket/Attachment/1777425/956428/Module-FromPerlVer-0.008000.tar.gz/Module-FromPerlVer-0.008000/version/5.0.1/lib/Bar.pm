package Bar;
our VERSION='1.234567';
no 5.0.1;
1
__END__

