package Foo;
our VERSION='1.234567';
use 5.0.1;
1
__END__

