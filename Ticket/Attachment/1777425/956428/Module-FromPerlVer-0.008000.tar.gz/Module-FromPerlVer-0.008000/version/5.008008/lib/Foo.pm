package Foo;
our VERSION='1.234567';
use 5.008008;
1
__END__

