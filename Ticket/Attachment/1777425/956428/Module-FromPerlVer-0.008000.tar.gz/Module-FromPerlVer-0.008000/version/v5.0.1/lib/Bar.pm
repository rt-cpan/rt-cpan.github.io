package Bar;
our VERSION='1.234567';
no v5.0.1;
1
__END__

