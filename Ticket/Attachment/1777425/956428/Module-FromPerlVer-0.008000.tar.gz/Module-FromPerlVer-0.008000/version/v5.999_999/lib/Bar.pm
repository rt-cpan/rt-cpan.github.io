package Bar;
our VERSION='1.234567';
no v5.999_999;
1
__END__

