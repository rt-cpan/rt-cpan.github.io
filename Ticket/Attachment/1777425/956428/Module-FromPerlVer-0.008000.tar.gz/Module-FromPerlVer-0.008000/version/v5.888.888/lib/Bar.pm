package Bar;
our VERSION='1.234567';
no v5.888.888;
1
__END__

