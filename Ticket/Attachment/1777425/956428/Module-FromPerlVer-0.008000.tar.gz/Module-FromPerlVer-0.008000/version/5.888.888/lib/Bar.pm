package Bar;
our VERSION='1.234567';
no 5.888.888;
1
__END__

