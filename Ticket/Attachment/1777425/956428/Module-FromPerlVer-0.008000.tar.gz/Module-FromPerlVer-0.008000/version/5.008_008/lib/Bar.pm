package Bar;
our VERSION='1.234567';
no 5.008_008;
1
__END__

