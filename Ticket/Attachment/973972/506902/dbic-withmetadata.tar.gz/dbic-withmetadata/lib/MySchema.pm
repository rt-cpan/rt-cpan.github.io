package MySchema;

use Moose;

BEGIN { extends 'DBIx::Class::Schema'; }

__PACKAGE__->load_namespaces(
    default_resultset_class => 'ResultSetBase',
);

1;
