package MySchema::Result::Foo;

use Moose;

BEGIN { extends 'DBIx::Class'; }

__PACKAGE__->load_components("Core");

__PACKAGE__->table("foo");
__PACKAGE__->add_columns('id', 'name');

1;
