package MySchema::ResultSetBase;

use Moose;

BEGIN { extends 'DBIx::Class::ResultSet::WithMetaData'; }

1;
