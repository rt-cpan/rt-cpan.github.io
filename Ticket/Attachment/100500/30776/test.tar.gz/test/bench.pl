#!/usr/bin/perl

use strict;
use warnings;

use IO::File;
use Midcom::Plucene::RequestProcessor;

my $i;
eval {
	for ($i = 0; $i < 50000; $i++)
	{
		my $in = IO::File->new('query.xml', "r");
		my $out = IO::File->new('/dev/null', "w");
	
		# my $proc = Midcom::Plucene::RequestProcessor->new($in, $out);
		# $proc->Process();

		# undef $proc;
		# undef $in;
		# undef $out;
	}
};
if ($@)
{
	print "Caught a runtime error:\n\n";
	print "Loops done: $i\n\n";
	print $@;
	sleep 60;
}
