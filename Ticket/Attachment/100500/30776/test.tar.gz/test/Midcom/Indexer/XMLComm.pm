# MidCOM Indexer XML Communication Protocol driver
# 
# $Id: XMLComm.pm,v 1.4 2005/01/31 17:34:04 torben Exp $

package Midcom::Indexer::XMLComm;

use strict;
use warnings;
use XML::LibXML;
use XML::Writer;
use Midcom::Plucene::QueryRequest;
use Midcom::Plucene::DeleteRequest;
use Midcom::Plucene::IndexRequest;

=head1 NAME

Midcom::Indexer::XMLComm - XML Communication Protocol driver

=head1 SYNOPSIS

TBD

=head1 DESCRIPTION

This class allows for reading and writing MRFC 0014 compatible XML streams.
It is independant from a search engine.

Built on XML::Simple and XML::Writer it is not really complex, and should work
reasonably well with most data.

It will read requests and write responses, not vice-versa.

=head1 METHODS

TBD

=cut

#############
# Constructor

sub new 
{
	my $class = shift;
	my $self = {};

	$self->{_requests} = [];
	$self->{_indexname} = undef;

	$self->{_parser} = XML::LibXML->new();
	$self->{_parser}->validation(0);
	$self->{_parser}->keep_blanks(0);

	$self->{_in} = shift;
	$self->{_out} = shift;
	$self->{_processor} = shift;

	$self->{_output} = new XML::Writer(
		OUTPUT => $self->{_out},
		DATA_MODE => 1,
		DATA_INDENT => 1
	);

	$self->{_document} = undef;

	bless ($self, $class);
	return $self;
}

###########
# Accessors

sub output
{
	my $self = shift;
	return $self->{_output};
}

sub processor
{
	my $self = shift;
	return $self->{_processor};
}

sub indexName
{
	my $self = shift;
	return $self->{_indexname};
}

sub requests
{
	my $self = shift;
	return $self->{_requests};
}


# Parsed dem im ersten Argument �bergebenen XML-String und populiert die
# Requests Liste.
#
# Auth-Requests werden derzeit ignoriert.

sub ParseRequest
{
	my $self = shift;

	# Initialize output XML file
	
	$self->{_output}->xmlDecl('UTF-8');
	$self->{_output}->doctype('response', undef, 'xml-communication-response.dtd');
	$self->{_output}->startTag('response');

	
	# Parse input XML file
	
	$self->{_document} = $self->{_parser}->parse_fh($self->{_in});

	my $root = $self->{_document}->documentElement();
	$self->{_indexname} = $root->getAttribute('index');
	
	my @childs = $root->childNodes;
	foreach my $node (@childs)
	{
		# Check only nodes, skip all other stuff like comments
		if ($node->nodeType != 1)
		{
			next;
		}
		
		# Parse node type, relay to corresponding handler
		if ($node->nodeName eq 'query')
		{
			$self->_ParseQuery($node);
		}
		elsif ($node->nodeName eq 'index')
		{
			$self->_ParseIndex($node);
		}
		elsif ($node->nodeName eq 'delete')
		{
			$self->_ParseDelete($node);
		}
		elsif ($node->nodeName eq 'auth')
		{
			# We skip auth requests, as we do not support authentication for now
			# This should emit a warning later on
			print "AUTH ID " . $node->getAttribute('id') . " skipped.\n";
		}
		else
		{
			die ("The Request type $node ( " . $node->nodeName . ") is unknown to this handler.");
			# Should we throw an error here?
		}
	}


	# Finish output XML file
	
	$self->{_output}->endTag('response');
	$self->{_output}->end();
}



# Query-Requestnder

sub _ParseQuery
{
	my ($self, $node) = @_;
	
	my $node_query = $node->firstChild;
	my $node_filter = $node_query->nextSibling();
	my $request = Midcom::Plucene::QueryRequest->new($self);

	$request->id($node->getAttribute('id'));
	$request->queryString($node_query->textContent);

	if ($node_filter)
	{
		# The DTD gurantees that node_filter does only have one child.
		# At the moment we support only datefilters
		# We just have to check for an empty filter node, which cannot
		# be caught by the dtd.

		my $node_filter_spec = $node_filter->firstChild;
		if ($node_filter_spec->hasChildNodes() && $node_filter_spec->nodeName eq 'datefilter')
		{
			$request->dateFilterField($node_filter_spec->getAttribute('field'));

			# Ok, we might now have either one of from and to, or both.
			# If we have both, the order is fixed to from,to by the DTD.
			
			my $child1 = $node_filter_spec->firstChild;
			my $child2 = $child1->nextSibling();
			
			if ($child1->nodeName eq 'from')
			{
				$request->dateFilterFrom($child1->textContent);
				if ($child2)
				{
					$request->dateFilterTo($child2->textContent);
				}
			}
			else
			{
				$request->dateFilterTo($child1->textContent);
			}
		}
	}
	
	# $request->dump;
	$request->execute();
	push @{$self->{_requests}}, $request;
}


sub _ParseDelete
{
	my ($self, $node) = @_;
	
	my $request = Midcom::Plucene::DeleteRequest->new($self);

	$request->id($node->getAttribute('id'));
	$request->documentID($node->getAttribute('documentid'));

	# $request->dump;
	$request->execute();
	push @{$self->{_requests}}, $request;
}


sub _ParseIndex
{
	my ($self, $node) = @_;

	
	my $request_id = $node->getAttribute('id');
	my $document_node = $node->firstChild;

	while ($document_node)
	{
		my $request = Midcom::Plucene::IndexRequest->new($self);
		$request->id($request_id);
		$request->documentID($document_node->getAttribute('id'));

		# Parse the documents
		
		my $field = $document_node->firstChild;
		while ($field)
		{
			my $type = $field->nodeName;
			my $name = $field->getAttribute('name');
			my $content = $field->textContent;

			if ($type eq 'date') 
			{ 
				$request->addDate($field->getAttribute('name'), $field->textContent); 
			}
			elsif ($type eq 'keyword') 
			{ 
				$request->addKeyword($field->getAttribute('name'), $field->textContent); 
			}
			elsif ($type eq 'unindexed') 
			{ 
				$request->addUnIndexed($field->getAttribute('name'), $field->textContent); 
			}
			elsif ($type eq 'unstored') 
			{ 
				$request->addUnStored($field->getAttribute('name'), $field->textContent); 
			}
			elsif ($type eq 'text') 
			{ 
				$request->addText($field->getAttribute('name'), $field->textContent); 
			}
			
			$field = $field->nextSibling();
		}
		
		# $request->dump;
		$request->execute();
		push @{$self->{_requests}}, $request;

		# Go to the next document
		$document_node = $document_node->nextSibling();
	}
}






1;
