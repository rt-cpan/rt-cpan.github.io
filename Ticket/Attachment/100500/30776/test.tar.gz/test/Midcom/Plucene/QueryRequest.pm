# MidCOM Plucene Indexer Interface: Query Request
#
# $Id: QueryRequest.pm,v 1.3 2005/01/31 17:34:04 torben Exp $

package Midcom::Plucene::QueryRequest;

use strict;
use warnings;

use Midcom::Plucene::BaseRequest;
use Plucene::Document::DateSerializer;
use Plucene::Search::DateFilter;


@Midcom::Plucene::QueryRequest::ISA = ('Midcom::Plucene::BaseRequest');


=head1 NAME

Midcom::Plucene::QueryRequest - Query Request interface

=head1 SYNOPSIS

TBD

=head1 DESCRIPTION

This class serves as an interface between tha XML Comm driver, which creates
it, and the actual Plucene Backend.

Upon execution it requires a QueryParser object, which is alread prepared. The 
resulting data is then automatically added to the XML Comm Driver whose reference
will be passed during construction.

=head1 METHODS

TBD

=cut


#############
# Constructor
#
# Stores a reference to the XML Comm Driver.

sub new
{
	my $class = shift;
	my $self = $class->SUPER::new(@_);

	$self->type('query');
	$self->{_queryString} = undef;
	$self->{_dateFilterField} = undef;
	$self->{_dateFilterFrom} = undef;
	$self->{_dateFilterTo} = undef;

	bless ($self, $class);
	return $self;
}


###########
# Accessors

sub queryString
{
	my $self = shift;
	if (@_) { $self->{_queryString} = shift; }
	return $self->{_queryString};
}

sub dateFilterField
{
	my $self = shift;
	if (@_) { $self->{_dateFilterField} = shift; }
	return $self->{_dateFilterField};
}

sub dateFilterFrom
{
	my $self = shift;
	if (@_) { $self->{_dateFilterFrom} = $self->mkDate(shift); }
	return $self->{_dateFilterFrom};
}

sub dateFilterTo
{
	my $self = shift;
	if (@_) { $self->{_dateFilterFrom} = $self->mkDate(shift); }
	return $self->{_dateFilterTo};
}


#################
# Execute Handler

# execute Plucnene::QueryParser $parser Plucene::Search::Searcher $searcher

sub execute
{
	my $self = shift;

	my $query = $self->{_processor}->queryParser->parse($self->{_queryString});
	my $hits;
	
	if ($self->{_dateFilterFrom} || $self->{_dateFilterTo})
	{
		my $filter_config = {};
		
		$filter_config->{field} = $self->{_dateFilterField};
		if ($self->{_dateFilterFrom})
		{
			$filter_config->{from} = $self->{_dateFilterFrom};
		}
		if ($self->{_dateFilterFrom})
		{
			$filter_config->{from} = $self->{_dateFilterFrom};
		}
		
		$hits = $self->{_processor}->indexSearcher->search(
			$query, 
			Plucene::Search::DateFilter->new($filter_config)
		);
	}	
	else
	{
		$hits = $self->{_processor}->indexSearcher->search($query);
	}

	my $output = $self->{_XMLComm}->output;

	$output->startTag('resultset', 'id' => $self->id());
	
	# Build a sorted resultset (take the indices directly, order them, then go ahead)
	my @order = sort 
		{ 
			$hits->score($b) <=> $hits->score($a) 
		} 
		(0..($hits->length-1));
	
	foreach my $i (@order)
	{
		my $doc = $hits->doc($i);
		my $score = $hits->score($i);
		my $id = $doc->get('__RI')->string;

		$output->startTag('document',
			'id' => $id,
			'score' => $score);
		
		foreach my $field ($doc->fields)
		{
			$output->cdataElement('field', $field->string, 'name' => $field->name);
		}
		
		$output->endTag('document');
	}

	$output->endTag('resultset');
}


sub dump
{
	my $self = shift;
	$self->SUPER::dump();

	print "\tQueryString: " . $self->{_queryString} . "\n";
	if ($self->{_dateFilterField})
	{
		print "\tDate Filter Field: " . $self->{_dateFilterField} . "\n";
	}
	if ($self->{_dateFilterFrom})
	{
		print "\tDate Filter From: " . $self->{_dateFilterFrom}->strftime() . "\n";
	}
	if ($self->{_dateFilterTo})
	{
		print "\tDate Filter To: " . $self->{_dateFilterTo}->strftime(). "\n";
	}
}


1;
