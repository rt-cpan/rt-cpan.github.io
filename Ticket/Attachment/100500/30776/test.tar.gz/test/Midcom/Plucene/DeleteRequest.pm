# MidCOM Plucene Indexer Interface: Delete Request
#
# $Id: DeleteRequest.pm,v 1.3 2005/01/31 17:34:04 torben Exp $

package Midcom::Plucene::DeleteRequest;

use strict;
use warnings;

use Midcom::Plucene::BaseRequest;
use Plucene::Index::Term;


@Midcom::Plucene::DeleteRequest::ISA = ('Midcom::Plucene::BaseRequest');


=head1 NAME

Midcom::Plucene::DeleteRequest - Delete interface

=head1 SYNOPSIS

TBD

=head1 DESCRIPTION

This class serves as an interface between tha XML Comm driver, which creates
it, and the actual Plucene Backend.

Upon execution it requires a IndexReader object, which is alread prepared. 
Unless a critical error occures, on data is appended to the XMLReader.

=head1 METHODS

TBD

=cut


#############
# Constructor
#
# Stores a reference to the XML Comm Driver.

sub new
{
	my $class = shift;
	my $self = $class->SUPER::new(@_);
	
	$self->type('delete');
	$self->{_documentID} = undef;

	bless ($self, $class);
	return $self;
}

###########
# Accessors

sub documentID
{
	my $self = shift;
	if (@_) { $self->{_documentID} = shift; }
	return $self->{_documentID};
}


#################
# Execute Handler

# execute Plucene::Index::Reader $reader

sub execute
{
	my $self = shift;

	my $term = Plucene::Index::Term->new(
		{
			field => '__RI',
			text => $self->{_documentID}
		}
	);
	$self->{_processor}->indexReader->delete_term($term);
	
	# Tag the Writer object, so that it gets loaded from the request
	# processor. This is will optimize the database after completing
	# the current batch thus dropping all unused references to the
	# deleted documents. I hate it.
	$self->{_processor}->indexWriter();
}


sub dump
{
	my $self = shift;
	$self->SUPER::dump();
	print "\tDocument ID: " . $self->{_documentID} . "\n";
}


1;

