#!/usr/bin/perl

use strict;
use warnings;

use IO::Handle;
use Midcom::Plucene::RequestProcessor;

my $in = IO::Handle->new_from_fd(fileno(STDIN), "r");
my $out = IO::Handle->new_from_fd(fileno(STDOUT), "w");

my $proc = Midcom::Plucene::RequestProcessor->new($in, $out);

$proc->Process();
