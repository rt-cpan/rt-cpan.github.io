input => {
  title   => 'Correct News',
  content => 'This content should always be above 20 charters in length.',
  author  => 'mowens',
  created => '2007-11-09 20:23:12',
  edited  => '2007-11-09 20:23:12',
}
