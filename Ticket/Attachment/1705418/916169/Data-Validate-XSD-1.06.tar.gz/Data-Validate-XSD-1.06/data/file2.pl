input => {
  title   => 'Bad News which has a title which is way too long for this validation to work.',
  content => 'Too Short',
  editor  => [ 'token1', 'token2' ],
  created => '2008-11-09 20:23:12',
  edited  => [ '2007-11-09 20:23:12', '2007-11-09 20:23:12', '2007-11-09 20:23:12', '2007-11-09 20:23:12' ],
}
