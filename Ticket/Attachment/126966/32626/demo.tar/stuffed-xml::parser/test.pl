#!/usr/bin/perl

use XML::Parser;

my $xp = new XML::Parser(Handlers => { Start => \&start_handler,
				       Char  => \&char_handler,
                                       End   => \&end_handler,
				       },
			 );

if (! ($file=shift) ) {
    die "usage: $0 xmlfile\n";
}

$xp->parsefile($file);

sub start_handler {
  my $expat = shift;
  $expat->{'all_text'} = '';
}

sub char_handler {
  my $expat = shift;
  my $text = shift;
  $expat->{'all_text'} .= $text;
  print "char_handler was given '$text'\n" if ($text =~ /\S/);
  return undef;
}

sub end_handler {
  my $expat = shift;
  my $text=$expat->{'all_text'};
  print "Closing tag: " . $expat->recognized_string() . "\n";
  print "Character data inside tag: '$text'\n";
}
