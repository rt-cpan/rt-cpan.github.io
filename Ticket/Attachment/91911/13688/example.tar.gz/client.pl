#!/usr/bin/perl -w

use SOAP::Lite; 
use Data::Dumper;

  my %searchParms = (
    '!Table' => 'so_orderhead, co_custaddr_v',
    '!TabJoin' => 'so_orderhead LEFT JOIN co_custaddr_v USING (contact_id)',
    '!Order' => 'ordernr',
    '$where' => 'status = 100 AND ordernr NOT IN (SELECT ordernr FROM so_invoice)',
    '$max' => 20
  );

  my $example = new SOAP::Lite 
    ->uri ('DBIx')
    ->proxy('http://127.0.0.1:8080'); 
  print $example ->getData( \%searchParms )->result;
