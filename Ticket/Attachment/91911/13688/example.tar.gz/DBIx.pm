package DBIx;

use Data::Dumper;

  sub new {
    my $type = shift;
    my $self = {};
    return bless $self,$type;
  }

  sub getData {
    my $type = shift;
    my $sp = shift;
    my $data = Dumper($sp);
    return $data;
  }

1; 
