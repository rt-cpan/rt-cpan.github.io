#!/usr/bin/env perl

use strict;
use warnings;
use Spreadsheet::ParseExcel;

my $file = $ARGV[0];

print_usage() if !defined $file;

my $parser = Spreadsheet::ParseExcel->new(
    CellHandler => \&callback,
    NotSetCell  => 1
);
print "\nWill print out row_range() values every 100 cells.\nThe value should be 0 - 299 every time.\n\n";
$parser->Parse($file);
print "\n";

my $counter = 0;

sub callback {
    my ($workbook,$sheetIndex,$row,$col,$cell) = @_;
    
    my ($rowMin,$rowMax) = $workbook->Worksheet($sheetIndex)->row_range();
    
    if ($counter++ % 100 == 0) {
        print "Got row range: $rowMin - $rowMax\n";
    }
}

sub print_usage {
    print "\nUsage: $0 foo.xls\n\n";
    exit 1;
}