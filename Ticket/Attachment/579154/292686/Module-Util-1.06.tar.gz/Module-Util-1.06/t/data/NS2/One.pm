package NS2::One;

our $VERSION = 1;

# Dummy Module for namespace test

1;

