package middle;
{
   use Object::InsideOut qw( grand );

   use strict;
   use warnings;

}
1;
