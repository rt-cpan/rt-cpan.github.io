package grand;
{
   use Object::InsideOut;

   use strict;
   use warnings;

   my @field : Field : Arg(Mandatory => 1, Name => 'field')
     : Standard('field');
}
1;
