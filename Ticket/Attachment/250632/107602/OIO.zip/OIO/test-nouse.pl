#!/usr/bin/perl 
use strict;
use warnings;
use lib qw( . );
use Test::More 'no_plan';
use Test::NoWarnings;

use grand;
# use nephew;  # NOTE: COMMENTED OUT!!!

{
   print "working with 'middle'\n";
   my $class = 'middle';
   eval "require $class";
   my $n = do {
      no strict 'refs';
      $class->new(field => 'ciao');
   };
   my $m = middle->new(field => 'a tutti');
   is($n->get_field(), 'ciao', 'field value for $n');
   is($m->get_field(), 'a tutti', 'field value for $m');
}
   
print "\n";

{
   print "working with 'nephew'\n";
   my $class = 'nephew';
   eval "require $class";
   my $n = do {
      no strict 'refs';
      $class->new(field => 'ciao');
   };
   my $m = nephew->new(field => 'a tutti');
   is($n->get_field(), 'ciao', 'field value for $n');
   is($m->get_field(), 'a tutti', 'field value for $m');
}

