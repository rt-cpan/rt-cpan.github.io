package nephew;
{
   use Object::InsideOut qw( middle );

   use strict;
   use warnings;

}
1;
