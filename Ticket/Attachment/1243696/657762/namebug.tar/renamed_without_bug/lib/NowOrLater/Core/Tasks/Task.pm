package NowOrLater::Core::Tasks::Task;

use Moose;
use Modern::Perl;
use MooseX::Privacy;    #!!!<- read up on this!!!
use Moose::Util::TypeConstraints;
use namespace::autoclean;

extends 'NowOrLater::Core::Tasks::TaskState';

=head1 NAME

NowOrLater::Core::Tasks::Task

=head1 DESCRIPTION

Tasks - measurable and classifiable (possibly large) molecules of work

=head1 AUTHOR

Jim Cochrane

=head1 LICENSE

This library is free software. You can redistribute it and/or modify
it under the same terms as ??? [Perl itself??]  (TO-DO!!!: fix).

=cut

__PACKAGE__->meta->make_immutable;


# Create a new task (!!!This does not belong here.)
sub new_task {
    my ($self, $desc) = @_;
    say "desc: $desc";
    return 'new task';
}
1;
