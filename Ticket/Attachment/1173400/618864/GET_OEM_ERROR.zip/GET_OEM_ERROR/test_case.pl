use strict;
use warnings;

use SOAP::Lite;

my $filename = "server_response.xml";
open(my $fh, $filename) or die("Cannot opem $filename: $!");

my $xml;
{
    local $/ = undef;
    $xml = <$fh>;
}
close($fh);

my $som = SOAP::Deserializer->deserialize($xml);
$som->result();
