use strict;
use warnings;

use Data::Dumper;
use Carp;

use SOAP::Lite;

my $soap = SOAP::Lite->service('http://els-maxtest.englab.local/elspv/pvwsadmin.exe/wsdl/Ipvwsadmin');
$soap->envprefix('SOAP-ENV');
$soap->encprefix('SOAP-ENC');

my @res = $soap->StartSession('sidtxt', 'seckeytxt');
my $sid = $res[1];
$soap->Login($sid, '123456789', '987654321');

$soap->outputxml(1);
my $xml = $soap->GetOems($sid);
print $xml;

$soap->EndSession($sid);
