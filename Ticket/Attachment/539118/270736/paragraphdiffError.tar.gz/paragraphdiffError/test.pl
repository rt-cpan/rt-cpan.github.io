#!/usr/bin/perl -w

use strict;
use Text::ParagraphDiff;

print text_diff("oldfile","newfile");
