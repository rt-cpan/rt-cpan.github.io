package Animal::Cat;
use base 'Animal';
use strict;
use warnings;

sub new
{
	my $var;
	bless \$var, 'Animal::Cat';
}

sub speak
{
	print "Meoww! Meoww!\n";
}

1;