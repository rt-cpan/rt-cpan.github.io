package Animal::Dog;
use base 'Animal';
use strict;
use warnings;

sub new
{
	my $var;
	bless \$var, 'Animal::Dog';
}

sub speak
{
	print "Bark! Bark!\n";
}

1;