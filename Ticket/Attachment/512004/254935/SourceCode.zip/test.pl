use strict;
use warnings;

use Animal;
use Animal::Dog;
use Animal::Cat;

my $animal = new Animal();
my $dog = new Animal::Dog();
my $cat = new Animal::Cat();

$animal->speak();
$dog->speak();
$cat->speak();
