package Animal;
use strict;
use warnings;

use Animal::Dog;
use Animal::Cat;

sub new
{
	my $var;
	bless \$var, 'Animal';
}

sub speak
{
	print "Animal! Animal!\n";
}

1;