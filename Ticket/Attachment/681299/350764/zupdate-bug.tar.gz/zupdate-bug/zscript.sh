#! /bin/sh

cat >ztable <<-HERE
	column1|column2
	H|19
	H|10
	H|21
	KK|1
	KK|2
	KK|13
	MMM|25
	MMM|26
	MMM|15
HERE

cp -p ztable ztable.0

echo ./zupdate.pl KK XXXX
./zupdate.pl KK XXXX
cp -p ztable ztable.1
echo =============== Three rows should have had column1 updated from KK to XXXX =================
diff ztable.[01]

echo ./zupdate.pl XXXX KK
./zupdate.pl XXXX KK
cp -p ztable ztable.2
diff ztable.[12]

echo =============== There should be no diff between initial and final data  =================
diff ztable.[02]

exit 0
