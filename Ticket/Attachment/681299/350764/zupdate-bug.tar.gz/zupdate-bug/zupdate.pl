#! /usr/bin/perl -w
use strict;
use DBI;

if( @ARGV != 2) {
	my $usage="Usage: zupdate.pl <from_column1> <to_column1>";
	die "$usage - Incorrect no of args,";
}
my ($oldcolumn1,$newcolumn1) = @ARGV;

my $dbi_connect_string = "DBI:CSV:f_dir=.;csv_quote_char=;csv_eol=\n;csv_sep_char=|";

my $dbh = DBI->connect($dbi_connect_string)
	or die "Cannot connect: ".$DBI::errstr;

my $sth_update = $dbh->prepare(
	'update ztable set column1=? where column1=?'
) or die "Cannot prepare update: ".$DBI::errstr;

my $rows = $sth_update->execute($newcolumn1,$oldcolumn1)
	or die 'Could not update ztable';
printf("%d rows updated from column1 %s to %s\n",
	$rows,$oldcolumn1,$newcolumn1);

exit 0;
