package XML::Simple;
    
sub import { die };

1;
