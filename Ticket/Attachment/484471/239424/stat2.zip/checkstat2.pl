#!/usr/bin/perl

use strict;

use Win32::SharedFileOpen;
use Win32::UTCFileTime ();

my $file = 'perl-v.txt';

my @keys = qw( dev ino mode nlink uid gid rdev size 
	       atime mtime ctime blksize blocks );

fsopen(*FH, $file, 'r', SH_DENYRD) or warn "fsopen() failed";

my @statResult = stat( $file );
if ( !@statResult ) {
    warn "stat() failed: $!";
}
else {
    printf( "info            stat()\n");
    for (my $i=0; $i<@keys; $i++) {
        printf( "%8s: %12d\n",
	        $keys[$i],
	        $statResult[$i],
	      );
    }
}
    
my @statResult2 = Win32::UTCFileTime::stat( $file );
if ( !@statResult2 ) {
    warn "Win32::UTCFileTime::stat() failed: $Win32::UTCFileTime::ErrStr";
}
else {
    printf( "info        UTC-stat()\n");
    for (my $i=0; $i<@keys; $i++) {
        printf( "%8s: %12d\n",
	        $keys[$i],
	        $statResult2[$i],
	      );
    }
}
    
my @statResult3 = Win32::UTCFileTime::alt_stat( $file );
if ( !@statResult3 ) {
    warn "Win32::UTCFileTime::alt_stat() failed: $Win32::UTCFileTime::ErrStr";
}
else {
    printf( "info    UTC-alt_stat()\n");
    for (my $i=0; $i<@keys; $i++) {
        printf( "%8s: %12d\n",
	        $keys[$i],
	        $statResult3[$i],
	      );
    }
}

close *FH;
