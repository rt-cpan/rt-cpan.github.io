use strict;
use warnings;
package Godfather;
our $VERSION = '0.004';

1;
__DATA__
__[a]__
foo
