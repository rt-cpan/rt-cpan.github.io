use strict;
use warnings;
package Grandchild;
our $VERSION = '0.004';

use base 'Child';

1;
__DATA__
__[a]__
111
__[d]__
