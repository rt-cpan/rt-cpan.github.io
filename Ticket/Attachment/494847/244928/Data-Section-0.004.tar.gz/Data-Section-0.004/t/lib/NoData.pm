use strict;
use warnings;
package NoData;
our $VERSION = '0.004';

use Data::Section -setup;

1;
