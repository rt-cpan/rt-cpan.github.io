package Form1;

use strict;

use base qw(Rose::HTML::Form);

sub build_form {
    my $self = shift;

    $self->add_fields(
        foo1 => { label => 'Foo 1', type => 'text' },
        foo2 => { label => 'Foo 2', type => 'text' },
    );
}

1;
