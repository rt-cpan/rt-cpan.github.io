package Form2;

use strict;

use base qw(Rose::HTML::Form);

sub build_form {
    my $self = shift;

    $self->add_fields(
        bar1 => { label => 'Bar 1', type => 'text' },
        bar2 => { label => 'Bar 2', type => 'text' },
        bar3 => { label => 'Bar 3', type => 'radio group',
                  choices => [ 'Yes', 'No' ] },
    );
}

1;
