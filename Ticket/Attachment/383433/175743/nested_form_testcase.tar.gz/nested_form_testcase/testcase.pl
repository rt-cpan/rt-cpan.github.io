#!/usr/bin/env perl

use strict;

use FindBin;

use lib "$FindBin::Bin/lib";

use Form1;
use Form2;

my $form = Form1->new();

$form->add_form('subform' => Form2->new);

my $html;
foreach my $field ($form->fields) {
    $html .= $field->html_label . "\n";
    $html .= $field->html . "\n";
}

unless ($html =~ qr/name="subform.bar3"/) {
    print "not ok - radio button does't have parent form name\n";
}
else {
    print "ok - test passes\n";
}
