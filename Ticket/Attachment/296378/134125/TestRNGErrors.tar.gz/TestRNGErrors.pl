use strict;
use XML::LibXML;

my $schemafile = 'conf.rng';
my $instancefile = 'conf.xml';
my $instancefile_err1 = 'conf_err1.xml';
my $instancefile_err2 = 'conf_err2.xml';
my $instancefile_err3 = 'conf_err3.xml';
my $parser = XML::LibXML->new();
my $schemaDOM = $parser->parse_file($schemafile);
my $configDOM = $parser->parse_file($instancefile);

eval {
  my $rng = XML::LibXML::RelaxNG->new(DOM => $schemaDOM);
  $rng->validate($configDOM);
  print "Validated!\n\n";
};
if ($@) {
  warn "No error expected: $@\n\n";
}

$configDOM = $parser->parse_file($instancefile_err1);

eval {
  my $rng = XML::LibXML::RelaxNG->new(DOM => $schemaDOM);
  $rng->validate($configDOM);
  print "Validated!\n\n";
};
if ($@) {
  warn "err1: $@\n\n";
}

$configDOM = $parser->parse_file($instancefile_err2);

eval {
  my $rng = XML::LibXML::RelaxNG->new(DOM => $schemaDOM);
  $rng->validate($configDOM);
  print "Validated!\n\n";
};
if ($@) {
  warn "err2: $@\n\n";
}

$configDOM = $parser->parse_file($instancefile_err3);

eval {
  my $rng = XML::LibXML::RelaxNG->new(DOM => $schemaDOM);
  $rng->validate($configDOM);
  print "Validated!\n\n";
};
if ($@) {
  warn "err3: $@\n\n";
}

exit;
