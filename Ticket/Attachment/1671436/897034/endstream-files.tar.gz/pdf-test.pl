#!/usr/bin/perl

use strict;
use warnings;
use autodie;

#use lib 'lib';

use Text::PDF::File;
use Text::PDF::Page;
use Text::PDF::TTFont0;


my $pdf_filename = 'test.pdf';
my $arial_bold = '/usr/share/fonts/truetype/msttcorefonts/Arial_Bold.ttf';
my $text = 'ABCNOPSTWacdeghilmnoprstuwxyz012345679,@:/.';

my $pdf = Text::PDF::File->new;
my $root = Text::PDF::Pages->new($pdf);
$root->proc_set("PDF", "Text");
$root->bbox(0, 0, 595, 840);
my $page = Text::PDF::Page->new($pdf, $root);

my $font = Text::PDF::TTFont0->new($pdf, $arial_bold, 'F0', -subset => 1);
$root->add_font($font);

my $enc_text = $font->out_text($text);

$page->add("BT /F0 13 Tf 60 700 Td $enc_text Tj ET");

$pdf->out_file($pdf_filename);


