package t::ErrorParent;

???       # syntax error

sub parent_func {
    return 1;
}

1;
