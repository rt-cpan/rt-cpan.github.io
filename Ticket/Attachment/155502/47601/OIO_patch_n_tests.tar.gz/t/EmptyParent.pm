package t::EmptyParent;
1;
