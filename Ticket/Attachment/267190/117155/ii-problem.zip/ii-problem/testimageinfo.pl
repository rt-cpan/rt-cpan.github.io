#!/Usr/bin/perl -w
use strict;
use Image::Info qw(image_info dim);

my ($resolution, $pageWidth, $pageHeight, $datetime);

#get args
my $file = $ARGV[0];

#processing	
print"Start getting image infos ...\n";

my $info = image_info("$file");
 if (my $error = $info->{error}) {
	 die "Can't parse image info: $error\n";
 	}

$resolution = $info->{XResolution};
$resolution = eval $resolution;

($pageWidth, $pageHeight) = dim($info);

#print result
print"Imageinfos: $resolution, $pageWidth, $pageHeight\n";


# exit script
exit 0;

