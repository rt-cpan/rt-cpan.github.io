package A;
import A if 0;
1;
