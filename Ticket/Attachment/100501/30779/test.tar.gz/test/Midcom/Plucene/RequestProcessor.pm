# MidCOM Plucene Indexer Interface: Base Request Class
#
# $Id: RequestProcessor.pm,v 1.1 2005/01/31 17:34:04 torben Exp $

package Midcom::Plucene::RequestProcessor;

use strict;
use warnings;

use Midcom::Indexer::XMLComm;
use Plucene::Analysis::SimpleAnalyzer;
use Plucene::Index::Reader;
use Plucene::Index::Writer;
use Plucene::QueryParser;
use Plucene::Search::IndexSearcher;

# Constructor
#
# Stores a reference to the XML Comm Driver.

sub new
{
	my $class = shift;
	my $self = {};

	$self->{_in} = shift;
	$self->{_out} = shift;
	$self->{_xmlComm} = Midcom::Indexer::XMLComm->new($self->{_in}, $self->{_out}, $self);

	$self->{_indexReader} = undef;
	$self->{_indexWriter} = undef;
	$self->{_queryParser} = undef;
	$self->{_indexSearcher} = undef;

	bless ($self, $class);
	return $self;
}


###########
# Accessors

sub indexReader
{
	my $self = shift;
	if (! $self->{_indexReader})
	{
		$self->{_indexReader} = Plucene::Index::Reader->open($self->{_xmlComm}->indexName());
	}
	return $self->{_indexReader};
}

sub indexSearcher
{
	my $self = shift;
	if (! $self->{_indexSearcher})
	{
		$self->{_indexSearcher} = Plucene::Search::IndexSearcher->new($self->indexReader());
	}
	return $self->{_indexSearcher};
}

sub indexWriter
{
	my $self = shift;
	if (! $self->{_indexWriter})
	{
		my $create;
		if (-e $self->{_xmlComm}->indexName())
		{
			$create = 0;
		}
		else
		{
			$create = 1;
		}
		$self->{_indexWriter} = Plucene::Index::Writer->new(
			$self->{_xmlComm}->indexName(),
			Plucene::Analysis::SimpleAnalyzer->new(),
			$create
		);
	}
	return $self->{_indexWriter};
}

sub queryParser
{
	my $self = shift;
	if (! $self->{_queryParser})
	{
		$self->{_queryParser} = Plucene::QueryParser->new(
			{
				analyzer => Plucene::Analysis::SimpleAnalyzer->new(),
				default => 'content'
			}
		);
	}
	return $self->{_queryParser};
}


#################
# Execute Handler

sub Process 
{ 
	my $self = shift;
	$self->{_xmlComm}->ParseRequest();
}

sub close
{
	my $self = shift;
	if ($self->{_indexSearcher})
	{
		$self->{_indexSearcher}->close();
		$self->{_indexSearcher} = undef;
	}
	if ($self->{_indexReader})
	{
		$self->{_indexReader}->close();
		$self->{_indexReader} = undef;
	}
	if ($self->{_indexWriter})
	{
		$self->{_indexWriter}->optimize();
		$self->{_indexWriter} = undef;
	}
	if ($self->{_queryParser})
	{
		$self->{_queryParser} = undef;
	}
}




1;



