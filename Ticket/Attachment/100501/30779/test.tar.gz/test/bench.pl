#!/usr/bin/perl

use strict;
use warnings;

use IO::File;
use Midcom::Plucene::RequestProcessor;

my $i;
my $in;
my $out;
my $proc;

eval {
	$in = IO::File->new('query.xml', "r");
	$out = IO::File->new('/dev/null', "w");
	
	$proc = Midcom::Plucene::RequestProcessor->new($in, $out);

	for ($i = 0; $i < 5000; $i++)
	{
		$in->seek(0, SEEK_SET);
		$proc->Process();
	}
};
if ($@)
{
	print "Caught a runtime error:\n\n";
	print "Loops done: $i\n\n";
	print $@;
}
print "Closing the Request Processor.\n";
$proc->close();
