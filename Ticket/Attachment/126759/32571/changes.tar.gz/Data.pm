package WT::Email::Data;

use strict;
use warnings;
use Class::DBI::Loader;

Class::DBI::Loader->new(
        dsn       => "dbi:SQLite2:/tmp/wtemail.db",
        user      => "",
        password  => "",
        namespace => __PACKAGE__,
);

{
	package WT::Email::Data::TblSched;

	__PACKAGE__->set_sql(title => qq{
		SELECT
			DISTINCT(tblSched.title), tblSched.id
		FROM
			tblSched,tblStatus
		WHERE
			term = tblStatus.current_semester
		GROUP BY
			tblSched.title 
	});

	__PACKAGE__->set_sql(section => qq{
		SELECT
			DISTINCT(tblSched.section), tblSched.id
		FROM
			tblSched,tblStatus
		WHERE
			term = tblStatus.current_semester
		GROUP BY
			tblSched.section
	});
}

{
	package WT::Email::Data::TblEmail;

	__PACKAGE__->set_sql(email => qq{
		SELECT
			DISTINCT(tblClasses.riscid), tblEmail.email
		FROM
			tblClasses,tblEmail
		WHERE
			tblClasses.title=? AND tblClasses.section=? AND tblClasses.riscid = tblEmail.riscid
		GROUP BY
			tblClasses.riscid
		ORDER BY
			tblEmail.email
	});
}

1;
