package SimpleSchema;

use strict;
use warnings;

use base 'DBIx::Class::Schema';
use DateTime;

__PACKAGE__->load_namespaces( default_resultset_class => '+DBIx::Class::ResultSet::RecursiveUpdate' );



sub get_test_schema {
    my ( $dsn, $user, $pass ) = @_;
    $dsn ||= 'dbi:SQLite:dbname=t/var/simple.db';
    #warn "testing $dsn\n";
    my $schema = __PACKAGE__->connect( $dsn, $user, $pass, {} );
    my $deploy_attrs;
    $deploy_attrs->{add_drop_table} = 1 ;
    $schema->deploy( $deploy_attrs );
    $schema->populate('Parent', [
        [ qw/id/ ],
        [ '1' ],
        ]
    );
    $schema->populate('Related', [
        [ qw/id parent_id/ ],
        [ 1 , 1 ],
        [ 2 , 1 ],
        [ 3 , 1 ],
        ]
    );
    return $schema;
}
    
    
1;

