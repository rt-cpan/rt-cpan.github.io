package SimpleSchema::Result::Parent;


use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components('Core');
__PACKAGE__->table("parent");
__PACKAGE__->add_columns(
    "id" => {
        data_type => 'integer',
        is_auto_increment => 1,
    },
  );
__PACKAGE__->set_primary_key("id");
__PACKAGE__->has_many(
  "related",
  "Related",
  { "foreign.parent_id" => "self.id" },
);

1;

