package SimpleSchema::Result::Related;

use strict;
use warnings;

use base 'DBIx::Class';

__PACKAGE__->load_components("Core");
__PACKAGE__->table("related");
__PACKAGE__->add_columns(
  "id",
  { data_type => "INTEGER", is_auto_increment => 1,
      is_nullable => 0 },
  "parent_id",
  { data_type => "INTEGER", is_nullable => 1 },
);
__PACKAGE__->set_primary_key("id");

__PACKAGE__->belongs_to(
    'parent',
    'SimpleSchema::Result::Parent',
    'parent_id',
);


1;
