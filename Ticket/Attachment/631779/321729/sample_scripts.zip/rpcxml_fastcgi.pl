#!/usr/bin/perl -w

use warnings;
use strict;

use FCGI;
use RPC::XML::Server;

my $parser = RPC::XML::Parser->new();
my $server = RPC::XML::Server->new(no_http => 1);

### at this point add whatever methods you want to publish over XMLRPC
#$server->add_method(...);

my $http_headers = $server->response->headers_as_string("\r\n");

while(FCGI::accept() >= 0) {
  my $request = $parser->parse(<STDIN>);
  my $result;

  if ((ref $request) && ($request->isa('RPC::XML::request'))) {
    $result = $server->dispatch($request);
  }
  else {
    $result = RPC::XML::response->new(
        RPC::XML::fault->new(200, "XML parse error: $request")
    );
  }
  *STDOUT->syswrite($http_headers . "\r\n" . $result->as_string);
}
