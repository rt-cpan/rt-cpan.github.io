package Python::Serialise::Pickle::Mark;

=head1 NAME

Python::Serialise::Pickle::Mark - mark for internal use by Python::Serialise::Pickle

=head1 DESCRIPTION

The pickle bytecode engine uses mark objects to delimit variable length
lists on the stack. This class implements such an object - is contains
no information and is only recognizable by its type.

=cut


sub new {
	my $class = shift;
	my $self = {};
	bless $self, $class;
	return $self;
}

=head1 AUTHOR

Peter J. Holzer <hjp@hjp.at>


=head1 COPYRIGHT

(c) 2008 Peter J. Holzer

Distributed under the same terms as Perl itself.

This software is under no warranty and will probably ruin your life,
kill your friends, burn your house and bring about the apocalypse.

=cut

1;
