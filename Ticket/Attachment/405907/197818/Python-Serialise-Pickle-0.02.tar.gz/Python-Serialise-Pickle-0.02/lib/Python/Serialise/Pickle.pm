package Python::Serialise::Pickle;

use strict;
use warnings;

use Data::Dumper;
use IO::File;
use vars qw($VERSION);
use Python::Serialise::Pickle::Mark;
use Encode qw(decode);

$VERSION   = '0.02';



my %_set_handlers = (
	'NUMBER' => \&_set_num,
	'STRING' => \&_set_string,
	'HASH'   => \&_set_dict,
	'ARRAY'  => \&_set_list,
);


my %_get_handlers = ( 
		'I' => \&_do_int,
		'L' => \&_get_num,
		'F' => \&_get_num,
		'S' => \&_do_string,
		'N' => \&_do_none,
		'l' => \&_do_list,
		'd' => \&_do_dict,
		'c' => \&_do_global,
		'p' => \&_do_put,
		'(' => \&_do_mark,
		'}' => \&_do_empty_dict,
		'q' => \&_do_binput,
		'U' => \&_do_short_binstring,
		']' => \&_do_empty_list,
		'K' => \&_do_binint1,
		'M' => \&_do_binint2,
		'J' => \&_do_binint,
		'G' => \&_do_binfloat,
		'e' => \&_do_appends,
		'u' => \&_do_setitems,
		'h' => \&_do_binget,
		'X' => \&_do_binunicode,
		'.' => \&_do_stop,
		'a' => \&_do_append,
		's' => \&_do_setitem,
		'o' => \&_do_obj,
		't' => \&_do_tuple,
		'b' => \&_do_build,
);


=head1 NAME

Python::Serialise::Pickle - a file for reading and writing pickled Python files

=head1 SYNOPSIS


    use Python::Serialise::Pickle;

    my $pr = Python::Serialise::Pickle->new("file/for/reading");
    while (my $data = $pr->load()) {
          print Dumper $data;
    }

    my $pw = Python::Serialise::Pickle->new(">file/for/writing");
    
    $pw->dump(['a' 'list']);
    $pw->dump("a string");
    $pw->dump(42);
    $pw->dump({'a'=>'hash'});

    $pw->close();  

=head1 DESCRIPTION

Pickling is a method of serialising files in Python (another method, 
Marshalling, is also available).

This module is an attempt to write a pure Perl implementation of the algorithm.


=head1 METHODS

=head2 new <filename>

Open a file for reading or writing. Can take any arguments that C<IO::File> can.

=cut 

sub new {
	my $class = shift;
	my $file  = shift || die "You must pass a file\n";

	## FIXME error here
	my $fh    = IO::File->new($file) || die "Couldn't open file\n";
	my $self = { _fh => $fh, _stack => [], _memo => [] };

	return bless $self, $class;
	
}

=head2 load

Returns the next data structure from the pickle file or undef.

=cut

sub load {
	my $self = shift;
	$self->{_cur_id} = 0;

	print "LOAD\n";

	for(;;) {
		my $id = $self->_get_char();
		return undef if (!defined $id or $id eq "");

		my $sub = $_get_handlers{$id}    || die "We have no handler to deal with '$id'\n";
		my $result = $self->$sub();
		return $result if defined $result;
	}

}


=head2 dump <data structure>

Takes a ref to an array or a hash or a number or string and pickles it. 

Structures may be nested.

=cut

sub dump {
	my $self = shift;
	my $val  = shift;



	my $sub = $_set_handlers{$self->_type($val)};
	
	my $line = $self->$sub($val);
	$line .= ".";
	
	$self->_write($line);
	return $line;

}



sub _get_char
{
	my $self = shift;
	$self->{_fh}->read(my $data, 1);
	# print "C=$data\n";

	return $data;
}

sub _get_line {
	my $self = shift;
	my $line = "";

	while (1) {
		my $char = $self->_get_char();
		last unless defined $char;
		last if $char eq "\n";
		$line .= $char;
	}

	return $line;
}

sub _get_nchars {
	my $self = shift;
	my $count = shift;

	my $string = "";
	while ($count--) {
		my $char = $self->_get_char();
		die "premature EOF in _get_nchars" unless defined $char;
		$string .= $char;
	}
	return $string;
}


sub _write {
	my $self = shift;
	my $val  = shift;

	$self->{_fh}->write($val);
}


sub _get_num 
{
	my $self = shift;
	my %opts = @_;

	my $num  = $self->_get_line();

	unless (defined $opts{'ignore_end_marker'} && $opts{'ignore_end_marker'} == 1) {
		$self->_get_char();
	}


	return $num;	
}

sub _do_int
{
	# Push an integer or bool.
	# 
	# The argument is a newline-terminated decimal literal string. 
	# 
	# The intent may have been that this always fit in a short Python int,
	# but INT can be generated in pickles written on a 64-bit box that
	# require a Python long on a 32-bit box.  The difference between this
	# and LONG then is that INT skips a trailing 'L', and produces a short
	# int whenever possible.
	# 
	# Another difference is due to that, when bool was introduced as a
	# distinct type in 2.3, builtin names True and False were also added to
	# 2.2.2, mapping to ints 1 and 0.  For compatibility in both directions,
	# True gets pickled as INT + "I01\\n", and False as INT + "I00\\n".
	# Leading zeroes are never produced for a genuine integer.  The 2.3
	# (and later) unpicklers special-case these and return bool instead;
	# earlier unpicklers ignore the leading "0" and return the int.

	# perl doesn't distinguish between boolean and numeric, but "00"
	# is a "zero but true" value, so we need to handle this
	# specially to preserve its falseness.

	my $self = shift;

	my $num  = $self->_get_line();
	$num =~ s/L$//;
	$num = !1 if $num eq "00";
	$self->_push($num);
	return;
}



sub _get_uint1 
{
	my $self = shift;
	my %opts = @_;

	my $num  = $self->_get_char();

	defined($num) || die "EOF in uint1";

	$num = ord($num);

	return $num;	
}



sub _do_binint1 
{
	# Push a one-byte unsigned integer.
	# 
	# This is a space optimization for pickling very small non-negative ints, in range(256).

	my $self = shift;

	my $num  = $self->_get_uint1();

	$self->_push($num);
	return;
}



sub _get_uint2 {
	my $self = shift;
	my $bytes  = $self->_get_nchars(2);
	my $num = unpack("v", $bytes);
	return $num;
}



sub _do_binint2 
{
	# Push a two-byte unsigned integer.
	#
	# This is a space optimization for pickling small positive ints,
	# in range(256, 2**16).  Integers in range(256) can also be
	# pickled via BININT2, but BININT1 instead saves a byte.

	my $self = shift;

	my $num  = $self->_get_uint2();

	$self->_push($num);
	return;
}



sub _get_int4 {
	my $self = shift;
	my $bytes  = $self->_get_nchars(4);
	if (pack('s', 1) eq "\0\1") {
		$bytes = reverse($bytes);
	}
	my $num = unpack("l", $bytes);
	return $num;
}



sub _do_binint 
{
	# Push a four-byte signed integer. (little endian)
	# 
	# This handles the full range of Python (short) integers on a 32-bit
	# box, directly as binary bytes (1 for the opcode and 4 for the integer).
	# If the integer is non-negative and fits in 1 or 2 bytes, pickling via
	# BININT1 or BININT2 saves space.


	my $self = shift;

	my $num = $self->_get_int4;

	$self->_push($num);
	return;
}

sub _set_num 
{
	my $self = shift;
	my $num  = shift;
	my %opts = @_;


	my $return;
	if (int $num != $num) {
		$return =  "F$num\n";
	} else {
		$return = "I$num\n";
	}

	 $return .= $opts{'terminator'} if ($opts{'terminator'});

	return $return;
}



sub _do_string 
{
	# Push a Python string object.
	# 
	# The argument is a repr-style string, with bracketing quote characters,
	# and perhaps embedded escapes.  The argument extends until the next 
	# newline character.

	# I haven't found a documentation for "repr-style" strings, so
	# I'll go by the existing test cases which use only octal
	# escapes.
	
	my $self = shift;
	my $string = $self->_get_line();
	$string =~ s/^(['"])(.*)\1$/$2/;

	$string =~ s/\\([0-7]{1,3})/chr(oct($1))/eg;

	$self->_push($string);
	return;
}



sub _do_binfloat
{
	# Float stored in binary form, with 8 bytes of data.
	# 
	# This generally requires less than half the space of FLOAT encoding.
	# In general, BINFLOAT cannot be used to transport infinities, NaNs, or
	# minus zero, raises an exception if the exponent exceeds the range of
	# an IEEE-754 double, and retains no more than 53 bits of precision (if
	# there are more than that, "add a half and chop" rounding is used to
	# cut it back to 53 significant bits).

	my $self = shift;

	my $bytes = $self->_get_nchars(8);

	# the docs don't say explicitely, but FP seem to be big-endian.
	if (pack('s', 1) eq "\1\0") {
		$bytes = reverse($bytes);
	}
	my $float = unpack("d", $bytes);
	$self->_push($float);
	return;
}



sub _do_appends
{
	# Extend a list by a slice of stack objects.
	# 
	# Stack before:  ... pylist markobject stackslice
	# Stack after:   ... pylist+stackslice
	# 
	# although pylist is really extended in-place.

	# Assumption: Objects on the stack should be added to the list
	# in the same order they were pushed.

	my $self = shift;

	my $idx = $#{ $self->{_stack} };
	while ($idx >= 1 &&
	       ! eval { $self->{_stack}[$idx]->isa('Python::Serialise::Pickle::Mark') }) {
		$idx --;
	}
	die "no mark found in stack" if ($idx < 1);
	die "no arrayref found in stack" if ref $self->{_stack}[$idx-1] ne 'ARRAY';
	push @{ $self->{_stack}[$idx-1] }, splice(@{ $self->{_stack} }, $idx+1);
	pop @{ $self->{_stack} };
	return;
}



sub _do_append
{
	# Append an object to a list.
	# 
	# Stack before:  ... pylist anyobject
	# Stack after:   ... pylist+[anyobject]
	# 
	# although pylist is really extended in-place.

	my $self = shift;

	my $obj = pop @{ $self->{_stack} };
	die "no arrayref found in stack" if ref $self->{_stack}[-1] ne 'ARRAY';
	push @{ $self->{_stack}[-1] }, $obj;
	return;
}



sub _do_setitem
{
	# Add a key+value pair to an existing dict.
	# 
	# Stack before:  ... pydict key value
	# Stack after:   ... pydict
	# 
	# where pydict has been modified via pydict[key] = value.

	my $self = shift;

	my $value = pop @{ $self->{_stack} };
	my $key = pop @{ $self->{_stack} };
	die "no hashref found in stack" if ref $self->{_stack}[-1] ne 'HASH';
	$self->{_stack}[-1]{$key} = $value;
	return;
}



sub _do_setitems
{
	# Add an arbitrary number of key+value pairs to an existing dict.
	# 
	# The slice of the stack following the topmost markobject is taken as
	# an alternating sequence of keys and values, added to the dict
	# immediately under the topmost markobject.  Everything at and after the
	# topmost markobject is popped, leaving the mutated dict at the top
	# of the stack.
	# 
	# Stack before:  ... pydict markobject key_1 value_1 ... key_n value_n
	# Stack after:   ... pydict
	# 
	# where pydict has been modified via pydict[key_i] = value_i for i in
	# 1, 2, ..., n, and in that order.

	# Assumption: Objects on the stack should be added to the dict
	# in the same order they were pushed.

	my $self = shift;

	my $idx = $#{ $self->{_stack} };
	while ($idx >= 1 &&
	       ! eval { $self->{_stack}[$idx]->isa('Python::Serialise::Pickle::Mark') }) {
		$idx --;
	}
	die "no mark found in stack" if ($idx < 1);
	die "number of items after mark not even" if (($#{ $self->{_stack} } - $idx) % 2 != 0);
	die "no hashref found in stack" if ref $self->{_stack}[$idx-1] ne 'HASH';
	for (my $idx1 = $idx+1; $idx1 < $#{ $self->{_stack} }; $idx1 += 2) {
	    $self->{_stack}[$idx-1]{$self->{_stack}[$idx1]} = $self->{_stack}[$idx1+1];
	}
	splice(@{ $self->{_stack} }, $idx);
	return;
}



sub _set_string
{
	my $self = shift;
	my $string = shift;
	my %opts = @_;

	# escape some control chars
	$string =~ s{
                (.)
            }{
                (ord($1)<33 || ord($1)>126)?sprintf '\\%.3o',ord($1):$1
            }sxeg;
	
	my $return = "S";
	if ($string =~ /^'.+'$/) {
		$return .= "\"$string\"\n";
	} else {
		$return .= "'$string'\n";
	}
	


	$return .= $self->_set_id();
	$return .= $opts{'terminator'} if ($opts{'terminator'});


	return $return;

}



sub _set_id {
	my $self = shift;
	
	my $id = $self->{_cur_id}++;
	return "p$id\n";
}



sub _set_list {
	my $self = shift;
	my $list = shift;
	my %opts = @_;
	
	my $terminator = $opts{'terminator'} || "";

	my $return = "";
	$return   .= "(" unless ($opts{ignore_compound});
	$return   .= "l";
	$return   .= $self->_set_id();	

	$opts{'terminator'} = 'a';

	foreach my $val (@$list) {
		my $sub = $_set_handlers{$self->_type($val)};
                die "No handler to set '$val'" unless defined $sub;
                $return .= $self->$sub($val, %opts);

	}

	$return .= $terminator;
	return $return;

}



sub _do_mark {
        my $self = shift;
	$self->_push(Python::Serialise::Pickle::Mark->new);
	return;
}



sub _push {
	my $self = shift;
	my $arg = shift;
	push @{ $self->{_stack} }, $arg;
}



sub _do_empty_dict {
	my $self = shift;
	my %opts = @_;
	$self->_push({});
	return;
}



sub _do_empty_list {
	my $self = shift;
	my %opts = @_;
	$self->_push([]);
	return;
}



sub _set_dict 
{
	my $self = shift;
	my $hash  = shift;
        my %opts = @_;

	my $return = "";
        $return   .= "(";
        $return   .= "d";
        $return   .= $self->_set_id();
	

	$opts{'ignore_compound'}   = 0;
	$opts{'ignore_end_marker'} = 1;
	$opts{'terminator'}        = "";

	foreach my $key (keys %{$hash}) {
		my $val = $hash->{$key};
		
		my $keysub = $_set_handlers{$self->_type($key)};
                die "No handler for setting key '$key'" unless defined $keysub;
                $return .= $self->$keysub($key, %opts);

		my $valsub = $_set_handlers{$self->_type($val)};
                die "No handler for setting val '$val'" unless defined $valsub;
                $return .= $self->$valsub($val, %opts);
				

		$return .= "s";
	}	

	return $return;

}





sub _do_none {
	# Push None on the stack.
	my $self = shift;
	$self->_push(undef);
	return;

}



sub _do_global {
	# Push a global object (module.attr) on the stack.
	# 
	# Two newline-terminated strings follow the GLOBAL opcode.  The first is
	# taken as a module name, and the second as a class name.  The class
	# object module.class is pushed on the stack.  More accurately, the
	# object returned by self.find_class(module, class) is pushed on the
	# stack, so unpickling subclasses can override this form of lookup.

	# This almost certainly doesn't make much sense in perl, so
	# we'll just consume the two arguments and push undef on the
	# stack.

	my $self = shift;
	my $module = $self->_get_line();
	my $class = $self->_get_line();
	$self->_push(undef);
	return;
}



sub _do_obj {
	# Build a class instance.
	# 
	# This is the protocol 1 version of protocol 0's INST opcode, and is
	# very much like it.  The major difference is that the class object
	# is taken off the stack, allowing it to be retrieved from the memo
	# repeatedly if several instances of the same class are created.  This
	# can be much more efficient (in both time and space) than repeatedly
	# embedding the module and class names in INST opcodes.
	# 
	# Unlike INST, OBJ takes no arguments from the opcode stream.  Instead
	# the class object is taken off the stack, immediately above the
	# topmost markobject:
	# 
	# Stack before: ... markobject classobject stackslice
	# Stack after:  ... new_instance_object
	# 
	# As for INST, the remainder of the stack above the markobject is
	# gathered into an argument tuple, and then the logic seems identical,
	# except that no __safe_for_unpickling__ check is done (XXX this is
	# a bug; cPickle does test __safe_for_unpickling__).  See INST for
	# the gory details.
	# 
	# NOTE:  In Python 2.3, INST and OBJ are identical except for how they
	# get the class object.  That was always the intent; the implementations
	# had diverged for accidental reasons.

	# as with _do_global, we assume that we can't build a useful
	# object in perl and just push undef instead.

	my $self = shift;

	my ($class, @stackslice) = $self->_pop_to_mark;
	$self->_push(undef);
	return;
}



sub _do_build {
	# Finish building an object, via __setstate__ or dict update.

	# Stack before: ... anyobject argument
	# Stack after:  ... anyobject

	# where anyobject may have been mutated, as follows:

	# If the object has a __setstate__ method,

	#     anyobject.__setstate__(argument)

	# is called.

	# Else the argument must be a dict, the object must have a __dict__, and
	# the object is updated via

	#     anyobject.__dict__.update(argument) 

	# This may raise RuntimeError in restricted execution mode (which
	# disallows access to __dict__ directly); in that case, the object
	# is updated instead via

	#     for k, v in argument.items(): 
	#         anyobject[k] = v

	# Another python-specific method.

	my $self = shift;

	my $argument = $self->_pop;
	my $object = $self->_pop;
	$self->_push(undef);
	return;
}



sub _pop {
	my $self = shift;

	my $obj = pop @{ $self->{_stack} };
	return $obj;
}



sub _pop_to_mark {
	my $self = shift;

	my $idx = $#{ $self->{_stack} };
	while ($idx >= 0 &&
	       ! eval { $self->{_stack}[$idx]->isa('Python::Serialise::Pickle::Mark') }) {
		$idx --;
	}
	die "no mark found in stack" if ($idx < 0);
	my @result = splice(@{ $self->{_stack} }, $idx);
	shift @result;
	return @result;
}



sub _do_tuple {
	# Build a tuple out of the topmost stack slice, after markobject.
	# 
	# All the stack entries following the topmost markobject are placed into
	# a single Python tuple, which single tuple object replaces all of the
	# stack from the topmost markobject onward.  For example,
	# 
	# Stack before: ... markobject 1 2 3 'abc'
	# Stack after:  ... (1, 2, 3, 'abc')
	# 
	my $self = shift;

	my (@stackslice) = $self->_pop_to_mark;
	$self->_push([ @stackslice ]);
	return;
}



sub _do_list {
	# Build a list out of the topmost stack slice, after markobject.
	# 
	# All the stack entries following the topmost markobject are placed into
	# a single Python list, which single list object replaces all of the
	# stack from the topmost markobject onward.  For example,
	# 
	# Stack before: ... markobject 1 2 3 'abc'
	# Stack after:  ... [1, 2, 3, 'abc']

	# Looks just like _do_tuple to me ...

	my $self = shift;
	return $self->_do_tuple;
}



sub _do_dict {
	# Build a dict out of the topmost stack slice, after markobject.
	# 
	# All the stack entries following the topmost markobject are placed into
	# a single Python dict, which single dict object replaces all of the
	# stack from the topmost markobject onward.  The stack slice alternates
	# key, value, key, value, ....  For example,
	# 
	# Stack before: ... markobject 1 2 3 'abc'
	# Stack after:  ... {1: 2, 3: 'abc'}

	my $self = shift;

	my (@stackslice) = $self->_pop_to_mark;
	$self->_push({ @stackslice });
	return;
}



sub _type {
	my $self = shift;
	my $val = shift;

	my $ref = ref $val;

	return $ref if defined $ref && $ref ne "";

	return "NUMBER" if ($val =~ /^-?(?:\d+(?:\.\d*)?|\.\d+)$/);
	return "STRING";

}



sub _do_put {
	# Store the stack top into the memo.  The stack is not popped.
	# 
	# The index of the memo location to write into is given by the newline-
	# terminated decimal string following.  BINPUT and LONG_BINPUT are
	# space-optimized versions.

	my $self = shift;

	my $idx = $self->_get_line;
	die "empty stack" unless scalar @{ $self->{_stack} };
	$self->{_memo}[$idx] = $self->{_stack}[-1];
	return;

}



sub _do_binput {
	# Store the stack top into the memo.  The stack is not popped.
	#
	# The index of the memo location to write into is given by the
	# 1-byte unsigned integer following.
	my $self = shift;

	my $idx = $self->_get_uint1;
	die "empty stack" unless scalar @{ $self->{_stack} };
	$self->{_memo}[$idx] = $self->{_stack}[-1];
	return;
}



sub _do_binget {
	# Read an object from the memo and push it on the stack.
	#
	# The index of the memo to push is given by the
	# 1-byte unsigned integer following.
	my $self = shift;

	my $idx = $self->_get_uint1;
	die "empty memo slot" unless exists $self->{_memo}[$idx];
	$self->_push($self->{_memo}[$idx]);
	return;
}



sub _do_short_binstring {
	# Push a Python string object.
	#
	# There are two arguments:  the first is a 1-byte unsigned int
	# giving the number of bytes in the string, and the second is
	# that many bytes, which are taken literally as the string
	# content.
	my $self = shift;

	my $len = $self->_get_uint1;
	my $string = $self->_get_nchars($len);
	$self->_push($string);
	return;
}



sub _do_binunicode {
	# Push a Python Unicode string object.
	# 
	# There are two arguments:  the first is a 4-byte little-endian signed int
	# giving the number of bytes in the string.  The second is that many
	# bytes, and is the UTF-8 encoding of the Unicode string.
	my $self = shift;

	my $len = $self->_get_int4;
	my $string = $self->_get_nchars($len);
	$string = decode('UTF-8', $string);
	$self->_push($string);
	return;
}



sub _do_stop {
	# Stop the unpickling machine.
	# 
	# Every pickle ends with this opcode.  The object at the top of the stack
	# is popped, and that's the result of unpickling.  The stack should be
	# empty then.
	
	my $self = shift;

	die "stack doesn't have one element at stop" unless @{ $self->{_stack} } == 1;
	my $result = $self->{_stack}[0];
	pop(@{ $self->{_stack} });
	return $result;
}



=head2 close

Closes the current file.

=cut 

sub close {
	my $self = shift;
	$self->{_fh}->close() if $self->{_fh};
	delete $self->{_fh};
}

sub DESTROY {
	my $self = shift;
	$self->close();
}


=head1 BUGS

Almost certainly lots and lots.

=over 4

=item Serialised objects

At the moment we don't deal with serialised objects very well. The
opcodes are parsed correctly in the input stream but the result is
always undef.
Should probably just take or return a Python::Serialise::Pickle::Object 
object (which is really just a hashref). Or we could expose the
find_class method and let a subclass override it, like python does.

=item The 'None' object

Is parsed correctly, but handled correctly (i.e., as undef) only inside compound objects, 
because if we returned undef then that would signify the end of the Pickle file.
Fortunately that is probably the only realistic case.

=item Longs

There's no testing for longs

=item Some nested dictionaries

Dictionaries are the Python equivalent of hashes. This module can deal with most nested 
dictionaries but, for some reason, this one :

	a={'a':['two',{'goof':'foo', 'a':[1,2,3]}]}

causes it to fail.

Changing it slightly starts it working again. (this one may be fixed -
testcase is missing)

=item Bad reading of specs

This is entirely my fault (and mine, too :-) --hjp)

=back

=head1 ALTERNATIVES

You could always dump the data structure out as YAML in Python
and then read it back in with YAML in Perl.

=head1 AUTHOR

Simon Wistow <simon@thegestalt.org> originally wrote the module to read
and write files in pickle protocol 0. 

Peter J. Holzer <hjp@hjp.at> changed the underlying model to the
stack-based bytecode engine described in pickletools.py and implemented
some of the protocol 1 opcodes.

=head1 COPYRIGHT

(c) 2003 Simon Wistow

(c) 2008 Peter J. Holzer

Distributed under the same terms as Perl itself.

This software is under no warranty and will probably ruin your life,
kill your friends, burn your house and bring about the apocalypse.

=head1 SEE ALSO

http://www.python.org, L<YAML>, L<IO::File> and the RESOURCES file in 
this distribution.

=cut

1;
