package POE::Filter::STIPacket;

use Data::Dumper;
use POE::Filter;

@ISA = qw(POE::Filter);

################################################################################
# This is the instance creation method for this class. This filter implements a
# packet protocol. The packet is structured as follows:
#  	
#	4 bytes		payload size (big endian integer)
#	4 bytes		packet type  (a 4 byte ASCII string, unterminated)
#	4 bytes		Mode (a 4 byte ASCII string: (FORK|KEEP))
#	N bytes		Data/payload, the size is specified in the first phase
#
# Each of these 4 pieces of data is referred to in the code as a 'phase'. Thus,
# this packet has 4 phases. What is described above is the structure of the
# packet that will be sent to the server application. The server can reply to
# the packet as follows
#
#	4 bytes		payload size (big endian integer)
#	N bytes		Data/payload, the size is specified in the first phase
#
# The response payload will be a serialized version of what the server
# specified to send. The serialization is done via the Data::Dumper.
#
# The string encoded in the 'packet type' phase specifies what is to be done
# with the payload. This filter makes no attempt to take action based on the
# 'packet type'. Any action that is to be taken in this regard is the
# responsibility of the application. Thus, the 'get' method will provide
# structures of the following sort to the server application:
#
#  		{
#		  'type' => 'this is the 4 byte type',
#		  'data' => 'this is the raw payload',
#		};
#
# So, for example, the type string might be 'CMD_' indicating that the payload
# carries some sort of command. The server can decide that for this 'CMD_'
# function, the data is to be interpreted as a serialized structure, via the
# Data::Dumper. So, the server will 'eval' the payload and then process the
# resulting structure.

sub new 
{
  my($Class) = @_;
		#_______________________________________________________________
		# This is the instance data for the class. Here are the keys
		# that are specified:
		#
		# buffer	This is the data that is to be processed to
		#  		parse the packet. This data will be appended
		#		and to and also 'shift'ed off as the data
		#		arrives and is processed.
		#
		# phase		This is the name of the next phase that is to
		#  		be processed. If the buffer contains a partial
		#		packet, the 'phase' holds the name of the phase
		#		that will be processed when the data for that
		#		phase becomes available.
		#
		# data_type	This is the data type that has been parsed from
		#  		the packet that is currently being processed.
		#
		# data_mode	This is the data mode that has been parsed from
		#  		the packet that is currently being processed.
		#
		# result	This is the result structure that is to be
		#  		passed on to the server application. Here is
		#		how that data is structured:
   		#		  {
 		#  		    'type' => 'this is the 4 byte type',
 		#  		    'data' => 'this is the raw payload',
 		#		  };
		#
		# sequence	This hash defines the rules that govern the
		#  		parsing of the packet. The Size, Type, Mode,
		#		Data keys point to the phase that comes next.
		#		Thus, if the current phase being processed is
		#		the 'Mode' phase, then "Mode" => "Data"
		#		specifies that the "Data" phase is the next
		#		phase to be processed. The "_count" keys
		#		specify how many bytes are to be parsed from
		#		the data for that phase of the packet. Notice
		#		that the "Data_count" => 0. This value will be
		#		set according to what is present in the "Size"
		#		phase.
		#_______________________________________________________________

  my($Self) = {
		    'buffer' => '',
		    'phase' => 'Size',
		    'data_type' => '',
		    'data_mode' => '',
		    'result' => '',
		    'sequence' => {
		    		    "Size" => "Type",
		    		    "Type" => "Mode",
		    		    "Mode" => "Data",
		    		    "Data" => "Size",
		    		    "Size_count" => "4",
		    		    "Type_count" => "4",
		    		    "Mode_count" => "4",
		    		    "Data_count" => "0",
		    		  },
	      };

  bless($Self, $Class);
  return($Self);
}

################################################################################
# This function provides the processing that is needed for each of the packet
# phases. Mostly, the operations just write the data to the appropriate
# structure in the instance variable. The function takes the following pass
# parameters:
#
# $Self		This is the instance variable.
#
# $Phase	This is the phase for which the processing is to be done.
#
# $Data		This is the data that is to be processed.

sub Process_phase
{
  my($Self, $Phase, $Data) = @_;
  my($Map) = {
	       'Size' => sub {
  			   my($Packet_size);
			   $Packet_size = unpack("N", $Data);
			   $Self->{'sequence'}->{"Data_count"} = $Packet_size;
	       		 },
	       'Type' => sub {
			   $Self->{'data_type'} = $Data;
	       		 },
	       'Mode' => sub {
			   $Self->{'data_mode'} = $Data;
	       		 },
	       'Data' => sub {
			   $Self->{'result'} = {
					  'type' => $Self->{'data_type'},
					  'data' => $Data,
			   		  };
	       		 },
  	     };
  $Map->{$Phase}->();
}

################################################################################
# This is one of the methods that is required by the POE::Filter specification.
# The function takes 2 pass parameters:
#
# $Self		This is a refrence to an instance variable for this class
#
# $Data		This is an array of bits of data that were captured by the
#  		driver. This is the only access this class gets to the lower
#  		level data that is acquired by the driver.

sub get_one_start 
{
  my ($Self, $Data) = @_;
  				#_______________________________________________
				# The algorithm employed by this class uses the
				# 'buffer' to accumulate all of the bits of
				# data provided by the driver.
  				#_______________________________________________

  $Self->{'buffer'} .= join('', @$Data);
}

################################################################################
# This method provides the filtered data to the application. If the buffer has
# enough data to form a full packet, the data is filtered into the following
# structure:
#   		{
# 		  'type' => 'this is the 4 byte type',
# 		  'data' => 'this is the raw payload',
# 		};
#
# The specification says that granules of filtered data are to be returned in
# an array. Thus, the filtered structure will be pushed into an array. If more
# than one packet's worth of data is present in the buffer, multiple filtered
# structures will be placed into the return array.
#
# The calling function is notified that no filtered data is available at
# present by returning an empty array.

sub get_one 
{
  my($Self) = @_;
  my($Target_count);
  my($Phase_data);
  my($Return_set) = [];
  					#_______________________________________
					# The exit condition for this loop is
					# that the buffer is missing the data
					# needed to process the next complete
					# packet.  
  					#_______________________________________
  while(1)
    {
  					#_______________________________________
					# This piece determins how many bytes
					# must be present in the buffer to
					# process the current phase. If the
					# buffer has fewer bytes than these,
					# its time to exit the loop.
  					#_______________________________________
      $Target_count = $Self->{'sequence'}->{$Self->{'phase'}."_count"};
      if(length($Self->{'buffer'}) < $Target_count ) {last;}

  					#_______________________________________
					# This piece takes 1 phase worth of
					# bytes off of the front of the buffer.
  					#_______________________________________
      $Phase_data = substr($Self->{'buffer'},0,$Target_count);
      $Self->{'buffer'} = substr($Self->{'buffer'},$Target_count);

  					#_______________________________________
					# This line applies the phase specific
					# processing to the data.
  					#_______________________________________
      $Self->Process_phase($Self->{'phase'}, $Phase_data);
  					#_______________________________________
					# If the current phase is the data
					# phase, the packet is complete and the
					# needed data is pushed into the return
					# array.
  					#_______________________________________
      if($Self->{'phase'} eq 'Data'){push(@$Return_set, $Self->{'result'});}
  					#_______________________________________
					# This section determins what the next
					# phase is.
  					#_______________________________________
      $Self->{'phase'} = $Self->{'sequence'}->{$Self->{'phase'}};
    }
  return($Return_set);
}

################################################################################
#
# get() is inherited from POE::Filter.
#
################################################################################
# This section sends data off to the client. This will be data that is send in
# response to a packet that the client sent to the server. The data that is
# sent to the client is encoded as a packet having 2 phases:
#
#	4 bytes		payload size (big endian integer)
#	N bytes		Data/payload, the size is specified in the first phase
# 
# The function takes the following pass parameter in addition to the instance
# variable:
#
# $Chunks	This is an array of items to be sent to the client. These are
#  		assumed to be arbitrary perl structures. These structures must
#		not contain any refrences to functions.
#
# Each of the data items in the $Chunks array will be expanded into a string
# using the Dumper. These strings will then be pushed into the result array
# that is returned to the caller. The strings will be in packet form, prepended
# by 4 bytes to encode the size.

sub put 
{
  my ($Self, $Chunks) = @_;
  my($Size);
  my($String);
  my($Dump_string);
  my($Item);
  my($Result) = [];

  foreach $Item (@$Chunks)
    {
      $Dump_string = Dumper($Item);
      $String = pack("N", length($Dump_string));
      $String .= $Dump_string;
      push(@$Result, $String);
    }
  return($Result);
}

################################################################################
# This method returns the current contents of the buffer. For the most part,
# any data that this function returns will be useless. It may be that this
# function should be elimiated altogether. One potential use of this function
# might be to determin if data remains to be processed. This might be part of
# some error management scheme.

sub get_pending 
{
  my($Self) = @_;
  return([$Self->{'buffer'}]) if(length($Self->{'buffer'}));
  return undef;
}

###############################################################################

return(1);
