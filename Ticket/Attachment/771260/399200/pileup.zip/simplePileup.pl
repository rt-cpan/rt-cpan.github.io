use strict;
use Bio::DB::Sam;


my $db = 'DNA_DB.fasta';
my $bam = 'test.bam';	
my $sam = Bio::DB::Sam->new( 
	-bam => $bam,
    -fasta => $db,  
    #-expand_flags => 1,
	);         		

 my @SNPs;  # this will be list of SNPs
 my $snp_caller = sub {
        my ($seqid,$pos,$p) = @_;
        my $refbase = $sam->segment($seqid,$pos,$pos)->dna;

        for my $pileup (@$p) {
            my $b = $pileup->alignment;
            #next if $pileup->indel;  # don't deal with these ;-)

            my $qbase  = substr($b->qseq,$pileup->qpos,1);
            #next if $qbase =~ /[nN]/;

            #next unless $refbase ne $qbase;
        	if ($pileup->indel != 0 && $b->qname eq 'FZA5HME15JE8W2'){
        		print "$pos:".($pileup->indel)."/".$b->qname."\n";
        		print "$refbase:$qbase\n";
				my ($x, $y, $z) = $b->padded_alignment;
				print $x . "\n" . $y . "\n" . $z . "\n";	
        		
        	}
        	
        	if ($b->qname eq 'FZA5HME15JE8W2' && $refbase ne $qbase && $pileup->indel == 0){
        		print "$pos:".($pileup->indel)."/".$b->qname."\n";
        		print "$refbase:$qbase\n";
				my ($x, $y, $z) = $b->padded_alignment;
				print $x . "\n" . $y . "\n" . $z . "\n";	
        	}
        	
        }

		      

    };


 $sam->pileup('lcl|569|mmKIR3DL_splice_variant_1', $snp_caller);
