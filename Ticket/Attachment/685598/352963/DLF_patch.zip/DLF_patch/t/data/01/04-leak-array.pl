
my @foo;
$foo[0] = \@foo;
