
my $foo;
$foo = \$foo;
