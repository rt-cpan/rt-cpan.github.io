package Test::ORM;

use ORM::Db::DBI::MySQL;
use base 'ORM';

Test::ORM->_init (
  prefer_lazy_load    => 1,
  emulate_foreign_keys=> 1,
  default_cache_size  => 200,

  db => new ORM::Db::DBI::MySQL (
    host     => 'mysql4.pace.co.uk',
    database => 'testorm' ,
    user     => 'cvsaccess',
    password => 'getit',
  ),

);

sub _guess_table_name
{
  my $my_class = shift;
  my $class = shift;
  my $table = $class;
  
  $table =~ s/^Test:://;
  $table =~ s/::/_/g;
  
  return lc($table);
}

-1;

