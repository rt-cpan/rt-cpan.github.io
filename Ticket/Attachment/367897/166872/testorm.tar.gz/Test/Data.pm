package Test::Data;

$VERSION=0.1;

use ORM::Base 'Test::ORM';

# setValue(error, name, value)

sub setValue
{
  my ($error, $name, $value) = @_;

  my $record = Test::Data->find_or_new(
                prop => {
                  name => $name
                }, 
                error => $error,
                lazy_load => 0,
              );

  $error->fatal and return 0;
  $record->refresh(error => $error);
  $error->fatal and return 0;

  if ($value != $record->value) {
    $record->update(
              prop => {value => $value},
              error=> $error,
          );
  }
  return !$error->fatal;
}

-1;


