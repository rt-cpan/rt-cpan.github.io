package App::Script::Server;

use Moose;
extends 'CatalystX::Script::Server::Starman';

1;

__END__
