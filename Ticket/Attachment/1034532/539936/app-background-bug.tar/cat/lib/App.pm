package App;

use Moose;

use namespace::autoclean;

use Catalyst::Runtime 5.80;
use Log::Log4perl::Catalyst;

use Catalyst qw/
  -Debug
  ConfigLoader
  Authentication
/;

extends 'Catalyst';

our $VERSION = '1.0';

__PACKAGE__->log(Log::Log4perl::Catalyst->new('log.conf'));

__PACKAGE__->config(
  name => 'App',
  disable_component_resolution_regex_fallback => 1
);

__PACKAGE__->setup;

__PACKAGE__->meta->make_immutable( replace_constructor => 1 );

1;

__END__
