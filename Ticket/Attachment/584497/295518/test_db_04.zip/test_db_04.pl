#!E:/PROGRA~1/OTRS/Perl/bin/perl.exe -w
# --
# test_db_04.pl - to create table with CLOB field, insert some stuff and read them out
# Copyright (C) 30.03.2009 IMCons GmbH
# --
# $Id: test_db_04.pl,v 1.00 2009/03/30 10:24 sd
# --

use strict;
use warnings;

# use ../ as lib location
use File::Basename;
use FindBin qw($RealBin);
use lib dirname($RealBin);
use lib dirname($RealBin) . "/Kernel/cpan-lib";

use vars qw($VERSION);
$VERSION = qw($Revision: 1.00 $) [1];

use Kernel::Config;
use Kernel::System::DB;
use Kernel::System::Log;
use Kernel::System::Main;
use Digest::MD5;
use MIME::Base64;


my $Debug = 0;

# common objects
my %CommonObject = ();
$CommonObject{ConfigObject} = Kernel::Config->new();
$CommonObject{LogObject}    = Kernel::System::Log->new(
    LogPrefix => 'IMS check CLOB',
    %CommonObject,
);
$CommonObject{MainObject}   = Kernel::System::Main->new(%CommonObject);
$CommonObject{DBObject}     = Kernel::System::DB->new(%CommonObject);
$CommonObject{TimeObject}   = Kernel::System::Time->new(%CommonObject);

my $tmpDir="c:\\temp\\XML\\OUTPUT\\";

# check args
my $Command = shift || '--help';
print "test_db_04.pl <Revision $VERSION> - IMS check CLOB\n";
print "Copyright (C) 30.03.2009 IMCons GmbH\n";
print "Command used: $Command\n";
# create CLOB Table
if ( $Command eq '-CRT' ) {

    print " IMS create CLOB-Table:\n";
	my $Table = "CLOB_test_01";
	my $SQL     = "CREATE TABLE OTRS.$Table ("
				."SESSION_ID	VARCHAR(150)	NOT NULL,"
				."SESSION_VALUE	CLOB(195K)	NOT NULL	LOGGED	NOT COMPACT"
				.") "
				."IN USERSPACE1;";
    $CommonObject{DBObject}->Prepare( SQL => $SQL );
}
# create CLOB Table
elsif ( $Command eq '-DROP' ) {
	print " IMS drop CLOB-Table:\n";
	my $Table = "CLOB_test_01";
	my $SQL     = "DROP TABLE OTRS.$Table; ";
    $CommonObject{DBObject}->Prepare( SQL => $SQL );
}
# insert CLOB Table
elsif ( $Command eq '-INS' ) {
	print " IMS insert CLOB-Table:\n";
    # get REMOTE_ADDR
    my $RemoteAddr = $ENV{REMOTE_ADDR} || 'none';
    # get HTTP_USER_AGENT
    my $RemoteUserAgent = $ENV{HTTP_USER_AGENT} || 'none';
	# create SessionID
    my $md5 = Digest::MD5->new();
    $md5->add(
        ( $CommonObject{TimeObject}->SystemTime() . int( rand(999999999) ) . "localhost" )
        . $RemoteAddr
            . $RemoteUserAgent
    );
    my $SessionID = "localhost" . $md5->hexdigest;
    # data 2 strg
    my $DataToStore = '';
    $DataToStore
        = "UserSessionStart:" . encode_base64( $CommonObject{TimeObject}->SystemTime(), '' ) . ":;";
    $DataToStore
        .= "ModUserSessionStart:" .$CommonObject{TimeObject}->SystemTime(). ":;";
    my $UserLogin = "UserLogin";
	$DataToStore
        .= "ModUserLogin:" .$UserLogin. ":;";
	print " IMS insert PARM: '.$SessionID.', '.$DataToStore.' Length of DatatoStore: ". length($DataToStore)."\n";
	my $Table = "CLOB_test_01";
	$CommonObject{DBObject}->Do(
        SQL => "INSERT INTO $Table "
            . " (SESSION_ID, SESSION_VALUE) VALUES (?, ?)",
        Bind => [ \$SessionID, \$DataToStore ],
    );
}
# read CLOB Table
elsif ( $Command eq '-GET' ) {
	print " IMS read CLOB-Table:\n";

	my @Tickets = ();
	my $Table = "CLOB_test_01";
	my $SQL = 	"SELECT * FROM OTRS.$Table";
    $CommonObject{DBObject}->Prepare( SQL => $SQL );

    while ( my @RowTmp = $CommonObject{DBObject}->FetchrowArray() ) {
        push( @Tickets, \@RowTmp );
    }
    for (@Tickets) {
        my @Row = @{$_};
		my $Value = $Row[1];
        print " Reading record  $Row[0] as id $Row[1] as value \n";
        print " length of value  ".length ($Value) ." \n";
		}
}
else {
    print "usage: $0 [options] \n";
    print "  Options are as follows:\n";
    print "  -CRT        create Test-CLOB table\n";
    print "  -DROP       drop Test-Clob-Table\n";
    print "  -INS        insert CLOB-Records\n";
    print "  -GET        read all CLOB-Records\n";
    exit(1);
}

 # my $stmt = "CREATE TABLE blobTest (id INTEGER, data BLOB)";
 # my $sth = $dbh->prepare($stmt);
 # $sth->execute();

 # $stmt = "INSERT INTO blobTest (id, data) values (?,?)";
 # my $sth = $dbh->prepare($stmt);

 # $sth->bind_param(1,1);.
 # $sth->bind_param(2,sample,$attrib_blobfile);
 # $sth->execute();
