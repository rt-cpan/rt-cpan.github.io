#!/usr/bin/perl
use warnings;
use strict;

use Config::Simple;

#=======================================================================

sub test1 {
  # Error-1: guess_syntax() is getting confused by the equal sign in the 'value' for simple format key (space) value
  # If you move the first key/value pair down, the read() works fine.

  my $file = shift;
  print "starting test1 using $file\n";

  my $cfg  = Config::Simple->new( $file );
  my %Cfg  = $cfg->vars();
  my $val  = $Cfg{key1};
  if ( $val eq 'one=' ) { print "Passed test-1\n"; }
  else { print "Failed test-1 with [$val]\n"; }
}

#=======================================================================

sub test2 {
  # Error-2: guess_syntax() is called even though the syntax is explicitly specified in the constructor

  my $file = shift;
  print "starting test2 using $file\n";

  my $cfg  = Config::Simple->new( filename => $file, syntax => 'simple' );
  my %Cfg  = $cfg->vars();
  my $val  = $Cfg{key1};
  if ( $val eq 'one=' ) { print "Passed test-2\n"; }
  else { print "Failed test-2 with [$val]\n"; }
}

#=======================================================================

sub do_tests {
  my $file = shift;

  print "starting tests using file: $file\n";

  test1( $file );
  test2( $file );
}

#=======================================================================

do_tests( 'config_works.cfg' );
do_tests( 'config_repro.cfg' );

exit();
