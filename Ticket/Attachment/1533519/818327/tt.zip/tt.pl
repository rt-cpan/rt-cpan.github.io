#!/usr/bin/perl -w

use strict;
use warnings;

use PDF::API2;

my $pdf = PDF::API2->new;
my $font = $pdf->ttfont("DejaVuSansMono.ttf", -dokern => 1);

my $page = $pdf->page();
my $text = $page->text;
$text->fillcolor('#000000');
$text->strokecolor('#000000');

$text->font( $font, 12 );
$text->translate( 100, 100 );
$text->text( "Hello, World!");

$pdf->saveas( "__new__.pdf" );

