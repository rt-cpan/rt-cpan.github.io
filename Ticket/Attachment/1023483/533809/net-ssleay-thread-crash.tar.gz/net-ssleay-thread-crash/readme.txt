Make sure that you have Thread::Queue::Duplex

Run in parallel:

1/ perl httpd-multithreaded.pl
2/ perl client-multithreaded.pl

and wait for crash