use threads;

use strict;
use warnings;

use Thread::Queue::Duplex;
use Net::SSLeay;

Net::SSLeay::load_error_strings();
Net::SSLeay::SSLeay_add_ssl_algorithms();
Net::SSLeay::randomize();
#$Net::SSLeay::trace = 2;

my $host = 'localhost';
my $port = 3443;
my $url = '/asdf/qwer';

#for some reason it is good to call once CTX_new() in the main thread
my $ctx = Net::SSLeay::CTX_new();

my $q = Thread::Queue::Duplex->new(ListenerRequired => 1, MaxPending => 100);
my $m = threads->create(\&thread_master);
$m->join;

warn "Should never reach this point!\n";

sub thread_master {
  $q->listen();
  #create initial 30 threads
  threads->create(\&thread_worker)->detach for (1..30);
  #for each finished thread start a new one
  while(1) {    
    my ($id, $msg) = @{$q->dequeue()};
    printf STDERR "job=%04d msg=%s\n", $id, $msg;
    threads->create(\&thread_worker)->detach
  }
}

sub thread_worker {
    warn("starting thread tid=".threads->tid."\n");    
    my ($page, $response, %reply_headers);
    $q->wait_for_listener();
    eval {
      ($page, $response, %reply_headers) = Net::SSLeay::get_https($host, $port, $url) for (1..5);
      $response = '<undef>' unless defined $response;
      $page = '' unless defined $page;
    };
    if ($@) {
      $q->enqueue("error: $@");
    }
    else {
      $q->enqueue("resp-code=$response length=".length($page)." tid=".threads->tid);
    }
    warn("exiting thread tid=".threads->tid."\n");    
    threads->exit(0);
}

