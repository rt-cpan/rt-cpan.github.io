use threads;
#use threads::shared;

use strict;
use warnings;

use FindBin;
use IO::Socket::INET;
use Socket qw(sockaddr_in);

use Thread::Queue::Duplex;

use Net::SSLeay qw(die_now die_if_ssl_error);
Net::SSLeay::load_error_strings();
Net::SSLeay::SSLeay_add_ssl_algorithms();
Net::SSLeay::randomize();

#for some reason it is good to call once CTX_new() in the main thread
my $ctx = Net::SSLeay::CTX_new();

# parameters
my $addr = 'localhost';
my $port =  3443;
my $workers = 40;
my $ssl_server = 1;

my $TQ_handles = Thread::Queue::Duplex->new(ListenerRequired => 1, MaxPending => 100);
my $TQ_logs    = Thread::Queue::Duplex->new(ListenerRequired => 1, MaxPending => 100);

my $TH_dispatcher = threads->new(\&thread_dispatcher, $TQ_handles, $TQ_logs);
my $TH_logger     = threads->new(\&thread_logger, $TQ_logs);
my @TH_workers    = threads->new(\&thread_worker, $TQ_handles, $TQ_logs)->detach for (1..$workers);

$TH_dispatcher->join;
die "#FATAL# We should never reach this point!";

sub thread_dispatcher {
    my ($TQ_handles, $TQ_logs) = @_;
    $TQ_handles->wait_for_listener();
    $TQ_logs->wait_for_listener();

    #open listen socket    
    my $listenfd = IO::Socket::INET->new(LocalAddr=>$addr, LocalPort=>$port, Proto=>'tcp', Listen=>$workers);
    die "#FATAL# Can't create dispatcher: $!" unless $listenfd;

    while (1) {    
      my $fd = $listenfd->accept();
      #$TQ_logs->enqueue(threads->tid, "Info: dispatcher accepted connection");
      if ($fd) {
        #pass fileno to other thread and wait for response
        my $resp = $TQ_handles->enqueue_and_wait('newfd', $fd->fileno);
        #worker has taken the socken therefore now it is safe to close it in this thread
        $fd->close();
      }
      else {
        warn "#WARNING# accept() failed retval=", defined($fd) ? $fd : '<undef>';
      }
    }
    die "#FATAL# We should never reach this point!";
}

sub thread_logger {
    my ($TQ_logs) = @_;
    $TQ_logs->listen();
    while (1) {
      my ($id, $tid, $msg) = @{$TQ_logs->dequeue()};
      print STDERR sprintf("#ID=%03d:TID=%03d# %s\n", $id, $tid, $msg);
    }
    die "#FATAL# We should never reach this point!";
}

sub thread_worker {
    my ($TQ_handles, $TQ_logs) = @_;
    my $tid = threads->tid();
    
    $TQ_logs->wait_for_listener();
    $TQ_handles->listen();
    
    $TQ_logs->enqueue(threads->tid, "Info: entering worker loop");
    while (1) {
      #prepare all necessary stuff before we start waiting in dequeue()
      #to minimize delay between getting and actual handling request
      my ($ctx, $ssl, $socket, $retval);
      eval {          
          if ($ssl_server) {
            $ctx = Net::SSLeay::CTX_new() or die_now("CTX_new ($ctx): $!");
            Net::SSLeay::CTX_set_options($ctx, &Net::SSLeay::OP_ALL);
            Net::SSLeay::CTX_use_RSAPrivateKey_file ($ctx, "$FindBin::Bin/server1.key", &Net::SSLeay::FILETYPE_PEM);
            die_if_ssl_error("private key");
            Net::SSLeay::CTX_use_certificate_file ($ctx, "$FindBin::Bin/server1.crt", &Net::SSLeay::FILETYPE_PEM);
            die_if_ssl_error("certificate");          
            $ssl = Net::SSLeay::new($ctx) or die_now("SSL_new ($ssl): $!");
          }
          $socket = IO::Socket::INET->new() or die "cannot create socket";
      }; 
      if ($@) {
          $TQ_logs->enqueue(threads->tid, "#ERROR# gonna restart after 5 sec, failure: $@");
          sleep 5;
          next;
      }      
      
      #BEWARE: the following section is blocking the dispatcher - keep it as short/simple as possible
      my ($id, $cmd, $fn) = @{$TQ_handles->dequeue()}; # wait for a socket from dispatcher
      $retval = $socket->fdopen($fn, '+>');            
      $TQ_handles->respond($id, 'newfd');              # now we can tell dispatcher that we taken the socket      
      $TQ_logs->enqueue(threads->tid, "#ERROR# worker fdopen failure"), next unless $retval;
      
      #handle the connection
      my ($port, $iaddr, $host, $ip);
      eval {
        ($port, $iaddr) = sockaddr_in(getpeername($socket));
        $host = gethostbyaddr($iaddr, AF_INET);
        $ip = inet_ntoa($iaddr);
        
        if ($ssl_server) {
          #handle HTTPS request
          Net::SSLeay::set_fd($ssl, $fn);
          my $err = Net::SSLeay::accept($ssl) and die_if_ssl_error('ssl accept');
          my $request = Net::SSLeay::read($ssl);
          die "read error" unless defined $request;
          Net::SSLeay::write($ssl, "HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\n".
                                   "###ORIGINAL REQUEST - ".localtime." [".threads->tid."]###\n".
                                   $request);
          Net::SSLeay::free($ssl);
        }
        else {
          #handle HTTP request
          my $request = "";
          my $len = $socket->sysread($request, 4000);
          die "sysread error" unless defined $len;
          $socket->syswrite("HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\n".
                            "###ORIGINAL REQUEST - ".localtime." [".threads->tid."]###\n".
                            $request);
        }
        $socket->close;
      };
      
      #report success/failure
      if ($@) {
        $TQ_logs->enqueue(threads->tid, "#ERROR# worker (port=$port host=$host ip=$ip ssl=$ssl_server) failure: $@");
      }
      else {
        $TQ_logs->enqueue(threads->tid, "Info: worker (port=$port host=$host ip=$ip ssl=$ssl_server) finished correctly");
      }
   }
   die "#FATAL# We should never reach this point!";
}
