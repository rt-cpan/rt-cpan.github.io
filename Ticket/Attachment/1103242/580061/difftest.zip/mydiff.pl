#!/bin/perl
use strict;
use warnings;
my $file = 'xml1.xml';
my $file2 = 'xml2.xml';
my $h = Myclass->new;
use XML::SemanticDiff;
my $diff =  XML::SemanticDiff->new(diffhandler => $h, keepdata => 1);
$diff->compare($file, $file2);
package Myclass;
use Data::Dumper;
sub new { bless {}, shift }

sub attribute_value
{
  my ($self, $attr_name, $element, $to_props, $from_props) = @_;
  print "\n\nattribute value\n";
  print Dumper($self, $attr_name, $element, $to_props, $from_props);
}

sub rogue_element
{
  my ( $self, $name, $props ) = @_;
  print "\n\nrogue element\n";
  print Dumper($self, $name, $props);
}