package Foo;

use Moose::Role;
use namespace::autoclean;

has 'llama' => (is => 'ro',
                isa => 'Str',
                required => 1);

1;
