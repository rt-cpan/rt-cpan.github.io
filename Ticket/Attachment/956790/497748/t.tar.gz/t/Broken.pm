package Broken;

use MooseX::Singleton;
with 'Foo';
