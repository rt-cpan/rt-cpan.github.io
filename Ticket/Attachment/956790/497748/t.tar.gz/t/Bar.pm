package Bar;

use Moose::Role;
use namespace::autoclean;

requires 'llama';

around 'llama' => sub {
    "tron";
};

1;
