package Works;

use Moose;
with 'Foo';
