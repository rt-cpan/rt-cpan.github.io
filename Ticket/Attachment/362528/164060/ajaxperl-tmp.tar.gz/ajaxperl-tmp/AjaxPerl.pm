#!/usr/bin/env perl

package AjaxPerl;

use warnings;
use strict;

#use Smart::Comments;
use JavaScript;
use HTML::DOM;
use Hook::LexWrap;
use File::Slurp;

$| = 1;

our $js_runtime = new JavaScript::Runtime;
our $js = $js_runtime->create_context;
#$js->function_set('include',
#sub { $js->eval_file($_) || die $@ for @_  });
for my $func (@Test::More::EXPORT) {
    no strict 'refs';
    #warn $func;
    $js->bind_function($func, \&$func);
}
$js->bind_function('warn', sub { warn "@_"; });

my $Counter = 0;
my @Nodes = ();

my $register_handle = sub {
    my $self = $_[-1];
    my $id = $Counter++;
    $Nodes[$id] = $self;
    $self->{__id} = $id;
    #warn "@_";
};

wrap 'HTML::DOM::Element::new',
    post => $register_handle;

wrap 'HTML::DOM::new',
    post => $register_handle;

#wrap 'HTML::DOM::Node::new',
    #post => $register_handle;

my $dom_js = 'dom.js';
$js->eval_file($dom_js);
die("dom.js:\n" . $@ ) if $@;
$js->bind_function(
    loadHTML => sub {
        my $filename = shift;
        my $DOM = new HTML::DOM(@_);
        my $html = read_file($filename);
        $DOM->parse($html);
        $DOM->eof();
        $js->eval( qq{
            var document = new HTMLDocument("$DOM->{__id}");
        } );
        warn $@ if $@;
    }
);
$js->eval_file('JSON.js');
die $@ if $@;
sub decode_arg {
    my $arg = shift;
    return undef unless $arg and ref $arg;
    my ($type, $value) = @$arg;
    if ($type eq 'N') {
        return $Nodes[$value];
    } elsif ($type eq 'D') {
        return $value;
    } else {
        warn "Unknown argument type: $type";
        return undef;
    }
}
$js->bind_function('perl_call',
    sub {
        ### perl_call: @_
        my $this_id = shift;
        my $subname = shift;
        #if (!defined $this_id) {
        #    warn "$subname";
        #    die "Cant' find ID";
        #}
        my $node = $Nodes[$this_id];
        ## $node
        ### $subname
        my @args = map { decode_arg($_) } @_;
        #die "Hello!" if $subname eq 'parentNode';
        my $res = $node->$subname(@args);
        # XXX This die doesn't work
        die $res if $subname eq 'parentNode';
        ### $res
        if (ref $res && ($res->isa('HTML::DOM::Node') || $res->isa('HTML::DOM::Element'))) {
            my $id = $res->{__id};
            if (!defined $id) {
                die "Can't find ID: ", ref $res;
                #die;
                $id = $res->{__id} = $Counter++;
                $Nodes[$id] = $res;
            }
            #warn "ID: $id";
            return [N => "new HTMLElement('$id');"];
        } else {
            return [D => $res];
        }
    }
);

1;
