var decodeArg = function (arg) {
    if (arg[0] == "N") {
        return eval(arg[1]);
    } else {
        return arg[1];
    }
}

var HTMLElement = function (dom_id) {
    if (dom_id) {
        this.dom_id = dom_id;
    } else {
        // create new HTML::DOM instance
    }
    this.__defineGetter__(
        "parentNode",
        function () {
            var res = perl_call(this.dom_id, 'parentNode');
            //return 'hello';
            return decodeArg(res);
        }
    );

    this.__defineGetter__(
        "tagName",
        function () {
            var res = perl_call(this.dom_id, 'tagName');
            //return 'hello';
            return decodeArg(res);
        }
    );
};

HTMLElement.prototype.toString = function () {
    return "[object HTMLElement]";
};

encodeArg = function (arg) {
    //warn(typeOf arg);
    if (arg.dom_id)
        return ['N', arg.dom_id];
    else
        return ['D', arg];
}

HTMLElement.prototype.getAttribute = function (a) {
    //warn("Hello");
    //warn(Array.prototype.forEach);
    //warn("arguments: " + arguments);
    //args.forEach(JSON.stringify);
    //warn("args: " + JSON.stringify(args));
    var res = perl_call(this.dom_id, 'getAttribute', encodeArg(a));
    return decodeArg(res);
};
/*
var HTMLNode = function (dom_id) {
};
*/

var HTMLDocument = function (dom_id) {
    //warn(dom_id);
    if (dom_id) {
        this.dom_id = dom_id;
    } else {
        // create new HTML::DOM instance
    }
    this.__defineSetter__(
        "title",
        function (value) {
            var res = perl_call(this.dom_id, 'title', encodeArg(value));
            //return 'hello';
            // XXX a HTML::DOM bug
            return value;
        }
    );

    this.__defineGetter__(
        "title",
        function () {
            var res = perl_call(this.dom_id, 'title');
            //return 'hello';
            return decodeArg(res);
        }
    );

    this.__defineGetter__(
        "URL",
        function () {
            var res = perl_call(this.dom_id, 'URL');
            //return 'hello';
            return decodeArg(res);
        }
    );
    this.__defineSetter__(
        "URL",
        function (value) {
            var res = perl_call(this.dom_id, 'URL', encodeArg(value));
            //return 'hello';
            // XXX a HTML::DOM bug
            res = perl_call(this.dom_id, 'URL');
            return decodeArg(res);
        }
    );
    this.__defineGetter__(
        'domain',
        function () {
            return 'yahoo.cn';
        }
    );
}

HTMLDocument.prototype.getElementById = function (id) {
    //warn(this.dom_id);
    var res = perl_call(this.dom_id, 'getElementById', encodeArg(id));
    //return 'hello';
    //warn(res);
    return decodeArg(res);
};

HTMLDocument.prototype.write = function (s) {
    var res = perl_call(this.dom_id, 'write', encodeArg(s));
    return decodeArg(res);
};

HTMLDocument.prototype.writeln = function (s) {
    var res = perl_call(this.dom_id, 'writeln', encodeArg(s));
    return decodeArg(res);
};

var HTMLWindow = function () {
};
var Navigator = function () {
    this.userAgent = 'Netscape';
    return this;
};

var window = new HTMLWindow();
var navigator = new Navigator();
//var document = window.document;

Object.attachEvent = function () {};

