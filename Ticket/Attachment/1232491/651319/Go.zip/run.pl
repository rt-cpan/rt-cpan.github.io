#!/usr/bin/perl
use myapp;
my $app = myapp->new_with_options();
# ... rest of the script here