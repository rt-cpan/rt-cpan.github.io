#!/usr/bin/perl
use myapp_usage;
my $app = myapp_usage->new_with_options();
# ... rest of the script here