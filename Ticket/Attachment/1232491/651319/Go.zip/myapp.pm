package myapp;
use Moose;
with 'MooseX::Getopt';

has 'out' => (is => 'rw', isa => 'Str', required => 1);
has 'in'  => (is => 'rw', isa => 'Str', required => 1);

1;