package myapp_usage;
use Moose;
with 'MooseX::Getopt::Usage';

has 'out' => (is => 'rw', isa => 'Str', required => 1);
has 'in'  => (is => 'rw', isa => 'Str', required => 1);

1;