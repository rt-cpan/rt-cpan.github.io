#!/usr/bin/perl -w


use Test::Simple tests => 1;


ok( 1 + 1 == 2 );


