#!/usr/bin/perl -w


use Test::More qw(no_plan);

$total_tests = 1;

plan tests => $total_tests;


ok( 1 + 1 == 2 );


