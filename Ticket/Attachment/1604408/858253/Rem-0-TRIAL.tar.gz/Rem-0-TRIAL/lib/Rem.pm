package Rem;

=head1 NAME

Rem - Don't do anything usedful.

=head1 VERSION

Version 0.001

=cut

1;
