package TestException;

use strict;
use warnings;

use base 'Class::Throwable';

1;