#!/usr/bin/perl

use strict;
use Device::Gsm;

my $myport = '/dev/ttyS0';
my $mypin  = '0000';
my $gsm = new Device::Gsm( port => $myport, pin => $mypin, log => 'file,debug-send-read.log', loglevel => 'debug' );
die "cannot create Device::Gsm object!" unless $gsm;
$gsm->connect( baudrate => 115200 ) or die "cannot connect to GSM device on [$myport]\n";
$gsm->register() or die "cannot register on GSM network: check pin and/or network signal!"; 
$gsm->atsend( qq{AT+CPMS="ME","ME","ME"} . Device::Modem::CR ."\r\n" );
print $gsm->answer() ."\n";
my $stop;

while (not $stop) {

print "Send msg?\n";
chomp( my $yes = <STDIN>);

if ($yes =~ /yes/) {
my $number = '+628156026252';
my $content = 'testing minta dibales';
my $sent = $gsm->send_sms(
	content => $content,
	recipient => $number,
	class     => 'normal',
	status_report => 'true'
);

if( $sent ) {
	print "SMS sent!\n" ;
} else { 
	print "Error in sending!\n";
}

# end yes
}

my @msgs;
my $msg;

$gsm->storage('ME');
$gsm->atsend( qq{AT+CPMS?} . Device::Modem::CR ."\r\n" );
print $gsm->answer() ."\n";
@msgs = $gsm->messages('ME');
$msg = scalar @msgs;
print "dari ME: $msg\n";

if (not $msg)
{
    $gsm->storage('SM');
    $gsm->atsend( qq{AT+CPMS?} . Device::Modem::CR ."\r\n" );
    print $gsm->answer() ."\n";
    @msgs = $gsm->messages('SM');
    $msg = scalar @msgs;
}
print "plus SM: $msg\n";

if ($msg)
{
    foreach (@msgs)
    {
	my $sms = $_;
	next unless defined($sms);
	print $sms->sender() ." ". $sms->text() ."\n";
	my $del = 1;
	#my $del = $sms->delete();
	if ($del)
	{
	    print "fake deleted\n";
	}
    }
}

=begin
# find out why they dont show my messages
else
{
    $gsm->storage('ME');
    my $bak = $gsm->answer();
    $gsm->atsend( qq{AT+CPMS?} . Device::Modem::CR ."\r\n" );
    print $gsm->answer() ."\n";

    $gsm->atsend( qq{AT+CMGF=0} . Device::Modem::CR ."\r\n" );
    $gsm->answer();

    $gsm->atsend( qq{AT+CMGL=4} . Device::Modem::CR ."\r\n" );
    my ($isi) = $gsm->answer();
    
    print "----\n";
    @pesan = split /[\r\n]+/m, $isi;
    while (@pesan)
    {
	my $headerna = shift @pesan;
	my $isina = shift @pesan;
	
	if ($headerna =~ /CMGL/)
	{
	    print "[H]: $headerna [I]: $isina\n";
	    my $wew = new Device::Gsm::Sms(
			    header => $headerna,
			    pdu => $isina,
			    storage => $bak
			    );
	    if ( defined($wew) )
	    {
		print $wew->sender() ."\n";
		print $wew->text() ."\n";
	    }
	}
    }
}
=cut

# end while
}

