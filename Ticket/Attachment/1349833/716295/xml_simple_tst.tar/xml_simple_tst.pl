#!/usr/bin/perl

use strict;
use warnings;

use XML::Simple;
use Data::Dumper;
$Data::Dumper::Indent = 1;

my $infile = $ARGV[0];

my $xs  = new XML::Simple(searchpath => ".", ForceArray => 1);

my $ref = $xs->XMLin($infile);

# print Dumper($ref);

print $ref->{script}, "\n";
