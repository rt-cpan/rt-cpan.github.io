package WT::Email::App;

use warnings;
use strict;

use base "CGI::Prototype::Hidden";

our $VERSION = '0.01';

sub config_class_prefix { "WT::Email" }
sub config_default_page { "Search"}
sub config_tt_extension { ".html" }
sub config_wrapper { "WT/Email/WRAPPER.html" }

1;
