package WT::Email::Display;

use warnings;
use strict;

use base "WT::Email::App";

sub emails {
	my $self = shift;
	my @email_objs = WT::Email::Data::TblEmail->search_email($self->param('title'),$self->param('section'));
	my @emails = map { $_->email } @email_objs;
	return \@emails;
}

sub count_email {
	my $self = shift;
	my @email_objs = WT::Email::Data::TblEmail->search_email($self->param('title'),$self->param('section'));
	return scalar @email_objs;
}

sub respond_per_page {
        my $self = shift;
        return $self->name_to_page('Search');
}


1;
