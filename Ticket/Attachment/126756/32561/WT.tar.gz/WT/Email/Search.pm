package WT::Email::Search;

use warnings;
use strict;

use WT::Email::Data;
use Data::Dumper;
use base "WT::Email::App";

sub current_term {
	my $self = shift;
	my ($term) = WT::Email::Data::TblStatus->retrieve_all;
	return $term->current_semester;
}

sub titles {
	my $self = shift;
	my @title_objs = WT::Email::Data::TblSched->search_title;
	my @titles = map { $_->title } grep { $_->title ne "" } @title_objs;
	unshift @titles, "";
	return \@titles;
}

sub sections {
	my $self = shift;
	my @section_objs = WT::Email::Data::TblSched->search_section;
	my @section = map { $_->section } @section_objs;
	unshift @section, "";
	return \@section;
}

sub respond_per_page {
	my $self = shift;
	return ($self->param('title') && $self->param('section')) ? $self->name_to_page('Display')
		: $self->name_to_page($self->config_default_page);
}

1;
