#!/usr/bin/env perl

# again.pm, it works well if import().

use lib "ex/lib";
use feature "say";

use again;

require_again("mymod1");
mymod1->import("num");

say num();

$INC{'mymod1.pm'}--; # for force reload.
require_again("mymod1");
mymod1->import("num");

say num(); # change
