#!/usr/bin/env perl

# again.pm, it does not work well if pkgname::subname();

use lib "ex/lib";
use feature "say";

use again;

require_again("mymod1");

say mymod1::num(); # Undefined subroutine &mymod1::num called
