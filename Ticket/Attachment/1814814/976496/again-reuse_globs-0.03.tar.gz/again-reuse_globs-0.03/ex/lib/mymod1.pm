package mymod1;

use Exporter qw(import);

our @EXPORT_OK = qw(num);

my $num = rand;

sub num { $num }

1;
