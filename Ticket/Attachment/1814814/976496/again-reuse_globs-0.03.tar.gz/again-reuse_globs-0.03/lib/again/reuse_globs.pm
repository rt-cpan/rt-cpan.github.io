package again::reuse_globs;
# ABSTRACT: Same as again.pm, but delete symbols and reuse globs.
$again::reuse_globs::VERSION = '0.03';
require again;

my $src = do { open my $fh, "<", $INC{'again.pm'}; local $/; <$fh> };
$src =~ s/^package \Kagain(?=;)/@{[ __PACKAGE__ ]}/ or die "unexpected again.pm";
eval $src;
die $@ if $@;

# original https://st.aticpan.org/source/NEILB/again-0.08/lib/again.pm
# sub _unload_module
# {
#     my $package      = shift;
#     my $symbol_table = $package.'::';
#
#     no strict 'refs';
#     foreach my $symbol (keys %$symbol_table) {
#         next if $symbol =~ /\A[^:]+::\z/;
#         delete $symbol_table->{$symbol};
#     }
# }

use Package::Stash;
*{_unload_module} = sub {
    my $package = shift;

    my $stash = Package::Stash->new($package);
    for ($stash->list_all_symbols) {
        for my $sigil (qw($ @ % &), '') {
            $stash->remove_symbol("$sigil$_");
        }
    }
};

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

again::reuse_globs - Same as again.pm, but delete symbols and reuse globs.

=cut
