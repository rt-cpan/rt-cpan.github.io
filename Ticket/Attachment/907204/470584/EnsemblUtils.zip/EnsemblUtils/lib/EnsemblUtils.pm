package EnsemblUtils;

use 5.012;
use IPC::System::Simple 'capture';
use Params::Validate ':all';
use Sub::Exporter -setup => { exports => ['mgi2ensembl'] };

# ABSTRACT: example utilities module

=func mgi2ensembl( Str I<$mgi_accession_id> where { m/^MGI:\d+$/ } ) -> Array[Str]

Get EnsEMBL gene IDs for the given MGI accession ID

=cut

sub mgi2ensembl {
    grep length, map { ( split /\s+/, $_, 3 )[1] } split $/,
        capture( 'mgi2ensembl.pl',
        validate_pos( @_, { regex => qr/^MGI:\d+$/ } ) );
}

1;
