use strict;
use Test::LeakTrace; ## Memory leakage test module

use Site::MyDBI; ## Rose::DB connection implementation
use OCS::DB::Session::Log; ## Rose::DB::Object implementation for table 'sessions'

leaktrace {
	print "\n Memory Test: OCS::DB::Session::Log->save\n";

	my $SessionLog = OCS::DB::Session::Log->new(db => Site::MyDBI->new( database => 'OCS100' ));
	$SessionLog->realm_session_id('ab');
	$SessionLog->status('Expired');
	$SessionLog->save;
	} sub {
		my($ref, $file, $line) = @_;
		#print "leaked $ref from $file at $line\n";
		`echo "leaked $ref from $file at $line" >> RoseDBInsertLeak.log`;
	};

print "\n LOG FILE: RoseDBInsertLeak.log\n";

__END__
