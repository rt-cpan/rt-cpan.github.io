package OCS::DB::Session::Log;

use strict;
use Site::DateUtils;
use base qw(OCS::DB);

__PACKAGE__->meta->setup
(
  table   => 'session_logs',

  columns => 
  [
    id                          => { type => 'bigint' },
    realm_session_id            => { type => 'varchar', length => 45, default => '' },
    realm_id                    => { type => 'varchar', length => 45, default => '' },
    total_allocated_cash_quota  => { type => 'numeric', precision => 20, scale => '9', default => '' },
    total_allocated_units_quota => { type => 'integer', default => '' },
    total_consumed_units        => { type => 'integer', default => '' },
    total_consumed_cash         => { type => 'numeric', precision => 20, scale => 9, default => '' },
    service_type                => { type => 'enum', check_in => [ 'Voice', 'INTL_VOICE', 'Data', 'SMS', 'MMS' ], default => 'Voice' },
    status                      => { type => 'enum', check_in => [ 'Active', 'Closed', 'Expired' ] },
    expiration_date_time        => { type => 'varchar', default => '' },
    sub_identity_id             => { type => 'integer', default => '' },
    sub_identity                => { type => 'varchar', length => 45, default => '' },
    start_time                  => { type => 'varchar', default => '' },
    end_time                    => { type => 'varchar', default => '' },
    unused_quota_allocated      => { type => 'integer', default => '' },
    session_id                  => { type => 'integer', default => '' },
    talk_start_time             => { type => 'datetime', not_null => 1, default => '0000-00-00 00:00:00' },
    call_direction              => { type => 'enum', check_in => [ 'ORIG_VOICE', 'TERM_VOICE' ], not_null => 1, default => 'ORIG_VOICE' },
    call_type                   => { type => 'enum', check_in => [ 'UNKNOWNSVC', 'ORIGINATING', 'FORWARDING', 'TERMINATING', 'MAPSVC', 'UNIVERSALBAL' ], not_null => 1, default => 'UNKNOWNSVC' },
    quota_request_counts        => { type => 'integer', default => '0' },
    skip_billing_code           => { type => 'integer', default => '0' },
    intl_rate_description       => { type => 'varchar', length => 45, default => '' },
  ],

  primary_key_columns => [ 'id' ],

  relationships =>
    [
      charge_logs =>
      {
        type       => 'one to many',
        class      => 'OCS::DB::Session::ChargeLog',
        column_map => { session_id => 'session_id' },
      },
    ],
);

sub set_start_time
	{
	my $self = shift;
	$self->start_time(Site::DateUtils->get_formatted_timestamp('-'));
	}

sub set_end_time
	{
	my $self = shift;
	$self->end_time(Site::DateUtils->get_formatted_timestamp('-'));
	}

1;

__END__