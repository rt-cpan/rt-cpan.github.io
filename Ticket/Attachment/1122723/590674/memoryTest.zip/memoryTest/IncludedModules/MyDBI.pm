package Site::MyDBI;

use strict;
use Rose::DB;
use Data::Dumper;
use base qw(Rose::DB);
use base qw(Site::Errors);
use base qw(Site::PerformanceMonitor);


__PACKAGE__->register_db(
		driver		=> 'mysql',
		database 	=> 'global',
		host		=> 'xxx.xxx.xxx.xxx',
		username	=> 'xxxxxx',
		password	=> 'xxxxxx',
		);


__PACKAGE__->register_db(
		domain		=> 'DEVELOPMENT',
		type		=> 'main',
		driver		=> 'mysql',
		database 	=> 'loca',
		host		=> 'localhost',
		username	=> 'xxxxxx',
		password	=> 'xxxxxx',
#		server_time_zone => 'UTC',
		);


__PACKAGE__->register_db(
		domain		=> 'PRODUCTION',
		type		=> 'main',
		driver		=> 'mysql',
		database 	=> 'OCS100',
		host		=> 'xxx.xxx.xxx.xxx',
		username	=> 'xxxxxx',
		password	=> 'xxxxxx',
#		server_time_zone => 'UTC',
		);

my $GLOBAL_OPTIONS = {
	domain => Site::MyConfig->getDomain,
	type => 'main',
	};

__PACKAGE__->default_domain($GLOBAL_OPTIONS->{'domain'});
__PACKAGE__->default_type($GLOBAL_OPTIONS->{'type'});

sub sth
	{
	my $self = shift;
	if (@_) { $self->{STH_HANDLE} = shift };
	return $self->{STH_HANDLE};
	}

sub numrows
	{
	my $self = shift;
	if (@_) { $self->{STH_NUMROWS} = shift };
	return $self->{STH_NUMROWS};
	}

sub query_data
	{
	my $self = shift;
	if (@_) { $self->{TABLE_ARRAY} = shift };
	return $self->{TABLE_ARRAY};
	}

sub query_field_number
	{
	my $self = shift;
	if (@_) { $self->{QUERY_FIELD_NUMBER} = shift };
	return $self->{QUERY_FIELD_NUMBER};
	}

sub select
	{
	my $self = shift;
	my $statement = shift;
	my $useResult = shift; ## option to fetch row by row, vs DBI gathering all rows at once
	my $obref = {};

	#print STDERR "\n" . $statement;

	my $dbh = $self->dbh;

	my $sth = $dbh->prepare($statement);
	$sth->{'mysql_use_result'} = 1 if ($useResult);

	unless ($sth->execute)
		{
		$self->add_internal_error({
			DESCRIPTION => "Full query: $statement; failed due to $DBI::errstr",
			MESSAGE => 'Query failed to execute',
			});
		return undef;
		}

	unless (my $names = $sth->{NAME})
		{
		$self->add_internal_error({
			DESCRIPTION => $DBI::errstr,
			MESSAGE => 'Query did not return field names',
			});
		return undef;
		}

	bless($obref);

	my $tbl_ary_ref = $sth->fetchall_arrayref;
	$obref->query_data($tbl_ary_ref);
	$obref->numrows(scalar @$tbl_ary_ref);
	$obref->sth($sth);

	return $obref;
	}

sub fetchrow
	{
	my $self = shift;
	my $rowno = shift;
	my $return_hash = {};

	return undef unless ($rowno >= 0);

	my $row_data_array = $self->query_data->[$rowno];
	my $field_count = $self->query_field_number;

	if (!$field_count)
		{
		$field_count = scalar @$row_data_array;
		$self->query_field_number($field_count)
		}

	for (my $i = 0; $i < $field_count; $i++)
		{
		my $fieldname = $self->sth->{NAME}->[$i];
		$return_hash->{$fieldname} = $row_data_array->[$i];
		}

	if ($rowno == $self->numrows)
		{
		$self->sth->finish;
		}

	return $return_hash;
	}

1;

__END__