package OCS::DB;

use strict;
use base qw(Rose::DB::Object);

sub myDBI
	{
	my $self = shift;
	if (@_) { $self->{db} = shift }
	return $self->{db};
	}

sub to_string
	{
	my $self = shift;
	my $columns = $self->meta->column_names; #column_accessor_methods
	my $to_str = "";
	foreach my $column (@$columns)
		{
		$to_str .= "\n$column: " . $self->$column;
		}

	#print STDERR "\n" . caller . "To str: " . Dumper($to_str);
	return $to_str;
	}

1;

__END__