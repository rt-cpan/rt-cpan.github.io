use strict; use warnings;
use POE;

sub cmd_quit {
	my ($heap, $input, $wheel_id) = @_;
	$heap->{client}->{$wheel_id}->put("007 Bye-bye!");
	# And destroy the socket right after the next flush.
	$heap->{kill_after_flush} = 1;
}

1;
