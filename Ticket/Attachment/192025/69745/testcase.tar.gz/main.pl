#!/usr/bin/perl
use warnings;
use strict;

use POE qw(Wheel::SocketFactory Wheel::ReadWrite);

require "functions.pl";

POE::Session->create (
	inline_states => {
		_start => \&server_start,
		server_accepted => \&server_accepted,
		server_error	=> \&server_error,
		client_input	=> \&client_input,
		client_error	=> \&client_error,
		socket_flush	=> \&socket_flush,
	}
);

print "Running.\n";
POE::Kernel->run();
exit;

sub server_start {
	$_[HEAP]->{server} = POE::Wheel::SocketFactory->new (
		BindPort => 24680,
		SuccessEvent => "server_accepted",
		FailureEvent => "server_error",
	);
}

sub server_accepted {
	my $socket = $_[ARG0];
	my $wheel = POE::Wheel::ReadWrite->new (
		Handle => $socket,
		InputEvent => "client_input",
		ErrorEvent => "client_error",
		FlushedEvent => "socket_flush",
		);
	$_[HEAP]->{client}->{ $wheel->ID() } = $wheel;
	
	$wheel->put("001 (Here comes a message, it's removed in this test case)");
	sub do_shutdown {
		delete $_[HEAP]->{server};
	}
}

sub client_input {
	my ($heap, $input, $wheel_id) = @_[HEAP, ARG0, ARG1 ];
	chomp $input;
	
	# Dngor: I modified this piece that it just calls cmd_quit, no matter what one writes.
	cmd_quit($heap,$input,$wheel_id);
}

sub client_error {
	my ($heap, $error_number, $error_string, $wheel_id) = @_[HEAP, ARG1, ARG2, ARG3];
	#print "Error: $error_number - $error_string\n";
	delete $heap->{client}->{$wheel_id};
}

sub server_error {
	print "Server Error: $!!\n";
	delete $_[HEAP]->{server};
}

sub socket_flush {
	if(defined($_[HEAP]->{kill_after_flush}) and $_[HEAP]->{kill_after_flush}) {
		print "Shutdown bit set, closing connection.\n";
		delete $_[HEAP]->{client}->{$_[ARG0]};
	}
}
