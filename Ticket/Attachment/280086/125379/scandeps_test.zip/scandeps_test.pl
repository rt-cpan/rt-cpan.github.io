use strict;
use warnings;

use Module::ScanDeps;
use Data::Dump qw(dump);

sub test_dependencies(@) {
  my @files = @_;
  my $outputFile = "output_".join('_and_', @files).".txt";
  $outputFile =~ s/\.pl//og;
  print "Working on $outputFile\n";

  open(OUTPUT, "> $outputFile") or die "Couldn't open $outputFile for writing";
  my $dependencies =
    scan_deps(
      files   => \@files,
      recurse => 1,
    );

  print OUTPUT dump($dependencies);
  close OUTPUT or die "Couldn't close $outputFile";
}

test_dependencies('use_strict.pl');
test_dependencies('use_warnings.pl');
test_dependencies('use_strict_+_warnings.pl');
test_dependencies('use_warnings.pl', 'use_strict.pl');
test_dependencies('use_strict.pl', 'use_warnings.pl');
