package MyApp::Model;

use Moose;

with 'MyApp::Roles::iGlue';
with 'MyApp::Roles::iJSON';

__PACKAGE__->meta->make_immutable;
1;
