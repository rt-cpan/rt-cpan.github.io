
package MyApp::Glue::XYZ;

use Moose;

with 'MyApp::Roles::iGlue';
with 'MyApp::Roles::iJSON';

has bar => (is => 'ro', isa => 'Str');

__PACKAGE__->meta->make_immutable;
1;
