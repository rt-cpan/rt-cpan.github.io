
package MyApp::Roles::iJSON;

use Moose::Role;
use MooseX::Storage;

with Storage(format => 'JSON');

1;

