package MyApp::Model::ABC;

use Moose;

extends 'MyApp::Model';

has abc => (is => 'ro', isa => 'Str');

__PACKAGE__->meta->make_immutable;
1;

