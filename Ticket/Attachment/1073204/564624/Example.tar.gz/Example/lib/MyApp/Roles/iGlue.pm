package MyApp::Roles::iGlue;

use Moose::Role;

use MyApp::Glue::XYZ;

has '__glue__' => (
    is => 'ro', 
    lazy_build => 1,
);

sub _build___glue__ {
    my( $self ) = @_;
    return MyApp::Glue::XYZ->new;
}


1;
