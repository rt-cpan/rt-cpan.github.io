use strict;
use warnings;

package t::B; {
    use Object::InsideOut;
}

1;

# EOF
