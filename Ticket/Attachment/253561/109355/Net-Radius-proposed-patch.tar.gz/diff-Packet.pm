--- Net-Radius-1.49/Radius/Packet.pm	2006-08-09 17:15:40.000000000 +0200
+++ Radius/Packet.pm	2006-10-21 15:26:07.054375320 +0200
@@ -144,10 +144,7 @@
 
   my $p_vsa_3com  = "C C N N a*";    
 
-  my %codes  = ('Access-Request'      => 1,  'Access-Accept'      => 2,
-		'Access-Reject'       => 3,  'Accounting-Request' => 4,
-		'Accounting-Response' => 5,  'Access-Challenge'   => 11,
-		'Status-Server'       => 12, 'Status-Client'      => 13);
+  my %codes  = $self->{Dict}->packet_numbers();
   my $attstr = "";                # To hold attribute structure
   # Define a hash of subroutine references to pack the various data types
   my %packer = (
@@ -247,10 +244,7 @@
   my $dict = $self->{Dict};
   my $p_hdr  = "C C n a16 a*";    # Pack template for header
   my $p_attr = "C C a*";          # Pack template for attribute
-  my %rcodes = (1  => 'Access-Request',      2  => 'Access-Accept',
-		3  => 'Access-Reject',       4  => 'Accounting-Request',
-		5  => 'Accounting-Response', 11 => 'Access-Challenge',
-		12 => 'Status-Server',       13 => 'Status-Client');
+  my %rcodes = $dict->packet_names();
 
   # Decode the header
   my ($code, $id, $len, $auth, $attrdat) = unpack $p_hdr, $data;
