package ARole;
use Moose::Role;

has 'b' => ( is => 'ro', isa => 'Scalar' );
with 'BRole';

1;
