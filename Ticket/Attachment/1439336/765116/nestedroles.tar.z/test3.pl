use warnings;
use strict;

use ARoleNoWith;

use Moose;
with 'ARole';
with 'BRole';
