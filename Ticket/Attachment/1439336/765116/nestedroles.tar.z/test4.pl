use warnings;
use strict;

use Moose;
with 'ABRole';
