package BRole;
use Moose::Role;

requires qw(b);

1;
