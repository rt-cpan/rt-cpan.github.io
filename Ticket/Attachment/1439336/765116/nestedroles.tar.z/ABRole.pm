package ABRole;
use Moose::Role;
use ARoleNoWith;

with 'ARole';
with 'BRole';

1;
