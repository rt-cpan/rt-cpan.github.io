use warnings;
use strict;

# use ARole;

use Moose;

with 'ARole';
