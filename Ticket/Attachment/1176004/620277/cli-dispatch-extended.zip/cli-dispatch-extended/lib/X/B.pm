package X::B;
use strict;
use base 'CLI::Dispatch::Extended::Command';

use X::B::X;

sub options { 'B=s' };

sub run {

    my $self = shift;

    $self->dump_options( qw[ X B ] );

    X::B::X->run( $self );

}
1;

__END__

=head1 NAME

X::A - x::a
