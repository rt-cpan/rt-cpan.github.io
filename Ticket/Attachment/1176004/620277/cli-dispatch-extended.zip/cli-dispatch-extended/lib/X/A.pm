package X::A;

use strict;
use warnings;

use base 'CLI::Dispatch::Extended::Command';

sub options { 'A=s' };

sub run {

    my $self = shift;

    $self->dump_options( qw[ X A ] );
}
1;

__END__

=head1 NAME

X::A - x::a
