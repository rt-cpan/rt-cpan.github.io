package X::B::X::C;
use strict;
use base 'CLI::Dispatch::Extended::Command';

sub options { 'C=s' }

sub run {

    my $self = shift;

    $self->dump_options( qw[ X B C ] );

}
1;


__END__

=head1 NAME

X::B::X::C  - x b x c
