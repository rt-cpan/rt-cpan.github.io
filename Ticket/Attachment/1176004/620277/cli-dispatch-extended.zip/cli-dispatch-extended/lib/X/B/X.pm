package X::B::X;
use strict;
use base 'CLI::Dispatch::Extended::SubDispatch';


1;
