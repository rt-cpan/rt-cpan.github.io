package X;
use strict;

use base 'CLI::Dispatch::Extended';

sub options {

    return $_[0]->SUPER::options, 'X=s'
}

1;
