package CLI::Dispatch::Extended;

use strict;
use base 'CLI::Dispatch';

use Config::Tiny;

my %seen;

sub options { 'config|f=s' } ;

sub get_options {

    my $class = shift;

    my %hash = $class->SUPER::get_options( @_ );

    # only handle config arg for the first call to get_options in this
    # class, which is for the global config.

    if ( ! $seen{$class}++ ) {

	my $config;

	if ( exists $hash{config} ) {

	    $config = Config::Tiny->read( delete $hash{config} )
	      or die Config::Tiny->errstr;

	    %hash = ( %{$config->{_}}, %hash );

	}

	else {

	    $config = { '_' => {} };

	}

	$hash{_config} = $config;

    }

    return %hash;
};

1;
