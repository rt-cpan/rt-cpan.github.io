package CLI::Dispatch::Extended::Command;

use strict;
use warnings;

use base 'CLI::Dispatch::Command', 'CLI::Dispatch::Extended::Utils';

use CLI::Dispatch::Help;

use CLI::Dispatch::Extended::Utils;


sub set_options {

    my ( $self, %options ) = @_;

    $self->add_to_command_path( \%options );

    $self->SUPER::set_options( $self->cmd_config_options( \%options ), %options );

}

sub dump_options {

    my $self = shift;

    my $class = ref $self;

    print join( "\n",
		map { join( '', "$class: $_ = ", $self->option( $_ ) ) }
		@_
		),  "\n";


}

1;
