package CLI::Dispatch::Extended::SubDispatch;

use strict;
use warnings;
use base 'CLI::Dispatch', 'CLI::Dispatch::Extended::Utils';

use CLI::Dispatch::Help;

my %cache;

sub get_options {

    my $class = shift;

    # load inherited options from higher levels
    # into the global options.
    my %ihash = %{ delete $cache{$class} || {} };

    return %ihash, $class->SUPER::get_options(  @_ );
};

# augment run so can pass in higher level options; otherwise
# they will get lost
sub run {

    my ( $class, $options ) = @_;

    $cache{$class} = { %{$options} };

    $class->SUPER::run;

}

1;
