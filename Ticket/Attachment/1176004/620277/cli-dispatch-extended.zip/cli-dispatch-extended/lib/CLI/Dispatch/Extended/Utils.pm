package CLI::Dispatch::Extended::Utils;

use strict;
use warnings;

use CLI::Dispatch::Help;

sub add_to_command_path {

    my ( $self, $options ) = @_;

    $options->{_command_path} = []
      unless defined $options->{_command_path};

    my $class = ref $self || $self;

    ( my $name = $class ) =~ s/.*:://;

    push @{$options->{_command_path}}, 
      CLI::Dispatch::Help->convert_command( $name );

    return unless exists $options->{_config};

}

sub fq_cmd {

    my ( $self, $options ) = @_;

    return join( '.', @{$options->{_command_path}} );

}

sub cmd_config_options {

    my ( $self, $options ) = @_;

    my $fq_cmd = $self->fq_cmd( $options );

    return defined $options->{_config}{$fq_cmd}
           ? %{ $options->{_config}{$fq_cmd} }
	   : ();

}


1;
