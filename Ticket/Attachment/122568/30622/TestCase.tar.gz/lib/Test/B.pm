package Test::B;

use strict;
use warnings;

Test->set('b');

1;
