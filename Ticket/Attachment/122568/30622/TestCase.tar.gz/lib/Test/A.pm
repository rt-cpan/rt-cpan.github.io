package Test::A;

use strict;
use warnings;

Test->set('a');

1;
