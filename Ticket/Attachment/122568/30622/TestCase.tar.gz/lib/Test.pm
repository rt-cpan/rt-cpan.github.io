package Test;

use strict;
use warnings;

use Test2;
use Data::Dumper;

my %hash;

sub set {
  $hash{$_[1]} = '';
};

sub handler {
  print Dumper \%hash; 
} 

use Test::A;
use Test::B;

1;
