#!/usr/bin/perl -w
# Function: bug replicator perl 2.26
# Note: alarm() with negative argument at /usr/perl5/5.26/lib/IPC/Cmd.pm line 1312.
# History:
#  1.0  20200602 LA  Genesis
#---------------------------------------------------------------------------

# Perl modules
#-------------
use IPC::Cmd qw[run];

my $cmdHook = "/usr/bin/ls";
my $cmdHookBuffer;
my $hookTimeout = 60;
for (my $cnt=0;$cnt<10;$cnt++) {
    printf("Run %s\n",$cnt);
    run( command => $cmdHook,
         buffer  => \$cmdHookBuffer,
         timeout => \$hookTimeout );
    sleep 1;
}