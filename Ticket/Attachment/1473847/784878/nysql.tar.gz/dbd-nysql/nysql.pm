package DBD::nysql;

use strict;
use warnings;

use DBI;
use parent 'DynaLoader';

our $VERSION = '4.031';

bootstrap DBD::nysql $VERSION;


our $drh = undef;

sub driver
{
	return $drh if $drh;
	my ($class, $attr) = @_;

	$class .= "::dr";

	$drh = DBI::_new_drh($class, {
			Name    => 'nysql',
			Version => $VERSION,
		})
		or return undef;

	return $drh;
}


1;
