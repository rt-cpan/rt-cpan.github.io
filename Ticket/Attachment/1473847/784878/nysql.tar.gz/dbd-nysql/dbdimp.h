#define PERL_NO_GET_CONTEXT

#include <DBIXS.h>

struct imp_drh_st {
	dbih_drc_t com;
};

struct imp_dbh_st {
	dbih_dbc_t com;
};

struct imp_sth_st {
	dbih_stc_t com;
};

#include <dbd_xsh.h>
