#include "dbdimp.h"

DBISTATE_DECLARE;

void dbd_init(dbistate_t* dbistate)
{
	DBISTATE_INIT;
}

int dbd_db_commit(SV* dbh, imp_dbh_t* imp_dbh)
{
	return TRUE;
}

int dbd_db_STORE_attrib(SV* dbh, imp_dbh_t* imp_dbh, SV* keysv, SV* valuesv)
{
	STRLEN kl;
	char *key = SvPV(keysv, kl);
	const bool bool_value = SvTRUE(valuesv);

	if (kl==10 && strEQ(key, "AutoCommit"))
	{
		bool oldval = DBIc_has(imp_dbh,DBIcf_AutoCommit) ? 1 : 0;

		if (bool_value == oldval)
			return TRUE;

		DBIc_set(imp_dbh, DBIcf_AutoCommit, bool_value);

		return TRUE;
	}

	return FALSE;
}

SV* dbd_db_FETCH_attrib(SV *dbh, imp_dbh_t *imp_dbh, SV *keysv)
{
	STRLEN kl;
	char *key = SvPV(keysv, kl);

	if (kl==10 && strEQ(key, "AutoCommit"))
	{
		return sv_2mortal(boolSV(DBIc_has(imp_dbh,DBIcf_AutoCommit)));
	}

	return &PL_sv_yes;
}

