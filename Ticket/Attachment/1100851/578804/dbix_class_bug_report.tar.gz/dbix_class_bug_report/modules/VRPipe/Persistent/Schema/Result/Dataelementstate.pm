use utf8;
package VRPipe::Persistent::Schema::Result::Dataelementstate;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

=head1 NAME

VRPipe::Persistent::Schema::Result::Dataelementstate

=cut

use strict;
use warnings;

use base 'DBIx::Class::Core';

=head1 TABLE: C<dataelementstate>

=cut

__PACKAGE__->table("dataelementstate");

=head1 ACCESSORS

=head2 pipelinesetup

  data_type: 'integer'
  is_foreign_key: 1
  is_nullable: 0

=head2 dataelement

  data_type: 'integer'
  is_foreign_key: 1
  is_nullable: 0

=head2 id

  data_type: 'integer'
  is_auto_increment: 1
  is_nullable: 0

=head2 completed_steps

  data_type: 'smallint'
  default_value: 0
  is_nullable: 0

=cut

__PACKAGE__->add_columns(
  "pipelinesetup",
  { data_type => "integer", is_foreign_key => 1, is_nullable => 0 },
  "dataelement",
  { data_type => "integer", is_foreign_key => 1, is_nullable => 0 },
  "id",
  { data_type => "integer", is_auto_increment => 1, is_nullable => 0 },
  "completed_steps",
  { data_type => "smallint", default_value => 0, is_nullable => 0 },
);

=head1 PRIMARY KEY

=over 4

=item * L</id>

=back

=cut

__PACKAGE__->set_primary_key("id");

=head1 RELATIONS

=head2 dataelement

Type: belongs_to

Related object: L<VRPipe::Persistent::Schema::Result::Dataelement>

=cut

__PACKAGE__->belongs_to(
  "dataelement",
  "VRPipe::Persistent::Schema::Result::Dataelement",
  { id => "dataelement" },
  { is_deferrable => 1, on_delete => "CASCADE", on_update => "CASCADE" },
);

=head2 pipelinesetup

Type: belongs_to

Related object: L<VRPipe::Persistent::Schema::Result::Pipelinesetup>

=cut

__PACKAGE__->belongs_to(
  "pipelinesetup",
  "VRPipe::Persistent::Schema::Result::Pipelinesetup",
  { id => "pipelinesetup" },
  { is_deferrable => 1, on_delete => "CASCADE", on_update => "CASCADE" },
);


# Created by DBIx::Class::Schema::Loader v0.07025 @ 2012-07-19 11:03:33
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:ZALrqsrClMQNiUnujQmMgA


# You can replace this text with custom code or comments, and it will be preserved on regeneration
1;
