package VRPipeTest;
use strict;
use warnings;
use base 'Test::DBIx::Class';

sub _initialize_schema {
    my $class = shift;
    
    my $config = { schema_class     => 'VRPipe::Persistent::Schema',
                   force_drop_table => 1,
                   keep_db          => 1,
                   # following args are dsn, username, password
                   connect_info     => ['dbi:mysql:database='.$ENV{vrpipe_testing_db}.';host='.$ENV{vrpipe_testing_host}.';port='.$ENV{vrpipe_testing_port}, $ENV{vrpipe_testing_username}, $ENV{vrpipe_testing_password}] };
    
    return $class->SUPER::_initialize_schema($config);
}

1;
