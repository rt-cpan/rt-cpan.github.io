#!/usr/bin/perl

use warnings;
use strict;
use Time::HiRes;

BEGIN {
	die "POE::Component::Client::Ping requires root privilege\n" if $> and ( $^O ne 'VMS' );
}

use Tk;
use POE;
use POE::Component::Client::Ping;

my $debugging = 1;

# How many seconds to wait for ping responses.
use constant PING_TIMEOUT => 1;

# How many seconds to wait between sending consecutive pings to one address.
use constant DELAY_BETWEEN_PINGS => 2;

#------------------------------------------------------------------------------
# Addresses to ping

my @addresses = qw( 192.168.1.1 192.168.1.88 192.168.1.89 192.168.1.2 );
# 1.2 and 1.2 exist on my test network, and will reply
# 1.88 and 1.89 don't exist, so will not reply

#------------------------------------------------------------------------------
# Create the main session, responsible for the main window.

POE::Session->create (
	inline_states => {
		_start => \&main_start,
		quit => \&main_quit
	},
);

$poe_kernel->run();
exit;

#------------------------------------------------------------------------------
# Event handlers.

sub main_start {
	my ( $kernel, $session, $heap ) = @_[ KERNEL, SESSION, HEAP ];

	if ($debugging) {
		print "main _start event\n";
	}

	$poe_main_window->Button(
		-text => "Quit",
		-command => $session->postback("quit")
	)->pack;

	# Create a pinger component.  This will do the work of multiple
	# concurrent pings.  It requires another session to interact with it.

	POE::Component::Client::Ping->spawn (
		Alias => 'pinger',		# The component's name.
		Timeout => PING_TIMEOUT,	# The default ping timeout.
		OneReply  => 1			# We only want one reply
	);

	foreach my $address (@addresses) {
		POE::Session->create (
			inline_states => {
				_start => \&client_start,
				send_ping => \&client_send_ping,
				receive_pong => \&client_receive_pong
			},
			args => [$address]
		);
	}
}

sub main_quit {

	if ($debugging) {
		print "quit event\n";
	}
	exit;
}

sub client_start {
	my ( $kernel, $session, $heap, $address ) = @_[ KERNEL, SESSION, HEAP, ARG0 ];

	if ($debugging) {
		print "client _start event for session ", $session->ID, "\n";
	}

	$heap->{address} = $address;

	my $session_frame = $poe_main_window->Frame(
		-label => "Pinging $address",
		-borderwidth => 2,
		-relief => 'groove'
	)->pack;

	my $latest_result_frame = $session_frame->Frame()->pack;
	my $counters_frame = $session_frame->Frame()->pack;
	my $sent_frame = $counters_frame->Frame()->pack(-side => 'left');
	my $replies_frame = $counters_frame->Frame()->pack(-side => 'left');
	my $timedout_frame = $counters_frame->Frame()->pack(-side => 'left');

	$latest_result_frame->Label(
		-text => "Latest:"
	)->pack(-side => 'left');

	$heap->{latest_result} = "";

	$latest_result_frame->Label(
		-textvariable => \$heap->{latest_result}
	)->pack(-side => 'left');

	$sent_frame->Label(
		-text => "Sent"
	)->pack(-side => 'left');

	$heap->{sent_count} = 0;

	$sent_frame->Label(
		-textvariable => \$heap->{sent_count}
	)->pack(-side => 'left');

	$replies_frame->Label(
		-text => "Replies"
	)->pack(-side => 'left');

	$heap->{replies_count} = 0;

	$replies_frame->Label(
		-textvariable => \$heap->{replies_count}
	)->pack(-side => 'left');

	$timedout_frame->Label(
		-text => "Timed out"
	)->pack(-side => 'left');

	$heap->{timedout_count} = 0;

	$timedout_frame->Label(
		-textvariable => \$heap->{timedout_count}
	)->pack(-side => 'left');

	$kernel->yield("send_ping");
}

sub client_send_ping {
	my ( $kernel, $session, $heap ) = @_[ KERNEL, SESSION, HEAP ];
	my $address = $heap->{address};

	if ($debugging) {
		print "send_ping event for session ", $session->ID, "\n";
	}

	# "Pinger, do a ping and return the results as a receive_pong event.  The
	# address to ping is $address."

	$kernel->post( 'pinger' => ping => receive_pong => $address );
	$heap->{sent_count}++;
	$kernel->delay_set( "send_ping", DELAY_BETWEEN_PINGS );
}

sub client_receive_pong {
	my ( $kernel, $session, $heap ) = @_[ KERNEL, SESSION, HEAP ];

	if ($debugging) {
		print "receive_pong event for session ", $session->ID, "\n";
	}

	# The original request is returned as the first parameter.  It
	# contains the address we wanted to ping, the total time to wait for
	# a response, and the time the request was made.

	my $request_packet = $_[ARG0];
	my ( $request_address, $request_timeout, $request_time ) = @{$request_packet};

	# The response information is returned as the second parameter.  It
	# contains the response address (which may be different from the
	# request address), the ping's round-trip time, and the time the
	# reply was received.

	my $response_packet = $_[ARG1];
	my ( $response_address, $roundtrip_time, $reply_time ) = @{$response_packet};

	if ( defined $response_address ) {
		$heap->{replies_count}++;
		$heap->{latest_result} = sprintf( "roundtrip %6.3fs", $roundtrip_time);
		if ($debugging) {
			print "$heap->{latest_result} for session ", $session->ID, "\n";
		}
	}
	else {
		$heap->{timedout_count}++;
		$heap->{latest_result} = "no reply";
		if ($debugging) {
			print "$heap->{latest_result} for session ", $session->ID, "\n";
		}
	}
}
