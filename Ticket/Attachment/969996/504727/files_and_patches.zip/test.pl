# Before `make install' is performed this script should be runnable with
# `make test'. After `make install' it should work as `perl test.pl'

######################### We start with some black magic to print on failure.

# Change 1..1 below to 1..last_test_to_print .
# (It may become useful if the test is moved to ./t subdirectory.)

BEGIN { $| = 1; print "1..4\n"; }
END {print "not ok 1\n" unless $loaded;}
use Net::Z3950::SimpleServer;
$loaded = 1;
print "ok 1\n";

######################### End of black magic.

print "not " if Net::Z3950::SimpleServer::yaz_diag_srw_to_bib1(11) != 3;
print "ok 2\n";

print "not " if Net::Z3950::SimpleServer::yaz_diag_bib1_to_srw(3) != 11;
print "ok 3\n";

# Insert your test code below (better if it prints "ok 13"
# (correspondingly "not ok 13") depending on the success of chunk 13
# of the test code):

sub my_init_handler {
	my $href = shift;
	my %log = ();

	$log{"init"} = "Ok";
	$href->{HANDLE} = \%log;
}

sub my_search_handler {
	my $href = shift;
	my %log = %{$href->{HANDLE}};

	$log{"search"} = "Ok";
	$href->{HANDLE} = \%log;
	$href->{HITS} = 1;
}

sub my_fetch_handler {
	my $href = shift;
	my %log = %{$href->{HANDLE}};
	my $record = "<xml><head>Headline</head><body>I am a record</body></xml>";

	$log{"fetch"} = "Ok";
	$href->{HANDLE} = \%log;
	$href->{RECORD} = $record;
	$href->{LEN} = length($record);
	$href->{NUMBER} = 1;
	$href->{BASENAME} = "Test";
}

sub my_close_handler {
	my @services = ("init", "search", "fetch", "close");
	my $href = shift;
	my %log = %{$href->{HANDLE}};
	my $status;
	my $service;
	my $error = 0;

	$log{"close"} = "Ok";

	print "\n-----------------------------------------------\n";
	print "Available Z39.50 services:\n\n";

	foreach $service (@services) {
		print "Called $service: ";
		if (defined($status = $log{$service})) {
			print "$status\n";
		} else {
			print "FAILED!!!\n";
			$error = 1;
		}
	}
	if ($error) {
		print "make test: Failed due to lack of required Z39.50 service\n";
	} else {
		print "\nEverything is ok!\n";
	}
	print "-----------------------------------------------\n";
	print "not " if $error;
	print "ok 4\n";
}

if ($^O ne "MSWin32") {
	my $socketFile = "/tmp/SimpleServer-test-$$";
	my $socket = "unix:$socketFile";

	if (!defined($pid = fork() )) {
		die "Cannot fork: $!\n";
	} elsif ($pid) {                                        ## Parent launches server
		my $handler = Net::Z3950::SimpleServer->new(
			INIT		=>	\&my_init_handler,
			CLOSE		=>	\&my_close_handler,
			SEARCH		=>      \&my_search_handler,
			FETCH		=>	\&my_fetch_handler);

		$handler->launch_server("test.pl", "-1", $socket);
	} else {						## Child starts the client
		sleep(1);
		open(CLIENT, "| yaz-client $socket > /dev/null")
			or die "Couldn't fork client: $!\n";
		print CLIENT "f test\n";
		print CLIENT "s\n";
		print CLIENT "close\n";
		print CLIENT "quit\n";
		close(CLIENT) or die "Couldn't close: $!\n";
		unlink($socketFile);
	}
}
else {
	print <<ENDOFWARNING;

==============================================================================
To conduct a server test on Windows this program must be able to open and
communicate to a port on this machine through a valid IP address.

By default it will try to use IP 127.0.0.1 and port 9999, but it will give you
the chance of changing them.

It's very likely that the specified port needs to be open in the Windows
Firewall.  You can interrupt the program right now and go open the port on the
firewall or you can continue and the program will try to establish a temporary
rule via "netsh advfirewall firewall".

Also it's absolutely necessary for this program to find "yaz-client" in the
PATH.  If "YAZ/bin" is not already there, please interrupt the program and do
"set PATH" before running it again.
==============================================================================

Press [Enter] to continue or Ctrl-C to interrupt...
ENDOFWARNING

	<STDIN>;

	my $test_ip = "127.0.0.1";
	print "Test on this IP address [${test_ip}]: ";
	$_ = <STDIN>; chomp;
	$test_ip = $_ ? $_ : $test_ip;

	my $test_port = "9999";
	print "Test on this TCP port [${test_port}]: ";
	$_ = <STDIN>; chomp;
	$test_port = $_ ? $_ : $test_port;

	print qq(Trying to add firewall rule for port $test_port...\n);
	system(qq(netsh advfirewall firewall add rule name="Net::Z3950::SimpleServer temporary test rule" dir=in protocol=tcp localport=${test_port} action=allow));

	if ( !defined( $pid = fork() ) ) {
		die "Cannot fork: $!\n";
	} elsif ($pid) {		## Parent launches server
		my $handler = Net::Z3950::SimpleServer->new(
			INIT	=>	"main::my_init_handler",
			CLOSE	=>	"main::my_close_handler",
			SEARCH	=>      "main::my_search_handler",
			FETCH	=>	"main::my_fetch_handler");

		$handler->launch_server("test.pl", "-1", "tcp:${test_ip}:${test_port}");
	} else {			## Child starts the client
		sleep(1);
		open(CLIENT, "| yaz-client tcp:${test_ip}:${test_port}")
			or die "Couldn't fork client: $!\n";
		print CLIENT "f test\n";
		print CLIENT "s\n";
		print CLIENT "close\n";
		print CLIENT "quit\n";
		sleep(1);
		close(CLIENT) or die "Couldn't close: $!\n";

		sleep(1);
		print qq(Trying to remove firewall rule for port $test_port...\n);
		system('netsh advfirewall firewall delete rule name="Net::Z3950::SimpleServer temporary test rule"');

		print "Everything is done.  Please review the results report above.\n\nCtrl-C to exit.\n";
	}
}
