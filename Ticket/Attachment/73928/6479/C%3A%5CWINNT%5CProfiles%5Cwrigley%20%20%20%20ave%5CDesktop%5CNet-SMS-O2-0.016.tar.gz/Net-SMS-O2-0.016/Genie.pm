package Net::SMS::Genie;
require Net::SMS::O2;
use vars qw( @ISA );
@ISA = qw( Net::SMS::O2 );
