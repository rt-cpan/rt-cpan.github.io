    ExcludeFromDigestGeneration('in-files' => qr/\.in$/);
    AddRule 'target', [ 'file.target' => 'file.in' ] =>
	'cat %DEPENDENCY_LIST > %FILE_TO_BUILD';
