sub CreateLog {
    my ($pbs_config, $dependency_tree, $inserted_nodes, $build_sequence, $build_node) = @_ ;
    print "Test plugin\n";
}

1 ;

