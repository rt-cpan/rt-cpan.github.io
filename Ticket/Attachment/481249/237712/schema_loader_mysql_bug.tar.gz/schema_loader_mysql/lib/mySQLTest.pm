package mySQLTest;

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_classes;


# Created by DBIx::Class::Schema::Loader v0.04005 @ 2008-07-01 11:06:57
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:mdaau5Qyxb9haXhTz9h8Kw


# You can replace this text with custom content, and it will be preserved on regeneration
1;
