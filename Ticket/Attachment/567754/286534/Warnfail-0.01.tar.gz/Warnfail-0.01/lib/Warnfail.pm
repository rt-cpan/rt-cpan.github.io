package Warnfail;

our $VERSION = 0.01;

sub warnfail {
    return 1 > undef;
}

1;
