#!/usr/bin/perl -w

use strict;

use XML::Simple;
use Net::SSH::Perl;
use Data::Dumper;

#Beginning XML object for parsing

my $xml = new XML::Simple;
my $xmlData = $xml->XMLin("config.xml");

# Command to be executed vi SSH
my $cmd = "hostname -i";

# Define the variables from our prior processed XML
my $hostname = $xmlData->{"location"}->{"system"}->{"hostname"};
my $user = $xmlData->{"location"}->{"system"}->{"username"};
my $pass = $xmlData->{"location"}->{"system"}->{"password"};

# Bug #49102, https://rt.cpan.org/Public/Bug/Display.html?id=49102
# This is required in order to handle the UTF-8 characters returned by LibXML
utf8::downgrade($user);
utf8::downgrade($pass);
utf8::downgrade($hostname);

# Execute SSH connection and Login
my $ssh = Net::SSH::Perl->new($hostname, compression => 0, debug => 0);
$ssh->login($user,$pass) or die $!;

# Execute command
my ($out, $err, $exit) = $ssh->cmd($cmd);

# Dump output
print Dumper($out);
