\encoding utf-8
create table test1 (a text);
insert into test1 values ('あいう');
create table test2 (a text[]);
insert into test2 values (array['あ', 'い', 'う']);
