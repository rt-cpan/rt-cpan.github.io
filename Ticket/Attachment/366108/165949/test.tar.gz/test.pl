#!/usr/bin/perl

use strict;
use warnings;
use DBI;
use Encode;

my $dbh = DBI->connect('dbi:Pg:dbname=test', undef, undef, {pg_enable_utf8=>1});
my @ret;

@ret = $dbh->selectrow_array('select * from test1');
print "-------\n";
print "test1: \n";
print Encode::encode_utf8($ret[0]), "\n";                  # from perl string
print $ret[0], "\n";                                       # WARNING
print Encode::is_utf8($ret[0]), "\n";                      # true


@ret = $dbh->selectrow_array('select * from test2');
print "-------\n";
print "test2: \n";
print Encode::encode_utf8($ret[0]), "\n";                  # from utf-8 octet
print $ret[0], "\n";                                       # show normary
print Encode::is_utf8($ret[0]), "\n";                      # false <- want 'true'
print "-------\n";
