#!/usr/bin/perl

use strict;
use warnings;

#use lib '.';
use Net::FTP;

my $host     = 'ftp.ti.com';
my $login    = 'anonymous';
my $password = 'troyl@ti.com';

my $proxy_host     = 'gate.ti.com';
my $proxy_login    = '<proxy_login>';
my $proxy_password = '<proxy_password>';


my $ftp = Net::FTP->new( $host,
                         Firewall     => $proxy_host,
                         FirewallType => 7,   # see Net::Config
                         Debug        => 1,
                       )
  or die "ERROR: ", $@, " ";

$ftp->login( $login, $password )
  or die "ERROR: ", $ftp->message, " ";

$ftp->authorize( $proxy_login, $proxy_password )
  or die "ERROR: ", $ftp->message, " ";

$ftp->quit
  or die "ERROR: ", $ftp->message, " ";

exit 0;
