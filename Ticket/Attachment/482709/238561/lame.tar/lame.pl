#!/usr/bin/perl

use strict;
use warnings;

use Template;
my $tt = Template->new({
    INCLUDE_PATH    => '/tmp/lame',
    RELATIVE        => 1,
 #  DEBUG           => 'all',
}) || die "lame!\n";

$tt->process('foo.html');

warn "done with top level\n\n\n";

$tt->process('lamer/foo.html');

warn "done with second level\n\n\n";

