use Tk;

my $main = new MainWindow;
my $image_f = $main->Frame(-width => 100);
$image_f->pack();
my $filename = 'fails.xpm'; # this one fails!
# $filename = 'ok.xpm'; # this get's loaded
my $thumbnail_p = $main->Photo();
$thumbnail_p->configure(-file => $filename);
my $form_l = $image_f->Label(-image => $thumbnail_p);
$form_l->pack();

MainLoop;
