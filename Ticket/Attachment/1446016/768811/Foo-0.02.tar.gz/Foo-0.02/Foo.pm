package Foo;

=head1 NAME

Foo - The great new Foo!

=head1 VERSION

Version __VERSION__

=cut

1;
