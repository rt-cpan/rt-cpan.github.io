#!/home/utils/perl-5.8.8/bin/perl
use strict;

$SIG{INT} = sub {
	print STDERR "GOT INT SIGNAL " . time() . "\n";
};
$SIG{CONT} = sub {
	print STDERR "GOT CONT SIGNAL " . time() . "\n";
};
$SIG{TERM} = sub {
	print STDERR "GOT TERM SIGNAL " . time() . "\n";
#	exit(1);
};
$SIG{KILL} = sub {
	print STDERR "GOT KILL SIGNAL " . time() . "\n";
	exit(1);
};

my $ppid = getppid();

print "$0: PID=$$, PPID=$ppid\n";

my $count_down = 100;
while ($count_down) {
	print STDERR "count: $count_down\n";
	sleep 5;
	$count_down--;
}
