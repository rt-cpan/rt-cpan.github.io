use Test::More 'no_plan';
use Spiffy -Base;
use strict;
use warnings;
use lib 'lib';
use Clipboard;
