#!/usr/bin/env perl

use feature qw/say unicode_strings/;
use open qw(:std :utf8);
use strict;
use warnings;
use warnings qw(FATAL utf8);
use lib 'lib';

use Local::MooDemo1;

# ----------------

my($obj) = Local::MooDemo1 -> new;

say "New returns:      $obj";
say "config() returns: ", $obj -> config;
