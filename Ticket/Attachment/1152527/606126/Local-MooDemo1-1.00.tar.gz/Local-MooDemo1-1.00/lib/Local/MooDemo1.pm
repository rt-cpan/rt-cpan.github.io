package Local::MooDemo1;

use feature qw/say unicode_strings/;
use open    qw/:std :utf8/;

use Moo;
use Moo::Role;

has config =>
(
	default  => sub{return 'A string'},
	is       => 'rw',
	required => 0,
);

our $VERSION = '1.00';

# -----------------------------------------------

sub BUILD
{
	my($self) = @_;

	say 'Initial value of config: ', $self -> config;

} # End of BUILD.

# --------------------------------------------------

1;

=head1 NAME

Local::MooDemo1 - Manage per-module config files

=head1 Synopsis

	#!/usr/bin/env perl

	use strict;
	use warnings;

	use Local::MooDemo1;

	# ----------------

	my($config) = Local::MooDemo1 -> new -> config;

=head1 Description

C<Local::MooDemo1> is a pure Perl module.

=head1 Constructor and initialization

C<< Local::MooDemo1 -> new -> config >> returns a string.

=head1 Author

C<Local::MooDemo1> was written by Ron Savage I<E<lt>ron@savage.net.auE<gt>> in 2006.

Home page: L<http://savage.net.au/index.html>.

=cut
