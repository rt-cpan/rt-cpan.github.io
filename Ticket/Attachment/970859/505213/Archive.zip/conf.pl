#!/usr/bin/perl

# DOT NOT EDIT! This line starts all the magic
Configure->run();

package Configure;
use base qw(CLI::Framework);
use Template;

sub usage_text {
qq {
$0 [--help|h] <subcommand>

OPTIONS:
	--help|h: show help

ARGUMENTS (subcommands):
	hspe:		produce HSPE base build config
	asbr:		produce HSPE iVPN VRFs

}	
}

sub option_spec {
	[ 'help|h' => 'show help' ],
}

sub command_map {
	opendir DIR, 'temp' or die "can't open temp: $!";
	my @platforms = grep { /^[^\.]/ && -d "temp/$_" } readdir DIR;
	
	map { $_ => 'Configure::Platform' } @platforms;
}

# find out which subcommand was given and store it in the cache
sub init {
	my ($self) = @_;
	
	$self->cache->set(platform => $self->get_current_command);
	
	my $template = Template->new(INCLUDE_PATH => 'temp/'. $self->get_current_command);
	die Template->error() unless defined $template;
	$self->cache->set(template => $template);
	
	return 1;

}

####################################################################################################

package Configure::Platform;
use base qw(CLI::Framework::Command);

sub usage_text {
q {
		 hspe-base --hostname <host> --lo0 <IP address> --ospf-area-id <IP address>
		 	--red-ip-address <IP address> --blue-ip-address <IP address> --saa-pop-rt <route target>
		 	--regional-saa-rt <route target>
}
}

# doesn't work, yet ;)
sub option_spec {
#	my ($self, $opt, @args) = @_;
#	my $platform = $self->cache->get('platform');
	
#	opendir DIR, "temp/$platform/" or die "can't open temp: $!";
#	my @templates = grep { /^[^\.]+.tt2/ && -f "temp/$platform" } readdir DIR;
	
#	map { [ "$_=s" => 'description'] } @templates;
	
	[ 'ifd=s' => 'Physical interface' ],
	[ 'mtu=s' => 'MTU for physical interface' ],
}

sub run {
	my ($self, $opt, @args) = @_;
	my $platform = $self->cache->get('platform');
	my $template = $self->cache->get('template');
	my $output;
	
	foreach (@args) {
		die $template->error(), "\n" unless $output = $template->process("$_.tt2", $opt);
		print $output;
	}

}

1;
__END__