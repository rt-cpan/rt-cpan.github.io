# ***************************
# Web sync V1.0 2015-12-14
# Author: Birdal Kocak
# ***************************
use Encode;
use Net::FTPSSL;
use File::Basename;
use IO::Compress::Bzip2 qw(bzip2 $Bzip2Error);
use IO::Uncompress::Bunzip2 qw(bunzip2 $Bunzip2Error);
use File::stat;
use DateTime;
use Time::localtime;
use JSON;
use Time::Piece;
use File::Copy;
use strict;
use warnings;
use Data::Dumper;
use utf8;

my $base_path = 'c:/cronjobs';
my $lock_file = $base_path."/_lock";
my $IS_LOCKED = 0;

# Check if programm is still running
if(-e $lock_file && localtime()->epoch() - localtime(stat($lock_file)->mtime)->epoch() < 86000)
{
	$IS_LOCKED = 1;
	print "Programm is already running!\n" ;
	exit(0);
}
else
{
	open(LOCK_FILE, ">$lock_file") || die "Could not create lock file!\n";
	print LOCK_FILE "Program startet at: ".localtime()->ymd('-')." ".localtime()->hms(':');
	close(LOCK_FILE);
}

sub END {
	if(-e $lock_file && $IS_LOCKED == 0)
	{
		unlink $lock_file;
	}
}

my %config = (
					 'clientdir' 	=> '//Downloads',
					 'remotedir' 	=> '',
					 'host' 			=> '11.11.11.11',
					 'user' 			=> 'USER',
					 'passwd' 		=> 'PASSWD'
					 );
					 
my @folder =  (\%config);
my @files = ();
my @suffixlist = qw(.txt .bz2);
my %timestamp_new = ();

my $logfile 		= sprintf("$base_path/logs/sync_%s.txt", localtime()->ymd('-'));
my $configfile 	= "$base_path/config.json";
my $logdate 		= localtime()->ymd('-')." ".localtime()->hms(':');

#**********************************
#	Read director recursively
#**********************************
sub getFiles 
{
	# Init vars
  my $path = shift;
  my $base_path = shift;
	
  local *DIR;
  my @dir_list = ();
  my $pathtotal = '';

	# Verzeichnis lesen
  opendir(DIR, $path);
	@dir_list = readdir(DIR);
  closedir(DIR);

	#print Dumper(@dir_list)."\n";
	# Addition oder Rekursion für alle gelesenen

  foreach my $row (@dir_list) 
	{	
    next if  ($row =~ /^\.+|.*\.db/);
    $pathtotal = "$path/$row";
		
    if(-d $pathtotal) {
     #print "VERZEICHNIS: $pathtotal\n";			
		 # Recursion
     push(@files, getFiles($pathtotal, $base_path));

    } else {
			(my $folder = $path) =~s/$base_path\/?//g;
			#print "Folder: $folder \n";
			#print "pathtotal: ".$pathtotal." \n";
			#print "Is a plain file!\n" if -f $pathtotal;
			
			my $cdate = localtime(stat(Encode::encode('ISO-8859-15', $pathtotal))->mtime)->epoch();
			$timestamp_new{$path}{$pathtotal} = {"time" => $cdate, "file" => $row, "dir" => $folder};
			#print "Timestamp: $cdate \n";
			push(@files, $pathtotal);
		  #print "DATEI: $row\n";
    }
  }
	#print Dumper(\%timestamp_new)."\n";	
}

#**********************************
#	Upload files
#**********************************
sub SyncData {
	# Parameters
  my $folder = shift;
	my $loop = shift;
	my $buffer;
	my $localtime = localtime()->epoch();
	
	#print LOGFILE "Data sync start: $logdate\n";
		
	# Read timestamp file for comparing
	my $json = '{}';
	my $fh;
	
	local $/; #Enable 'slurp' mode
	
	if(open $fh, "<", $configfile)
	{
		$json = <$fh>;
	} else {
		print "Could not load timestamp list!\n";
		print LOGFILE "Could not load timestamp list!\n";
	}
	
	close $fh;
	
	my $timestamp_old = ();
	my $CREATE_CFG = 0;
	
	eval {
		$timestamp_old = decode_json($json);
		1;
	} or do {
		$CREATE_CFG = 1;
		my $e = $@;
		#print "ASAS $e\n";
	};

	#print Dumper($folder)."\n";	
	
	# Loop through all folder
	while (my($idx, $data) = each(@folder))
	{
		my $host 			= @$data{'host'};
		my $user 			= @$data{'user'};
		my $pass 			= @$data{'passwd'};
		my $clientdir	= @$data{'clientdir'};
		my $remotedir = @$data{'remotedir'};
		
		if(!-e $clientdir || !-d $clientdir){
			print "Folder $clientdir doesn't exist! \n";
			next;
		}
		
		# Read the upload directory and create new timestamp array
		getFiles($clientdir, $clientdir);
		

		#delete $timestamp_new{$folder->{'clientdir'}};
		
		# Use Implicit SSL (FTPS) port 990 I Mode; or 21 E Mode auth TLS
		my $ftps = Net::FTPSSL->new($host, 
																Port => 21,
																Encryption => 'E',
																Debug => 0,
																Timeout => 20) 
			or die "Can't open ftp port";

		$ftps->login($user, $pass) or die "Can't login: ", $ftps->last_message();
		
		# Change to binary mode
		$ftps->binary();

		if(!$CREATE_CFG)
		{
			# *****************************************
			# Delete files from remote ftp 
			# *****************************************
			
			while (my($path, $files) = each(%{$timestamp_old}))
			{
				#print "$path \n";			
				# Loop through files in folder
				
				my $remoteDir = '';
				my $remoteFile = '';
				
				while (my($file, $attr) = each(%{$files}))
				{
					#print Dumper($attr)."\n";
					Encode::encode('ISO-8859-15', $file);
					if(!defined($timestamp_new{$path}{$file}))
					{
						$remoteFile = $attr->{'dir'}.($attr->{'dir'}?"/":"").$attr->{'file'};
						
						# Delete file from remote server
						print LOGFILE "File doesn't exist anymore.\n";
						print LOGFILE "Deleting file from remote: /".$remoteFile."\n";
						print "Deleting file from remote: /".$remoteFile."\n";
						
						if($ftps->delete(Encode::encode('UTF-8',"/".$remoteFile))){
							delete $timestamp_old->{$path}{$path.'/'.$attr->{'file'}};
						}
					}
				}
			}
			
			# *****************************************
			# Delete empty folders from ftp recursively
			# *****************************************
			while (my($path, $files) = each(%{$timestamp_old}))
			{
				# Loop through files in folder
				my $remoteFile = '';
				
				# Get folder which we want to parse
				my $remoteDir = $path =~ s/$folder->{'clientdir'}//r;
				
				# Check if folder contains files
				if(!keys(%{$timestamp_new{$path}}))
				{
					#print "Empty folder: $path \n";
					
					# Split folder hierarchically and check if it's empty locally and sync with ftp
					my @dirs = split /\//, $remoteDir;
					my $recursiveFolder = $path;
					my $sub = '';

					# Delete empty folder from ftp hierarchically
					foreach $sub (sort {$b <=> $a} keys @dirs) 
					{
						# Skip empty rows
						# Skip if base folder
						next if  (!$sub);
						
						# print "Folder:".$dirs[$sub].' Local:'.$recursiveFolder." Remotedir: $remoteDir \n";
						
						my $is_empty = 1;
						for (keys %timestamp_new)
						{		
							my $subFolder = $_."/";
							my $contains = $recursiveFolder."/";
							if($subFolder =~ /$contains/ && keys(%{$timestamp_new{$_}})){
								#print $subFolder." contains $recursiveFolder \n";
								$is_empty = 0;
								last;
							}
						}
						
						if($is_empty)
						{
							print "Directory is empty. Deleting remote directory ".$remoteDir."\n";
							print LOGFILE "Directory is empty. Deleting remote directory ".$remoteDir."\n";
							
							$ftps->rmdir("/".Encode::encode('UTF-8', $remoteDir));
							
							# Delete from timestamp database
							delete $timestamp_old->{$recursiveFolder};
						}

						# Set next higher folder
						$remoteDir = $remoteDir =~ s/\/$dirs[$sub]//r;	
						
						# Retrieve parent folder
						$recursiveFolder = $recursiveFolder =~ s/\/$dirs[$sub]//r;
					}
				}
			}
			
		}

		# *****************************************
		# Loop through folder and upload new files
		# *****************************************
		while (my($path, $files) = each(%timestamp_new))
		{
			#print $path."\n";
			#print Dumper($files)."\n";	

			# Loop through files
			while (my($file, $attr) = each(%{$files}))
			{
				#print Dumper($timestamp_old->{$path}[$id]{$file}{'time'})."\n";

				Encode::encode('ISO-8859-15', $attr);
				Encode::encode('ISO-8859-15', $file);
				
				my $newFile = $attr;
				my $uploadFile = $file;
				
				# Check if file already known
				if(defined $timestamp_old->{$path}{$file})
				{					
					my $oldFile = $timestamp_old->{$path}{$file};
				
					#print "Newtime: ".$newFile->{'time'}." Oldtime: ".$oldFile->{'time'}."\n";
				
					# If file is newer then upload
					if($newFile->{'time'} ne $oldFile->{'time'})
					{
						# Change to working directory on ftp server
						print LOGFILE "Changing director to: ".$newFile->{'dir'}."\n";
						
						# Change working directory
						if($ftps->cwd("/".Encode::encode('UTF-8', $newFile->{'dir'})))
						{
							print "Uploading file:".$uploadFile."\n";
							print LOGFILE "Uploading file:".$uploadFile."\n";
							
							if(!$ftps->put($uploadFile, Encode::encode('UTF-8', $newFile->{'file'}))){
								print "Upload failed:".$ftps->last_message()."\n";
								print LOGFILE "Upload failed:".$ftps->last_message()."\n";
							} else {
								# Add file to new timestamp database
								$timestamp_old->{$path}{$path.'/'.$newFile->{'file'}} = $attr;
							}
						}
						else 
						{						
							print "Working directory doesn't exist \n";
							print LOGFILE "Working directory doesn't exist \n";
							
							if(UploadFile($ftps, $newFile, $uploadFile)){
								$timestamp_old->{$path}{$path.'/'.$newFile->{'file'}} = $attr;
							}
						}
					}
				}
				else 
				{
					# File is new, upload
					if(UploadFile($ftps, $newFile, $uploadFile)){
						$timestamp_old->{$path}{$path.'/'.$newFile->{'file'}} = $attr;
					}
				}
				# Overide old timestamp file with new one
				open(CFGFILE, ">$configfile") || die "Could not open config file\n";
				print CFGFILE encode_json($timestamp_old);
				close(CFGFILE);
			}			
			#print Dumper($timestamp_old)."\n";	
		}		
		$ftps->quit();
	}
	#print LOGFILE "Folder sync completed: ".localtime()->ymd('-')." ".localtime()->hms(':')."\n********************************************\n";
	
	if(--$loop > 0) {
		select(undef, undef, undef, 10.0);
		SyncData(@folder, $loop);
	}
}

# Upload file and create directories recursively
sub UploadFile()
{
  my $ftps = shift;
	my $newFile = shift;
	my $uploadFile = shift;
	
	# Create directory recursively
	my @dirs = split /\//, $newFile->{'dir'};
	my $dir = '';
	my $sub = '';
	
	my $return_val = 1;
	
	foreach $sub (@dirs) 
	{
		my $newFolder = $dir."/".$sub;
		$dir = $newFolder;
		
		if($ftps->cwd(Encode::encode('UTF-8', $newFolder))){
		}
		else 
		{	
			print "Creating new ftp folder: $dir\n";
			
			if($ftps->mkdir(Encode::encode('UTF-8', $newFolder))){		
				print LOGFILE "Created directory $newFolder successfull \n";
			} else {
				print LOGFILE "Error creating folder : $newFolder\n";
				$return_val = 0;
				last;
			}
		}
	}						

	if(!$return_val) {
		return $return_val;
	}
	
	print "Uploading file:".$uploadFile."\n";			
	print LOGFILE	"Uploading file:".$uploadFile."\n";			
	
	$ftps->cwd("/".Encode::encode('UTF-8', $newFile->{'dir'}));
	
	if(!$ftps->put($uploadFile, Encode::encode('UTF-8', $newFile->{'file'})))
	{
		print "Upload failed:".$ftps->last_message()."\n";
		print LOGFILE "Upload failed:".$ftps->last_message()."\n";
		
		$return_val = 0;
	}
	
	return $return_val;
}

#**********************************
# Start main process
#**********************************
open(LOGFILE, ">>$logfile") || die "Could not open log file\n";
SyncData(@folder, 1);
close(LOGFILE);

