#!/usr/bin/perl

use strict;

# keep both of the following lines commented for normal stat()

# uncomment next line for (wrong) results with UTC-stat()
# use Win32::UTCFileTime qw(:DEFAULT);

# uncomment next line for (wrong) results with stat()
use Win32::UTCFileTime;


my $file = '//xesgrp005/Groups2/G_DSP/Sub projects/MAC-hs L2/L2 SW Problem Solving/DSP L2 Prontos.xls';

#
# perform stat()
#

my @statResult = stat( $file );
if ( !@statResult ) { die "stat() failed"; }

#
# print result in table form
#

my @keys = qw( dev ino mode nlink uid gid rdev size 
	       atime mtime ctime blksize blocks );

printf( "info            stat()\n");
for (my $i=0; $i<@keys; $i++) {
    printf( "%8s: %12d\n",
	    $keys[$i],
	    $statResult[$i],
	  );
}
    
