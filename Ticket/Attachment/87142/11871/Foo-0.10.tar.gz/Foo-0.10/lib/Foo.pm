package Foo;

our $VERSION = '0.10';

1;
