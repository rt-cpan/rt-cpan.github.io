package BugTest::View::TT;

use strict;
use base 'Catalyst::View::TT';

#~ __PACKAGE__->config(TEMPLATE_EXTENSION => '.tt');

=head1 NAME

BugTest::View::TT - TT View for BugTest

=head1 DESCRIPTION

TT View for BugTest. 

=head1 SEE ALSO

L<BugTest>

=head1 AUTHOR

f,,,

=head1 LICENSE

This library is free software, you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

1;
