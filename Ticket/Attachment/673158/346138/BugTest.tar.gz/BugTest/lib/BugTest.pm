package BugTest;

use strict;
use warnings;

use Catalyst::Runtime 5.80;

# Set flags and add plugins for the application
use parent qw/Catalyst/;
use Catalyst qw/-Debug
                Static::Simple
                Unicode::Encoding

                StackTrace
                /;

our $VERSION = '0.01';

# Configure the application.
__PACKAGE__->config( name => 'BugTest',
                     encoding => 'UTF-8',
                     'View::TT' => {
                        WRAPPER            => 'wrapper',
                        TEMPLATE_EXTENSION => '.tt2',
                     },
                   );

# Start the application
__PACKAGE__->setup();


=head1 NAME

BugTest - Catalyst based application

=head1 SYNOPSIS

    script/bugtest_server.pl

=head1 DESCRIPTION

[enter your description here]

=head1 SEE ALSO

L<BugTest::Controller::Root>, L<Catalyst>

=head1 AUTHOR

f,,,

=head1 LICENSE

This library is free software. You can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

1;
