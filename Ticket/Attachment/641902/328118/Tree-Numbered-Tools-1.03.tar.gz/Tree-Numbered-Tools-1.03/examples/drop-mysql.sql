# Run from the command line (assumes that the database 'test' already exists):
# mysql -u root -pmysqlpassword test < drop-mysql.sql
#
DROP TABLE treetest;
