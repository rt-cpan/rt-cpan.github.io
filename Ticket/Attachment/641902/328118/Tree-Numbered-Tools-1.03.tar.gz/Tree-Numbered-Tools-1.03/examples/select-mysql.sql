# Run from the command line (assumes that the database 'test' already exists):
# mysql -u root -pmysqlpassword test < select-mysql.sql
#
SELECT * FROM treetest ORDER BY serial;
