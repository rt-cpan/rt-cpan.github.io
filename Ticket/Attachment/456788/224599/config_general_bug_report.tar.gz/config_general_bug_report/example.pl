#!/usr/bin/perl

use strict;
use warnings;

use Config::General;
use Data::Dumper;

print "VERSION = $Config::General::VERSION\n";

my ($Conf,%conf,$fh);

##
## The o-umlaut character breaks Config::General.
## It thinks it's a separator character.
##

$Conf = new Config::General("example.conf");

%conf = $Conf->getall;

print Dumper \%conf;


##
## This problem is fixable by using the "<:utf8" option to open
##

open($fh, "<:utf8", "example.conf");
$Conf = new Config::General($fh);
close($fh);

%conf = $Conf->getall;

print Dumper \%conf;

##
## This fix unfortunately doesn't extend to Include statements
##

open($fh, "<:utf8", "includes.conf");
$Conf = new Config::General(-ConfigFile => $fh, -UseApacheInclude => 1);
close($fh);

%conf = $Conf->getall;

print Dumper \%conf;
