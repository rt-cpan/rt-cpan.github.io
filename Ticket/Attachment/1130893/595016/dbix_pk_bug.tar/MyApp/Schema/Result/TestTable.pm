package MyApp::Schema::Result::TestTable;
use base qw/DBIx::Class::Core/;

__PACKAGE__->table('TestTable');
__PACKAGE__->add_columns(qw/ id name /);
__PACKAGE__->set_primary_key('id');

1;
