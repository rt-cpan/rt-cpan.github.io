#!/usr/local/bin/perl
use lib '/home/nemo/perl';
use MyApp::Schema;

my %dbi_params = (AutoCommit => 1);
my $schema = MyApp::Schema->connect($dsn, 'user','password',\%dbi_params);

my $TestTable = $schema->resultset('TestTable')->create(
  {
    name => 'jj',
  });

print "and the new id is ", $TestTable->id, "\n";
my $idd = $schema->storage->last_insert_id(undef,undef,undef,undef);
print "The id via DBI is ", $idd, "\n";

$schema->storage->disconnect();
