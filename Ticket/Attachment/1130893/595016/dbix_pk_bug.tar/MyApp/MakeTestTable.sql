if not Exists(select * from sys.objects where name = N'TestTable')
BEGIN

create table TestTable (
  id int IDENTITY(1,1) NOT NULL,
  name varchar(25)
)
END
